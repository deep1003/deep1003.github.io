from pathlib import Path
import csv
import hashlib
import json
import re
import shutil
import struct
import zipfile

from PIL import Image
from pypdf import PdfWriter
from pypdf.generic import DictionaryObject, NameObject, NumberObject, EncodedStreamObject, DecodedStreamObject

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'10_final_publication_20261117'
PUBLIC=ROOT/'09_public_release/genai-exploration-rca'
ASSETS=ROOT/'09_public_release/homepage/assets/research/genai-exploration-rca'
DOWNLOADS=ASSETS/'downloads'
FIGS=OUT/'figures_600dpi'
web=ASSETS/'figures'
records=json.loads((OUT/'figures_manifest.json').read_text())

def pixel_pdf(png,target,dpi=600):
    image=Image.open(png).convert('RGB')
    # Embed the PNG's original filtered RGB samples without recompression or JPEG loss.
    data=Path(png).read_bytes();pos=8;idat=[]
    while pos<len(data):
        length=struct.unpack('>I',data[pos:pos+4])[0]
        kind=data[pos+4:pos+8];payload=data[pos+8:pos+8+length]
        if kind==b'IHDR': assert payload[8:10]==bytes([8,2]), 'RGB 8-bit PNG required'
        if kind==b'IDAT':idat.append(payload)
        pos+=length+12
    w,h=image.size
    writer=PdfWriter();page=writer.add_blank_page(w*72/dpi,h*72/dpi)
    stream=EncodedStreamObject();stream._data=b''.join(idat)
    stream.update({NameObject('/Type'):NameObject('/XObject'),NameObject('/Subtype'):NameObject('/Image'),NameObject('/Width'):NumberObject(w),NameObject('/Height'):NumberObject(h),NameObject('/ColorSpace'):NameObject('/DeviceRGB'),NameObject('/BitsPerComponent'):NumberObject(8),NameObject('/Filter'):NameObject('/FlateDecode'),NameObject('/DecodeParms'):DictionaryObject({NameObject('/Predictor'):NumberObject(15),NameObject('/Colors'):NumberObject(3),NameObject('/BitsPerComponent'):NumberObject(8),NameObject('/Columns'):NumberObject(w)})})
    ref=writer._add_object(stream)
    page[NameObject('/Resources')]=DictionaryObject({NameObject('/XObject'):DictionaryObject({NameObject('/Im1'):ref})})
    content=DecodedStreamObject();content.set_data(f'q {w*72/dpi} 0 0 {h*72/dpi} 0 0 cm /Im1 Do Q'.encode())
    page[NameObject('/Contents')]=writer._add_object(content)
    with Path(target).open('wb') as f:writer.write(f)

formats=[]
for r in records:
    n=r['number'];png=Path(r['png']);image=Image.open(png).convert('RGB')
    before=image.tobytes()
    image.save(png,optimize=True,compress_level=9,dpi=(600,600))
    assert Image.open(png).convert('RGB').tobytes()==before
    jpg=png.with_suffix('.jpg');image.save(jpg,quality=98,subsampling=0,optimize=True,dpi=(600,600))
    pdf=png.with_suffix('.pdf')
    original=ROOT/r['source']
    if n not in (1,9) and original.suffix=='.pdf':shutil.copy2(original,pdf)
    else:pixel_pdf(png,pdf)
    if n==9:
        assert image.size==(3780,4035)
        assert image.tobytes()==Image.open(ROOT/'fast_figures_20261117/Figure_09_600dpi.png').convert('RGB').tobytes()
        assert all(p.stat().st_size<10_000_000 for p in [png,jpg,pdf])
    for p in [png,jpg,pdf]:
        shutil.copy2(p,web/p.name)
        formats.append(dict(figure=n,format=p.suffix[1:],path=str(p),bytes=p.stat().st_size,width_px=image.width,height_px=image.height,dpi=600 if p.suffix!='.pdf' or n in (1,9) else 'vector',sha256=hashlib.sha256(p.read_bytes()).hexdigest()))

manifest=[]
def bundle(name,files):
    path=DOWNLOADS/name
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for src,arc in files:z.write(src,arc)
        z.writestr('README.txt','Working manuscript and associated public materials, 17 November 2026.\nPatent-level provider inputs and personal records are not redistributed.\nThe manuscript retains unresolved scientific checks. No new analyses were run for this packaging.\n')
    assert path.stat().st_size<95_000_000
    manifest.append(dict(file=name,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),contents=len(files)))

bundle('manuscript_word_20261117.zip',[(OUT/'genai_exploration_rca_final_20261117.docx','genai_exploration_rca_final_20261117.docx')])
bundle('manuscript_pdf_20261117.zip',[(ROOT/'07_reports/final_us_english_20261117/overleaf_final_us_verified.pdf','genai_exploration_rca_final_20261117.pdf')])
source=ROOT/'final_us_english_20261117.tex'
latexfiles=[(source,source.name)]
for p in re.findall(r'\\includegraphics\[[^\]]*\]\{([^}]+)\}',source.read_text()):latexfiles.append((ROOT/p,p))
entry=OUT/'main.tex';entry.write_text(r'\input{final_us_english_20261117.tex}'+'\n')
latexfiles.append((entry,'main.tex'))
bundle('manuscript_latex_20261117.zip',latexfiles)
bundle('figures_600dpi_20261117.zip',[(Path(r['path']),Path(r['path']).name) for r in formats])
codefiles=[(p,str(p.relative_to(PUBLIC))) for p in (PUBLIC/'code').rglob('*') if p.is_file() and p.suffix in ['.py','.ipynb','.R','.r','.m','.sh','.md','.txt','.json'] and '__pycache__' not in p.parts]
codefiles += [(ROOT/'06_scripts'/name,'publication/'+name) for name in ['build_word_and_article_site_20261117.py','finalize_word_layout_20261117.py','build_research_page_20261117.py','publish_hf_dataset_20261117.py']]
codefiles.append((Path(__file__),'publication/package_publication_resources_20261117.py'))
bundle('analysis_code_20261117.zip',codefiles)
datafiles=[(p,str(p.relative_to(PUBLIC))) for p in (PUBLIC/'data').rglob('*') if p.is_file() and p.suffix in ['.csv','.json','.md','.txt']]
bundle('aggregate_data_20261117.zip',datafiles)
public_formats=[dict(r,path='figures/'+Path(r['path']).name) for r in formats]
(DOWNLOADS/'download_manifest_20261117.json').write_text(json.dumps(dict(release='20261117-final-us-english',downloads=manifest,figures=public_formats,restricted_patent_level_data_included=False),indent=2))
(OUT/'figure_formats_verification.json').write_text(json.dumps(formats,indent=2))
print(json.dumps(dict(figure9=[r for r in formats if r['figure']==9],downloads=manifest),indent=2))
