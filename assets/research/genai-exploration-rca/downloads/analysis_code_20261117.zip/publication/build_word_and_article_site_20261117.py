from pathlib import Path
import csv
import hashlib
import html
import json
import re
import shutil
import subprocess
import zipfile
from copy import deepcopy

import pypdfium2 as pdfium
from PIL import Image
from docx import Document
from docx.shared import Inches, Pt, Mm
from docx.shared import RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'10_final_publication_20261117'
OUT.mkdir(exist_ok=True)
SITE=ROOT/'09_public_release/homepage'
PUBLIC=ROOT/'09_public_release/genai-exploration-rca'
SOURCE=ROOT/'final_us_english_20261117.tex'
FINAL=ROOT/'07_reports/final_us_english_20261117'
ASSETS=SITE/'assets/research/genai-exploration-rca'
ASSETS.mkdir(parents=True,exist_ok=True)
FIGS=OUT/'figures_600dpi'; FIGS.mkdir(exist_ok=True)
DOWNLOADS=ASSETS/'downloads'; DOWNLOADS.mkdir(exist_ok=True)
WEBFIGS=ASSETS/'figures'; WEBFIGS.mkdir(exist_ok=True)
PANDOC='/opt/homebrew/bin/pandoc'
source=SOURCE.read_text()

def run(args,**kw):
    return subprocess.run([str(a) for a in args],check=True,capture_output=True,text=True,**kw)

def balanced(text,start):
    assert text[start]=='{'
    level=1; pos=start+1
    while level:
        if text[pos]=='\\': pos+=2;continue
        if text[pos]=='{': level+=1
        elif text[pos]=='}': level-=1
        pos+=1
    return text[start+1:pos-1],pos

def command(text,name,start=0):
    pos=text.index('\\'+name+'{',start)+len(name)+1
    return balanced(text,pos)

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

# Re-download verification distinguishes the saved source from the browser preview.
shutil.copy2('/Users/deep1003/Downloads/조원선_박사님_01 (18).zip',FINAL/'overleaf_after_final_us.zip')
shutil.copy2('/Users/deep1003/Downloads/조원선_박사님_01 (13).pdf',FINAL/'overleaf_final_us_verified.pdf')
before=zipfile.ZipFile(FINAL/'overleaf_before_final_us.zip')
after=zipfile.ZipFile(FINAL/'overleaf_after_final_us.zip')
assert after.read('main.tex').decode().strip()==r'\input{final_us_english_20261117.tex}'
assert after.read(SOURCE.name)==SOURCE.read_bytes()
assert after.read('research_policy_proofread_20261117.tex')==(ROOT/'research_policy_proofread_20261117.tex').read_bytes()
unchanged=[p for p in before.namelist() if p!='main.tex' and not p.endswith('/')]
assert all(before.read(p)==after.read(p) for p in unchanged)
(FINAL/'overleaf_verification.json').write_text(json.dumps(dict(old_files_preserved=len(unchanged),new_files=sorted(set(after.namelist())-set(before.namelist())),online_errors=0,online_warnings=0,source_byte_verified=True,previous_proofread_byte_verified=True,pdf=str(FINAL/'overleaf_final_us_verified.pdf')),indent=2))

title,_=command(source,'title')
title=' '.join(title.split())
abstract=re.search(r'\\begin\{abstract\}(.*?)\\end\{abstract\}',source,re.S).group(1).strip()
body,bib=source.split(r'\begin{thebibliography}{99}',1)
body=body.split(r'\end{frontmatter}',1)[1]
bib=bib.split(r'\end{thebibliography}',1)[0]
entries={}
for match in re.finditer(r'\\bibitem\[([^\n]+)\]\{(ref\d+)\}\s*(.*?)(?=\n\\bibitem|\Z)',bib,re.S):
    label,key,content=match.groups()
    auth,year=label.rsplit('(',1)
    entries[key]=dict(author=auth,year=year.rstrip(')'),tex=content.strip())
assert len(entries)==63

def cite(match):
    kind,opts,keytext=match.groups()
    keys=keytext.split(',')
    groups=[]
    for key in keys:
        e=entries[key.strip()]
        if groups and groups[-1][0]==e['author']: groups[-1][1].append(e['year'])
        else: groups.append((e['author'],[e['year']]))
    if kind=='t': result='; '.join(a+' ('+', '.join(ys)+')' for a,ys in groups)
    else: result='('+'; '.join(a+', '+', '.join(ys) for a,ys in groups)+')'
    options=re.findall(r'\[([^\]]*)\]',opts or '')
    if options and options[0]: result=result.replace('(','('+options[0]+' ',1)
    return result
body=re.sub(r'\\cite([tp])((?:\[[^\]]*\])*)\{([^}]+)\}',cite,body)

fig_records=[]
def figure(match):
    fragment=match.group(0)
    num=len(fig_records)+1
    path=re.search(r'\\includegraphics\[[^\]]*\]\{([^}]+)\}',fragment).group(1)
    caption,_=command(fragment,'caption')
    note,_=command(fragment,'figurenotes')
    src=ROOT/path
    png=FIGS/f'Figure_{num:02d}_600dpi.png'
    if src.suffix=='.pdf':
        pdf=pdfium.PdfDocument(str(src)); page=pdf[0]
        image=page.render(scale=3780/page.get_width()).to_pil().convert('RGB')
        image.save(png,dpi=(600,600)); pdf.close()
    else:
        image=Image.open(src).convert('RGB'); image.save(png,dpi=(600,600))
    preview=image.copy(); preview.thumbnail((2000,2400))
    preview.save(WEBFIGS/f'figure-{num:02d}.webp',quality=95,method=6)
    # Preserve full-resolution images for download and zoom.
    shutil.copy2(png,WEBFIGS/png.name)
    fig_records.append(dict(number=num,source=path,png=str(png),caption=caption,notes=note,width=image.width,height=image.height,sha256=digest(png)))
    return '\n\n'+r'\includegraphics[width=6.3in]{'+str(png)+'}\n\n'+r'\textbf{Figure '+str(num)+':} '+caption+'\n\n'+r'\emph{Notes:} '+note+'\n\n'
body=re.sub(r'\\begin\{figure\}(?:\[[^\]]*\])?.*?\\end\{figure\}',figure,body,flags=re.S)
assert len(fig_records)==9

table_records=[]
def table(match):
    fragment=match.group(0)
    n=len(table_records)+1
    caption,capend=command(fragment,'caption')
    env=re.search(r'\\begin\{(longtable|tabular)\}',fragment)
    start=env.end()
    if fragment[start:start+2]=='[]': start+=2
    assert fragment[start]=='{'
    _,specend=balanced(fragment,start)
    inner=fragment[specend:fragment.index(r'\end{'+env.group(1)+'}',specend)]
    if env.group(1)=='longtable':
        firsthead=inner[:inner.index(r'\endfirsthead')]
        header=firsthead[firsthead.index(r'\toprule'):]
        rows=inner[inner.index(r'\endlastfoot')+len(r'\endlastfoot'):]
        inner=header+'\n'+rows
    inner=re.sub(r'\\(?:toprule|midrule|bottomrule)(?:\\noalign\{\})?','',inner)
    note=''
    if env.group(1)=='tabular':
        tail=fragment[fragment.index(r'\end{tabular}')+len(r'\end{tabular}'):]
        p=tail.index(r'\emph{Notes:}')+len(r'\emph{Notes:}')
        note=tail[p:tail.index(r'\end{table}')].strip()
    table_records.append(dict(number=n,caption=caption,rows_tex=inner,notes=note))
    result='\n\n'+r'\textbf{Table '+str(n)+':} '+caption+'\n\n'+r'\begin{longtable}{llll}'+'\n'+inner+'\n'+r'\end{longtable}'+'\n\n'
    if note: result+=r'\emph{Notes:} '+note+'\n\n'
    return result
body=re.sub(r'\\begin\{table\}(?:\[[^\]]*\])?.*?\\end\{table\}|\\begin\{longtable\}.*?\\end\{longtable\}',table,body,flags=re.S)
assert len(table_records)==4

# Nonprinting layout commands are not manuscript content.
body=re.sub(r'\\(?:setcounter|setlength)\{[^}]+\}\{[^}]*\}','',body)
body=re.sub(r'\\Needspace\{[^}]*\}','',body)
body=re.sub(r'\\(?:clearpage|noindent|centering|raggedright|footnotesize|small)\b','',body)
body=re.sub(r'\\vspace\{[^}]*\}','',body)
body=body.replace(r'\begin{minipage}{\linewidth}','').replace(r'\end{minipage}','')
body=body.replace(r'\symbfit',r'\boldsymbol')
body=re.sub(r'\\label\{[^}]+\}','',body)
body=body.replace(r'\par','\n\n')
prelude=r'\documentclass{article}\usepackage{amsmath,graphicx,longtable,booktabs,hyperref}'
keyword='Generative artificial intelligence; Technological distance; Comparative advantage; Patent embedding; Dominant design; Weaponized interdependence'
text=prelude+'\n'+r'\begin{document}'+'\n'+r'\section*{Abstract}'+'\n'+abstract+'\n\n'+r'\textit{Keywords:} '+keyword+'\n\n'+r'\textit{JEL:} O33; O38; F51; L86\n\n'+body+'\n\n'+r'\section*{References}'+'\n'
for key,e in entries.items(): text+='\n\n'+r'\hypertarget{bib-'+key+r'}{}'+e['tex']+'\n'
text+='\n'+r'\end{document}'
text=text.replace(r'\textendash{}','–').replace(r'\textendash','–')
text=text.replace(r'\textemdash{}','—').replace(r'\textemdash','—')
text=re.sub(r'\$\^\{(\*+)\}([^$]*)\$',lambda m:r'\textsuperscript{'+m[1]+'}'+(r'\('+m[2]+r'\)' if m[2] else ''),text)
(OUT/'conversion_source.tex').write_text(text)
ast=json.loads(run([PANDOC,OUT/'conversion_source.tex','-f','latex','-t','json']).stdout)
assert len([b for b in ast['blocks'] if b['t']=='Table'])==4

def walk(value,fn):
    if isinstance(value,list): return [walk(x,fn) for x in value]
    if isinstance(value,dict):
        value={k:walk(v,fn) for k,v in value.items()}
        return fn(value)
    return value

def normalize(node):
    # Preserve caption and Notes paragraphs as ordinary editable text.
    if node.get('t')=='Header':
        content=node['c']
        txt=' '.join(x.get('c','') for x in content[2] if x['t']=='Str')
        if txt in ['Abstract','References']: content[1][1].append('unnumbered')
    if node.get('t')=='Math' and node['c'][0]['t']=='DisplayMath':
        node['c'][1]=node['c'][1].replace(r'\begin{equation}','').replace(r'\end{equation}','').strip()
        if r'\begin{aligned}' in node['c'][1]:
            node['c'][1]=node['c'][1].replace(r'\begin{aligned}',r'\begin{gathered}').replace(r'\end{aligned}',r'\end{gathered}').replace('&','')
    return node
ast=walk(ast,normalize)
split_blocks=[]
equation_no=0
for block in ast['blocks']:
    if block['t']=='Para' and any(x.get('t')=='Math' and x['c'][0]['t']=='DisplayMath' for x in block['c']):
        pending=[]
        for inline in block['c']:
            if inline.get('t')=='Math' and inline['c'][0]['t']=='DisplayMath':
                if pending:split_blocks.append({'t':'Para','c':pending});pending=[]
                equation_no+=1
                split_blocks.append({'t':'Div','c':[[f'equation-{equation_no}',['equation-block'],[]],[{'t':'Para','c':[inline]},{'t':'Para','c':[{'t':'Str','c':f'({equation_no})'}]}]]})
            else:pending.append(inline)
        if pending:split_blocks.append({'t':'Para','c':pending})
    else:split_blocks.append(block)
ast['blocks']=split_blocks
assert equation_no==3
ast['meta']['title']={'t':'MetaString','c':title}
(OUT/'manuscript_ast.json').write_text(json.dumps(ast,ensure_ascii=False))

# Use a reference DOCX rather than relying on viewer-specific default styling.
ref=Document()
sec=ref.sections[0]; sec.page_width=Mm(210);sec.page_height=Mm(297)
sec.top_margin=sec.bottom_margin=sec.left_margin=sec.right_margin=Mm(25)
for name in ['Normal','Body Text','Title','Subtitle','Heading 1','Heading 2','Heading 3','Caption']:
    st=ref.styles[name];st.font.name='Times New Roman';st.font.size=Pt(12)
    st.font.color.rgb=RGBColor(0,0,0)
    fonts=st.element.get_or_add_rPr().rFonts
    if fonts is not None:
        for attribute in list(fonts.attrib):
            if 'Theme' in attribute or 'theme' in attribute:del fonts.attrib[attribute]
    st.paragraph_format.line_spacing=1.0
    st.paragraph_format.space_after=Pt(6)
    st.paragraph_format.widow_control=True
ref.styles['Title'].font.size=Pt(15);ref.styles['Title'].paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
for name in ['Heading 1','Heading 2','Heading 3']:
    ref.styles[name].font.bold=True;ref.styles[name].paragraph_format.keep_with_next=True
    ref.styles[name].paragraph_format.space_before=Pt(12)
ref.styles['Caption'].font.size=Pt(10)
ref.styles['Caption'].font.bold=False
ref.save(OUT/'reference_styles.docx')
docx=OUT/'genai_exploration_rca_final_20261117.docx'
run([PANDOC,OUT/'manuscript_ast.json','-f','json','-t','docx','--number-sections','--reference-doc',OUT/'reference_styles.docx','-o',docx])
doc=Document(docx)
sect=doc.sections[0];sect.page_width=Mm(210);sect.page_height=Mm(297)
sect.top_margin=sect.bottom_margin=sect.left_margin=sect.right_margin=Mm(25)
eqnum=0
for p in list(doc.paragraphs):
    mathparas=p._p.xpath('.//m:oMathPara')
    if mathparas:
        eqnum+=1
        following=p._p.getnext()
        if following is not None and ''.join(following.xpath('.//w:t/text()')).strip()==f'({eqnum})':following.getparent().remove(following)
        layout=doc.add_table(rows=1,cols=2)
        layout.style='Normal Table';layout.autofit=False
        for cell,width in zip(layout.rows[0].cells,[5.95,.35]):cell.width=Inches(width)
        left,right=layout.rows[0].cells
        left._tc.remove(left.paragraphs[0]._p)
        left._tc.append(deepcopy(p._p))
        right.text=f'({eqnum})';right.paragraphs[0].alignment=WD_ALIGN_PARAGRAPH.RIGHT
        right.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
        p._p.addprevious(layout._tbl)
        p._p.getparent().remove(p._p)
        p.paragraph_format.keep_together=True
        p.paragraph_format.space_before=Pt(8);p.paragraph_format.space_after=Pt(8)
assert eqnum==3

def paragraph_text(p): return ''.join(p.itertext())
for p in doc.paragraphs:
    p.paragraph_format.widow_control=True
    if re.match(r'^(?:Figure|Table) \d+:',p.text):
        p.style=doc.styles['Caption'];p.paragraph_format.keep_with_next=True
    if p.text.startswith('Notes:'):
        p.paragraph_format.keep_together=True;p.paragraph_format.space_after=Pt(8)
        for r in p.runs:r.font.size=Pt(10)
    if p._p.xpath('.//w:drawing'):
        p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.keep_with_next=True
    if p._p.xpath('.//m:oMathPara'):
        p.paragraph_format.keep_together=True
for inline in doc.inline_shapes:
    ratio=min(Inches(6.3)/inline.width,Inches(7.4)/inline.height,1)
    inline.width=int(inline.width*ratio);inline.height=int(inline.height*ratio)
tnum=0
for tbl in doc.tables:
    if len(tbl.columns)==2 and len(tbl.rows)==1:
        w=tbl._tbl.tblPr.find(qn('w:tblW'));w.set(qn('w:type'),'dxa');w.set(qn('w:w'),'9072')
        for col,width in zip(tbl.columns,[5.95,.35]):col.width=Inches(width)
        continue
    tnum+=1
    tbl.style='Normal Table'
    tbl.autofit=False
    width=tbl._tbl.tblPr.find(qn('w:tblW'));width.set(qn('w:type'),'dxa');width.set(qn('w:w'),'9072')
    borders=OxmlElement('w:tblBorders')
    for edge in ['top','bottom']:
        border=OxmlElement('w:'+edge);border.set(qn('w:val'),'single');border.set(qn('w:sz'),'8');border.set(qn('w:color'),'000000');borders.append(border)
    tbl._tbl.tblPr.append(borders)
    widths=[2.0,1.5,1.4,1.4] if tnum==1 else ([2.35,1.32,1.32,1.31] if tnum==2 else [2.5,1.25,1.25,1.3])
    for rownum,row in enumerate(tbl.rows):
        cant=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(cant)
        if rownum==0:
            repeat=OxmlElement('w:tblHeader');row._tr.get_or_add_trPr().append(repeat)
        for col,cell in enumerate(row.cells):
            cell.width=Inches(widths[col])
            for p in cell.paragraphs:
                p.style=doc.styles['Normal']
                p.paragraph_format.space_after=Pt(3);p.paragraph_format.line_spacing=1.0
                for r in p.runs:r.font.name='Times New Roman';r.font.size=Pt(9.5)
    for col,width in zip(tbl.columns,widths):col.width=Inches(width)
    # A compact table is kept together; the regression table may span with repeat headers.
    if tnum!=2:
        for row in tbl.rows:
            for cell in row.cells:
                for p in cell.paragraphs:p.paragraph_format.keep_with_next=True
doc.core_properties.title=title
doc.core_properties.subject='Final American-English manuscript'
doc.settings.element.append(OxmlElement('w:doNotAutoCompressPictures'))
footer=doc.sections[0].footer.paragraphs[0]
footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
doc.save(docx)

# A second AST changes only image URLs and display attributes for the web.
webast=deepcopy(ast)
def webnode(node):
    if node.get('t')=='Image':
        path=node['c'][2][0]
        rec=next(r for r in fig_records if r['png']==path)
        node['c'][0][2]=[['width',str(rec['width'])],['height',str(rec['height'])],['loading','lazy']]
        node['c'][1]=[{'t':'Str','c':f"Figure {rec['number']}. "+rec['caption']}]
        node['c'][2][0]=f"../assets/research/genai-exploration-rca/figures/figure-{rec['number']:02d}.webp"
    return node
webast=walk(webast,webnode)
(OUT/'web_ast.json').write_text(json.dumps(webast,ensure_ascii=False))
fragment=run([PANDOC,OUT/'web_ast.json','-f','json','-t','html5','--mathml','--number-sections']).stdout
(OUT/'article_fragment.html').write_text(fragment)

# Native tables and MathML preserve the manuscript's content and order on the site.
head='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'''+html.escape(title)+''' | Youngsam Chun</title><meta name="description" content="Full manuscript, figures, tables, equations, and downloadable research materials."><link rel="stylesheet" href="../assets/style.css?v=4"><style>
.project{max-width:1000px;margin:30px auto;padding:0 24px 60px;color:#222}.project h1{font-size:30px;line-height:1.25;letter-spacing:0;overflow-wrap:break-word}.project h2{font-size:23px;line-height:1.3;margin-top:38px;letter-spacing:0}.project h3{font-size:19px;letter-spacing:0;margin-top:26px}.project p{line-height:1.7}.byline{color:#555}.downloads{border-top:1px solid #bbb;border-bottom:1px solid #bbb;padding:15px 0;margin:20px 0;display:flex;gap:12px 20px;flex-wrap:wrap}.downloads a{display:inline-block}.article img{display:block;width:100%;max-width:900px;height:auto;margin:28px auto 12px}.article figure{margin:25px 0}.article table{border-collapse:collapse;width:100%;font-size:14px;line-height:1.45;margin:14px 0}.article th,.article td{border-bottom:1px solid #ccc;padding:7px 8px;text-align:left;vertical-align:top}.article thead{border-top:2px solid #555;border-bottom:1px solid #555}.table-scroll{overflow-x:auto}.article .math.display{display:block;overflow-x:auto;margin:20px 0;text-align:center}.article math{font-family:"Cambria Math",serif}.article p:has(>em:first-child){line-height:1.55}.article a{overflow-wrap:anywhere}.article .header-section-number{margin-right:.3em}.article h1{font-size:25px}.article{font-family:Georgia,"Times New Roman",serif;font-size:17px}.project .release-note{font-size:14px;color:#555}.project .top-links{font-size:14px}a:focus-visible{outline:2px solid #16717b;outline-offset:4px}@media(max-width:600px){.project{padding:0 16px 40px}.project>h1{font-size:25px}.article{font-size:16px}.article table{font-size:12px;min-width:650px}.downloads{gap:12px 16px}.article img{max-width:100%}}
</style></head><body><nav class="topbar"><div class="topbar-inner"><span class="brand">Youngsam Chun</span><a class="nav" href="../index.html">About</a><a class="nav active" href="../research.html">Research</a><a class="nav" href="../publications.html">Publications</a></div></nav><main class="project"><p class="top-links"><a href="../research.html#genai-research">Research</a> / Generative AI innovation</p><h1>'''+html.escape(title)+'''</h1><p class="byline">One-Sun Cho and Youngsam Chun · Working manuscript · Updated 17 November 2026</p>
<nav class="downloads" aria-label="Download manuscript and research files"><a href="../assets/research/genai-exploration-rca/downloads/manuscript_word_20261117.zip" download>Word ZIP</a><a href="../assets/research/genai-exploration-rca/downloads/manuscript_pdf_20261117.zip" download>PDF ZIP</a><a href="../assets/research/genai-exploration-rca/downloads/manuscript_latex_20261117.zip" download>LaTeX ZIP</a><a href="../assets/research/genai-exploration-rca/downloads/figures_600dpi_20261117.zip" download>Figures ZIP</a><a href="../assets/research/genai-exploration-rca/downloads/analysis_code_20261117.zip" download>Code ZIP</a><a href="../assets/research/genai-exploration-rca/downloads/aggregate_data_20261117.zip" download>Aggregate data ZIP</a></nav><p class="release-note">Patent-level provider data and personal records are not redistributed. The manuscript retains its stated methodological limitations. <a href="https://github.com/deep1003/genai-exploration-rca">Research repository</a> · <a href="../assets/research/genai-exploration-rca/downloads/download_manifest_20261117.json">File manifest</a></p><article class="article">'''
fragment=re.sub(r'(<table\b.*?</table>)',r'<div class="table-scroll">\1</div>',fragment,flags=re.S)
# Click through to the preserved 600 dpi figure rather than a lossy enlarged preview.
for rec in fig_records:
    url=f"../assets/research/genai-exploration-rca/figures/figure-{rec['number']:02d}.webp"
    full=f"../assets/research/genai-exploration-rca/figures/{Path(rec['png']).name}"
    fragment=re.sub(r'(<img\b[^>]*src="'+re.escape(url)+r'"[^>]*>)',r'<a href="'+full+r'">\1</a>',fragment)
head=head.replace('</style>','.equation-block{position:relative;margin:20px 0;padding-right:2em}.equation-block>p:last-child{position:absolute;right:0;top:0}.equation-block .math.display{margin:0}</style>')
page=head+fragment+'</article></main></body></html>'
sitefile=SITE/'research/genai-exploration-rca.html'
backup=OUT/'previous_homepage_preserved.html'
if not backup.exists():shutil.copy2(sitefile,backup)
sitefile.write_text(page)
(OUT/'figures_manifest.json').write_text(json.dumps(fig_records,indent=2))
(OUT/'tables_manifest.json').write_text(json.dumps(table_records,indent=2))
(OUT/'conversion_manifest.json').write_text(json.dumps(dict(source=str(SOURCE),source_sha256=digest(SOURCE),docx=str(docx),docx_sha256=digest(docx),site=str(sitefile),figures=9,tables=4,bibliography_entries=63,native_math=True,restricted_raw_data_included=False),indent=2))
print(json.dumps(dict(docx=str(docx),website=str(sitefile),figures=len(fig_records),tables=len(table_records)),indent=2))
