from pathlib import Path
import re
from docx import Document
from docx.shared import Pt
from docx.oxml import OxmlElement

ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'10_final_publication_20261117/genai_exploration_rca_final_20261117.docx'
doc=Document(path)
paras=doc.paragraphs
for i,p in enumerate(paras):
    if p.text.startswith(('Figure ','Table ')) and not re.match(r'^(?:Figure|Table) \d+:',p.text):
        p.style=doc.styles['Body Text']
        p.paragraph_format.keep_with_next=False
        for r in p.runs:r.font.size=Pt(12)
    if p.text.startswith('Figure 7:'):
        preceding=paras[i-1]
        assert preceding._p.xpath('.//w:drawing')
        preceding.paragraph_format.page_break_before=True
        p.paragraph_format.keep_with_next=True
    if p.text.startswith('Table 2:'):
        p.paragraph_format.page_break_before=True
for table in doc.tables:
    if len(table.columns)==4 and len(table.rows)==27:
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:p.paragraph_format.keep_with_next=True
if not doc.settings.element.xpath('./w:doNotAutoCompressPictures'):
    doc.settings.element.append(OxmlElement('w:doNotAutoCompressPictures'))
doc.save(path)
print(path)
