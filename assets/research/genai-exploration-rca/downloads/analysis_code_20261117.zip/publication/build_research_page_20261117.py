from pathlib import Path
import csv
import html
import json
import re
import subprocess
from copy import deepcopy
from lxml import html as lh
from lxml import etree
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'10_final_publication_20261117'
SITE=ROOT/'09_public_release/homepage'
page=SITE/'research/genai-exploration-rca.html'
parsed=lh.fragment_fromstring((OUT/'article_fragment.html').read_text(),create_parent='div')
tables=parsed.xpath('.//table')
assert len(tables)==4
reg=deepcopy(tables[1])
def promote_header(table):
    if not table.xpath('.//thead'):
        first=table.xpath('.//tbody/tr')[0]
        first.getparent().remove(first)
        thead=etree.Element('thead');thead.append(first);table.insert(0,thead)
        for cell in first:cell.tag='th'
    for cell in table.xpath('.//th|.//td'):cell.attrib.pop('style',None)
promote_header(reg)
for element in reg.xpath('.//th|.//td'):
    if element.text_content().strip()=='Pooled replay':element.text='Pooled OLS'
regional=deepcopy(tables[2])
promote_header(regional)
header=regional.xpath('.//thead/tr')[0]
th=etree.SubElement(header,'th');th.text='Applications'
counts=list(csv.DictReader((ROOT/'research_policy_reconciled_20261116/audit/table3_restored_from_counts.csv').open()))
for row,rec in zip(regional.xpath('.//tbody/tr'),counts):
    first=row[0]
    for child in list(first):first.remove(child)
    first.text='Cluster '+rec['cluster']
    cell=etree.SubElement(row,'td');cell.text=f"{int(rec['denominator']):,}"
table2=lh.tostring(reg,encoding='unicode')
table3=lh.tostring(regional,encoding='unicode')
source=(ROOT/'final_us_english_20261117.tex').read_text()
bib=source.split(r'\begin{thebibliography}{99}',1)[1].split(r'\end{thebibliography}',1)[0]
entries={m[2]:m[3].strip() for m in re.finditer(r'\\bibitem\[([^\n]+)\]\{(ref\d+)\}\s*(.*?)(?=\n\\bibitem|\Z)',bib,re.S)}
refs=[]
for key in ['ref04','ref05','ref66','ref16','ref31','ref35','ref41']:
    tex=entries[key].replace(r'\textendash{}','–')
    rendered=subprocess.run(['/opt/homebrew/bin/pandoc','-f','latex','-t','html5'],input=tex,text=True,capture_output=True,check=True).stdout.strip()
    refs.append(f'<li id="{key}">{rendered}</li>')
reference_html='\n'.join(refs)
base='../assets/research/genai-exploration-rca'
def fig(n,title,note):
    width,height=Image.open(SITE/f'assets/research/genai-exploration-rca/figures/figure-{n:02d}.webp').size
    return f'''<figure id="figure-{n}"><a href="{base}/figures/Figure_{n:02d}_600dpi.png"><img src="{base}/figures/figure-{n:02d}.webp" width="{width}" height="{height}" loading="lazy" alt="{html.escape(title)}"></a><figcaption><strong>Figure {n}. {html.escape(title)}</strong><p><em>Notes.</em> {note}</p></figcaption></figure>'''
downloads=''.join(f'<a href="{base}/downloads/{name}_20261117.zip" download>{label}</a>' for name,label in [('manuscript_word','Word'),('manuscript_pdf','PDF'),('manuscript_latex','LaTeX'),('figures_600dpi','Figures: PDF · PNG · JPG'),('analysis_code','Code'),('aggregate_data','Aggregate data')])
content=f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Generative AI innovation | Youngsam Chun</title><meta name="description" content="Technological exploration and national specialization in generative AI: key findings, three figures, two tables, and research data."><link rel="stylesheet" href="../assets/style.css?v=4">
<style>
.paper{{max-width:1040px;margin:30px auto;padding:0 24px 64px;color:#222}}.paper h1{{font-size:30px;line-height:1.25;letter-spacing:0;overflow-wrap:break-word;max-width:1000px}}.paper h2{{font-size:23px;line-height:1.3;letter-spacing:0;margin:36px 0 14px}}.paper h3{{font-size:19px;letter-spacing:0;margin-top:25px}}.paper p,.paper li{{line-height:1.7}}.paper .byline{{color:#555}}.downloads{{display:flex;flex-wrap:wrap;gap:12px 22px;margin:22px 0 12px;padding:16px 0;border-top:1px solid #bbb;border-bottom:1px solid #bbb}}.resource-links{{font-size:14px;color:#555}}.resource-links a{{white-space:normal}}.highlights{{padding-left:22px;max-width:930px}}.highlights li{{margin:7px 0}}.paper figure{{margin:30px 0}}.paper figure img{{display:block;width:100%;height:auto;max-width:920px;margin:auto}}.paper figcaption{{font-size:15px;line-height:1.6;margin-top:12px}}.paper figcaption p{{margin:7px 0 0}}.table-scroll{{overflow-x:auto;margin:15px 0}}.paper table{{width:100%;border-collapse:collapse;font-size:14px;line-height:1.45}}.paper th,.paper td{{padding:7px 10px;border-bottom:1px solid #ddd;text-align:right;vertical-align:top}}.paper th:first-child,.paper td:first-child{{text-align:left}}.paper thead{{border-top:2px solid #555;border-bottom:1px solid #555}}.table-title{{margin-bottom:8px}}.table-note{{font-size:14px;line-height:1.6}}.references{{padding-left:22px;font-size:15px}}.references li{{margin:12px 0;overflow-wrap:anywhere}}.references p{{margin:0}}.paper a{{overflow-wrap:anywhere}}.paper math{{font-family:"Cambria Math",serif}}a:focus-visible{{outline:2px solid #16717b;outline-offset:4px}}@media(max-width:600px){{.paper{{padding:0 16px 45px;margin-top:24px}}.paper h1{{font-size:25px}}.paper h2{{font-size:21px}}.paper table{{font-size:12px;min-width:630px}}.downloads{{gap:12px 18px}}.paper figcaption{{font-size:14px}}}}
</style></head><body>
<nav class="topbar"><div class="topbar-inner"><span class="brand">Youngsam Chun</span><a class="nav" href="../index.html">About</a><a class="nav active" href="../research.html">Research</a><a class="nav" href="../publications.html">Publications</a></div></nav>
<main class="paper"><p><a href="../research.html#genai-research">Research</a> / Generative AI innovation</p>
<h1>Technological exploration distance, revealed comparative advantage, and the US-China dual-core reconfiguration of generative AI innovation</h1>
<p class="byline">One-Sun Cho and Youngsam Chun</p>
<nav class="downloads" aria-label="Download research files by type">{downloads}</nav>
<p class="resource-links"><a href="https://huggingface.co/datasets/deep1003/genai-exploration-rca">Hugging Face dataset</a> · <a href="https://github.com/deep1003/genai-exploration-rca">Research code</a> · Figure 9 at 600 dpi: <a href="{base}/figures/Figure_09_600dpi.pdf" download>PDF</a> · <a href="{base}/figures/Figure_09_600dpi.png" download>PNG</a> · <a href="{base}/figures/Figure_09_600dpi.jpg" download>JPG</a></p>
<section aria-labelledby="highlights"><h2 id="highlights">Highlights</h2><ul class="highlights">
<li>Semantic convergence does not imply uniform national patent portfolios.</li>
<li>US and Chinese portfolios differ in patent volume and inventor team size.</li>
<li>The distance-specialization association depends on the observation unit.</li>
<li>Patent concentration alone does not establish control over AI inputs.</li>
</ul></section>
<section><h2>Introduction</h2>
<p>Patent counts measure the scale of invention, not technological position. Drawing on research on exploration and catch-up (<a href="#ref41">March, 1991</a>; <a href="#ref31">Katila and Ahuja, 2002</a>; <a href="#ref35">Lee and Malerba, 2017</a>), this study compares national patent portfolios, semantic distance, and technological specialization in generative artificial intelligence (GenAI).</p></section>
<section><h2>Data and methods</h2>
<p>The corpus contains 267,519 AI patent records from 2000–2024, including 97,911 GenAI records. PatentSBERTa measures proximity to technological cluster centroids (<a href="#ref05">Bekamiri et al., 2024</a>). Country-CPC-year revealed comparative advantage (RCA) measures relative specialization (<a href="#ref04">Balassa, 1965</a>; <a href="#ref66">Chun et al., 2024</a>). The regression outcome is RCA above one in the following year, including both new and continuing specialization.</p></section>
<section><h2>Results</h2><h3>National patenting differs in scale and organization</h3>
<p>China overtakes the United States in annual GenAI filings in 2017. Filing volume indicates scale, not technological quality; publication lags affect recent counts.</p>
{fig(2,'Annual GenAI patent applications, 2000–2023.','The series show the global country mean, the United States, and China. Shading marks 2017. Recent filing counts are affected by publication lags.')}
<p>Chinese GenAI patents generally have larger inventor teams than US patents. Team size and family-publication counts vary over time and describe different organizational features of the portfolios.</p>
{fig(3,'Inventor team size and patent-family publications per GenAI application.','(a) Mean number of inventors. (b) Mean patent-family publication count. The shared legend applies to both panels. Shading is the 95 percent confidence band for the global series.')}
<h3>Semantic distance declines without a uniform national trajectory</h3>
<p>Mean patent-to-centroid distance declines, particularly after 2017, along different US and Chinese paths. This is semantic convergence, not evidence that the Transformer caused it.</p>
{fig(4,'Mean technological exploration distance of GenAI patents by year.','Distance is measured from each patent embedding to its assigned cluster centroid. The observation-weighted global mean has a 95 percent confidence band; US and Chinese series are shown separately.')}
<h3>Distance and subsequent specialization depend on the unit of analysis</h3>
<p>The distance-RCA association changes across observation units and specifications. The estimates do not establish a robust optimal exploration distance.</p>
<p class="table-title"><strong>Table 2. Exploration distance and subsequent comparative advantage.</strong></p><div class="table-scroll">{table2}</div>
<p class="table-note"><em>Notes.</em> Outcome: RCA &gt; 1 at <em>t</em> + 1. Parentheses contain country-clustered standard errors. FE models absorb additive year, country, and CPC effects. Cell means of distance and squared distance are standardized separately; the latter is not the square of the former. Samples and weights differ. *** <em>p</em> &lt; .01; ** <em>p</em> &lt; .05; * <em>p</em> &lt; .10.</p>
<h3>National application profiles vary across clusters</h3>
<p>Regional application shares differ across clusters. The sample sizes below distinguish large portfolios from small groups.</p>
<p class="table-title"><strong>Table 3. Regional application shares with RCA above one, 2000–2024.</strong></p><div class="table-scroll">{table3}</div>
<p class="table-note"><em>Notes.</em> Shares use the combined US, Chinese, Korean, and EU application count. LLM records are used where available, otherwise GenAI records. Cluster identifiers do not establish technological categories or ownership. Clusters 2 and 5 are small. Percentages may not sum to 100 because of rounding.</p></section>
<section><h2>Discussion and implications</h2>
<p>Semantic convergence can coexist with different national portfolios. Innovation policy should therefore assess portfolio composition and collaboration alongside patent counts, rather than infer a preferred search strategy from one indicator.</p>
<p>The Data-Human-Computing-Politics framework connects these differences to potential dependence on data, talent, and computing. Strategic leverage requires control of access and costly substitutes (<a href="#ref16">Farrell and Newman, 2019</a>). Those conditions need direct evidence: patent concentration alone does not establish them.</p></section>
<section><h2>Data availability</h2><p>Aggregate tables, model outputs, and figure-series data are available on <a href="https://huggingface.co/datasets/deep1003/genai-exploration-rca">Hugging Face</a>. Analysis code is available on <a href="https://github.com/deep1003/genai-exploration-rca">GitHub</a>. Patent-provider inputs and personal records are not redistributed; access to underlying data remains subject to the providers' terms.</p></section>
<section><h2>References</h2><ul class="references" style="list-style:none;padding-left:0">{reference_html}</ul></section>
</main></body></html>'''
assert content.count('<figure ')==3
assert content.count('<table')==2
assert all(s not in content.lower() for s in ['recovered','regenerated','pipeline','re-estimated','under revision','archived','restored','workflow'])
page.write_text(content)
(OUT/'homepage_content_verification.json').write_text(json.dumps(dict(displayed_figures=[2,3,4],displayed_tables=[2,3],highlights=4,references=7,huggingface_link=True,internal_workflow_language_removed=True,source=str(ROOT/'final_us_english_20261117.tex')),indent=2))
print(json.dumps(dict(page=str(page),figures=3,tables=2,highlights=4,references=7),indent=2))
