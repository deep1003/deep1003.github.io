from pathlib import Path
import csv
import hashlib
import json
import shutil

from huggingface_hub import HfApi, hf_hub_download

ROOT=Path(__file__).resolve().parents[1]
PUBLIC=ROOT/'09_public_release/genai-exploration-rca'
OUT=ROOT/'10_final_publication_20261117'
STAGE=OUT/'huggingface_dataset'
STAGE.mkdir(exist_ok=True)
repo='deep1003/genai-exploration-rca'
manifest=[]
configs=[]
for p in sorted((PUBLIC/'data').rglob('*')):
    if not p.is_file() or p.suffix not in ['.csv','.json','.md','.txt']:continue
    rel=p.relative_to(PUBLIC)
    dest=STAGE/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    entry=dict(path=str(rel),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    if p.suffix=='.csv':
        with p.open(newline='') as f:
            rows=list(csv.reader(f));entry['columns']=rows[0];entry['rows']=max(0,len(rows)-1)
        configs.append(dict(config_name=p.stem.replace('-','_'),data_files=[dict(split='data',path=str(rel))]))
    manifest.append(entry)
for p in sorted((OUT/'figures_600dpi').glob('*')):
    if p.suffix not in ['.pdf','.png','.jpg']:continue
    dest=STAGE/'figures'/p.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest)
    manifest.append(dict(path=str(dest.relative_to(STAGE)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
meta=STAGE/'metadata';meta.mkdir(exist_ok=True)
(meta/'file_manifest.json').write_text(json.dumps(manifest,indent=2))
card='---\n'+json.dumps(dict(pretty_name='Generative AI Exploration and Revealed Comparative Advantage',language=['en'],tags=['patents','generative-ai','innovation','comparative-advantage','aggregate-data'],configs=configs),indent=2)+'\n---\n'
card+='''# Generative AI Exploration and Revealed Comparative Advantage

One-Sun Cho and Youngsam Chun

Public aggregate data accompanying the manuscript on technological exploration, national specialization, and generative AI innovation.

## Data

- `data/tables/` contains counts, shares, regression coefficients, uncertainty estimates, and model metadata.
- `data/figure_series/` contains non-identifying line, interval, and bar-series data.
- `figures/` contains all nine manuscript figures in PDF, PNG, and JPG. Raster files are 600 dpi. Figure 9 preserves its PNG pixels and is below 10,000,000 bytes in each format; its compact PDF embeds those pixels without JPEG recompression.
- `metadata/file_manifest.json` gives file hashes, CSV columns, and row counts.

Each CSV is a separate viewer configuration. The `data` split is a browsing convention, not a claim that these aggregate observations are a machine-learning training set. Files with different statistical units must not be concatenated into a patent-level dataset.

## Units and interpretation

The regression results distinguish equally weighted country-CPC-year cells, repeated patent-CPC rows with additive fixed effects, and pooled OLS. The coefficients do not establish a robust intermediate-distance optimum. Mean squared distance is not the square of mean distance.

Regional application shares use the included US, Chinese, Korean, and EU counts. Keyword shares count repeated occurrences in text, not distinct patents or technological ownership. Some cluster totals are very small. Historical cluster labels are not a validated mapping to the regenerated semantic partition.

Figures 5 and 6 retain pooled illustrations whose polynomial scaling requires verification. The event-study design and reference-year interpretation, national counting rules, and correspondence between historical network percentages and regenerated outputs also require verification. These materials do not establish a causal Transformer effect or control of critical inputs.

## Access and rights

This release contains all data files in the approved public aggregate release, not every underlying patent observation. PATSTAT/WIPS and other provider-level inputs, personal records, full notebook outputs, and patent-level embedding coordinates are excluded because redistribution rights have not been confirmed. Obtain underlying data under the original providers' terms. No blanket license is asserted over third-party inputs or publisher materials.

## Links

- Research page: https://deep1003.github.io/research/genai-exploration-rca.html
- Analysis code and source documentation: https://github.com/deep1003/genai-exploration-rca

## Citation

Cho, O.-S., and Chun, Y. (2026). Technological exploration distance, revealed comparative advantage, and the US-China dual-core reconfiguration of generative AI innovation. Working manuscript.
'''
(STAGE/'README.md').write_text(card)
api=HfApi()
assert api.whoami()['name']=='deep1003'
api.create_repo(repo_id=repo,repo_type='dataset',private=False,exist_ok=True)
commit=api.upload_folder(repo_id=repo,repo_type='dataset',folder_path=str(STAGE),commit_message='Publish approved aggregate GenAI research data and figure formats')
files=api.list_repo_files(repo_id=repo,repo_type='dataset')
assert all(r['path'] in files for r in manifest)
downloaded=Path(hf_hub_download(repo_id=repo,repo_type='dataset',filename='metadata/file_manifest.json',revision=commit.oid))
assert downloaded.read_bytes()==(meta/'file_manifest.json').read_bytes()
result=dict(url='https://huggingface.co/datasets/'+repo,commit_url=commit.commit_url,commit_sha=commit.oid,files=len(files),data_files=sum(r['path'].startswith('data/') for r in manifest),figure_files=sum(r['path'].startswith('figures/') for r in manifest),restricted_data_included=False,manifest_byte_verified=True)
(OUT/'huggingface_publication_verified.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
