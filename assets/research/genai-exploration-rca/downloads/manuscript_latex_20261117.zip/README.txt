Working manuscript and associated public materials, 17 November 2026.
Patent-level provider inputs and personal records are not redistributed.
The manuscript retains unresolved scientific checks. No new analyses were run for this packaging.
