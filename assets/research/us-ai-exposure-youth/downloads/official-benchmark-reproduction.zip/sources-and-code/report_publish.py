"""Explain sample-to-population scaling and publish independent official checks."""

from pathlib import Path
import hashlib
import json
import shutil
import zipfile

import pandas as pd
from bs4 import BeautifulSoup

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Official_Benchmark_20261126"
S = R / "work/homepage-expert-review/assets/research/us-ai-exposure-youth"
summary = json.loads((O / "BENCHMARK_SUMMARY.json").read_text())
monthly = pd.read_csv(O / "BLS_2026_monthly_comparison.csv")
states = pd.read_csv(O / "BLS_2024_state_age_comparison.csv")
funnel = pd.read_csv(O / "2026_national_sample_to_population_funnel.csv")
maps = pd.read_csv(
    R / "outputs/US_State_Map_20261126/state_youth_Q5_fulltime_rates.csv"
)
maps = maps[maps.year.eq(2026)]
assert len(maps) == 51 and maps.rate_pct.notna().all()
assert monthly.within_publication_rounding.all()


def table(frame, columns):
    q = frame[columns].copy()
    for c in q.select_dtypes("number"):
        q[c] = q[c].map(lambda v: f"{v:,.3f}")
    return (
        "| "
        + " | ".join(q.columns)
        + " |\n| "
        + " | ".join(["---"] * len(q.columns))
        + " |\n"
        + "\n".join(
            "| " + " | ".join(map(str, row)) + " |"
            for row in q.itertuples(index=False, name=None)
        )
    )


examples = maps[maps.abbr.isin(["AL", "ME", "CA", "AK", "DE"])].sort_values("abbr")
october = monthly[monthly.month.eq(10) & monthly.group.eq("16+")]
decomp = summary["state_population_control_diagnostic"]
e = float(
    funnel.set_index("stage").loc["Employed 22–25", "monthly_average_estimated_people"]
)
p = float(
    funnel.set_index("stage").loc[
        "Population 22–25", "monthly_average_estimated_people"
    ]
)
qe = float(
    funnel.set_index("stage").loc[
        "Q5 employed 22–25", "monthly_average_estimated_people"
    ]
)
qf = float(
    funnel.set_index("stage").loc[
        "Q5 full-time 22–25", "monthly_average_estimated_people"
    ]
)
report = f"""# Official-data benchmark and sample-to-population reconciliation

## Finding

The small numbers previously discussed were unweighted survey person-month records, not estimated workers. For Alabama, 49 observed Q5 full-time records across nine months imply approximately 19,942 employed people in an average month after survey weighting. Maine's 9 records imply about 2,077 people; California's 273 imply about 178,622. These are model-free survey-weighted population estimates, not a count of unique respondents. Repeated respondents can appear across months.

All 50 states and DC have finite observed-data estimates. All are now colored by default. The former display cutoff is retained as a caution flag, with a dagger and dashed border, and an optional higher-support filter. Showing an estimate does not make it precise. No interpolation or small-area model was used to create additional workers or states.

## Survey records versus estimated workers

{table(examples, ['state','nQ5_FT','Q5_FT_average','population_average','rate_pct'])}

nQ5_FT is the unweighted number of person-month records across January–September. Q5_FT_average is the estimated population of Q5 full-time workers in an average month. The estimate equals the sum of composite survey weights divided by nine, not the unweighted count. Neither measure is the number of distinct people who held such jobs at any time during nine months.

The raw composite weight has four implied decimal places. The parser divides PWCMPWGT by 10,000. This is a decimal-place conversion, not a division of the estimated population by 10,000 after weighting. The resulting weight indicates the population represented by an observed record. Averaging nine monthly stocks prevents counting nine months of the same population as nine times as many people.

## National filtering funnel, January–September 2026

{table(funnel, ['stage','survey_person_months','monthly_average_survey_records','monthly_average_estimated_people'])}

The age group contains an estimated {p:,.0f} residents, of whom {e:,.0f} are employed. Q5 employed workers number {qe:,.0f}; Q5 full-time workers number {qf:,.0f}. Their rate among the whole age-group population is {100*qf/p:.2f}%. Equivalently, the employment–population ratio ({100*e/p:.2f}%) multiplied by the Q5 share among employed workers ({100*qe/e:.2f}%) and the full-time share within Q5 employment ({100*qf/qe:.2f}%) gives that same rate. Thus, 10.09% is not the full-time share among Q5 workers, which is approximately {100*qf/qe:.2f}%.

The national Q5 full-time sample averages only 388 records per month, spread across 51 state/DC areas. That explains why narrow state cells can contain only a few records each month while representing thousands of workers. Frozen occupational Q5 membership does not require exactly 20% of each state's young population to belong to Q5.

## Independent national BLS comparison

The independently published [BLS October 2026 Table A-1](https://www.bls.gov/news.release/empsit.t01.htm) reports counts in thousands and separates seasonally adjusted from unadjusted estimates. We compare the unadjusted September and October 2026 columns to fresh raw-file calculations, with the same population universe and six age/sex groups. All 84 count/rate checks are within publication rounding. The largest count gap is {summary['monthly_unrounded_count_max_gap']:.2f} people against numbers rounded to the nearest thousand; all rate gaps are within 0.05 percentage points.

{table(october, ['metric','BLS','ours','gap'])}

This establishes that the raw-file weight scale, broad population filters, age/sex grouping and employment-status recodes reproduce those official monthly quantities. It does not validate THAIE scores or the precision of each Q5 state estimate.

## Actual gaps in state publications

We also rebuilt all 12 months of 2024 and compared [BLS expanded state demographic data](https://www.bls.gov/lau/table14full24.htm), covering all 51 areas at ages 16+, 50 available age-20–24 rows and 51 age-25–34 rows. These are 152 available state-by-age comparisons. They are not compared to the map's nine-month or age-22–25 values, because that would mix periods and age definitions.

For ages 16+, the largest employment-level gap is {decomp['max_original_E_relative_gap_pct']:.3f}%. The [2024 Geographic Profile](https://www.bls.gov/opub/geographic-profile/2024/) explicitly incorporates updated population controls. The original monthly public-use files retain their release-vintage weights. This difference matters. For California, the official state population is 31.618 million versus 31.205 million from the original files, and employment is 18.596 million versus 18.353 million. This is a population-control-vintage discrepancy, not hundreds of thousands of missing survey respondents.

As a diagnostic only, scaling each state's age-16+ estimate by the ratio of the official to reconstructed population reduces the largest employment discrepancy to {decomp['max_gap_after_state_population_alignment_pct']:.3f}% and the median to {decomp['median_gap_after_state_population_alignment_pct']:.3f}%. This documents that population-level alignment explains most of the broad state level gaps. It is not a valid calibration of age-22–25 occupational cells and was not applied to the map or regressions. Remaining discrepancies can include rounding, monthly versus annual control alignment and revised weighting.

Detailed-age gaps are larger. The maximum employment-level discrepancy is 4.588% for ages 20–24 and 2.429% for ages 25–34. The age-20–24 employment–population ratio differs by as much as 1.475 percentage points. Those residuals have not been fully reconciled to revised individual weights. We do not claim they are all rounding or that a broad state rescaling solves them. Published age groups also do not isolate age 22–25 or our THAIE Q5, so no identical official Q5 benchmark is available.

There is a further documented source of subgroup differences. [BLS public-use-file guidance](https://www.bls.gov/cps/data/public-use-file.htm) explains that age perturbation and associated public-file weight changes began in 2011, so fine age cells may not exactly match internal files used for official releases. This is a documented mechanism, not a measured decomposition of our residuals; quantifying its contribution requires internal comparison data. The [Census 2023 disclosure note](https://www.census.gov/programs-surveys/cps/technical-documentation/user-notes/cps_2023_01.html) also lists substate geography synthesis and earnings changes. Its geographic synthesis operates separately within states and does not justify assuming the state code itself was changed. We do not invent a 2023 state-boundary break to explain the results.

## Interpretation and correction

The confirmed presentation problem was emphasizing sample counts and suppressing finite state estimates in a way that looked like missing population data. The map now prioritizes estimated people and rates, labels survey records separately, and shows all available states. The original sample rule remains a visible warning rather than an automatic exclusion.

The statistical limitation remains real. A weighted estimate of thousands can be supported by few sampled records and have large uncertainty. The [BLS CPS reliability documentation](https://www.bls.gov/cps/methods/reliability-of-cps-estimates.htm) describes a sample survey rather than a census of all workers. The [LAUS FAQ](https://www.bls.gov/lau/laufaq.htm) explains population controls and identifies the Geographic Profile as CPS-based. LAUS modeled totals, payroll jobs, ACS respondents, and CPS employed residents are different estimands and cannot be substituted without aligning definitions.

Cross-year original-vintage map changes can reflect population-control updates, demographic shifts, occupation changes and sampling variation. They are descriptive differences, not an AI treatment effect. A defensible future revision should harmonize control vintages at the appropriate demographic level, assess design-based uncertainty or larger-sample compatible sources, and preserve the original-vintage results as a documented sensitivity. We did not fabricate official THAIE counts or mechanically rescale narrow cells to unrelated totals.

## Reproduction and scope

National benchmarks were parsed from the official web table's unadjusted columns. The state table was captured in complete numbered-line segments through the web reader because direct command-line BLS HTML/XLSX requests returned HTTP 403. Segments were merged by line number; overlapping lines were required to agree; all lines covering the state table were present. Official source URLs, parsed rows, gaps and scripts are supplied. This is external published-table comparison, beyond same-parser internal regeneration, but not a complete survey-design validation.

Existing CPS raw files, score definitions, main DID coefficients and sample-size flags were not modified. Map visibility changed. No images or graphs were emitted by numerical checks. Updated November 26, 2026.
"""
(O / "OFFICIAL_BENCHMARK_REPORT_EN.md").write_text(report)
for p in O.iterdir():
    if p.suffix in [".csv", ".json", ".md"]:
        shutil.copy2(p, S / "downloads" / ("official-benchmark-" + p.name))

soup = BeautifulSoup((S / "index.html").read_text(), "html.parser")
old = soup.find(id="official-benchmark-note")
if old:
    old.decompose()
rows = "".join(
    f"<tr><td>{r.state}</td><td>{r.nQ5_FT:,}</td><td>{r.Q5_FT_average:,.0f}</td><td>{r.rate_pct:.2f}%</td></tr>"
    for r in examples.itertuples()
)
block = f"""<details id="official-benchmark-note"><summary>Why can a small survey count represent thousands of workers? Official-data checks</summary><p>Survey records are not population counts. The same CPS record is weighted to represent many residents. January–September totals are divided by nine to estimate an average monthly population.</p><div class="table-scroll"><table><caption>2026 January–September. The second column counts survey person-month records, not workers in the state.</caption><thead><tr><th>State</th><th>Survey records, nine months</th><th>Estimated Q5 FT workers, monthly average</th><th>Rate</th></tr></thead><tbody>{rows}</tbody></table></div><p>The 2026 national Q5 full-time sample averages 388 records per month but estimates 1,799,280 workers. Full-time workers are 10.09% of all residents aged 22–25, and approximately {100*qf/qe:.2f}% of employed Q5 workers. These denominators answer different questions.</p><p>All 84 matched national BLS monthly checks agree within publication rounding. State annual data do have control-vintage gaps: the largest age-16+ employment-level difference is 2.20%; a diagnostic population alignment reduces the largest to 0.25%. Detailed age-20–24 employment gaps reach 4.59% and are not fully reconciled. BLS also documents public-file age perturbation and weight differences relative to internal records. These revised official tables are not identical to the original-vintage public-use weights, and none contains our exact THAIE Q5 group.</p><p><a href="downloads/official-benchmark-OFFICIAL_BENCHMARK_REPORT_EN.md">Full benchmark report</a> · <a href="downloads/official-benchmark-BLS_2026_monthly_comparison.csv">National comparisons</a> · <a href="downloads/official-benchmark-BLS_2024_state_age_comparison.csv">State and age comparisons</a> · <a href="downloads/official-benchmark-reproduction.zip">Sources and code</a></p></details>"""
(O / "BENCHMARK_NOTE.html").write_text(block)
soup.find(id="state-youth-map").find(class_="result-body").append(
    BeautifulSoup(block, "html.parser")
)
(S / "index.html").write_text(str(soup))
with zipfile.ZipFile(
    S / "downloads/official-benchmark-reproduction.zip", "w", zipfile.ZIP_DEFLATED
) as z:
    for p in W.iterdir():
        if p.is_file() and p.suffix in [".py", ".txt", ".log"]:
            z.write(p, "sources-and-code/" + p.name)
    for p in O.iterdir():
        if p.is_file():
            z.write(p, "outputs/" + p.name)
    z.writestr(
        "README.txt",
        "Run benchmark.py then report_publish.py after the state-map publisher. Code retains project-relative paths and requires original CPS files and dictionaries. Published official sources are retained as web-reader line extracts. No person-level data or official Q5 data are bundled.",
    )
print(
    "Official comparison report and map explanation published; all 51 finite estimates are available."
)
