"""Compare public CPS microdata to independently published BLS benchmarks."""

from pathlib import Path
import hashlib
import importlib.util
import json
import re

import numpy as np
import pandas as pd

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Official_Benchmark_20261126"
O.mkdir(exist_ok=True)
mapdata = json.loads((R / "outputs/US_State_Map_20261126/state_map.json").read_text())
states = {s["name"].upper(): s["fips"] for s in mapdata["states"]}
names = {s["fips"]: s["name"] for s in mapdata["states"]}
lines = {}
for p in W.glob("bls_state_web_extract_*.txt"):
    for line in p.read_text().splitlines():
        m = re.match(r"L(\d+): (.*)", line)
        if m:
            n, text = int(m[1]), m[2]
            if n in lines:
                assert lines[n] == text
            lines[n] = text
assert all(n in lines for n in range(173, 2715))


def numeric(text):
    return float(text.replace(",", "").strip())


official = []
state, detailed, age_total, seen_total = None, False, False, False
for n, text in sorted(lines.items()):
    cells = [x.strip() for x in text.split("|")]
    label = cells[0]
    if label in states:
        state, detailed, age_total, seen_total = states[label], False, False, False
        continue
    if state is None:
        continue
    group = None
    if label == "Detailed age":
        detailed = True
    elif label == "Total" and len(cells) <= 2 and detailed:
        age_total = True
    elif label == "Total" and not seen_total and len(cells) >= 8:
        group, seen_total = "16+", True
    elif age_total and label in ["20 to 24 years", "25 to 34 years"]:
        group = {"20 to 24 years": "20–24", "25 to 34 years": "25–34"}[label]
    elif detailed and len(cells) <= 2 and label not in ["Total", "Detailed age"]:
        age_total = False
    if group:
        official.append(
            dict(
                state_fips=state,
                state=names[state],
                age=group,
                P=numeric(cells[1]) * 1000,
                LF=numeric(cells[2]) * 1000,
                E=numeric(cells[4]) * 1000,
                EPR=numeric(cells[5]),
                U=numeric(cells[6]) * 1000,
                UR=numeric(cells[7]),
                source_line=n,
                source="https://www.bls.gov/lau/table14full24.htm",
            )
        )
official = pd.DataFrame(official)
assert official[official.age.eq("16+")].state_fips.nunique() == 51
assert not official.duplicated(["state_fips", "age"]).any()
official.to_csv(O / "BLS_2024_official_state_age.csv", index=False)

records = json.loads(
    (
        R / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json"
    ).read_text()
)
idx = {(x["year"], x["month"]): x for x in records if x.get("available", True)}
pth = (
    R
    / "outputs/US_THAIE_Regional_Youth_20261122/panel_fe3_20261122/scripts/prepare_panel.py"
)
spec = importlib.util.spec_from_file_location("benchmark_parser", pth)
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)
parser.source = lambda y, m: (Path(idx[y, m]["path"]), Path(idx[y, m]["dictionary"]))
scorepath = (
    R
    / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/frozen_THAIE_occupation_assignments.csv"
)
scores = pd.read_csv(scorepath)
q5 = set(scores.loc[scores.THAIE_q.eq(5), "occ"])
parts, checks = [], []
for month in range(1, 13):
    d, check = parser.read(2024, month)
    assert check["sha256"] == idx[2024, month]["sha256"]
    for age, mask in [
        ("16+", d.PRTAGE.ge(16)),
        ("20–24", d.PRTAGE.between(20, 24)),
        ("25–34", d.PRTAGE.between(25, 34)),
    ]:
        a = (
            d[mask]
            .groupby("GESTFIPS")[["P", "E", "U"]]
            .sum()
            .reset_index()
            .rename(columns={"GESTFIPS": "state_fips"})
        )
        a["age"], a["month"] = age, month
        parts.append(a)
    checks.append(dict(year=2024, month=month, raw_sha256=check["sha256"]))
    print("Rebuilt 2024", month, flush=True)
rebuild = (
    pd.concat(parts)
    .groupby(["state_fips", "age"], as_index=False)[["P", "E", "U"]]
    .sum()
)
rebuild[["P", "E", "U"]] /= 12
rebuild["LF"] = rebuild.E + rebuild.U
rebuild["EPR"] = 100 * rebuild.E / rebuild.P
rebuild["UR"] = 100 * rebuild.U / rebuild.LF
comparison = official.merge(
    rebuild, on=["state_fips", "age"], suffixes=("_BLS", "_ours"), validate="one_to_one"
)
for metric in ["P", "E", "U", "LF", "EPR", "UR"]:
    comparison[metric + "_gap"] = (
        comparison[metric + "_ours"] - comparison[metric + "_BLS"]
    )
    if metric in ["P", "E", "U", "LF"]:
        comparison[metric + "_relative_gap_pct"] = (
            100 * comparison[metric + "_gap"] / comparison[metric + "_BLS"]
        )
comparison.to_csv(O / "BLS_2024_state_age_comparison.csv", index=False)

# Parse current official Table A-1's first three unadjusted columns.
a1 = {}
for line in (W / "bls_A1_2026M10_web.txt").read_text().splitlines():
    m = re.match(r"L(\d+): (.*)", line)
    if m:
        a1[int(m[1])] = m[2]
metric_labels = {
    "Civilian noninstitutional population": "P",
    "Civilian labor force": "LF",
    "Employed": "E",
    "Unemployed": "U",
    "Not in labor force": "N",
    "Employment-population ratio": "EPR",
    "Unemployment rate": "UR",
}
groups = {
    "TOTAL": "16+",
    "Men, 16 years and over": "Men16+",
    "Women, 16 years and over": "Women16+",
    "Men, 20 years and over": "Men20+",
    "Women, 20 years and over": "Women20+",
    "Both sexes, 16 to 19 years": "16–19",
}
group, official_a1 = None, []
for n, text in sorted(a1.items()):
    cells = [x.strip() for x in text.split("|")]
    if cells[0] in groups:
        group = groups[cells[0]]
    if group and cells[0] in metric_labels and len(cells) >= 4:
        metric = metric_labels[cells[0]]
        for month, cell in [(9, cells[2]), (10, cells[3])]:
            official_a1.append(
                dict(
                    year=2026,
                    month=month,
                    group=group,
                    metric=metric,
                    BLS=numeric(cell) * (1 if metric in ["EPR", "UR"] else 1000),
                    source_line=n,
                )
            )
rows = []
for month in [9, 10]:
    d, check = parser.read(2026, month)
    assert check["sha256"] == idx[2026, month]["sha256"]
    for group, mask in [
        ("16+", d.PRTAGE.ge(16)),
        ("Men16+", d.PESEX.eq(1)),
        ("Women16+", d.PESEX.eq(2)),
        ("Men20+", d.PESEX.eq(1) & d.PRTAGE.ge(20)),
        ("Women20+", d.PESEX.eq(2) & d.PRTAGE.ge(20)),
        ("16–19", d.PRTAGE.between(16, 19)),
    ]:
        z = d[mask]
        vals = dict(P=z.P.sum(), E=z.E.sum(), U=z.U.sum(), N=z.N.sum())
        vals["LF"] = vals["E"] + vals["U"]
        vals["EPR"] = 100 * vals["E"] / vals["P"]
        vals["UR"] = 100 * vals["U"] / vals["LF"]
        for metric, v in vals.items():
            rows.append(
                dict(year=2026, month=month, group=group, metric=metric, ours=float(v))
            )
monthly_cmp = pd.DataFrame(official_a1).merge(
    pd.DataFrame(rows), on=["year", "month", "group", "metric"], validate="one_to_one"
)
monthly_cmp["gap"] = monthly_cmp.ours - monthly_cmp.BLS
monthly_cmp["within_publication_rounding"] = np.where(
    monthly_cmp.metric.isin(["EPR", "UR"]),
    monthly_cmp.gap.abs() <= 0.05001,
    monthly_cmp.gap.abs() <= 500.01,
)
monthly_cmp.to_csv(O / "BLS_2026_monthly_comparison.csv", index=False)

# Trace exactly how weighted population estimates and unweighted records narrow.
stages, state_stages, weight_summaries = [], [], []
for month in range(1, 10):
    d, check = parser.read(2026, month)
    assert check["sha256"] == idx[2026, month]["sha256"]
    young = d.PRTAGE.between(22, 25)
    masks = [
        ("Civilian population 16+", d.PRTAGE.ge(16)),
        ("Population 22–25", young),
        ("Employed 22–25", young & d.nE.eq(1)),
        (
            "Mapped occupation, employed 22–25",
            young & d.nE.eq(1) & d.occ.isin(scores.occ),
        ),
        ("Q5 employed 22–25", young & d.nE.eq(1) & d.occ.isin(q5)),
        ("Q5 full-time 22–25", young & d.nE.eq(1) & d.occ.isin(q5) & d.PRFTLF.eq(1)),
    ]
    for label, mask in masks:
        z = d[mask]
        stages.append(
            dict(
                month=month,
                stage=label,
                survey_records=len(z),
                weighted_people=z.P.sum(),
            )
        )
        ss = (
            z.groupby("GESTFIPS")
            .P.agg(["size", "sum"])
            .reset_index()
            .rename(
                columns={
                    "GESTFIPS": "state_fips",
                    "size": "survey_records",
                    "sum": "weighted_people",
                }
            )
        )
        ss["stage"] = label
        ss["month"] = month
        state_stages.append(ss)
    for fips, z in d[young & d.nE.eq(1) & d.occ.isin(q5) & d.PRFTLF.eq(1)].groupby(
        "GESTFIPS"
    ):
        weight_summaries.append(
            dict(
                state_fips=int(fips),
                month=month,
                weight_min=float(z.P.min()),
                weight_max=float(z.P.max()),
                weight_sum=float(z.P.sum()),
                records=len(z),
            )
        )
stages = (
    pd.DataFrame(stages)
    .groupby("stage", as_index=False)
    .agg(
        survey_person_months=("survey_records", "sum"),
        weighted_person_months=("weighted_people", "sum"),
    )
)
stages["monthly_average_survey_records"] = stages.survey_person_months / 9
stages["monthly_average_estimated_people"] = stages.weighted_person_months / 9
stages.to_csv(O / "2026_national_sample_to_population_funnel.csv", index=False)
ss = (
    pd.concat(state_stages)
    .groupby(["state_fips", "stage"], as_index=False)
    .agg(
        survey_person_months=("survey_records", "sum"),
        weighted_person_months=("weighted_people", "sum"),
    )
)
ss["monthly_average_estimated_people"] = ss.weighted_person_months / 9
ss["state"] = ss.state_fips.map(names)
ss.to_csv(O / "2026_state_sample_to_population_funnel.csv", index=False)
pd.DataFrame(weight_summaries).to_csv(
    O / "2026_Q5_FT_survey_weight_ranges.csv", index=False
)
result = dict(
    monthly_benchmark_tests=len(monthly_cmp),
    monthly_within_rounding=int(monthly_cmp.within_publication_rounding.sum()),
    monthly_unrounded_count_max_gap=float(
        monthly_cmp.loc[~monthly_cmp.metric.isin(["EPR", "UR"]), "gap"].abs().max()
    ),
    state_age_comparisons=len(comparison),
    state_comparisons_summary={},
    raw_files_verified=checks,
    source_urls=[
        "https://www.bls.gov/news.release/empsit.t01.htm",
        "https://www.bls.gov/lau/table14full24.htm",
    ],
    plots_displayed=False,
)
for age, z in comparison.groupby("age"):
    result["state_comparisons_summary"][age] = dict(
        states=len(z),
        max_P_gap_people=float(z.P_gap.abs().max()),
        max_E_gap_people=float(z.E_gap.abs().max()),
        max_E_gap_pct=float(z.E_relative_gap_pct.abs().max()),
        max_UR_gap_pp=float(z.UR_gap.abs().max()),
        E_within_rounding=int(z.E_gap.abs().le(500.01).sum()),
    )
decomp = comparison[comparison.age.eq("16+")].copy()
decomp["E_with_BLS_state_population"] = decomp.E_ours * decomp.P_BLS / decomp.P_ours
decomp["remaining_gap_pct"] = 100 * (
    decomp.E_with_BLS_state_population / decomp.E_BLS - 1
)
decomp.to_csv(O / "BLS_2024_population_control_decomposition.csv", index=False)
result["state_population_control_diagnostic"] = dict(
    max_original_E_relative_gap_pct=float(decomp.E_relative_gap_pct.abs().max()),
    max_gap_after_state_population_alignment_pct=float(
        decomp.remaining_gap_pct.abs().max()
    ),
    median_gap_after_state_population_alignment_pct=float(
        decomp.remaining_gap_pct.abs().median()
    ),
    max_original_EPR_gap_pp=float(decomp.EPR_gap.abs().max()),
    interpretation="A population-level alignment diagnostic, not a valid age- or occupation-specific correction. Detailed-age residuals are not fully reconciled.",
)
(O / "BENCHMARK_SUMMARY.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result["state_comparisons_summary"], indent=2), flush=True)
print(
    "Monthly tests",
    len(monthly_cmp),
    "within rounding",
    monthly_cmp.within_publication_rounding.sum(),
    flush=True,
)
print(stages.to_string(index=False), flush=True)
