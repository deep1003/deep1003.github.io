"""Publish aggregate validation evidence and an opening pooled-state map."""

from pathlib import Path
import hashlib
import json
import shutil
import zipfile

from bs4 import BeautifulSoup
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
OUT = ROOT / "outputs/US_Public_Validation_20261126"
SITE = ROOT / "work/homepage-expert-review/assets/research/us-ai-exposure-youth"
PUBLIC = SITE / "downloads/public-validation-20261126"


def fragment(html):
    return BeautifulSoup(html, "html.parser")


def main():
    assert json.loads((OUT / "BUNDLE_FRESH_SMOKE_CHECKS.json").read_text())["passed"]
    shutil.copy2(WORK / "state/pooled-map.js", SITE / "state-map.js")
    css = SITE / "state-map.css"
    rule = "#state-youth-map .state-map-controls>[role=group]{display:flex;flex-wrap:wrap;gap:.4rem}"
    if rule not in css.read_text():
        css.write_text(css.read_text() + "\n" + rule + "\n")
    rates = pd.read_csv(OUT / "state/pooled_state_rates_working_uncertainty.csv")
    main_rates = rates[
        rates.band.eq("Q5")
        & rates.outcome.eq("FT")
        & rates.denominator.eq("all_age_population")
    ].copy()
    shares = (
        rates[
            rates.band.eq("Q5")
            & rates.outcome.eq("FT")
            & rates.denominator.eq("same_band_employed")
        ]
        .set_index(["period", "GESTFIPS"])
        .estimate_pct
    )
    main_rates["FT_share_pct"] = [
        shares.loc[p, s] for p, s in zip(main_rates.period, main_rates.GESTFIPS)
    ]
    geometry = json.loads(
        (ROOT / "outputs/US_State_Map_20261126/state_map.json").read_text()
    )["states"]
    periods = [
        dict(
            id="latest_36_calendar_months",
            button="Latest 3-year window",
            label="November 2023–October 2026",
            observed_months=35,
        ),
        dict(
            id="symmetric_pre",
            button="Pre-November 2022",
            label="November 2019–October 2022",
            observed_months=36,
        ),
        dict(
            id="symmetric_post",
            button="Post-November 2022",
            label="December 2022–November 2025",
            observed_months=35,
        ),
        dict(
            id="pre_pandemic_2017_2019",
            button="2017–2019 baseline",
            label="January 2017–December 2019",
            observed_months=36,
        ),
    ]
    payload = dict(
        states=geometry,
        periods=periods,
        rates=json.loads(
            main_rates[main_rates.GESTFIPS.ne(0)].to_json(orient="records")
        ),
        national=json.loads(
            main_rates[main_rates.GESTFIPS.eq(0)].to_json(orient="records")
        ),
        metadata=dict(
            default_period=periods[0]["id"],
            rate_scale=[0, 25],
            updated="2026-11-26",
            uncertainty="Working household-cluster linearization; not full CPS survey-design or causal occupation-shock inference",
            missing_month="2025-10",
            imputed_months=0,
        ),
    )
    assert len(payload["rates"]) == 204 and len(payload["national"]) == 4
    (SITE / "data/state-youth-pooled-map.json").write_text(
        json.dumps(payload, allow_nan=False, separators=(",", ":"))
    )
    for source in OUT.rglob("*"):
        if source.is_file() and source.suffix in {".md", ".json", ".csv"}:
            if source.name.startswith("SITE_"):
                continue
            # Bulk state-industry panels are in the compressed materials rather than duplicated online.
            if source.stat().st_size > 4_000_000:
                continue
            target = PUBLIC / source.relative_to(OUT)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    for extension in ["svg", "png"]:
        shutil.copy2(
            OUT / f"state/Q5_youth_fulltime_three_year_map.{extension}",
            SITE / f"figures/Q5_youth_fulltime_three_year_map.{extension}",
        )
    with zipfile.ZipFile(
        SITE / "downloads/public-validation-materials-20261126.zip",
        "w",
        zipfile.ZIP_DEFLATED,
    ) as archive:
        for source in OUT.rglob("*"):
            if source.is_file():
                archive.write(source, source.relative_to(ROOT))
        for source in WORK.rglob("*.py"):
            archive.write(source, source.relative_to(ROOT))
        source = WORK / "state/pooled-map.js"
        archive.write(source, source.relative_to(ROOT))
        archive.writestr(
            "README.txt",
            "Aggregate outputs, analysis scripts and source inventories. No respondent microdata are included. Scripts preserve the project-relative paths used in the study. Original official files and earlier project parser/mapping dependencies must be obtained separately from the documented sources; this is not a standalone raw-data environment. Read REPORT_EN.md and each module's limitations before reuse.\n",
        )
    html_path = SITE / "index.html"
    soup = BeautifulSoup(html_path.read_text(), "html.parser")
    old_map = soup.find(id="state-youth-map")
    old_map.decompose()
    previous = soup.find(id="state-overview")
    if previous:
        previous.decompose()
    buttons = "".join(
        f'<button type="button" data-period="{p["id"]}" aria-pressed="{str(i == 0).lower()}">{p["button"]}</button>'
        for i, p in enumerate(periods)
    )
    map_html = f"""<section id="state-overview"><h2>State overview</h2><details class="result" id="state-youth-map" open><summary>Where do young adults hold full-time jobs in highly exposed occupations?</summary><div class="result-body"><p class="state-map-kicker">THREE-YEAR STATE PICTURE · AGES 22–25 · THAIE Q5</p><h3 class="state-map-title">Full-time employment in THAIE Q5 · November 2023–October 2026</h3><p><strong>Rate = Q5 full-time workers ÷ all civilian noninstitutional residents aged 22–25 in each state.</strong> The map shows period averages, not a 2026-only estimate or the full-time share among Q5 workers. All 50 states and DC are included.</p><div class="state-map-controls"><div role="group" aria-label="Pooled map period">{buttons}</div></div><p class="state-map-stats" aria-live="polite">Loading pooled state estimates…</p><svg class="state-map-svg" viewBox="0 0 1000 700" role="group" aria-label="Pooled state map loading"></svg><div class="state-map-legend"></div><p class="state-map-info" aria-live="polite">Loading state details…</p><p class="state-map-note">The latest window contains 35 observed months out of 36; October 2025 was not collected and is not filled. It supplies 15,447 Q5 full-time person-month records nationally, with at least 89 in each state/DC. Repeated records are not distinct workers. Hover, tap, or focus a state for its weighted population, observed sample, and working 95% interval. These household-cluster intervals do not recover the full CPS survey design or establish AI effects. Colors show employment rates, not statistical significance.</p><p><a href="figures/Q5_youth_fulltime_three_year_map.svg">Static map SVG</a> · <a href="figures/Q5_youth_fulltime_three_year_map.png">PNG</a> · <a href="downloads/public-validation-20261126/state/pooled_state_rates_working_uncertainty.csv">State estimates and uncertainty</a> · <a href="downloads/public-validation-20261126/state/STATE_POOLING_METHODS_EN.md">Map methods</a> · <button type="button" class="state-map-save">Save selected map SVG</button></p><details><summary>Denominators, survey weights, and official benchmarks</summary><p>Nationally, the latest pooled Q5 full-time rate is 10.61% of the entire same-age population. Full-time workers are 81.69% of employed Q5 youth. These are different denominators. Population counts average survey-weighted monthly stocks across observed months; unweighted person-month records measure sample support.</p><p>The earlier January–September annual map and official BLS benchmark checks remain archived separately. The benchmark reproduces broad published national statistics within rounding, but there is no published official statistic for our exact THAIE Q5 group. Small age-specific state differences and public-file/weight-vintage limits remain documented.</p><p><a href="downloads/official-benchmark-OFFICIAL_BENCHMARK_REPORT_EN.md">Official benchmark report</a> · <a href="downloads/state-map-state_youth_Q5_fulltime_rates.csv">Archived nine-month annual estimates</a> · <a href="downloads/public-validation-20261126/state/STATE_INDEPENDENT_QA_EN.md">Independent pooled-map review</a></p></details></div></details></section>"""
    soup.find(id="introduction").insert_before(fragment(map_html))
    if not soup.select_one('.toc a[href="#state-overview"]'):
        soup.select_one(".toc-inner").insert(
            0, fragment('<a href="#state-overview">State map</a>')
        )
    soup.select_one(".hero .subtitle").string = (
        "Compare pooled state employment, monthly occupational trends, entry into work, and the experiences of incumbent workers. Each source answers a different question."
    )
    soup.select_one(".hero .meta").string = (
        "Updated November 26, 2026 · CPS, ACS, SIPP, and public administrative data · Own THAIE mapping"
    )
    soup.select_one(".takeaway p").string = (
        "Independent ACS validation confirms relative weakness in high-exposure youth employment. Linked CPS shows broadly weaker entry into full-time work, without an observed increase in Q5 full-time-to-part-time transitions. These findings do not establish an AI causal effect."
    )
    soup.find("meta", attrs={"name": "description"})["content"] = (
        "THAIE youth employment research with a three-year state map, ACS validation, linked CPS and SIPP worker transitions, and administrative hiring checks."
    )
    note = soup.find(id="state-map-method-note")
    note.string = "The opening map pools observed CPS months into three-year calendar windows and reports Q5 full-time employment divided by all same-age residents. The independent ACS check compares 2017–2019 with 2023–2024 and uses past-year usual-hours proxies. Linked CPS separates entry outcomes from incumbent transitions; SIPP observes personal histories through 2024. These distinct measures are not pooled into one causal estimate."
    methods_addition = soup.find(id="public-validation-methods")
    if methods_addition:
        methods_addition.decompose()
    soup.find(id="methods").append(
        fragment(
            """<details id="public-validation-methods"><summary>New survey and administrative validation methods</summary><p>ACS validation uses 2017, 2018, 2019, 2023, and 2024 national person files, exact ages 22–25, all states/DC, frozen THAIE thresholds, and 80 replicate weights. The 2017 occupation bridge contributes fractional expected group weights. Three-year pre and two-year post averages use separately normalized annual weights. Pointwise intervals assume independent annual replicate blocks and condition on the score and bridge. ACS hours and salary refer to the past year, not the current CPS schedule or hourly wage.</p><p>Linked CPS uses 79 genuine adjacent-month pairs from 2020–October 2026, rotation eligibility, validated person matches, and cross-fitted response IPW with trimming sensitivity. Origin occupation defines incumbent exposure; destination occupation classifies entry outcomes from a common nonemployment denominator. Neither unknown prior occupation nor missing response is coded as low exposure. The pooled transition periods differ in length and include pandemic effects, so they are descriptive rather than controlled DID estimates.</p><p>SIPP uses official two-, three-, and four-year longitudinal weights. Monthly hours intensity is distinguished from usual FT/PT, and general permanent-to-contract status is not inferred from union coverage or restricted-universe contract questions. QWI/J2J use quarterly industry exposure and published ages 22–24/35–64, not exact occupational Q5 or ages 22–25. Industry-cluster inference, Holm correction, trend sensitivity, and an extended 2017 preperiod accompany the administrative models.</p><p><a href="downloads/public-validation-20261126/REPORT_EN.md">Full construction, estimates, and limitations</a> · <a href="downloads/public-validation-20261126/BUNDLE_FRESH_SMOKE_CHECKS.json">Data-I/O validation</a></p></details>"""
        )
    )
    old_result = soup.find(id="public-validation-results")
    if old_result:
        old_result.decompose()
    result_html = """<details class="result" id="public-validation-results" open><summary>New validation separates employment levels, entry, and incumbent adaptation</summary><div class="result-body"><h3>Relative employment weakness is not an absolute job-loss estimate</h3><p>Five newly acquired ACS national person files contain 16,472,829 records, including 702,146 eligible youth records. Comparing the 2017–2019 average with 2023–2024, occupational Q5 employment grows less than Q1–Q4. The annual comparison does not establish when the divergence began or identify an AI effect.</p><div class="table-scroll"><table><caption>Ages 22–25, ACS pooled annual comparison. Changes are percentages, not percentage points. Intervals are pointwise 95% replicate-based approximations conditional on the fixed THAIE mapping and occupation bridge.</caption><thead><tr><th>Measure</th><th>Change</th><th>95% interval</th></tr></thead><tbody><tr><td>Q5/Q1–Q4 relative employment</td><td>−7.92%</td><td>−9.51% to −6.33%</td></tr><tr><td>Q5/Q1–Q4 relative FT-hours proxy</td><td>−7.41%</td><td>−9.26% to −5.55%</td></tr><tr><td>Q5/Q1–Q4 relative PT-hours proxy</td><td>−11.26%</td><td>−14.58% to −7.94%</td></tr><tr><td>Q5 FT-hours proxy, own count</td><td>−1.24%</td><td>−3.01% to +0.53%</td></tr><tr><td>Q5 PT-hours proxy, own count</td><td>−11.75%</td><td>−14.77% to −8.73%</td></tr></tbody></table></div><p>ACS FT/PT proxies combine current employment with usual hours over the past 12 months. They are not exact CPS current FT/PT measures. The Q5 absolute FT interval includes zero; the relative result must not be reported as a demonstrated absolute FT loss. PT employment also falls, providing no evidence here of an aggregate shift into PT.</p><h3>Entry into full-time work weakens in both exposure groups</h3><div class="table-scroll"><table><caption>Linked CPS, origin ages 22–25, response-IPW monthly entry rates. Every row uses the same origin-jobless denominator within period. These are unadjusted descriptive pre/post rates, not causal DID estimates.</caption><thead><tr><th>Destination</th><th>Pre</th><th>Post</th></tr></thead><tbody><tr><td>Q5 full-time</td><td>1.726%</td><td>1.314%</td></tr><tr><td>Q1–Q4 full-time</td><td>7.334%</td><td>6.201%</td></tr><tr><td>Q5 part-time</td><td>0.887%</td><td>0.871%</td></tr><tr><td>Q1–Q4 part-time</td><td>5.203%</td><td>5.187%</td></tr><tr><td>Any employment</td><td>15.436%</td><td>13.830%</td></tr></tbody></table></div><p>Pre-pairs end by October 2022; post-pairs start in December 2022. The unequal periods and pandemic composition prevent causal attribution. Destination THAIE defines the outcome rather than treatment for nonworkers. Entries can include re-entry and do not establish first-ever jobs. Different group sizes mean that entry-rate levels are not comparable measures of disadvantage by themselves.</p><h3>Incumbent transitions do not show an observed Q5 FT-to-PT increase</h3><div class="table-scroll"><table><caption>Linked CPS, ages 22–25, response-IPW monthly transitions among origin FT workers. No significance claim is attached to these descriptive rates.</caption><thead><tr><th>Outcome</th><th>Pre</th><th>Post</th></tr></thead><tbody><tr><td>Q5 FT → PT</td><td>3.669%</td><td>3.645%</td></tr><tr><td>Q1–Q4 FT → PT</td><td>5.736%</td><td>5.814%</td></tr><tr><td>Q5 FT → economic usual PT</td><td>0.705%</td><td>0.702%</td></tr></tbody></table></div><p>Economic usual PT requires destination usual PT. Economic short actual hours can include usual FT workers and is reported separately. SIPP adds personal hours and real-income histories through 2024, but its four-year youth Q5 cohort contains only 23 people. These observations do not identify general permanent-to-contract conversion or changes in the quality of offered jobs.</p><h3>Administrative hiring evidence is sensitive to the preperiod</h3><p>In the balanced quarterly models, youth new hires in high-exposure industries are estimated at −4.71% (p=.304) and entry from nonemployment at −4.80% (p=.242). Extending the preperiod to 2017 gives −0.70% (p=.899) and +0.83% (p=.858), respectively. No primary youth result survives the 24-test Holm correction. These public data use ages 22–24 and industry exposure; they are a separate mechanism check, not an occupational Q5 replication.</p><p><a href="downloads/public-validation-20261126/REPORT_EN.md">Integrated report</a> · <a href="downloads/public-validation-20261126/acs/ACS_VALIDATION_REPORT_EN.md">ACS methods and tables</a> · <a href="downloads/public-validation-20261126/longitudinal/LONGITUDINAL_METHODS_AND_RESULTS_EN.md">Worker adaptation</a> · <a href="downloads/public-validation-20261126/longitudinal/ENTRY_METHODS_EN.md">Entry methods</a> · <a href="downloads/public-validation-20261126/admin/ADMIN_EXTENDED_PRE_REPORT_EN.md">Administrative robustness</a></p></div></details>"""
    results = soup.find(id="results")
    results.h2.insert_after(fragment(result_html))
    for detail in results.find_all("details"):
        if detail.get("id") != "public-validation-results":
            detail.attrs.pop("open", None)
    discussion = soup.find(id="discussion")
    discussion.clear()
    discussion.append(
        fragment(
            """<h2>Discussion</h2><h3>1. Relative employment weakness is supported; absolute loss is a different claim</h3><p>The independent ACS comparison reproduces relative weakness in Q5 youth employment. The pooled FT-hours proxy is 7.41% lower relative to Q1–Q4, while Q5's own FT count changes −1.24% with an interval spanning zero. This supports a growth-gap description rather than a demonstrated absolute FT loss. The annual ACS comparison cannot date the divergence to ChatGPT, and past-year hours differ from current CPS FT/PT. Larger annual samples strengthen descriptive cross-checks without resolving identification.</p><h3>2. Entry opportunities weaken broadly, without an identified Q5-specific cause</h3><p>Linked CPS entry into Q5 FT work declines from 1.726% to 1.314% per month among origin-jobless youth, while Q1–Q4 FT entry also declines from 7.334% to 6.201%. These are realized transitions, not counts of job offers or first-career hires. They are consistent with broader difficulty entering full-time work but do not isolate a Q5-specific shock. Administrative hiring estimates weaken with a longer preperiod; a young-relative-to-older J2J contrast that survives multiplicity correction in one specification fails trend and extended-preperiod checks. Hiring contraction due to AI remains a hypothesis rather than an established mechanism.</p><h3>3. Stock changes do not establish incumbent downgrading</h3><p>The linked Q5 FT-to-PT rate is descriptively stable at 3.669% before and 3.645% after the transition. ACS PT employment also declines. Thus, weaker FT stocks cannot be translated into a claim that the same exposed workers moved into PT. SIPP enables hours and income tracking, but sparse young Q5 cohorts, survivor selection, and the distinction between monthly hours intensity and usual schedule constrain inference. FT/PT does not identify permanent versus fixed-term contracts. Rising annual salary among employed wage workers can reflect selection, hours, and composition; it does not establish improved welfare for all exposed youth.</p><h3>4. Statistical evidence and AI causal effects remain distinct</h3><p>The controlled symmetric-window CPS FT contrast remains −6.60% (95% interval, −13.22% to +0.53%; raw p=.069; 12-test Holm p=.756). The 36-month estimate is −1.82% (p=.618), and adding a Q5 trend gives −1.25% (p=.821). None of the 12 primary monthly CPS contrasts survives correction. The global post-period Wald test has p=.324 and the occupation-score multiplier diagnostic p=.318. The youth non-pandemic pretrend test has raw p=.029 and Holm p=.353; nonrejection after adjustment is not proof of parallel trends.</p><p>ACS replicate intervals quantify annual sampling uncertainty conditional on the score and bridge. The map's household-cluster working intervals do not reconstruct the full CPS survey design or occupational common shocks. Linked-CPS IPW assumes response on observed covariates and its descriptive rates do not include propensity-estimation inference. Administrative models have only 12 industry clusters and three treated groups. Public age categories, outcome definitions, source coverage, pandemic recovery, industry demand, and exposure versus actual adoption remain substantive limits. Neither numerical reproducibility nor statistically detectable annual relative changes establish an AI causal effect.</p><p><a href="downloads/public-validation-20261126/REPORT_EN.md">Integrated validation report</a> · <a href="downloads/SYMMETRIC_VALIDATION_REPORT_EN.md">Controlled monthly CPS validation</a> · <a href="downloads/public-validation-20261126/admin/ADMIN_EXTENDED_PRE_REPORT_EN.md">Extended administrative checks</a></p>"""
        )
    )
    materials = soup.find(id="materials")
    previous_materials = soup.find(id="public-validation-materials")
    if previous_materials:
        previous_materials.decompose()
    materials.h2.insert_after(
        fragment(
            """<div id="public-validation-materials"><h3>New public-data validation and three-year state estimates</h3><p><a href="downloads/public-validation-20261126/REPORT_EN.md">Integrated English report</a> · <a href="downloads/public-validation-materials-20261126.zip">Code, aggregate outputs, and source inventories</a> · <a href="downloads/public-validation-20261126/BUNDLE_FRESH_SMOKE_CHECKS.json">Final data-I/O checks</a></p><ul><li><a href="downloads/public-validation-20261126/state/pooled_state_rates_working_uncertainty.csv">CPS state estimates and working uncertainty</a></li><li><a href="downloads/public-validation-20261126/acs/acs_pooled_relative_changes.csv">ACS pooled relative and own-group changes</a></li><li><a href="downloads/public-validation-20261126/longitudinal/cps_entry_rates_pooled.csv">CPS entry opportunities and response-weight sensitivity</a></li><li><a href="downloads/public-validation-20261126/longitudinal/cps_transition_rates_pooled.csv">CPS incumbent transitions</a></li><li><a href="downloads/public-validation-20261126/longitudinal/sipp_person_year_outcomes.csv">SIPP personal hours and real-income histories</a></li><li><a href="downloads/public-validation-20261126/admin/administrative_primary_results.csv">Administrative primary estimates</a> · <a href="downloads/public-validation-20261126/admin/extended_pre_2017_results.csv">Extended preperiod</a></li></ul></div>"""
        )
    )
    soup.select_one(".footer-inner p").string = (
        "Youngsam Chun · Exploratory U.S. labor-market research · November 26, 2026"
    )
    for script in soup.find_all("script", src=True):
        if script["src"].startswith("state-map.js"):
            script["src"] = (
                "state-map.js?v="
                + hashlib.sha256((SITE / "state-map.js").read_bytes()).hexdigest()[:12]
            )
    for link in soup.find_all("link", href=True):
        if link["href"].startswith("state-map.css"):
            link["href"] = (
                "state-map.css?v=" + hashlib.sha256(css.read_bytes()).hexdigest()[:12]
            )
    html_path.write_text(str(soup))
    print(
        f"Prepared {len(payload['rates'])} state-period estimates and English evidence sections"
    )


if __name__ == "__main__":
    main()
