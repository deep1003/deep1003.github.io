"""Save a scientific map from verified aggregates without displaying figures."""

from pathlib import Path
import json
import re

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.patches import Polygon
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "outputs/US_Public_Validation_20261126/state"


def main():
    geometry = json.loads(
        (ROOT / "outputs/US_State_Map_20261126/state_map.json").read_text()
    )["states"]
    data = pd.read_csv(OUT / "pooled_state_rates_working_uncertainty.csv")
    d = data[
        (data.period == "latest_36_calendar_months")
        & (data.outcome == "FT")
        & (data.band == "Q5")
        & (data.denominator == "all_age_population")
        & (data.GESTFIPS != 0)
    ].set_index("GESTFIPS")
    assert len(d) == len(geometry) == 51
    cmap = LinearSegmentedColormap.from_list(
        "THAIE", ["#FFF7F5", "#F5CDD0", "#E79AA6", "#CF6479", "#AB3C56", "#7C2038"]
    )
    norm = Normalize(0, 25)
    plt.rcParams.update(
        {"font.family": "DejaVu Sans", "font.size": 10, "svg.fonttype": "none"}
    )
    fig, ax = plt.subplots(figsize=(12, 8))
    fig.subplots_adjust(left=0.025, right=0.975, top=0.82, bottom=0.16)
    for state in geometry:
        value = d.loc[state["fips"], "estimate_pct"]
        for part in re.findall(r"M([^Z]+) Z", state["path"]):
            points = np.array(
                [list(map(float, p.split(","))) for p in part.split(" L")]
            )
            ax.add_patch(
                Polygon(
                    points,
                    closed=True,
                    facecolor=cmap(norm(value)),
                    edgecolor="white",
                    linewidth=0.65,
                )
            )
        if state["abbr"] not in {"DC", "DE", "RI", "CT", "MA", "NJ"}:
            ax.text(
                *state["label"],
                state["abbr"],
                ha="center",
                va="center",
                fontsize=7,
                color="#343B41",
            )
    ax.set(xlim=(0, 960), ylim=(660, 0), aspect="equal")
    ax.axis("off")
    fig.text(
        0.04,
        0.95,
        "Young workers in high-THAIE occupations",
        fontsize=19,
        weight="bold",
        color="#27313A",
    )
    fig.text(
        0.04,
        0.906,
        "Full-time employment / all civilian noninstitutional residents aged 22–25",
        fontsize=11,
        color="#55616C",
    )
    fig.text(
        0.04,
        0.872,
        "November 2023–October 2026 · 35 observed months · 50 states and DC",
        fontsize=10,
        color="#55616C",
    )
    cax = fig.add_axes([0.25, 0.15, 0.5, 0.022])
    bar = fig.colorbar(
        plt.cm.ScalarMappable(norm=norm, cmap=cmap),
        cax=cax,
        orientation="horizontal",
        ticks=np.arange(0, 26, 5),
    )
    bar.ax.set_xticklabels([f"{v}%" for v in range(0, 26, 5)])
    bar.outline.set_visible(False)
    fig.text(
        0.04,
        0.082,
        "National pooled rate 10.61% · 15,447 Q5 full-time person-month records; state minimum 89",
        fontsize=10,
        color="#343B41",
    )
    fig.text(
        0.04,
        0.045,
        "Period averages, not 2026-only rates. October 2025 is unobserved. Repeated respondents are included.\nThe denominator includes nonworkers. This is not the full-time share within Q5; uncertainty is in the accompanying table.",
        fontsize=8.5,
        color="#66717C",
        linespacing=1.5,
    )
    for extension in ["svg", "png"]:
        fig.savefig(
            OUT / f"Q5_youth_fulltime_three_year_map.{extension}",
            dpi=220,
            facecolor="white",
        )
    plt.close(fig)
    assert not plt.get_fignums()
    print("Saved map files; no figure displayed")


if __name__ == "__main__":
    main()
