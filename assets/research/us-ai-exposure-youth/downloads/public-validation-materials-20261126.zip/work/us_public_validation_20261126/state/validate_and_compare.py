"""Check cached CPS totals and compute unadjusted pooled contrasts; no plots."""

from pathlib import Path
import json
import hashlib

import numpy as np
import pandas as pd
from scipy.stats import t

from build_pooled import PERIODS, ROOT, WORK, OUT


def main():
    frames, checks = [], []
    for cache in sorted(WORK.glob("youth_*.parquet")):
        d = pd.read_parquet(cache)
        provenance = json.loads(cache.with_suffix(".json").read_text())
        assert (
            provenance["cache_sha256"] == hashlib.sha256(cache.read_bytes()).hexdigest()
        )
        year, month = map(int, cache.stem.split("_")[1:])
        old = pd.read_parquet(
            ROOT
            / f"work/us_cps_only_monthly_did_20261125/states_{year}_{month:02}.parquet"
        )
        old = (
            old[old.age.eq("22–25") & old.band.eq("Q5")]
            .groupby("GESTFIPS")[["FT", "PT"]]
            .sum()
        )
        new = d.groupby("GESTFIPS")[["Q5_FT", "Q5_PT"]].sum()
        error = max(
            float(
                (new[f"Q5_{x}"] - old[x].reindex(new.index, fill_value=0)).abs().max()
            )
            for x in ["FT", "PT"]
        )
        pop = pd.read_parquet(
            ROOT
            / f"work/us_cps_only_monthly_did_20261125/population_{year}_{month:02}.parquet"
        )
        poperror = abs(float(d.P.sum() - pop.loc[pop.age.eq("22–25"), "P"].sum()))
        assert error < 1e-5 and poperror < 1e-5
        lower = pd.read_parquet(
            ROOT
            / f"work/us_cps_only_monthly_did_20261125/states_{year}_{month:02}.parquet"
        )
        lower = (
            lower[lower.age.eq("22–25") & lower.band.eq("Q1–Q4")]
            .groupby("GESTFIPS")[["FT", "PT"]]
            .sum()
        )
        current_lower = d.groupby("GESTFIPS")[["Q1_4_FT", "Q1_4_PT"]].sum()
        lower_error = max(
            float(
                (
                    current_lower[f"Q1_4_{x}"]
                    - lower[x].reindex(current_lower.index, fill_value=0)
                )
                .abs()
                .max()
            )
            for x in ["FT", "PT"]
        )
        assert lower_error < 1e-5
        for band in ["Q5", "Q1_4"]:
            assert np.allclose(
                d[f"{band}_PT_econ"],
                d.E * d[f"{band}_fraction"] * d.PRWKSTAT.isin([3, 6]),
            )
            assert np.allclose(
                d[f"{band}_FT"], d.E * d[f"{band}_fraction"] * d.PRFTLF.eq(1)
            )
        assert not d.duplicated(["date", "person_key"]).any()
        assert np.allclose(d.Q5_FT + d.Q5_PT, d.Q5_E)
        assert np.allclose(d.Q1_4_FT + d.Q1_4_PT, d.Q1_4_E)
        frames.append(d)
        checks.append(
            dict(
                date=d.date.iloc[0],
                state_numerator_max_difference=error,
                lower_band_numerator_max_difference=lower_error,
                national_population_difference=poperror,
            )
        )
    all_data = pd.concat(frames, ignore_index=True)
    pairs = [
        ("symmetric_pre", "symmetric_post"),
        ("symmetric_pre", "latest_36_calendar_months"),
        ("pre_pandemic_2017_2019", "latest_36_calendar_months"),
    ]
    rows = []
    for pre, post in pairs:
        a = all_data[all_data.date.between(*PERIODS[pre])]
        b = all_data[all_data.date.between(*PERIODS[post])]
        for state in [0, *sorted(all_data.GESTFIPS.unique())]:
            ga = a if state == 0 else a[a.GESTFIPS.eq(state)]
            gb = b if state == 0 else b[b.GESTFIPS.eq(state)]
            for outcome in ["FT", "PT", "PT_econ"]:
                na = ga[f"Q5_{outcome}"].sum()
                nb = gb[f"Q5_{outcome}"].sum()
                ma = ga[f"Q1_4_{outcome}"].sum()
                mb = gb[f"Q1_4_{outcome}"].sum()
                if min(na, nb, ma, mb) <= 0:
                    continue
                # The number of observed months cancels within each Q5/Q1–4 ratio.
                effect = np.log(nb / mb) - np.log(na / ma)
                sa = (
                    (ga[f"Q5_{outcome}"] / na - ga[f"Q1_4_{outcome}"] / ma)
                    .groupby(ga.household)
                    .sum()
                )
                sb = (
                    (gb[f"Q5_{outcome}"] / nb - gb[f"Q1_4_{outcome}"] / mb)
                    .groupby(gb.household)
                    .sum()
                )
                score = sb.subtract(sa, fill_value=0)
                k = len(score)
                se = np.sqrt(k / (k - 1) * score.pow(2).sum())
                critical = t.ppf(0.975, k - 1)
                minimum_events = min(
                    int(v[f"{band}_{outcome}"].gt(0).sum())
                    for v in [ga, gb]
                    for band in ["Q5", "Q1_4"]
                )
                ci_status = "working_household_cluster"
                if minimum_events < 5 or se == 0:
                    ci_status = "withheld_sparse_or_degenerate"
                    se = np.nan
                rows.append(
                    dict(
                        pre_period=pre,
                        post_period=post,
                        GESTFIPS=int(state),
                        outcome=outcome,
                        relative_change_pct=100 * np.expm1(effect),
                        working_log_SE=se,
                        working_CI_low_pct=100 * np.expm1(effect - critical * se),
                        working_CI_high_pct=100 * np.expm1(effect + critical * se),
                        working_p=2 * t.sf(abs(effect / se), k - 1),
                        households=k,
                        causal_estimate=False,
                        minimum_numerator_records=minimum_events,
                        CI_status=ci_status,
                        interpretation="Unadjusted pooled Q5/Q1–Q4 relative employment change; no covariate or occupation-shock adjustment",
                    )
                )
    result = pd.DataFrame(rows)
    result["multiplicity_family"] = np.where(
        result.GESTFIPS.eq(0),
        "national_descriptive_contrasts",
        "state_descriptive_contrasts",
    )
    result["working_p_Holm"] = np.nan
    for _, family in result.groupby("multiplicity_family"):
        order = family.working_p.dropna().sort_values().index
        planned_tests = 9 if family.GESTFIPS.eq(0).all() else 459
        adjusted = np.minimum(
            1,
            np.maximum.accumulate(
                result.loc[order, "working_p"].to_numpy()
                * (planned_tests - np.arange(len(order)))
            ),
        )
        result.loc[order, "working_p_Holm"] = adjusted
    result["outcome_definition"] = result.outcome.map(
        {
            "FT": "Usual full-time employment",
            "PT": "Usual part-time employment",
            "PT_econ": "Economic short actual hours; PRWKSTAT 3/6 includes usual full-time workers",
        }
    )
    result.to_csv(OUT / "unadjusted_relative_changes.csv", index=False)
    (OUT / "FRESH_SMOKE_CHECKS.json").write_text(
        json.dumps(
            dict(
                passed=True,
                months=len(checks),
                monthly_checks=checks,
                images_rendered=0,
            ),
            indent=2,
        )
    )
    print(
        f"Passed {len(checks)} month numerator/denominator checks; {len(rows)} descriptive contrasts; no figure output"
    )


if __name__ == "__main__":
    main()
