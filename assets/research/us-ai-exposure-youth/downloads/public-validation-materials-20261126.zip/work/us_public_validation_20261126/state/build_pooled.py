"""Pool observed CPS records; report household-cluster working uncertainty.

No figure rendering. Working covariance accounts for repeated household IDs,
but cannot recover confidential CPS strata/PSUs and is not official design SE.
"""

from pathlib import Path
import importlib.util
import hashlib
import json

import numpy as np
import pandas as pd
from scipy.stats import t

ROOT = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
OUT = ROOT / "outputs/US_Public_Validation_20261126/state"
OUT.mkdir(parents=True, exist_ok=True)
MANIFEST = (
    ROOT / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json"
)
PARSER = (
    ROOT
    / "outputs/US_THAIE_Regional_Youth_20261122/panel_fe3_20261122/scripts/prepare_panel.py"
)
SCORES = (
    ROOT
    / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/frozen_THAIE_occupation_assignments.csv"
)
BRIDGE = (
    ROOT
    / "outputs/US_THAIE_Regional_Youth_20261122/extension_2019/derived/occupation_conversion_2010_2018.csv"
)
PERIODS = {
    "pre_pandemic_2017_2019": ("2017-01", "2019-12"),
    "symmetric_pre": ("2019-11", "2022-10"),
    "symmetric_post": ("2022-12", "2025-11"),
    "latest_36_calendar_months": ("2023-11", "2026-10"),
}


def collect():
    records = json.loads(MANIFEST.read_text())
    lookup = {(r["year"], r["month"]): r for r in records if r.get("available", True)}
    spec = importlib.util.spec_from_file_location("pooled_parser", PARSER)
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    parser.FIELDS += ["HRHHID", "HRHHID2", "PULINENO"]
    parser.source = lambda y, m: (
        Path(lookup[y, m]["path"]),
        Path(lookup[y, m]["dictionary"]),
    )
    scores = pd.read_csv(SCORES)
    assert not scores.occ.duplicated().any()
    conversion = pd.read_csv(BRIDGE).merge(
        scores[["occ", "THAIE_q"]],
        left_on="new",
        right_on="occ",
        how="left",
        validate="many_to_one",
    )
    assert np.allclose(conversion.groupby("old").rate.sum(), 1, atol=1e-5)
    pre_fractions = {}
    for band, mask in [
        ("Q5", conversion.THAIE_q.eq(5)),
        ("Q1_4", conversion.THAIE_q.between(1, 4)),
    ]:
        pre_fractions[band] = conversion[mask].groupby("old").rate.sum()
    signature = hashlib.sha256(
        Path(__file__).read_bytes()
        + SCORES.read_bytes()
        + BRIDGE.read_bytes()
        + PARSER.read_bytes()
    ).hexdigest()
    audits, pieces = [], []
    for (year, month), rec in sorted(lookup.items()):
        if not 2017 <= year <= 2026:
            continue
        cache = WORK / f"youth_{year}_{month:02}.parquet"
        audit_path = cache.with_suffix(".json")
        dictionary_sha256 = hashlib.sha256(
            Path(rec["dictionary"]).read_bytes()
        ).hexdigest()
        if (
            cache.exists()
            and audit_path.exists()
            and json.loads(audit_path.read_text()).get("pipeline_signature")
            == signature
            and json.loads(audit_path.read_text()).get("dictionary_sha256")
            == dictionary_sha256
            and json.loads(audit_path.read_text()).get("cache_sha256")
            == hashlib.sha256(cache.read_bytes()).hexdigest()
        ):
            d = pd.read_parquet(cache)
            audit = json.loads(audit_path.read_text())
            assert audit["sha256"] == rec["sha256"]
        else:
            d, audit = parser.read(year, month)
            assert audit["sha256"] == rec["sha256"]
            d = d[d.PRTAGE.between(22, 25)].copy()
            if year < 2020:
                for band in ["Q5", "Q1_4"]:
                    d[f"{band}_fraction"] = d.occ.map(pre_fractions[band]).fillna(0)
            else:
                d = d.merge(
                    scores[["occ", "THAIE_q"]],
                    on="occ",
                    how="left",
                    validate="many_to_one",
                )
                d["Q5_fraction"] = d.THAIE_q.eq(5).astype(float)
                d["Q1_4_fraction"] = d.THAIE_q.between(1, 4).astype(float)
            d["date"] = f"{year}-{month:02}"
            d["household"] = (
                d.GESTFIPS.astype(str)
                + ":"
                + d.HRHHID.astype(str)
                + ":"
                + d.HRHHID2.astype(str)
            )
            d["person_key"] = d.household + ":" + d.PULINENO.astype(str)
            assert not d.duplicated(["date", "person_key"]).any()
            for band in ["Q5", "Q1_4"]:
                for status in ["E", "FT", "PT", "PT_econ"]:
                    d[f"{band}_{status}"] = d[status] * d[f"{band}_fraction"]
            keep = [
                "GESTFIPS",
                "date",
                "household",
                "person_key",
                "P",
                "E",
                "FT",
                "PT",
                "occ",
                "PRFTLF",
                "PRWKSTAT",
                "Q5_fraction",
                "Q1_4_fraction",
            ]
            keep += [
                f"{band}_{status}"
                for band in ["Q5", "Q1_4"]
                for status in ["E", "FT", "PT", "PT_econ"]
            ]
            d[keep].to_parquet(cache, index=False)
            audit["pipeline_signature"] = signature
            audit["dictionary_sha256"] = dictionary_sha256
            audit["cache_sha256"] = hashlib.sha256(cache.read_bytes()).hexdigest()
            audit_path.write_text(json.dumps(audit, indent=2))
            d = d[keep]
        pieces.append(d)
        audits.append(
            {"date": f"{year}-{month:02}", "sha256": audit["sha256"], "records": len(d)}
        )
        print(f"Validated {year}-{month:02}", flush=True)
    return pd.concat(pieces, ignore_index=True), audits


def ratio(g, numerator, denominator):
    n, den = float(g[numerator].sum()), float(g[denominator].sum())
    estimate = n / den if den else np.nan
    score = (g[numerator] - estimate * g[denominator]).groupby(g.household).sum()
    k = len(score)
    variance = (
        k / (k - 1) * float(score.pow(2).sum()) / den**2 if k > 1 and den else np.nan
    )
    se = np.sqrt(variance)
    critical = t.ppf(0.975, k - 1) if k > 1 else np.nan
    numerator_records = int(g[numerator].gt(0).sum())
    ci_status = "working_household_cluster"
    if numerator_records < 5 or not np.isfinite(se) or se == 0:
        ci_status = "withheld_sparse_or_degenerate"
        se = np.nan
    return dict(
        estimate_pct=100 * estimate,
        working_SE_pp=100 * se,
        working_CI_low_pct=100 * (estimate - critical * se),
        working_CI_high_pct=100 * (estimate + critical * se),
        working_RSE_pct=100 * se / estimate if estimate > 0 else np.nan,
        households=k,
        numerator_records=numerator_records,
        denominator_records=int(g[denominator].gt(0).sum()),
        person_keys=int(g.person_key.nunique()),
        CI_status=ci_status,
    )


def main():
    d, audits = collect()
    rows, coverage = [], []
    for period, (start, end) in PERIODS.items():
        p = d[d.date.between(start, end)]
        observed = sorted(p.date.unique())
        requested = pd.period_range(start, end, freq="M").astype(str).tolist()
        missing = sorted(set(requested) - set(observed))
        coverage.append(
            dict(
                period=period,
                start=start,
                end=end,
                calendar_months=len(requested),
                observed_months=len(observed),
                missing=missing,
            )
        )
        for state, g in [(0, p), *list(p.groupby("GESTFIPS"))]:
            for band in ["Q5", "Q1_4"]:
                for status in ["FT", "PT", "PT_econ"]:
                    numerator = f"{band}_{status}"
                    for denominator, label in [
                        ("P", "all_age_population"),
                        (f"{band}_E", "same_band_employed"),
                    ]:
                        r = ratio(g, numerator, denominator)
                        rows.append(
                            dict(
                                period=period,
                                GESTFIPS=int(state),
                                band=band,
                                outcome=status,
                                denominator=label,
                                observed_months=len(observed),
                                average_monthly_numerator=g[numerator].sum()
                                / len(observed),
                                average_monthly_denominator=g[denominator].sum()
                                / len(observed),
                                **r,
                            )
                        )
    result = pd.DataFrame(rows)
    assert result.estimate_pct.between(0, 100).all()
    assert len(result) == len(PERIODS) * 52 * 2 * 3 * 2
    result.to_csv(OUT / "pooled_state_rates_working_uncertainty.csv", index=False)
    d.groupby(["date", "GESTFIPS"])[
        ["P", "Q5_FT", "Q5_PT", "Q1_4_FT", "Q1_4_PT"]
    ].sum().to_csv(OUT / "observed_monthly_totals.csv")
    q5 = result[
        (result.band == "Q5")
        & (result.outcome == "FT")
        & (result.denominator == "all_age_population")
    ]
    support = (
        q5[q5.GESTFIPS.ne(0)]
        .groupby("period")
        .agg(
            states=("GESTFIPS", "size"),
            minimum_records=("numerator_records", "min"),
            median_records=("numerator_records", "median"),
            maximum_working_RSE_pct=("working_RSE_pct", "max"),
        )
    )
    support.to_csv(OUT / "sample_support.csv")
    checks = dict(
        passed=True,
        periods=coverage,
        raw_months=len(audits),
        rows=len(result),
        missing_months_not_imputed=True,
        CI_method="Household-ID clustered ratio linearization; working uncertainty, not full CPS survey-design inference",
        source_audit=audits,
    )
    (OUT / "VALIDATION.json").write_text(json.dumps(checks, indent=2))
    print(support.to_string())


if __name__ == "__main__":
    main()
