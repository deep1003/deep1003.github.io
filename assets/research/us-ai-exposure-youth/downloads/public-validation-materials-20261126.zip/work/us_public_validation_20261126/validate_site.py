"""Check publication content, links, aggregates and compressed scope; no images."""

from pathlib import Path
import hashlib
import json
import re
import zipfile

from bs4 import BeautifulSoup
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/US_Public_Validation_20261126"
SITE = ROOT / "work/homepage-expert-review/assets/research/us-ai-exposure-youth"


def main():
    soup = BeautifulSoup((SITE / "index.html").read_text(), "html.parser")
    sections = [s["id"] for s in soup.select("main > section")]
    assert sections[0] == "state-overview"
    ids = [x["id"] for x in soup.select("[id]")]
    assert len(ids) == len(set(ids))
    assert soup.find(id="state-youth-map").has_attr("open")
    assert [x.get("id") for x in soup.select("#results details[open]")] == [
        "public-validation-results"
    ]
    assert len(soup.select("#discussion h3")) == 4
    assert not re.search(r"[가-힣]", soup.get_text())
    assert "−7.41%" in soup.find(id="public-validation-results").get_text()
    assert "−1.24%" in soup.find(id="public-validation-results").get_text()
    assert "3.669%" in soup.find(id="discussion").get_text()
    linked = []
    for a in soup.select("a[href]"):
        href = a["href"]
        if href.startswith(
            ("downloads/public-validation", "figures/Q5_youth_fulltime_three_year_map")
        ):
            path = SITE / href.split("#")[0]
            assert path.is_file() and path.stat().st_size > 0, href
            linked.append(href)
    payload = json.loads((SITE / "data/state-youth-pooled-map.json").read_text())
    assert len(payload["states"]) == 51 and len(payload["rates"]) == 204
    raw = pd.read_csv(OUT / "state/pooled_state_rates_working_uncertainty.csv")
    expected = raw[
        raw.outcome.eq("FT")
        & raw.band.eq("Q5")
        & raw.denominator.eq("all_age_population")
    ].set_index(["period", "GESTFIPS"])
    for row in payload["rates"] + payload["national"]:
        target = expected.loc[row["period"], row["GESTFIPS"]]
        assert abs(target.estimate_pct - row["estimate_pct"]) < 1e-8
        assert int(target.numerator_records) == row["numerator_records"]
    copied = []
    for p in (SITE / "downloads/public-validation-20261126").rglob("*"):
        if p.is_file():
            source = OUT / p.relative_to(SITE / "downloads/public-validation-20261126")
            assert p.read_bytes() == source.read_bytes(), str(p)
            copied.append(str(p.relative_to(SITE)))
    with zipfile.ZipFile(
        SITE / "downloads/public-validation-materials-20261126.zip"
    ) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert not any(x.startswith("work/") and x.endswith(".parquet") for x in names)
        assert all(
            x.startswith(
                (
                    "outputs/US_Public_Validation_20261126/",
                    "work/us_public_validation_20261126/",
                )
            )
            or x == "README.txt"
            for x in names
        )
    for script in soup.select('script[src^="state-map.js"]'):
        assert (
            hashlib.sha256((SITE / "state-map.js").read_bytes()).hexdigest()[:12]
            in script["src"]
        )
    result = dict(
        passed=True,
        first_section=sections[0],
        state_period_rows=204,
        duplicate_ids=0,
        linked_files=len(linked),
        byte_identical_copied_files=len(copied),
        source_rates_reproduced=True,
        archive_integrity=True,
        working_microdata_excluded=True,
        figures_displayed=0,
    )
    (OUT / "SITE_PUBLICATION_CHECKS.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result))


if __name__ == "__main__":
    main()
