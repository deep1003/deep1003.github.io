"""Fresh adjacent-month CPS linkage and response adjustment. No chart output."""

from pathlib import Path
import importlib.util, json
import numpy as np, pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LogisticRegression

R = Path(__file__).resolve().parents[3]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Public_Validation_20261126/longitudinal"
O.mkdir(exist_ok=True, parents=True)
s = importlib.util.spec_from_file_location(
    "parser",
    R
    / "outputs/US_THAIE_Regional_Youth_20261122/panel_fe3_20261122/scripts/prepare_panel.py",
)
p = importlib.util.module_from_spec(s)
s.loader.exec_module(p)
p.FIELDS += ["HRHHID", "HRHHID2", "PULINENO"]
manifest = json.loads(
    (
        R / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json"
    ).read_text()
)
records = {
    (r["year"], r["month"]): r for r in manifest if r["year"] >= 2020 and "path" in r
}
p.source = lambda y, m: (Path(records[y, m]["path"]), Path(records[y, m]["dictionary"]))
KEY = ["HRHHID", "HRHHID2", "PULINENO"]
scores = (
    pd.read_csv(
        R
        / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/frozen_THAIE_occupation_assignments.csv"
    )
    .set_index("occ")
    .THAIE_q
)
AGES = ["16–21", "22–25", "26–30", "31–34", "35–40", "41–49", "50+"]
CAT = [
    "GESTFIPS",
    "agegroup",
    "PESEX",
    "PEEDUCA",
    "PTDTRACE",
    "PEHSPNON",
    "PEMLR",
    "HRMIS",
    "HRMONTH",
    "PRMJIND1",
    "exposure",
]


def read(y, m):
    d, _ = p.read(y, m)
    oc = "PTIO1OCD" if "PTIO1OCD" in d else "PEIO1OCD"
    d["exposure"] = d[oc].map(scores).fillna(0).astype(int)
    d["date"] = f"{y}-{m:02d}-01"
    return d


parts = []
pairaudit = []
prev = None
for y, m in sorted(records):
    cache = W / f"eligible_{y}_{m:02d}.parquet"
    if cache.exists():
        prev = None
        continue
    cur = read(y, m)
    prior = pd.Timestamp(y, m, 1) - pd.offsets.MonthBegin(1)
    if (prior.year, prior.month) not in records:
        prev = cur
        continue
    if prev is None or prev.date.iloc[0] != str(prior.date()):
        prev = read(prior.year, prior.month)
    left = prev[prev.HRMIS.isin([1, 2, 3, 5, 6, 7])].copy()
    dest = cur[
        KEY
        + [
            "HRMIS",
            "PESEX",
            "PTDTRACE",
            "PRTAGE",
            "GESTFIPS",
            "PEMLR",
            "PRFTLF",
            "PRWKSTAT",
            "PEHRUSLT",
            "PEIO1COW",
        ]
    ]
    assert not left.duplicated(KEY).any() and not dest.duplicated(KEY).any()
    d = left.merge(
        dest, on=KEY, how="left", suffixes=("", "_next"), validate="one_to_one"
    )
    d["linked"] = (
        d.PEMLR_next.notna()
        & d.HRMIS_next.eq(d.HRMIS + 1)
        & d.PESEX_next.eq(d.PESEX)
        & d.PTDTRACE_next.eq(d.PTDTRACE)
        & (d.PRTAGE_next - d.PRTAGE).between(0, 1)
        & d.GESTFIPS_next.eq(d.GESTFIPS)
    )
    d["agegroup"] = pd.cut(
        d.PRTAGE, [15, 21, 25, 30, 34, 40, 49, 200], labels=AGES
    ).astype(str)
    d["fold"] = ((d.HRHHID.astype("int64") ^ d.HRHHID2.astype("int64")) % 2).astype(int)
    d["dest_date"] = cur.date.iloc[0]
    keep = list(
        dict.fromkeys(
            KEY
            + CAT
            + [
                "P",
                "PRTAGE",
                "PRCITSHP",
                "PEHRUSLT",
                "PRFTLF",
                "PRWKSTAT",
                "PEIO1COW",
                "linked",
                "fold",
                "date",
                "dest_date",
                "PEMLR_next",
                "PRFTLF_next",
                "PRWKSTAT_next",
                "PEHRUSLT_next",
                "PEIO1COW_next",
            ]
        )
    )
    d[keep].to_parquet(cache, index=False)
    prev = cur
    print("parsed", y, m, len(d), flush=True)
for y in range(2020, 2027):
    fs = sorted(W.glob(f"eligible_{y}_*.parquet"))
    if not fs:
        continue
    d = pd.concat([pd.read_parquet(f) for f in fs], ignore_index=True)
    base = d.P.to_numpy()
    linked = d.linked.to_numpy()
    enc = OneHotEncoder(handle_unknown="ignore")
    x = enc.fit_transform(d[CAT].astype(str))
    prob = np.zeros(len(d))
    iters = []
    for fold in [0, 1]:
        train = d.fold.ne(fold).to_numpy()
        fit = LogisticRegression(C=1, max_iter=100, tol=1e-7, solver="newton-cholesky")
        fit.fit(x[train], linked[train], sample_weight=base[train] / base[train].mean())
        prob[~train] = fit.predict_proba(x[~train])[:, 1]
        iters.append(int(fit.n_iter_[0]))
        assert fit.n_iter_[0] < 100
    d["p_link"] = np.clip(prob, 0.05, 0.995)
    g = d[linked].copy()
    inv = 1 / g.p_link.to_numpy()
    cut = np.quantile(inv, 0.99)
    weights = {
        "origin": g.P.to_numpy(),
        "ipw": g.P.to_numpy() * inv,
        "ipw_trim99": g.P.to_numpy() * np.minimum(inv, cut),
    }
    # Persist identical response weights for downstream outcomes without refitting on outcomes.
    for method, values in weights.items():
        g["weight_" + method] = values
    g.to_parquet(W / f"linked_response_{y}.parquet", index=False)
    g["band"] = np.where(
        g.exposure.eq(5), "Q5", np.where(g.exposure.between(1, 4), "Q1–Q4", "unmapped")
    )
    d["band"] = np.where(
        d.exposure.eq(5), "Q5", np.where(d.exposure.between(1, 4), "Q1–Q4", "unmapped")
    )
    for date, v in d.groupby("date"):
        pairaudit.append(
            dict(
                origin_date=date,
                dest_date=v.dest_date.iloc[0],
                eligible=len(v),
                linked=int(v.linked.sum()),
                weighted_retention=np.average(v.linked, weights=v.P),
                fold_iterations=max(iters),
                p_min=float(v.p_link.min()),
                p_max=float(v.p_link.max()),
            )
        )
    retention = (
        d.groupby(["date", "agegroup", "band"])
        .apply(
            lambda z: pd.Series(
                {
                    "eligible": len(z),
                    "linked": z.linked.sum(),
                    "weighted_retention": np.average(z.linked, weights=z.P),
                }
            ),
        )
        .reset_index()
    )
    retention.to_csv(O / f"cps_retention_{y}.csv", index=False)
    g["period"] = np.select(
        [g.dest_date.le("2022-10-01"), g.date.ge("2022-12-01")],
        ["pre", "post"],
        default="transition_excluded",
    )
    g["FT0"] = g.PEMLR.isin([1, 2]) & g.PRFTLF.eq(1)
    g["PT0"] = g.PEMLR.isin([1, 2]) & g.PRFTLF.eq(2)
    g["emp0"] = g.PEMLR.isin([1, 2])
    g["FT1"] = g.PEMLR_next.isin([1, 2]) & g.PRFTLF_next.eq(1)
    g["PT1"] = g.PEMLR_next.isin([1, 2]) & g.PRFTLF_next.eq(2)
    g["econPT1"] = g.PEMLR_next.isin([1, 2]) & g.PRWKSTAT_next.isin([3, 6])
    g["U1"] = g.PEMLR_next.isin([3, 4])
    g["N1"] = g.PEMLR_next.isin([5, 6, 7])
    g["self1"] = g.PEMLR_next.isin([1, 2]) & g.PEIO1COW_next.isin([6, 7])
    flows = {
        "FT_to_PT": (g.FT0, g.PT1),
        "FT_to_economic_PT": (g.FT0, g.econPT1 & g.PT1),
        "FT_to_economic_short_hours": (g.FT0, g.econPT1),
        "FT_to_U": (g.FT0, g.U1),
        "FT_to_NILF": (g.FT0, g.N1),
        "PT_to_FT": (g.PT0, g.FT1),
        "employee_to_selfemployment": (g.emp0 & g.PEIO1COW.between(1, 5), g.self1),
    }
    rows = []
    for age in ["all16+"] + AGES:
        am = np.ones(len(g), bool) if age == "all16+" else g.agegroup.eq(age).to_numpy()
        for subgroup, sm in [
            ("all", np.ones(len(g), bool)),
            ("women", g.PESEX.eq(2).to_numpy()),
            ("no_BA", g.PEEDUCA.between(31, 42).to_numpy()),
            ("Black", g.PTDTRACE.eq(2).to_numpy()),
            ("Hispanic", g.PEHSPNON.eq(1).to_numpy()),
        ]:
            for band in ["Q5", "Q1–Q4"]:
                for period in ["pre", "post"]:
                    mask = (
                        am
                        & sm
                        & g.band.eq(band).to_numpy()
                        & g.period.eq(period).to_numpy()
                    )
                    for name, (origin, dest) in flows.items():
                        risk = mask & origin.to_numpy()
                        event = risk & dest.to_numpy()
                        if not risk.any():
                            continue
                        for method, w in weights.items():
                            den = w[risk].sum()
                            rows.append(
                                dict(
                                    year=y,
                                    age=age,
                                    subgroup=subgroup,
                                    band=band,
                                    period=period,
                                    transition=name,
                                    method=method,
                                    risk_pairs=int(risk.sum()),
                                    event_pairs=int(event.sum()),
                                    weighted_risk=den,
                                    weighted_events=w[event].sum(),
                                    risk_unique_people=len(
                                        g.loc[risk, KEY].drop_duplicates()
                                    ),
                                    ESS=den**2 / (w[risk] ** 2).sum(),
                                    rate_pct=100 * w[event].sum() / den,
                                )
                            )
    pd.DataFrame(rows).to_csv(O / f"cps_flows_{y}.csv", index=False)
    print("weighted", y, len(d), len(g), max(iters), flush=True)
pd.DataFrame(pairaudit).to_csv(O / "cps_pair_audit.csv", index=False)
flow = pd.concat([pd.read_csv(f) for f in sorted(O.glob("cps_flows_*.csv"))])
flow.to_csv(O / "cps_transition_rates_by_year.csv", index=False)
keys = ["age", "subgroup", "band", "period", "transition", "method"]
summary = flow.groupby(keys, as_index=False)[
    ["risk_pairs", "event_pairs", "weighted_risk", "weighted_events"]
].sum()
summary["rate_pct"] = 100 * summary.weighted_events / summary.weighted_risk
summary.to_csv(O / "cps_transition_rates_pooled.csv", index=False)
assert all(
    (pd.to_datetime(x.dest_date) - pd.to_datetime(x.origin_date)).days
    in [28, 29, 30, 31]
    for x in pd.DataFrame(pairaudit).itertuples()
)
(O / "cps_link_validation.json").write_text(
    json.dumps(
        {
            "passed": True,
            "adjacent_pairs": len(pairaudit),
            "periods": "pre through destinationOct2022; post originDec2022 onward; transition pairs excluded",
            "no_interpolation": True,
            "IPW": "cross-fitted household folds yearly, probability clipping.05/.995,99th inverse probability trimming sensitivity",
            "variance": "descriptive, no independent-person or causal claim; within-year unique counts not summed as unique persons",
        },
        indent=2,
    )
)
