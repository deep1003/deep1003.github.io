"""Entry outcomes among observed jobless origins, reusing the adaptation response weights."""

from pathlib import Path
import hashlib, importlib.util, json
import numpy as np, pandas as pd

R = Path(__file__).resolve().parents[3]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Public_Validation_20261126/longitudinal"
KEY = ["HRHHID", "HRHHID2", "PULINENO"]
s = importlib.util.spec_from_file_location(
    "raw_parser",
    R
    / "outputs/US_THAIE_Regional_Youth_20261122/panel_fe3_20261122/scripts/prepare_panel.py",
)
p = importlib.util.module_from_spec(s)
s.loader.exec_module(p)
p.FIELDS += KEY
manifest = json.loads(
    (
        R / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json"
    ).read_text()
)
records = {
    (r["year"], r["month"]): r for r in manifest if r["year"] >= 2020 and "path" in r
}
p.source = lambda y, m: (Path(records[y, m]["path"]), Path(records[y, m]["dictionary"]))
scores = (
    pd.read_csv(
        R
        / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/frozen_THAIE_occupation_assignments.csv"
    )
    .set_index("occ")
    .THAIE_q
)
rows = []
audit = []
for year in range(2020, 2027):
    g = pd.read_parquet(W / f"linked_response_{year}.parquet")
    g = g[g.PEMLR.isin([3, 4, 5, 6, 7])].copy()
    g["period"] = np.select(
        [g.dest_date.le("2022-10-01"), g.date.ge("2022-12-01")],
        ["pre", "post"],
        default="transition_excluded",
    )
    pieces = []
    for date, z in g.groupby("dest_date"):
        y, m = map(int, date[:7].split("-"))
        cache = W / f"destination_occupation_{y}_{m:02d}.parquet"
        if not cache.exists():
            cur, _ = p.read(y, m)
            oc = "PTIO1OCD" if "PTIO1OCD" in cur else "PEIO1OCD"
            cur["destination_THAIE_q"] = cur[oc].map(scores).fillna(0).astype(int)
            cur = cur[KEY + ["destination_THAIE_q", "PRTAGE"]].rename(
                columns={"PRTAGE": "destination_age"}
            )
            assert not cur.duplicated(KEY).any()
            cur.to_parquet(cache, index=False)
        cur = pd.read_parquet(cache)
        zz = z.merge(cur, on=KEY, how="left", validate="one_to_one")
        assert zz.destination_THAIE_q.notna().all()
        pieces.append(zz)
    g = pd.concat(pieces, ignore_index=True)
    employed = g.PEMLR_next.isin([1, 2])
    ft = employed & g.PRFTLF_next.eq(1)
    pt = employed & g.PRFTLF_next.eq(2)
    high = g.destination_THAIE_q.eq(5)
    low = g.destination_THAIE_q.between(1, 4)
    unknown = g.destination_THAIE_q.eq(0)
    outcomes = {
        "Q5_FT": high & ft,
        "Q1–Q4_FT": low & ft,
        "Q5_PT": high & pt,
        "Q1–Q4_PT": low & pt,
        "unmapped_employment": unknown & employed,
        "any_employment": employed,
    }
    partition = sum(v.astype(int) for k, v in outcomes.items() if k != "any_employment")
    assert partition.eq(employed.astype(int)).all()
    for age in ["all16+", "22–25"]:
        am = np.ones(len(g), bool) if age == "all16+" else g.PRTAGE.between(22, 25)
        for origin, om in [
            ("all_jobless", np.ones(len(g), bool)),
            ("unemployed", g.PEMLR.isin([3, 4])),
            ("NILF", g.PEMLR.isin([5, 6, 7])),
        ]:
            for hist, hm in [
                ("all_origins", np.ones(len(g), bool)),
                ("origin_occupation_unassigned", g.exposure.eq(0)),
                ("origin_occupation_assigned", g.exposure.between(1, 5)),
            ]:
                for period in ["pre", "post"]:
                    mask = am & om & hm & g.period.eq(period)
                    n = int(mask.sum())
                    if not n:
                        continue
                    for method in ["origin", "ipw", "ipw_trim99"]:
                        w = g["weight_" + method].to_numpy()
                        den = w[mask].sum()
                        for outcome, event in outcomes.items():
                            events = mask & event
                            rows.append(
                                dict(
                                    year=year,
                                    age=age,
                                    origin_status=origin,
                                    origin_occupation_availability=hist,
                                    period=period,
                                    method=method,
                                    outcome=outcome,
                                    risk_pairs=n,
                                    risk_people=len(g.loc[mask, KEY].drop_duplicates()),
                                    event_pairs=int(events.sum()),
                                    weighted_risk=den,
                                    weighted_events=w[events].sum(),
                                    rate_pct=100 * w[events].sum() / den,
                                    first_job_status="not_identified",
                                )
                            )
    audit.append(
        dict(
            year=year,
            linked_jobless_pairs=len(g),
            age25_to26_pairs=int((g.PRTAGE.eq(25) & g.destination_age.eq(26)).sum()),
            age25_to26_employment_entries=int(
                (g.PRTAGE.eq(25) & g.destination_age.eq(26) & employed).sum()
            ),
            destination_rows_matched=True,
        )
    )
    print("entry", year, len(g), flush=True)
d = pd.DataFrame(rows)
d.to_csv(O / "cps_entry_rates_by_year.csv", index=False)
keys = [
    "age",
    "origin_status",
    "origin_occupation_availability",
    "period",
    "method",
    "outcome",
]
pooled = d.groupby(keys, as_index=False)[
    ["risk_pairs", "event_pairs", "weighted_risk", "weighted_events"]
].sum()
pooled["rate_pct"] = 100 * pooled.weighted_events / pooled.weighted_risk
pooled.to_csv(O / "cps_entry_rates_pooled.csv", index=False)
contrasts = []
for key, z in pooled.groupby(
    ["age", "origin_status", "origin_occupation_availability", "method"]
):
    v = z.set_index(["outcome", "period"]).rate_pct
    for outcome in outcomes:
        if (outcome, "pre") in v and (outcome, "post") in v:
            contrasts.append(
                dict(
                    zip(
                        [
                            "age",
                            "origin_status",
                            "origin_occupation_availability",
                            "method",
                        ],
                        key,
                    )
                )
                | dict(
                    contrast="post_minus_pre",
                    outcome=outcome,
                    change_pp=v[outcome, "post"] - v[outcome, "pre"],
                )
            )
    for status in ["FT", "PT"]:
        hi, lo = "Q5_" + status, "Q1–Q4_" + status
        if all((x, t) in v for x in [hi, lo] for t in ["pre", "post"]):
            contrasts.append(
                dict(
                    zip(
                        [
                            "age",
                            "origin_status",
                            "origin_occupation_availability",
                            "method",
                        ],
                        key,
                    )
                )
                | dict(
                    contrast="difference_of_unadjusted_changes",
                    outcome=status,
                    change_pp=(v[hi, "post"] - v[hi, "pre"])
                    - (v[lo, "post"] - v[lo, "pre"]),
                )
            )
pd.DataFrame(contrasts).to_csv(O / "cps_entry_unadjusted_changes.csv", index=False)
prior = json.loads((W / "pre_entry_replay_hash.json").read_text())
current = hashlib.sha256(
    (O / "cps_transition_rates_pooled.csv").read_bytes()
).hexdigest()
assert prior["cps_transition_rates_pooled.csv"] == current
validation = dict(
    passed=True,
    years=audit,
    adaptation_table_sha_unchanged=True,
    shared_response_weights=True,
    destination_THAIE_is_outcome_not_treatment=True,
    age_at_origin=True,
    first_job_not_identified=True,
    no_causal_or_independent_person_inference=True,
    plots_displayed=False,
)
(O / "cps_entry_validation.json").write_text(json.dumps(validation, indent=2))
print("Entry checks passed", flush=True)
