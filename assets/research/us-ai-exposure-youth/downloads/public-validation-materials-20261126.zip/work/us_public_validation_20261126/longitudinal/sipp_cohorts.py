"""Official 2/3/4-year SIPP risk sets and strictly labelled hours-intensity transitions."""

from pathlib import Path
import json, zipfile, urllib.request, importlib.util
import numpy as np, pandas as pd

R = Path(__file__).resolve().parents[3]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Public_Validation_20261126/longitudinal"
RAW = R / "work/us_longitudinal/raw"
KEY = ["SSUID", "PNUM", "SPANEL"]
scores = (
    pd.read_csv(
        R
        / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/frozen_THAIE_occupation_assignments.csv"
    )
    .set_index("occ")
    .THAIE_q
)
summaries = []
rates = []
audits = []
spec = importlib.util.spec_from_file_location(
    "cpi_source",
    R
    / "outputs/US_THAIE_Regional_Youth_20261122/panel_fe3_20261122/scripts/prepare_panel.py",
)
cp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cp)
cpi = cp.cpi_values()
for length in [2, 3, 4]:
    fn = f"lgtwgt2025yr{length}_csv.zip"
    path = RAW / fn
    if not path.exists():
        urllib.request.urlretrieve(
            "https://www2.census.gov/programs-surveys/sipp/data/datasets/2025/" + fn,
            path,
        )
    with zipfile.ZipFile(path) as z:
        weights = pd.read_csv(
            z.open(z.namelist()[0]),
            sep="|",
            dtype={"SSUID": "string", "ssuid": "string"},
        )
    weights.columns = weights.columns.str.upper()
    weights.SSUID = weights.SSUID.str.zfill(14)
    wt = f"FINYR{length}"
    assert not weights.duplicated(KEY).any()
    assert weights[wt].gt(0).all()
    cols = (
        KEY
        + [
            "MONTHCODE",
            "TAGE_EHC",
            "ESEX",
            "ERACE",
            "EORIGIN",
            "EEDUC",
            "EDISABL",
            "RMESR",
            "RIN_UNIV",
            "TPEARN",
            "TPTOTINC",
        ]
        + [f"TJB{i}_MWKHRS" for i in range(1, 8)]
        + [f"TJB{i}_OCC" for i in range(1, 8)]
        + [f"EJB{i}_JOBID" for i in range(1, 8)]
        + [f"EJB{i}_JBORSE" for i in range(1, 8)]
    )
    frames = []
    for release in range(2026 - length, 2026):
        d = pd.read_parquet(
            R / f"work/us_longitudinal/sipp_{release}.parquet", columns=cols
        )
        d.SSUID = d.SSUID.str.zfill(14)
        d = d.merge(weights, on=KEY, validate="many_to_one")
        d["year"] = release - 1
        frames.append(d)
    d = pd.concat(frames, ignore_index=True)
    assert not d.duplicated(KEY + ["year", "MONTHCODE"]).any()
    d["pid"] = d.SSUID + "_" + d.PNUM.astype(str) + "_" + d.SPANEL.astype(str)
    d["time"] = d.year * 12 + d.MONTHCODE
    d = d.sort_values(["pid", "time"])
    d["valid"] = d.RIN_UNIV.eq(1) & d.RMESR.between(1, 8)
    d["employed"] = d.RMESR.between(1, 5) & d.valid
    hh = d[[f"TJB{i}_MWKHRS" for i in range(1, 8)]].to_numpy()
    hh = np.where(hh >= 0, hh, np.nan)
    known = np.isfinite(hh).any(axis=1)
    d["hours"] = np.nansum(hh, axis=1)
    d.loc[d.employed & ~known, "hours"] = np.nan
    d.loc[~d.valid, "hours"] = np.nan
    d.loc[d.valid & ~d.employed, "hours"] = 0
    active = hh > 0
    arr = d[[f"EJB{i}_JBORSE" for i in range(1, 8)]].to_numpy()
    ids = d[[f"EJB{i}_JOBID" for i in range(1, 8)]].to_numpy()
    oc = d[[f"TJB{i}_OCC" for i in range(1, 8)]].to_numpy()
    best = np.argmax(np.nan_to_num(hh, nan=-1), axis=1)
    rr = np.arange(len(d))
    d["main_occ"] = pd.to_numeric(
        pd.Series(oc[rr, best], index=d.index), errors="coerce"
    )
    d["main_job"] = ids[rr, best]
    d["main_arrangement"] = arr[rr, best]
    d.loc[~active.any(axis=1), ["main_occ", "main_job", "main_arrangement"]] = np.nan
    # Origin exposure is frozen before outcomes in the first reference year.
    baseyear = 2025 - length
    start = d[
        d.year.eq(baseyear) & d.MONTHCODE.le(10) & d.employed & d.main_occ.notna()
    ].copy()
    start["contribution"] = start.hours.clip(lower=0)
    occ = (
        start.groupby(["pid", "main_occ"])
        .contribution.sum()
        .reset_index()
        .sort_values(["pid", "contribution", "main_occ"], ascending=[True, False, True])
        .drop_duplicates("pid")
    )
    occ["THAIE_q"] = occ.main_occ.map(scores)
    b = d[d.year.eq(baseyear) & d.MONTHCODE.eq(10) & d.valid][
        ["pid", "TAGE_EHC", "ESEX", "ERACE", "EORIGIN", "EEDUC", "EDISABL"]
    ].merge(occ[["pid", "THAIE_q"]], on="pid", validate="one_to_one")
    b = b[b.TAGE_EHC.ge(16) & b.THAIE_q.notna()]
    b["age"] = pd.cut(
        b.TAGE_EHC,
        [15, 21, 25, 30, 34, 40, 49, 200],
        labels=["16–21", "22–25", "26–30", "31–34", "35–40", "41–49", "50+"],
    ).astype(str)
    b["band"] = np.where(b.THAIE_q.eq(5), "Q5", "Q1–Q4")
    d = d.merge(
        b[["pid", "age", "band", "ESEX", "EEDUC", "ERACE", "EORIGIN"]],
        on="pid",
        suffixes=("", "_baseline"),
        validate="many_to_one",
    )
    d = d.sort_values(["pid", "time"])
    prev = d.groupby("pid")[
        ["time", "hours", "valid", "employed", "RMESR", "main_job", "main_arrangement"]
    ].shift()
    adj = d.time.eq(prev.time + 1) & d.valid & prev.valid.eq(True)
    # Begin longitudinal risk set AFTER the exposure construction period; never use a future occupation.
    adj &= d.time.gt(baseyear * 12 + 10)
    d["origin_full_intensity"] = prev.employed.eq(True) & prev.hours.ge(35)
    d["dest_part_intensity"] = d.employed & d.hours.between(0, 35, inclusive="left")
    d["dest_nonemployment"] = d.valid & ~d.employed
    d["same_job_full_month"] = (
        prev.RMESR.eq(1)
        & d.RMESR.eq(1)
        & d.main_job.notna()
        & d.main_job.eq(prev.main_job)
    )
    d["employee0"] = prev.main_arrangement.eq(1)
    d["destination_hours_known"] = d.hours.notna()
    d["destination_arrangement_known"] = ~d.employed | d.main_arrangement.isin(
        [1, 2, 3]
    )
    d["self1"] = d.main_arrangement.eq(2)
    d["other1"] = d.main_arrangement.eq(3)
    for age in ["all16+", "22–25", "26–30", "31–34", "35–40", "41–49", "50+"]:
        am = np.ones(len(d), bool) if age == "all16+" else d.age.eq(age)
        for sub, sm in [
            ("all", np.ones(len(d), bool)),
            ("women", d.ESEX_baseline.eq(2)),
            ("no_BA", d.EEDUC_baseline.between(31, 42)),
            ("Black", d.ERACE_baseline.eq(2)),
            ("Hispanic", d.EORIGIN_baseline.eq(1)),
        ]:
            for band in ["Q5", "Q1–Q4"]:
                mask = adj & am & sm & d.band.eq(band)
                for yr in sorted(d.year.unique()):
                    ym = mask & d.year.eq(yr)
                    for name, risk, outcome in [
                        (
                            "full_to_part_monthly_intensity",
                            d.origin_full_intensity & d.destination_hours_known,
                            d.dest_part_intensity,
                        ),
                        (
                            "same_job_fullmonth_full_to_part_intensity",
                            d.origin_full_intensity
                            & d.same_job_full_month
                            & d.destination_hours_known,
                            d.dest_part_intensity,
                        ),
                        (
                            "full_intensity_to_nonemployment",
                            d.origin_full_intensity,
                            d.dest_nonemployment,
                        ),
                        (
                            "employee_to_selfemployment",
                            d.employee0 & d.destination_arrangement_known,
                            d.self1,
                        ),
                        (
                            "employee_to_other_arrangement",
                            d.employee0 & d.destination_arrangement_known,
                            d.other1,
                        ),
                    ]:
                        risk = ym & risk
                        event = risk & outcome
                        v = d[risk]
                        den = v[wt].sum()
                        if not len(v):
                            continue
                        rates.append(
                            dict(
                                cohort_years=length,
                                baseline_year=baseyear,
                                age=age,
                                subgroup=sub,
                                band=band,
                                year=int(yr),
                                transition=name,
                                risk_pairs=int(risk.sum()),
                                risk_persons=v.pid.nunique(),
                                event_pairs=int(event.sum()),
                                weighted_risk=den,
                                weighted_events=d.loc[event, wt].sum(),
                                rate_pct=100 * d.loc[event, wt].sum() / den,
                                sparse=int(event.sum()) < 5,
                            )
                        )
    audits.append(
        dict(
            cohort_years=length,
            official_weight_people=len(weights),
            matched_reference_people=pd.concat(frames).drop_duplicates(KEY).shape[0],
            baseline_mapped_workers=len(b),
            baseline_youth=int(b.age.eq("22–25").sum()),
            eligible_adjacent_pairs=int(adj.sum()),
            reference_years=sorted(d.year.unique().tolist()),
            employment_missing_hours=int((d.employed & d.hours.isna()).sum()),
        )
    )
    # Person-year averages preserve nonemployment, while retaining missing earnings as missing.
    factors = np.array(
        [cpi[2024, 12] / cpi[int(yy), int(mm)] for yy, mm in zip(d.year, d.MONTHCODE)]
    )
    d["real_earnings"] = d.TPEARN.where(d.TPEARN.ne(-100000998)) * factors
    d["real_income"] = d.TPTOTINC.where(d.TPTOTINC.ne(-10000000999)) * factors
    py = (
        d[d.valid]
        .groupby(["pid", "year", "age", "band"], as_index=False)
        .agg(
            hours=("hours", "mean"),
            real_earnings=("real_earnings", "mean"),
            real_income=("real_income", "mean"),
            employment=("employed", "mean"),
            months=("valid", "size"),
            weight=(wt, "first"),
        )
    )
    for age in ["all16+", "22–25", "26–30", "31–34", "35–40", "41–49", "50+"]:
        z = py if age == "all16+" else py[py.age.eq(age)]
        for (band, yr), v in z.groupby(["band", "year"]):
            for outcome in ["hours", "real_earnings", "real_income", "employment"]:
                good = v[outcome].notna()
                summaries.append(
                    dict(
                        cohort_years=length,
                        baseline_year=baseyear,
                        age=age,
                        band=band,
                        year=int(yr),
                        outcome=outcome,
                        persons=int(good.sum()),
                        mean=(
                            np.average(
                                v.loc[good, outcome], weights=v.loc[good, "weight"]
                            )
                            if good.any()
                            else np.nan
                        ),
                        currency=(
                            "December2024dollars"
                            if outcome.startswith("real_")
                            else "not_currency"
                        ),
                    )
                )
    if length == 4:
        d["eligible_adjacent"] = adj
        d.to_parquet(W / "sipp_corrected_4yr_person_months.parquet", index=False)
    print("SIPP rebuilt", length, len(weights), len(b), len(d), flush=True)
pd.DataFrame(summaries).to_csv(O / "sipp_person_year_outcomes.csv", index=False)
pd.DataFrame(rates).to_csv(O / "sipp_cohort_transition_rates.csv", index=False)
(O / "sipp_shorter_cohort_audit.json").write_text(
    json.dumps(audits, indent=2, default=str)
)
print("SIPP complete", flush=True)
