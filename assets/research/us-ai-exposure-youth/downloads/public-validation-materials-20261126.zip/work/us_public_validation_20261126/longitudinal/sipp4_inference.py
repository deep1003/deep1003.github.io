"""Marginal SIPP four-year transition rates with matching official Fay replicate weights."""

from pathlib import Path
import json
import numpy as np, pandas as pd

R = Path(__file__).resolve().parents[3]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Public_Validation_20261126/longitudinal"
KEY = ["SSUID", "PNUM", "SPANEL"]
d = pd.read_parquet(W / "sipp_corrected_4yr_person_months.parquet")
rep = pd.read_parquet(R / "work/us_longitudinal/sipp_replicate_weights.parquet")
rc = ["REPWGT" + str(i) for i in range(241)]
assert all(c in rep for c in rc)
b = d.drop_duplicates("pid")[["pid", "age", "band", "FINYR4"] + KEY].merge(
    rep[KEY + rc], on=KEY, validate="one_to_one"
)
full_weight_rounding_difference = float((b.FINYR4 - b.REPWGT0).abs().max())
assert full_weight_rounding_difference <= 1.1e-5
weights = b[rc].to_numpy()
rows = []
for age in ["all16+", "22–25"]:
    for band in ["Q5", "Q1–Q4"]:
        domain = b.band.eq(band) & (True if age == "all16+" else b.age.eq(age))
        ww = weights[domain]
        for period in ["pre", "post"]:
            pm = (
                d.time.le(2022 * 12 + 10)
                if period == "pre"
                else d.time.ge(2022 * 12 + 12)
            )
            for outcome, risk, event in [
                (
                    "full_to_part_monthly_intensity",
                    d.origin_full_intensity & d.destination_hours_known,
                    d.dest_part_intensity,
                ),
                (
                    "same_job_fullmonth_full_to_part_intensity",
                    d.origin_full_intensity
                    & d.same_job_full_month
                    & d.destination_hours_known,
                    d.dest_part_intensity,
                ),
                (
                    "full_intensity_to_nonemployment",
                    d.origin_full_intensity,
                    d.dest_nonemployment,
                ),
            ]:
                eligible = d.eligible_adjacent & pm & risk
                person = (
                    pd.DataFrame(
                        {
                            "pid": d.pid,
                            "den": eligible.astype(int),
                            "num": (eligible & event).astype(int),
                        }
                    )
                    .groupby("pid")[["den", "num"]]
                    .sum()
                    .reindex(b.pid)
                    .fillna(0)
                    .to_numpy()[domain]
                )
                den = person[:, 0] @ ww
                num = person[:, 1] @ ww
                rate = np.divide(
                    100 * num, den, out=np.full(241, np.nan), where=den > 0
                )
                est = rate[0]
                se = np.sqrt(4 / 240 * np.sum((rate[1:] - est) ** 2))
                rows.append(
                    dict(
                        age=age,
                        band=band,
                        period=period,
                        transition=outcome,
                        origin_people=int((person[:, 0] > 0).sum()),
                        risk_pairs=int(person[:, 0].sum()),
                        events=int(person[:, 1].sum()),
                        rate_pct=est,
                        se_pp=se,
                        ci_low_pct=max(0, est - 1.96 * se),
                        ci_high_pct=min(100, est + 1.96 * se),
                        sparse=(person[:, 0] > 0).sum() < 20 or person[:, 1].sum() < 5,
                        variance="official4yearFayBRRfactor4/240;fixedbaselineexposure",
                        interpretation="marginaldescriptiverate;notAIcausaleffect",
                    )
                )
result = pd.DataFrame(rows)
result["replicate_se_raw_pp"] = result.se_pp
result["inference_status"] = np.where(
    result["sparse"], "suppressed_sparse_domain", "marginal_descriptive_interval"
)
result.loc[result["sparse"], ["se_pp", "ci_low_pct", "ci_high_pct"]] = np.nan
result.to_csv(O / "sipp_4yr_transition_replicate_intervals.csv", index=False)
print("SIPP4yr official replicate intervals complete", len(rows))

(O / "sipp4_replicate_validation.json").write_text(
    json.dumps(
        dict(
            passed=True,
            full_weight_max_absolute_rounding_difference=full_weight_rounding_difference,
            full_weight_used="REPWGT0",
            replicates=240,
            Fay_rho=0.5,
            variance_factor=4 / 240,
            rows=len(result),
            sparse_intervals_suppressed=int(result["sparse"].sum()),
            source="https://www2.census.gov/programs-surveys/sipp/tech-documentation/source-accuracy-statements/2025/SIPP-2025-SA.pdf",
            local_source_lines="SIPP-2025-SA.txt1273-1275,1310,1358",
            not_AI_effect_inference=True,
        ),
        indent=2,
    )
)
