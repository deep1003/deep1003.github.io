"""Validate and describe fresh longitudinal outputs without plotting."""

from pathlib import Path
import hashlib, json
import pandas as pd, numpy as np

R = Path(__file__).resolve().parents[3]
O = R / "outputs/US_Public_Validation_20261126/longitudinal"
a = pd.read_csv(O / "cps_pair_audit.csv")
assert len(a) == 79
assert (a.fold_iterations < 100).all()
assert not a.origin_date.str.startswith("2025-10").any()
assert not a.dest_date.str.startswith("2025-10").any()
d = pd.read_csv(O / "cps_transition_rates_pooled.csv")
assert d.rate_pct.between(0, 100).all()
assert d.event_pairs.le(d.risk_pairs).all()
s = pd.read_csv(O / "sipp_cohort_transition_rates.csv")
assert s.rate_pct.between(0, 100).all()
assert s.event_pairs.le(s.risk_pairs).all()
# Economic usual-PT events must be nested in all actual-short-hour events.
z = d.pivot(
    index=["age", "subgroup", "band", "period", "method"],
    columns="transition",
    values="event_pairs",
)
assert (z.FT_to_economic_PT <= z.FT_to_economic_short_hours).all()
weights = []
for n in [2, 3, 4]:
    p = R / f"work/us_longitudinal/raw/lgtwgt2025yr{n}_csv.zip"
    weights.append(
        dict(
            years=n,
            url="https://www2.census.gov/programs-surveys/sipp/data/datasets/2025/"
            + p.name,
            bytes=p.stat().st_size,
            sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
        )
    )
(O / "sipp_weights_source_manifest.json").write_text(json.dumps(weights, indent=2))
sel = d[
    d.age.eq("22–25")
    & d.subgroup.eq("all")
    & d.method.eq("ipw")
    & d.transition.isin(
        [
            "FT_to_PT",
            "FT_to_economic_PT",
            "FT_to_economic_short_hours",
            "FT_to_U",
            "FT_to_NILF",
        ]
    )
][["band", "period", "transition", "risk_pairs", "event_pairs", "rate_pct"]]
sel.to_csv(O / "youth_transition_readout.csv", index=False)
annual = pd.read_csv(O / "sipp_person_year_outcomes.csv")
assert annual["mean"].notna().all()
assert annual.loc[annual.outcome.eq("hours"), "mean"].between(0, 200).all()
report = (
    (Path(__file__).resolve().parent / "METHODS_TEMPLATE_EN.md").read_text()
    + "\n```csv\n"
    + sel.to_csv(index=False)
    + "```\n"
)
entry = pd.read_csv(O / "cps_entry_rates_pooled.csv")
entry_keys = [
    "age",
    "origin_status",
    "origin_occupation_availability",
    "period",
    "method",
]
for _, z in entry.groupby(entry_keys):
    assert z.risk_pairs.nunique() == 1
    total = z[z.outcome.eq("any_employment")].rate_pct.iloc[0]
    assert np.isclose(total, z[~z.outcome.eq("any_employment")].rate_pct.sum())
assert json.loads((O / "cps_entry_validation.json").read_text())["passed"]
entry_readout = entry[
    entry.age.eq("22–25")
    & entry.origin_status.eq("all_jobless")
    & entry.origin_occupation_availability.eq("all_origins")
    & entry.method.eq("ipw")
]
entry_readout.to_csv(O / "youth_entry_readout.csv", index=False)
report += "\n" + (Path(__file__).resolve().parent / "ENTRY_METHODS_EN.md").read_text()
report += (
    "\n```csv\n"
    + entry_readout[
        ["period", "outcome", "risk_pairs", "event_pairs", "rate_pct"]
    ].to_csv(index=False)
    + "```\n"
)
(O / "LONGITUDINAL_METHODS_AND_RESULTS_EN.md").write_text(report)
(O / "longitudinal_final_checks.json").write_text(
    json.dumps(
        dict(
            passed=True,
            observed_adjacent_month_pairs=len(a),
            no_imputed_person_records=True,
            all_crossfit_models_converged=True,
            CPS_rate_rows=len(d),
            CPS_entry_rate_rows=len(entry),
            entry_common_denominators_and_partition=True,
            SIPP_rate_rows=len(s),
            SIPP_person_year_outcome_rows=len(annual),
            plots_displayed=False,
        ),
        indent=2,
    )
)
print(sel.to_string(index=False))
print("Longitudinal data-I/O checks passed. No plots displayed.")
