"""Validate saved analysis inputs/outputs without rendering any images."""

from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

import pandas as pd
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/US_Public_Validation_20261126"


def main():
    check_files = [
        "state/VALIDATION.json",
        "state/FRESH_SMOKE_CHECKS.json",
        "acs/acs_validation_checks.json",
        "acs/acs_pooled_validation_checks.json",
        "admin/validation_checks.json",
        "admin/extended_pre_checks.json",
        "longitudinal/longitudinal_final_checks.json",
        "longitudinal/cps_entry_validation.json",
    ]
    checks = {}
    for name in check_files:
        data = json.loads((OUT / name).read_text())
        assert data.get("passed") is True, name
        checks[name] = dict(
            passed=True, sha256=hashlib.sha256((OUT / name).read_bytes()).hexdigest()
        )
    rates = pd.read_csv(OUT / "state/pooled_state_rates_working_uncertainty.csv")
    assert len(rates) == 2496 and rates.estimate_pct.between(0, 100).all()
    assert (
        rates[rates.CI_status.eq("withheld_sparse_or_degenerate")]
        .working_SE_pp.isna()
        .all()
    )
    assert all(g.GESTFIPS.nunique() == 52 for _, g in rates.groupby("period"))
    primary = pd.read_csv(OUT / "admin/administrative_primary_results.csv")
    assert len(primary) == 24
    assert primary.p_Holm24_primary.between(0, 1).all()
    assert "22–25" not in set(primary.age)
    svg = ET.parse(OUT / "state/Q5_youth_fulltime_three_year_map.svg")
    assert svg.getroot().tag.endswith("svg")
    with Image.open(OUT / "state/Q5_youth_fulltime_three_year_map.png") as im:
        assert im.size == (2640, 1760)
        im.verify()
    payload = dict(
        passed=True,
        module_checks=checks,
        state_rows=len(rates),
        admin_primary_contrasts=len(primary),
        image_files_validated_without_display=True,
        figures_displayed=0,
    )
    (OUT / "BUNDLE_FRESH_SMOKE_CHECKS.json").write_text(json.dumps(payload, indent=2))
    print("Bundle data-I/O checks passed; no figures displayed")


if __name__ == "__main__":
    main()
