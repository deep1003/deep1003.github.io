"""Report complete annual and nonoverlapping pooled ACS validation."""

from pathlib import Path
import json, shutil
import pandas as pd

W = Path(__file__).resolve().parent
R = W.parents[2]
O = R / "outputs/US_Public_Validation_20261126/acs"


def table(frame):
    h = [
        "| " + " | ".join(map(str, frame.columns)) + " |",
        "| " + " | ".join(["---"] * len(frame.columns)) + " |",
    ]
    return "\n".join(
        h
        + [
            "| " + " | ".join(map(str, r)) + " |"
            for r in frame.itertuples(index=False, name=None)
        ]
    )


def main():
    a = json.loads((O / "acs_annual_processing_audit.json").read_text())
    ch = pd.read_csv(O / "acs_pooled_relative_changes.csv")
    p = pd.read_csv(O / "acs_pooled_employment_2017_19_vs_2023_24.csv")
    annual = pd.read_csv(O / "acs_employment_hours_annual.csv")
    pay = pd.read_csv(O / "acs_pooled_annual_salary_means.csv")
    checks = json.loads((O / "acs_pooled_validation_checks.json").read_text())
    obs = table(
        pd.DataFrame(
            [
                {
                    "Year": x["year"],
                    "All person records": f"{x['all_age_unweighted_records']:,}",
                    "Eligible youth records": f"{x['civilian_noninstitutional_age22_25_n']:,}",
                    "Weighted youth population": f"{x['civilian_noninstitutional_age22_25_weighted_people']:,.0f}",
                    "Mapped employment": f"{100*x['employed_mapping_share']:.2f}%",
                }
                for x in a
            ]
        )
    )
    nat = ch[
        ch.state.eq(0) & ch.contrast.eq("Q5_vs_Q1_4_relative_pool_change_pct")
    ].copy()
    nat["Outcome"] = nat.outcome.map(
        {
            "employed": "Employment",
            "FT_proxy": "Usual past-year FT-hours proxy",
            "PT_proxy": "Usual past-year PT-hours proxy",
        }
    )
    nat["Relative change"] = nat.estimate.map(lambda x: f"{x:+.2f}%")
    nat["95% CI"] = nat.apply(
        lambda x: f"[{x.CI95_low:+.2f}, {x.CI95_high:+.2f}]", axis=1
    )
    main_table = table(nat[["Outcome", "Relative change", "95% CI"]])
    ac = annual[
        annual.state.eq(0)
        & annual.band.isin(["Q5", "Q1–Q4"])
        & annual.outcome.isin(["employed", "FT_proxy", "PT_proxy"])
        & annual.measure.eq("weighted_people")
    ].copy()
    ac["People"] = ac.estimate.map(lambda x: f"{x:,.0f}")
    annual_table = table(ac[["year", "band", "outcome", "People"]])
    pn = pay[pay.state.eq(0) & pay.band.isin(["Q5", "Q1–Q4"])].copy()
    pn["Mean annual salary"] = pn.estimate.map(lambda x: f"${x:,.0f}")
    pn["95% CI"] = pn.apply(
        lambda x: f"[${x.CI95_low:,.0f}, ${x.CI95_high:,.0f}]", axis=1
    )
    pay_table = table(pn[["period", "band", "Mean annual salary", "95% CI"]])
    precision = p[
        p.state.ne(0)
        & p.band.eq("Q5")
        & p.outcome.isin(["FT_proxy", "PT_proxy"])
        & p.measure.eq("average_annual_weighted_people")
    ].copy()
    precision["RSE_pct"] = precision.SE / precision.estimate * 100
    precision.to_csv(O / "acs_pooled_state_Q5_precision.csv", index=False)
    total = sum(x["all_age_unweighted_records"] for x in a)
    eligible = sum(x["civilian_noninstitutional_age22_25_n"] for x in a)
    text = f"""# ACS annual and pooled independent validation

Completed November 26, 2026. We acquired five official national ACS 1-year person samples, linked our frozen THAIE occupational classification, and calculated national and state estimates for ages 22–25. The preferred descriptive comparison pools 2017–2019 against 2023–2024. Three pre-years and two post-years are available in this analysis; no third clean post-year is invented. This is an independent annual cross-check of occupational employment allocation, not a causal AI DID.

## Data actually processed

{obs}

The five complete person archives contain **{total:,} records**, of which **{eligible:,} civilian noninstitutional youth records** enter these age-specific analyses. These are person records across separate annual samples, not necessarily unique people across years. Every year contains all 50 states and DC. Public outputs include {checks['annual_employment_rows']:,} annual employment/hours/rate rows, {checks['pooled_employment_rows']:,} pooled employment/rate rows, {checks['pooled_change_rows']:,} pooled change rows, and {checks['pooled_salary_mean_rows']:,} pooled salary-mean rows.

The age-population denominator retains all eligible civilian noninstitutional people before occupation linkage. Armed Forces ESR codes 4/5 and institutional group quarters are excluded. Institutional status uses RELP=16 in 2017/2018 and RELSHIPP=37 thereafter, verified against year-specific official schemas. State codes are harmonized from ST or STATE. Years 2018 onward use Census 2018 occupation recodes and join directly to our frozen score table.

The 2017 sample uses Census 2010 occupation codes. We apply the verified 2010–2018 crosswalk to calculate **expected Q5, Q1–Q4 and unmapped contributions**. We preserve each original person record and multiply its survey weight by the corresponding band probability. We do not assign an unobserved detailed 2018 occupation to a worker. The three band probabilities sum to one, including unmapped contributions. Contributing record counts may overlap across bands in 2017; fractional record equivalents are reported separately. The frozen THAIE cutpoints are not recalculated by year, age or state.

## Pooled descriptive result

{main_table}

Each pre-period count is the average of its three annual weighted totals; each post-period count is the average of its two annual totals. Relative change is 100×[(post_Q5/pre_Q5)/(post_Q1–Q4/pre_Q1–Q4)−1]. The contrast compares annual-average counts after normalizing each period by its number of years. Population-contribution rates use the ratio of annual-average group employment to annual-average eligible population, preserving within-year covariance through the replicate weights.

These results describe relative high-exposure occupational employment allocation across the specified periods. They do not prove AI caused any change, identify the exact timing after November 2022, demonstrate permanent-to-contract transitions, or follow the same workers. Comparing the pooled result with the explicitly labeled exploratory 2019-to-2024 endpoint check helps reveal sensitivity to period selection. The older endpoint tables and intervals are preserved in `acs_endpoint_changes_2019_2024.csv`.

## Annual profile

{annual_table}

Employment is current civilian employment. The FT-hours proxy additionally requires usual weekly hours over the past 12 months of at least 35; the PT-hours proxy requires 1–34. These are not the CPS current usual FT/PT recodes and do not classify permanent or fixed-term contracts. Current occupational assignment and past-year hours do not share an identical reference period. The annual profile therefore supplements rather than replaces monthly CPS results.

## Annual salary means in pooled samples

{pay_table}

These are ratios of average annual salary numerators to average annual salary-worker counts, not averages of medians. Salary observations require current civilian employment, COW 1–5 and positive WAGP. Amounts are adjusted by ADJINC/1,000,000 and official annual CPI-U to 2024 dollars. In 2017, fractional exposure probabilities enter these linear numerators and denominators; no supposedly observed within-band 2017 median is imputed. Annual earnings reflect weeks, hours, occupation composition, income allocation and topcoding. They are not hourly pay or within-person wage growth. National CPI-U adjustment does not remove regional cost-of-living differences.

## Sampling uncertainty and state precision

We retain all 80 supplied person replicate weights, including legitimate negative replicate weights for counts and means. For an annual statistic, the variance is (4/80) times the sum of squared replicate deviations. In a pooled statistic, each year's replicate perturbations vary that year's numerator and denominator jointly, divided by the number of years in its period. The variance sums the year-block components under an explicit independent-year approximation. The supplied person weights determine point estimates. Weighted people and weighted totals are not treated as independent sample sizes.

All intervals are pointwise normal 95% intervals, without multiple-testing adjustment. They quantify sampling uncertainty conditional on the fixed THAIE score and fixed crosswalk, excluding score-estimation and bridge uncertainty. Cross-year covariance is not estimated. The 2017 mapping adds a modeling assumption even though exposure-group contributions are computed transparently.

The state precision file reports contributing person records, fractional record equivalents, annual-average weighted counts, replicate standard errors and relative standard errors. Thresholds on record count do not guarantee precision. Pooling may make state cells more stable but reduces timing resolution. Uncontrolled zero SDR errors have uncertainty withheld pending the Census generalized-variance fallback. Full-weight annual medians are preserved for directly mapped years, but quantile SEs are withheld where this estimator is undefined for signed replicate weights; no replicate weights are clipped to fabricate a median interval.

## Scope and remaining limits

The planned three-year pre/two-year post pooling is now complete for all states. A third clean post-year, 2025, is unavailable in the verified PUMS endpoints; 2026 PUMS is also unavailable. The ACS person samples do not expose the monthly timing needed to center a monthly event study at November 2022. The 2020 experimental sample and 2021/2022 are not substituted into the clean post pool. A five-year ACS release crossing the treatment date would not fix that timing problem.

The ACS check can support or challenge the descriptive occupational pattern with a different survey and larger annual sample. It cannot by itself establish AI adoption, permanent-contract displacement, individual adaptation, or causal hiring effects. Further causal work still requires appropriate comparison trends, measured adoption or plausibly exogenous exposure variation and attention to pandemic and industry shocks.

## Reproduction and provenance

Scripts, per-file source records, logs and locally retained age-subset caches are in `work/us_public_validation_20261126/acs/`. Source archives were downloaded free from the official Census FTP site and verified by SHA-256. `acs_pooled_validation_checks.json` records year/geography coverage, unique annual cells and national-to-state reconciliation. `acs_processing_lineage.json` hashes the processing code, THAIE scores, crosswalk and CPI inputs. The annual employment, population and salary replicate-component files preserve the inputs needed to recompute pooled uncertainty.

- [Official ACS PUMS access](https://www.census.gov/programs-surveys/acs/microdata/access.html)
- [2017 ACS variables](https://api.census.gov/data/2017/acs/acs1/pums/variables.html)
- [2018 ACS variables](https://api.census.gov/data/2018/acs/acs1/pums/variables.html)
- [2024 ACS variables](https://api.census.gov/data/2024/acs/acs1/pums/variables.html)
- [ACS accuracy and replicate inference](https://www2.census.gov/programs-surveys/acs/tech_docs/pums/accuracy/2024AccuracyPUMS.pdf)
- [Official CPI-U annual inputs](https://api.bls.gov/publicAPI/v2/timeseries/data/CUUR0000SA0?startyear=2017&endyear=2024&annualaverage=true)
"""
    old = O / "ACS_VALIDATION_REPORT_EN.md"
    if old.exists() and not (O / "ACS_ENDPOINT_CHECK_EN.md").exists():
        shutil.copy2(old, O / "ACS_ENDPOINT_CHECK_EN.md")
    ch[ch.state.eq(0)].to_csv(O / "acs_national_pooled_changes.csv", index=False)
    old.write_text(text)
    shutil.copy2(W / "source_manifest.json", O / "source_manifest.json")
    shutil.copy2(W / "cpi_annual_verified.json", O / "cpi_annual_verified.json")
    print("POOLED REPORT COMPLETE", old, flush=True)


if __name__ == "__main__":
    main()
