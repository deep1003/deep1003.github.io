"""Descriptive two-year changes with block-year replicate uncertainty."""

from pathlib import Path
import json
import pandas as pd
import numpy as np

W = Path(__file__).resolve().parent
R = W.parents[2]
O = R / "outputs/US_Public_Validation_20261126/acs"


def change_interval(point, rep_pre, rep_post):
    # Explicit approximation: independent annual survey samples; covariance inside
    # each year retained through its coordinated 80 replicate weights.
    se = float(
        np.sqrt(
            4
            / 80
            * (np.square(rep_pre - point).sum() + np.square(rep_post - point).sum())
        )
    )
    return {
        "estimate_pct": float(point),
        "SE_pct": se,
        "CI95_low_pct": float(point - 1.96 * se),
        "CI95_high_pct": float(point + 1.96 * se),
    }


def main():
    r = pd.read_parquet(O / "acs_employment_replicate_totals.parquet")
    cols = [f"estimate_r{i}" for i in range(81)]
    rows = []
    for state in sorted(r.state.unique()):
        for outcome in ["employed", "FT_proxy", "PT_proxy"]:
            g = r[(r.state == state) & (r.outcome == outcome)].set_index(
                ["year", "band"]
            )
            a = g.loc[(2019, "Q5"), cols].to_numpy(float)
            b = g.loc[(2024, "Q5"), cols].to_numpy(float)
            c = g.loc[(2019, "Q1–Q4"), cols].to_numpy(float)
            d = g.loc[(2024, "Q1–Q4"), cols].to_numpy(float)
            base = {
                "state": state,
                "age": "22–25",
                "outcome": outcome,
                "pre_year": 2019,
                "post_year": 2024,
                "Q5_pre_n": int(g.loc[(2019, "Q5"), "unweighted_n"]),
                "Q5_post_n": int(g.loc[(2024, "Q5"), "unweighted_n"]),
                "inference": "Pointwise 95% normal interval; independent-year replicate-block approximation; descriptive",
            }
            for band, old, new in [("Q5", a, b), ("Q1–Q4", c, d)]:
                if (old > 0).all():
                    point = 100 * (new[0] / old[0] - 1)
                    pre = 100 * (new[0] / old[1:] - 1)
                    post = 100 * (new[1:] / old[0] - 1)
                    rows.append(
                        {
                            **base,
                            "contrast": band + "_endpoint_change",
                            **change_interval(point, pre, post),
                        }
                    )
            if (a > 0).all() and (c > 0).all() and (d > 0).all():
                point = 100 * ((b[0] / a[0]) / (d[0] / c[0]) - 1)
                pre = 100 * ((b[0] / a[1:]) / (d[0] / c[1:]) - 1)
                post = 100 * ((b[1:] / a[0]) / (d[1:] / c[0]) - 1)
                rows.append(
                    {
                        **base,
                        "contrast": "Q5_vs_Q1_4_relative_endpoint_change",
                        **change_interval(point, pre, post),
                    }
                )
    t = pd.DataFrame(rows)
    t.to_csv(O / "acs_endpoint_changes_2019_2024.csv", index=False)
    print(t[t.state.eq(0)].to_string(index=False))
    audit = json.loads((O / "acs_processing_audit.json").read_text())
    n = pd.read_csv(O / "acs_employment_hours_2019_2024.csv")
    e = pd.read_csv(O / "acs_annual_salary_2019_2024.csv")
    assert n["estimate"].notna().all()
    assert n.loc[n.variance_status.eq("replicate_SDR"), "SE"].notna().all()
    assert len(n) == 2 * 52 * 3 * 4 * 2
    assert not n.duplicated(
        ["year", "state", "age", "band", "outcome", "measure"]
    ).any()
    assert set(n.year) == {2019, 2024} and n.state.nunique() == 52
    for y in [2019, 2024]:
        for o in ["employed", "FT_proxy", "PT_proxy", "hours_missing"]:
            q = n[n.year.eq(y) & n.outcome.eq(o) & n.measure.eq("weighted_people")]
            a = q[q.state.eq(0)].set_index("band").estimate
            b = q[q.state.ne(0)].groupby("band").estimate.sum()
            assert np.allclose(a.sort_index(), b.sort_index())
    rec = {
        "passed": True,
        "years": [2019, 2024],
        "states_and_DC": 51,
        "national_plus_state_geographies": 52,
        "employment_rows": len(n),
        "earnings_rows": len(e),
        "endpoint_rows": len(t),
        "all_51_states_present_each_year": all(len(x["states"]) == 51 for x in audit),
        "national_equals_state_sum": True,
        "replicate_variance": "4/80 sum squared deviations, 80 supplied person replicates",
        "endpoint_variance": "independent-year replicate-block approximation; pointwise normal intervals",
        "main_causal_DID": False,
    }
    assert rec["all_51_states_present_each_year"]
    (O / "acs_validation_checks.json").write_text(json.dumps(rec, indent=2))
    print("ACS DATA-I/O VALIDATION PASSED. No plots emitted.", flush=True)


if __name__ == "__main__":
    main()
