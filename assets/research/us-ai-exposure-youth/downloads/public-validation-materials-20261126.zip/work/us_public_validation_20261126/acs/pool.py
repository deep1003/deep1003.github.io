"""Nonoverlapping annual-average pools with separate year-block replication."""

from pathlib import Path
import json
import numpy as np, pandas as pd

W = Path(__file__).resolve().parent
R = W.parents[2]
O = R / "outputs/US_Public_Validation_20261126/acs"
PERIODS = {"pre2017_2019": [2017, 2018, 2019], "post2023_2024": [2023, 2024]}
RC = [f"estimate_r{i}" for i in range(81)]


def stats(point, perturbations):
    se = float(np.sqrt(4 / 80 * sum(np.square(x - point).sum() for x in perturbations)))
    status = "independent_year_block_SDR"
    if point == 0 or se == 0:
        se = np.nan
        status = "requires_GVF_fallback_SE_withheld"
    return {
        "estimate": float(point),
        "variance_status": status,
        "SE": se,
        "CI95_low": float(point - 1.96 * se),
        "CI95_high": float(point + 1.96 * se),
        "inference": "Pointwise normal95%; independent annual replicate-block approximation",
    }


def main():
    r = pd.read_parquet(O / "acs_employment_annual_replicate_totals.parquet")
    idx = r.set_index(["year", "state", "band", "outcome"])
    popidx = pd.read_parquet(
        O / "acs_population_annual_replicate_totals.parquet"
    ).set_index(["year", "state"])
    pool = []
    changes = []
    earn = []
    for state in sorted(r.state.unique()):
        for outcome in ["employed", "FT_proxy", "PT_proxy", "hours_missing"]:
            values = {}
            for period, years in PERIODS.items():
                for band in ["Q5", "Q1–Q4", "Unmapped"]:
                    vals = np.stack(
                        [
                            idx.loc[(y, state, band, outcome), RC].to_numpy(float)
                            for y in years
                        ]
                    )
                    point = vals[:, 0].mean()
                    pert = [point + (v[1:] - v[0]) / len(years) for v in vals]
                    row = {
                        "state": state,
                        "age": "22–25",
                        "period": period,
                        "years": ",".join(map(str, years)),
                        "band": band,
                        "outcome": outcome,
                        "sum_contributing_person_records": int(
                            sum(
                                idx.loc[(y, state, band, outcome), "unweighted_n"]
                                for y in years
                            )
                        ),
                        "sum_fractional_record_equivalents": float(
                            sum(
                                idx.loc[
                                    (y, state, band, outcome),
                                    "fractional_record_equivalents",
                                ]
                                for y in years
                            )
                        ),
                        "measure": "average_annual_weighted_people",
                        **stats(point, pert),
                    }
                    pool.append(row)
                    population_vals = np.stack(
                        [popidx.loc[(y, state), RC].to_numpy(float) for y in years]
                    )
                    population_mean = population_vals[:, 0].mean()
                    rate_point = 100 * point / population_mean
                    rate_pert = [
                        100
                        * (point + (vals[j, 1:] - vals[j, 0]) / len(years))
                        / (
                            population_mean
                            + (population_vals[j, 1:] - population_vals[j, 0])
                            / len(years)
                        )
                        for j in range(len(years))
                    ]
                    pool.append(
                        {
                            **row,
                            "measure": "contribution_to_age_population_pp",
                            **stats(rate_point, rate_pert),
                        }
                    )
                    values[period, band] = (vals, point)
            if outcome == "hours_missing":
                continue
            pre = PERIODS["pre2017_2019"]
            post = PERIODS["post2023_2024"]
            p5, a = values["pre2017_2019", "Q5"]
            q5, b = values["post2023_2024", "Q5"]
            p14, c = values["pre2017_2019", "Q1–Q4"]
            q14, d = values["post2023_2024", "Q1–Q4"]
            for band, pv, av, qv, bv in [
                ("Q5", p5, a, q5, b),
                ("Q1–Q4", p14, c, q14, d),
            ]:
                if av <= 0:
                    continue
                theta = 100 * (bv / av - 1)
                pert = [
                    100 * (bv / (av + (v[1:] - v[0]) / len(pre)) - 1) for v in pv
                ] + [100 * ((bv + (v[1:] - v[0]) / len(post)) / av - 1) for v in qv]
                changes.append(
                    {
                        "state": state,
                        "age": "22–25",
                        "outcome": outcome,
                        "contrast": band + "_pool_change_pct",
                        **stats(theta, pert),
                    }
                )
            if min(a, c, d) <= 0:
                continue
            theta = 100 * ((b / a) / (d / c) - 1)
            pert = []
            for j in range(len(pre)):
                ar = a + (p5[j, 1:] - p5[j, 0]) / len(pre)
                cr = c + (p14[j, 1:] - p14[j, 0]) / len(pre)
                pert.append(100 * ((b / ar) / (d / cr) - 1))
            for j in range(len(post)):
                br = b + (q5[j, 1:] - q5[j, 0]) / len(post)
                dr = d + (q14[j, 1:] - q14[j, 0]) / len(post)
                pert.append(100 * ((br / a) / (dr / c) - 1))
            changes.append(
                {
                    "state": state,
                    "age": "22–25",
                    "outcome": outcome,
                    "contrast": "Q5_vs_Q1_4_relative_pool_change_pct",
                    **stats(theta, pert),
                }
            )
    # Ratio of annual-average salary numerator and denominator, not average medians.
    sr = pd.read_parquet(
        O / "acs_salary_annual_replicate_components.parquet"
    ).set_index(["year", "state", "band"])
    full_salary_index = pd.MultiIndex.from_product(
        [
            [2017, 2018, 2019, 2023, 2024],
            sorted(r.state.unique()),
            ["Q5", "Q1–Q4", "Unmapped"],
        ],
        names=["year", "state", "band"],
    )
    sr = sr.reindex(full_salary_index, fill_value=0)
    nc = [f"num_r{i}" for i in range(81)]
    dc = [f"den_r{i}" for i in range(81)]
    for state in sorted(r.state.unique()):
        for band in ["Q5", "Q1–Q4", "Unmapped"]:
            for period, years in PERIODS.items():
                n = np.stack(
                    [sr.loc[(y, state, band), nc].to_numpy(float) for y in years]
                )
                d = np.stack(
                    [sr.loc[(y, state, band), dc].to_numpy(float) for y in years]
                )
                nn = n[:, 0].mean()
                dd = d[:, 0].mean()
                if dd <= 0:
                    continue
                theta = nn / dd
                pert = [
                    (nn + (n[j, 1:] - n[j, 0]) / len(years))
                    / (dd + (d[j, 1:] - d[j, 0]) / len(years))
                    for j in range(len(years))
                ]
                salary_stats = stats(theta, pert)
                zero_years = int((d[:, 0] <= 0).sum())
                if zero_years:
                    salary_stats.update(
                        SE=np.nan,
                        CI95_low=np.nan,
                        CI95_high=np.nan,
                        variance_status="Annual_zero_sample_GVF_fallback_SE_withheld",
                    )
                earn.append(
                    {
                        "state": state,
                        "age": "22–25",
                        "band": band,
                        "period": period,
                        "outcome": "annual_salary_mean_2024USD",
                        "average_annual_weighted_salary_workers": float(dd),
                        "annual_zero_sample_years": zero_years,
                        **salary_stats,
                    }
                )
    pd.DataFrame(pool).to_csv(
        O / "acs_pooled_employment_2017_19_vs_2023_24.csv", index=False
    )
    pd.DataFrame(changes).to_csv(O / "acs_pooled_relative_changes.csv", index=False)
    pd.DataFrame(earn).to_csv(O / "acs_pooled_annual_salary_means.csv", index=False)
    # Year/geography identities and all five source years must be present.
    annual = pd.read_csv(O / "acs_employment_hours_annual.csv")
    assert set(annual.year) == {2017, 2018, 2019, 2023, 2024}
    assert len(annual) == 5 * 52 * 3 * 4 * 2
    assert not annual.duplicated(
        ["year", "state", "age", "band", "outcome", "measure"]
    ).any()
    assert all(
        annual[annual.year.eq(y)].state.nunique() == 52
        for y in [2017, 2018, 2019, 2023, 2024]
    )
    assert all(np.isfinite(x["estimate"]) and np.isfinite(x["SE"]) for x in changes)
    for year in [2017, 2018, 2019, 2023, 2024]:
        for outcome in ["employed", "FT_proxy", "PT_proxy"]:
            g = annual[
                annual.year.eq(year)
                & annual.outcome.eq(outcome)
                & annual.measure.eq("weighted_people")
            ]
            national = g[g.state.eq(0)].set_index("band").estimate
            states = g[g.state.ne(0)].groupby("band").estimate.sum()
            assert np.allclose(national.sort_index(), states.sort_index())
    checks = {
        "passed": True,
        "years": [2017, 2018, 2019, 2023, 2024],
        "pre_years": pre,
        "post_years": post,
        "annual_employment_rows": len(annual),
        "pooled_employment_rows": len(pool),
        "pooled_change_rows": len(changes),
        "pooled_salary_mean_rows": len(earn),
        "geographies_each_year": 52,
        "national_equals_states": True,
        "2017_assignment": "Expected fractional exposure contributions; not imputed individual new codes",
        "post_pool_has_only_two_years": True,
        "causal_DID": False,
    }
    (O / "acs_pooled_validation_checks.json").write_text(json.dumps(checks, indent=2))
    print(pd.DataFrame(changes).query("state==0").to_string(index=False))
    print("ACS POOLED DATA-I/O CHECKS PASSED. No figures.", flush=True)


if __name__ == "__main__":
    main()
