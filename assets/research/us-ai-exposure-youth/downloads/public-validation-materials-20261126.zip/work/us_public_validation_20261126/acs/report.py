"""Write compact inspectable ACS validation report; no plots."""

from pathlib import Path
import json, shutil
import pandas as pd

W = Path(__file__).resolve().parent
R = W.parents[2]
O = R / "outputs/US_Public_Validation_20261126/acs"


def table(frame):
    c = list(frame.columns)
    rows = [
        "| " + " | ".join(map(str, c)) + " |",
        "| " + " | ".join(["---"] * len(c)) + " |",
    ]
    rows += [
        "| " + " | ".join(map(str, v)) + " |"
        for v in frame.itertuples(index=False, name=None)
    ]
    return "\n".join(rows)


def main():
    checks = json.loads((O / "acs_validation_checks.json").read_text())
    audit = json.loads((O / "acs_processing_audit.json").read_text())
    counts = pd.read_csv(O / "acs_employment_hours_2019_2024.csv")
    salary = pd.read_csv(O / "acs_annual_salary_2019_2024.csv")
    changes = pd.read_csv(O / "acs_endpoint_changes_2019_2024.csv")
    national = changes[
        changes.state.eq(0) & changes.contrast.eq("Q5_vs_Q1_4_relative_endpoint_change")
    ].copy()
    national["estimate_pct"] = national.estimate_pct.map(lambda x: f"{x:+.2f}%")
    national["95% CI"] = national.apply(
        lambda r: f"[{r.CI95_low_pct:+.2f}, {r.CI95_high_pct:+.2f}]", axis=1
    )
    nationaltable = table(
        national[["outcome", "Q5_pre_n", "Q5_post_n", "estimate_pct", "95% CI"]]
    )
    records = table(
        pd.DataFrame(
            [
                {
                    "Year": r["year"],
                    "All person records": r["all_age_unweighted_records"],
                    "Eligible 22–25 records": r["civilian_noninstitutional_age22_25_n"],
                    "Weighted 22–25 people": int(
                        r["civilian_noninstitutional_age22_25_weighted_people"]
                    ),
                    "Employed THAIE coverage": f"{r['employed_mapping_share']*100:.2f}%",
                }
                for r in audit
            ]
        )
    )
    earn = salary[salary.state.eq(0) & salary.band.isin(["Q5", "Q1–Q4"])].copy()
    earn["Estimate"] = earn.estimate.map(lambda x: f"${x:,.0f}")
    earntable = table(
        earn[["year", "band", "outcome", "unweighted_n", "Estimate", "variance_status"]]
    )
    precision = counts[
        counts.state.ne(0)
        & counts.band.eq("Q5")
        & counts.measure.eq("weighted_people")
        & counts.outcome.isin(["FT_proxy", "PT_proxy"])
    ].copy()
    precision["RSE_pct"] = precision.SE / precision.estimate * 100
    precision["small_sample_below30"] = precision.unweighted_n.lt(30)
    precision.to_csv(O / "acs_state_Q5_precision.csv", index=False)
    small = int(precision.small_sample_below30.sum())
    incompletequantile = int(
        salary.outcome.str.contains("median")
        .mul(salary.variance_status.ne("replicate_SDR"))
        .sum()
    )
    text = f"""# ACS independent occupation-based validation

Completed November26,2026. Exact ages22–25, own frozen THAIE mapping, national and all 50 states plus DC. This is an annual repeated-cross-section descriptive validation. It is not a November 2022 DID and does not establish AI causation.

## Completed coverage

{records}

The two official national person archives contain 6,662,441 person records. All 51 geographies are present in each year. In total, 2,496 employment/hours/contribution rows and {len(salary)} salary rows were computed. Both complete archives were newly acquired from Census, hashed, and parsed in chunks. Only necessary columns and ages 22–25 were retained locally.

The population universe is civilian noninstitutional ages22–25. Institutional group quarters (RELSHIPP = 37) and active Armed Forces (ESR = 4 or 5) are excluded. Both 2019 and 2024 use Census 2018 occupation codes; they join directly to the unchanged 547-occupation THAIE score universe. No CPS historical bridge is applied to these ACS years. The frozen national quintile cutpoints are retained across states and years.

## Main descriptive cross-check

{nationaltable}

The relative endpoint statistic is 100 × [(Q5_2024/Q5_2019)/(Q1–Q4_2024/Q1–Q4_2019)−1]. The table supports relative weakness of high-exposure occupational employment across this five-year interval. It does not locate that divergence after ChatGPT. It also does not show a shift into part-time employment. In Q5 itself, the FT-hours proxy changed +0.58% and the PT-hours proxy −6.56%; relative comparisons incorporate growth in the lower-exposure group.

FT_proxy means current civilian employment and usual past-12-month weekly hours ≥35; PT_proxy means current employment and usual past-12-month hours 1–34. These differ from CPS current usual FT/PT recodes and do not identify contract permanence. Occupation refers to the current or latest job, while hours refer to the past year. Employment divided by the entire eligible age population is labeled an exposure-group contribution to the overall employment rate, not an occupation-specific employment probability or unemployment rate.

## Annual salary cross-check

{earntable}

Salary estimates condition on current civilian employment, wage/salary class of worker 1–5, and positive past-year salary income. Income is adjusted by ADJINC/1,000,000 then by annual CPI-U to 2024 dollars. Official BLS CPI-U annual averages are255.657for2019and313.689for2024. Annual salary includes differences in weeks/hours worked and composition. It is not an hourly wage or a longitudinal gain for the same individuals. Public income topcoding and allocation can affect distributions.

## Replicate inference and precision

Counts, rates, and means use all 80 provided person replicate weights. Standard errors are sqrt[(4/80)×sum_r(theta_r−theta)^2]. State and national calculations retain the supplied negative replicate weights for linear totals and means; they are valid variance inputs. The minimum raw replicate weight among retained-age records is −178 in 2019 and −1125 in 2024. They are not replaced by zero.

A two-year endpoint statistic uses separate 80-replicate perturbations of 2019 and 2024 and sums the year-block variance components under an explicit independent-year approximation. Intervals are pointwise normal 95% intervals, without multiplicity correction. They quantify sampling uncertainty in this descriptive statistic; they do not account for THAIE measurement error or identify causal effects.

Full-weight medians are reported. For this quantile estimator, negative replicate weights do not define a probability distribution, so affected median standard errors are withheld rather than clipping weights or silently dropping the full-weight point estimate. Zero SDR errors/uncontrolled zero estimates also have uncertainty withheld pending the Census generalized-variance fallback. {incompletequantile} median cells have an explicit non-SDR variance status. Means provide the complete linear earnings cross-check in the meantime.

There are {small} state/year/Q5 FT-or-PT cells with fewer than 30 actual records. The detailed precision table reports actual n, weighted people, Kish weight-only diagnostic, replicate SE and relative SE. State estimates must not be read as uniformly precise. A threshold on n alone is not a precision guarantee. Negative normal lower bounds in sparse cells are a warning about the approximation, not negative population counts.

## What remains incomplete

2017–2018 and 2023 national files were not collected in this run, so the intended three-year baseline/two-year post pooling is not yet complete. The 2025 PUMS remains unverified/unreleased in the checked official endpoints, and the 2026 PUMS is unavailable. Only two annual endpoints were compared. No ACS monthly event study, individual transition, permanent-to-contract transition, or causal AI effect was estimated. Further work should complete pre/post annual profiles, harmonize missing historical code regimes, and prespecify pooling and precision rules.

## Reproduction and sources

Code and logs are in `work/us_public_validation_20261126/acs/`. Public outputs are in this directory. `acs_validation_checks.json` records passed data-I/O checks, source manifests record URLs/checksums, and `acs_employment_replicate_totals.parquet` preserves the 80 replicate totals.

- [2019 official national person ZIP](https://www2.census.gov/programs-surveys/acs/data/pums/2019/1-Year/csv_pus.zip)
- [2024 official national person ZIP](https://www2.census.gov/programs-surveys/acs/data/pums/2024/1-Year/csv_pus.zip)
- [2019 variable schema](https://api.census.gov/data/2019/acs/acs1/pums/variables.html)
- [2024 variable schema](https://api.census.gov/data/2024/acs/acs1/pums/variables.html)
- [ACS 2024 accuracy and replicate weights](https://www2.census.gov/programs-surveys/acs/tech_docs/pums/accuracy/2024AccuracyPUMS.pdf)
- [Official BLS CPI-U API](https://api.bls.gov/publicAPI/v2/timeseries/data/CUUR0000SA0?startyear=2019&endyear=2024&annualaverage=true)
"""
    # Keep prose readable without changing code/data labels.
    for old, new in [
        ("November26,2026", "November 26, 2026"),
        ("ages22–25", "ages 22–25"),
        ("50states", "50 states"),
        ("51geographies", "51 geographies"),
        ("6,662,441person", "6,662,441 person"),
        ("2,496employment", "2,496 employment"),
        ("80provided", "80 provided"),
        ("80-replicate", "80-replicate"),
        ("Census2018", "Census 2018"),
        (
            "CPI-U annual averages are255.657for2019and313.689for2024",
            "CPI-U annual averages are 255.657 for 2019 and 313.689 for 2024",
        ),
    ]:
        text = text.replace(old, new)
    (O / "ACS_VALIDATION_REPORT_EN.md").write_text(text)
    for name in ["source_manifest.json", "cpi_annual_verified.json"]:
        shutil.copy2(W / name, O / name)
    national.to_csv(O / "acs_national_relative_changes.csv", index=False)
    print("REPORT WRITTEN", O / "ACS_VALIDATION_REPORT_EN.md", flush=True)


if __name__ == "__main__":
    main()
