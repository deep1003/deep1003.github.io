"""Check calculation functions without emitting figures or mutating research data."""

import importlib.util
from pathlib import Path
import numpy as np

p = Path(__file__).with_name("process.py")
s = importlib.util.spec_from_file_location("acs_process", p)
m = importlib.util.module_from_spec(s)
s.loader.exec_module(m)
r = m.interval(10, np.full(80, 11.0))
assert r["SE"] == 2 and np.isclose(r["CI95_low"], 6.08)
x = np.array([10.0, 30.0, 20.0])
w = np.tile(np.array([1.0, 1.0, 2.0])[:, None], (1, 81))
med = m.weighted_median(x, w)
assert np.allclose(med, 20)
w[0, 1] = -1
assert np.isnan(m.weighted_median(x, w)[1])
assert m.weighted_median(x, w)[0] == 20
assert np.isnan(m.interval(0, np.zeros(80))["SE"])
import pandas as pd

score = pd.read_csv(m.SCORE)
bridge_test = m.assign_exposure_probabilities(
    pd.DataFrame({"OCCP": [50, 10, 9999]}), 2017, score
)
assert np.allclose(
    bridge_test[["prob_Q5", "prob_Q1–Q4", "prob_Unmapped"]].sum(axis=1), 1
)
assert bridge_test.loc[2, "prob_Unmapped"] == 1
assert "occupation" not in bridge_test and "occ" not in bridge_test
print("ACS CALCULATION AND FRACTIONAL-BRIDGE SMOKE PASSED. No figures emitted.")
