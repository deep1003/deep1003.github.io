"""Annual ACS occupation validation with replicate uncertainty, not current-hours DID."""

from pathlib import Path
import hashlib, json, zipfile, inspect
import pandas as pd
import numpy as np

W = Path(__file__).resolve().parent
R = W.parents[2]
O = R / "outputs/US_Public_Validation_20261126/acs"
O.mkdir(parents=True, exist_ok=True)
REPS = [f"PWGTP{i}" for i in range(1, 81)]
WEIGHTS = ["PWGTP"] + REPS
SCORE = (
    R
    / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/frozen_THAIE_occupation_assignments.csv"
)
COLS = [
    "RELP",
    "RELSHIPP",
    "TYPE",
    "TYPEHUGQ",
    "SERIALNO",
    "SPORDER",
    "AGEP",
    "ESR",
    "OCCP",
    "WKHP",
    "WKWN",
    "WKW",
    "WAGP",
    "PERNP",
    "ADJINC",
    "ST",
    "STATE",
    "COW",
    "SEX",
    "SCHL",
    "DIS",
    "RAC1P",
    "HISP",
] + WEIGHTS


def sha(p):
    with Path(p).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def extract(year):
    raw = W / "raw" / f"acs_{year}_person_us.zip"
    cache = W / f"age22_25_{year}.parquet"
    meta = W / f"age22_25_{year}_extract.json"
    signature = {
        "raw_sha256": sha(raw),
        "extract_code_sha256": hashlib.sha256(
            (inspect.getsource(extract) + json.dumps(COLS)).encode()
        ).hexdigest(),
        "age": [22, 25],
        "columns": COLS,
    }
    if cache.exists() and meta.exists():
        rec = json.loads(meta.read_text())
        if rec.get("signature") == signature and rec.get("cache_sha256") == sha(cache):
            return pd.read_parquet(cache), rec
    pieces = []
    total = 0
    files = []
    with zipfile.ZipFile(raw) as z:
        for name in z.namelist():
            if name.lower().endswith(".csv"):
                files.append(name)
                for c in pd.read_csv(
                    z.open(name),
                    usecols=lambda v: v in COLS,
                    dtype={"SERIALNO": "string"},
                    chunksize=100000,
                    low_memory=False,
                ):
                    total += len(c)
                    c = c[c.AGEP.between(22, 25)].copy()
                    c = c.rename(
                        columns={
                            "ST": "state",
                            "STATE": "state",
                            "TYPE": "unit_type",
                            "TYPEHUGQ": "unit_type",
                        }
                    )
                    pieces.append(c)
                    if total % 1000000 == 0:
                        print("READ", year, total, flush=True)
    d = pd.concat(pieces, ignore_index=True)
    assert d.AGEP.between(22, 25).all()
    assert not d.duplicated(["SERIALNO", "SPORDER"]).any()
    assert d.PWGTP.gt(0).all()
    assert d.state.between(1, 56).all()
    assert d[WEIGHTS].notna().all().all()
    d.to_parquet(cache, index=False)
    rec = {
        "year": year,
        "signature": signature,
        "all_age_unweighted_records": total,
        "age22_25_unweighted_records": len(d),
        "age22_25_weighted_people": float(d.PWGTP.sum()),
        "csv_members": files,
        "states": sorted(map(int, d.state.unique())),
        "minimum_person_replicate_weight": float(d[REPS].min().min()),
        "cache_sha256": sha(cache),
    }
    meta.write_text(json.dumps(rec, indent=2))
    return d, rec


def interval(point, rep):
    se = float(np.sqrt(4 / 80 * np.square(rep - point).sum()))
    status = "replicate_SDR"
    if not np.isfinite(se):
        status = "replicate_estimator_undefined_SE_withheld"
    elif point == 0 or se == 0:
        # Census accuracy guidance requires a GVF fallback for uncontrolled zero
        # estimates/zero SDR errors. Do not publish spurious certainty.
        se = np.nan
        status = "requires_GVF_fallback_SE_withheld"
    return {
        "estimate": float(point),
        "SE": se,
        "variance_status": status,
        "CI95_low": float(point - 1.96 * se),
        "CI95_high": float(point + 1.96 * se),
    }


def weighted_median(values, weights):
    order = np.argsort(values)
    v = values[order]
    w = weights[order, :]
    result = np.full(w.shape[1], np.nan)
    for j in range(w.shape[1]):
        # Signed replicate weights are legitimate for linear estimates, but do
        # not define a probability distribution for this quantile estimator.
        # Preserve them for counts/means; withhold affected quantile SEs.
        if (w[:, j] < 0).any() or w[:, j].sum() <= 0:
            continue
        cs = w[:, j].cumsum()
        result[j] = v[np.searchsorted(cs, w[:, j].sum() / 2, side="left")]
    return result


def assign_exposure_probabilities(d, year, score):
    """Keep historical workers intact; use expected exposure contributions only."""
    if year == 2017:
        conversion = pd.read_csv(
            R
            / "outputs/US_THAIE_Regional_Youth_20261122/extension_2019/derived/occupation_conversion_2010_2018.csv"
        )
        assert np.allclose(conversion.groupby("old").rate.sum(), 1)
        bridge = conversion.merge(
            score, left_on="new", right_on="occ", how="left", validate="many_to_one"
        )
        bridge["band"] = np.where(
            bridge.THAIE_q.eq(5),
            "Q5",
            np.where(bridge.THAIE_q.between(1, 4), "Q1–Q4", "Unmapped"),
        )
        probabilities = bridge.groupby(["old", "band"]).rate.sum().unstack(fill_value=0)
        for band in ["Q5", "Q1–Q4"]:
            d["prob_" + band] = d.OCCP.map(probabilities[band]).fillna(0)
        d["prob_Unmapped"] = 1 - d["prob_Q5"] - d["prob_Q1–Q4"]
    else:
        d = d.merge(
            score, left_on="OCCP", right_on="occ", how="left", validate="many_to_one"
        )
        d["prob_Q5"] = d.THAIE_q.eq(5).astype(float)
        d["prob_Q1–Q4"] = d.THAIE_q.between(1, 4).astype(float)
        d["prob_Unmapped"] = 1 - d["prob_Q5"] - d["prob_Q1–Q4"]
    assert np.allclose(d[["prob_Q5", "prob_Q1–Q4", "prob_Unmapped"]].sum(axis=1), 1)
    assert d[["prob_Q5", "prob_Q1–Q4", "prob_Unmapped"]].ge(-1e-12).all().all()
    return d


def run():
    score = pd.read_csv(SCORE)
    assert not score.occ.duplicated().any()
    rows = []
    earn = []
    audit = []
    rep_rows = []
    salary_rep_rows = []
    population_rep_rows = []
    cpi = json.loads((W / "cpi_annual_verified.json").read_text())
    ratio = {
        int(y): cpi["annual_CPI_U"]["2024"] / float(v)
        for y, v in cpi["annual_CPI_U"].items()
    }
    for year in [2017, 2018, 2019, 2023, 2024]:
        d, rec = extract(year)
        institutional = d.RELSHIPP.eq(37) if "RELSHIPP" in d else d.RELP.eq(16)
        d = d[~institutional & ~d.ESR.isin([4, 5])].copy()
        rec["civilian_noninstitutional_age22_25_n"] = len(d)
        rec["civilian_noninstitutional_age22_25_weighted_people"] = float(d.PWGTP.sum())
        d = assign_exposure_probabilities(d, year, score)
        d["employed"] = d.ESR.isin([1, 2])
        d["FT_proxy"] = d.employed & d.WKHP.ge(35)
        d["PT_proxy"] = d.employed & d.WKHP.between(1, 34)
        d["hours_missing"] = d.employed & ~(d.FT_proxy | d.PT_proxy)
        d["annual_salary_2024USD"] = d.WAGP * d.ADJINC / 1e6 * ratio[year]
        assert np.allclose(
            d.FT_proxy.astype(int)
            + d.PT_proxy.astype(int)
            + d.hours_missing.astype(int),
            d.employed.astype(int),
        )
        rec["employed_mapping_share"] = float(
            (d.PWGTP * (d["prob_Q5"] + d["prob_Q1–Q4"]))[d.employed].sum()
            / d.loc[d.employed, "PWGTP"].sum()
        )
        rec["exposure_assignment"] = (
            "Expected fractional 2010-to-2018 exposure contributions; no observed detailed new occupation"
            if year == 2017
            else "Direct Census2018 occupational score mapping"
        )
        audit.append(rec)
        for state in [0] + sorted(map(int, d.state.unique())):
            g = d if state == 0 else d[d.state.eq(state)]
            weights = g[WEIGHTS].to_numpy(float)
            pop = weights.sum(axis=0)
            population_rep_rows.append(
                {
                    "year": year,
                    "state": state,
                    "age": "22–25",
                    "unweighted_n": len(g),
                    **{f"estimate_r{i}": float(pop[i]) for i in range(81)},
                }
            )
            for band in ["Q5", "Q1–Q4", "Unmapped"]:
                for outcome in ["employed", "FT_proxy", "PT_proxy", "hours_missing"]:
                    probability = g["prob_" + band].to_numpy(float)
                    mask = g[outcome].to_numpy() & (probability > 0)
                    w = weights[mask] * probability[mask, None]
                    tot = w.sum(axis=0)
                    n = int(mask.sum())
                    eff = float(tot[0] ** 2 / np.square(w[:, 0]).sum()) if n else 0
                    base = {
                        "year": year,
                        "state": state,
                        "age": "22–25",
                        "band": band,
                        "outcome": outcome,
                        "unweighted_n": n,
                        "fractional_record_equivalents": float(probability[mask].sum()),
                        "n_interpretation": (
                            "Contributing observed records; groups can overlap due to fractional bridge"
                            if year == 2017
                            else "Observed group records"
                        ),
                        "population_unweighted_n": len(g),
                        "Kish_n_eff_weights_only": eff,
                    }
                    rows.append(
                        {
                            **base,
                            "measure": "weighted_people",
                            **interval(tot[0], tot[1:]),
                        }
                    )
                    rates = tot / pop * 100
                    rows.append(
                        {
                            **base,
                            "measure": "age_population_contribution_pp",
                            **interval(rates[0], rates[1:]),
                        }
                    )
                    rep_rows.append(
                        {**base, **{f"estimate_r{i}": float(tot[i]) for i in range(81)}}
                    )
                # Salary-worker annual pay conditional on current civilian employment and positive salary.
                mask = (
                    g.employed
                    & g.COW.between(1, 5)
                    & g.annual_salary_2024USD.gt(0)
                    & g["prob_" + band].gt(0)
                )
                z = g.loc[mask]
                w = (
                    z[WEIGHTS].to_numpy(float)
                    * z["prob_" + band].to_numpy(float)[:, None]
                )
                v = z.annual_salary_2024USD.to_numpy(float)
                n = len(z)
                if n:
                    denom = w.sum(axis=0)
                    salary_num = (v[:, None] * w).sum(axis=0)
                    salary_rep_rows.append(
                        {
                            "year": year,
                            "state": state,
                            "band": band,
                            "unweighted_n": n,
                            **{f"den_r{i}": float(denom[i]) for i in range(81)},
                            **{f"num_r{i}": float(salary_num[i]) for i in range(81)},
                        }
                    )
                    mean = np.divide(
                        (v[:, None] * w).sum(axis=0),
                        denom,
                        out=np.full(81, np.nan),
                        where=denom > 0,
                    )
                    median = (
                        weighted_median(v, w) if year != 2017 else np.full(81, np.nan)
                    )
                    for name, est in [
                        ("annual_salary_mean_2024USD", mean),
                        ("annual_salary_median_2024USD", median),
                    ]:
                        if np.isfinite(est[0]):
                            earn.append(
                                {
                                    "year": year,
                                    "state": state,
                                    "age": "22–25",
                                    "band": band,
                                    "outcome": name,
                                    "unweighted_n": n,
                                    "weighted_people": float(denom[0]),
                                    "small_sample_below30": n < 30,
                                    "fractional_record_equivalents": float(
                                        z["prob_" + band].sum()
                                    ),
                                    "exposure_assignment": (
                                        "Expected fractional band contributions"
                                        if year == 2017
                                        else "Observed occupation mapped to fixed band"
                                    ),
                                    **interval(est[0], est[1:]),
                                }
                            )
        print(
            "AGGREGATED",
            year,
            len(d),
            "records",
            rec["employed_mapping_share"],
            flush=True,
        )
    pd.DataFrame(population_rep_rows).to_parquet(
        O / "acs_population_annual_replicate_totals.parquet", index=False
    )
    pd.DataFrame(salary_rep_rows).to_parquet(
        O / "acs_salary_annual_replicate_components.parquet", index=False
    )
    employment = pd.DataFrame(rows)
    earnings = pd.DataFrame(earn)
    replicates = pd.DataFrame(rep_rows)
    employment.to_csv(O / "acs_employment_hours_annual.csv", index=False)
    earnings.to_csv(O / "acs_annual_salary_annual.csv", index=False)
    replicates.to_parquet(
        O / "acs_employment_annual_replicate_totals.parquet", index=False
    )
    (O / "acs_annual_processing_audit.json").write_text(json.dumps(audit, indent=2))
    # Preserve explicitly labeled two-endpoint outputs for the earlier check.
    employment[employment.year.isin([2019, 2024])].to_csv(
        O / "acs_employment_hours_2019_2024.csv", index=False
    )
    earnings[earnings.year.isin([2019, 2024])].to_csv(
        O / "acs_annual_salary_2019_2024.csv", index=False
    )
    replicates[replicates.year.isin([2019, 2024])].to_parquet(
        O / "acs_employment_replicate_totals.parquet", index=False
    )
    (O / "acs_processing_audit.json").write_text(
        json.dumps([x for x in audit if x["year"] in [2019, 2024]], indent=2)
    )
    lineage = {
        "processing_code_sha256": sha(__file__),
        "score_sha256": sha(SCORE),
        "crosswalk_sha256": sha(
            R
            / "outputs/US_THAIE_Regional_Youth_20261122/extension_2019/derived/occupation_conversion_2010_2018.csv"
        ),
        "CPI_sha256": sha(W / "cpi_annual_verified.json"),
        "population_universe": "Civilian noninstitutional ages22–25; all eligible population preserved before exposure mapping",
    }
    (O / "acs_processing_lineage.json").write_text(json.dumps(lineage, indent=2))
    print("COMPLETE", len(rows), len(earn), flush=True)


if __name__ == "__main__":
    run()
