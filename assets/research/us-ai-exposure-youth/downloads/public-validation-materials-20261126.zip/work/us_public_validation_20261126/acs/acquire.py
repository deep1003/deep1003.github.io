"""Acquire free official national ACS person archives with content provenance."""

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import requests, hashlib, json, zipfile, argparse

W = Path(__file__).resolve().parent
RAW = W / "raw"
RAW.mkdir(exist_ok=True)


def acquire(year):
    url = f"https://www2.census.gov/programs-surveys/acs/data/pums/{year}/1-Year/csv_pus.zip"
    target = RAW / f"acs_{year}_person_us.zip"
    side = RAW / f"acs_{year}_source.json"
    if target.exists() and side.exists():
        rec = json.loads(side.read_text())
        h = hashlib.file_digest(target.open("rb"), "sha256").hexdigest()
        if h == rec["sha256"] and zipfile.is_zipfile(target):
            print("VERIFIED cached", year, flush=True)
            return rec
    temp = target.with_suffix(".part")
    h = hashlib.sha256()
    size = 0
    print("DOWNLOAD", year, url, flush=True)
    with requests.get(url, stream=True, timeout=(30, 120)) as r:
        r.raise_for_status()
        etag = r.headers.get("etag")
        lm = r.headers.get("last-modified")
        with temp.open("wb") as f:
            for chunk in r.iter_content(1024 * 1024):
                if chunk:
                    f.write(chunk)
                    h.update(chunk)
                    size += len(chunk)
    assert zipfile.is_zipfile(temp)
    with zipfile.ZipFile(temp) as z:
        members = [
            {"name": x.filename, "uncompressed_bytes": x.file_size}
            for x in z.infolist()
        ]
    temp.replace(target)
    rec = {
        "year": year,
        "url": url,
        "path": str(target.resolve()),
        "sha256": h.hexdigest(),
        "bytes": size,
        "retrieved_utc": datetime.now(timezone.utc).isoformat(),
        "etag": etag,
        "last_modified": lm,
        "members": members,
    }
    side.write_text(json.dumps(rec, indent=2))
    print("DONE", year, size, flush=True)
    return rec


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--years", nargs="+", type=int, default=[2017, 2018, 2019, 2023, 2024]
    )
    args = parser.parse_args()
    with ThreadPoolExecutor(3) as ex:
        rows = list(ex.map(acquire, args.years))
    existing = (
        json.loads((W / "source_manifest.json").read_text())
        if (W / "source_manifest.json").exists()
        else []
    )
    merged = {r["year"]: r for r in existing + rows}
    rows = [merged[y] for y in sorted(merged)]
    (W / "source_manifest.json").write_text(json.dumps(rows, indent=2))
