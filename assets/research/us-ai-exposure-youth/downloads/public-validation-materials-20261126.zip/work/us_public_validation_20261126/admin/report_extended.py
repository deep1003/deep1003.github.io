"""Retain extended fits; add estimable annual-mean prelead diagnostics."""

import numpy as np
import pandas as pd
from run_admin_validation import O, POST_QWI, POST_J2J, regress


def table(frame, columns):
    z = frame[columns].copy()
    for c in z.select_dtypes("number"):
        z[c] = z[c].map(lambda value: f"{value:.4f}")
    return (
        "| "
        + " | ".join(columns)
        + " |\n| "
        + " | ".join(["---"] * len(columns))
        + " |\n"
        + "\n".join(
            "| " + " | ".join(map(str, row)) + " |"
            for row in z.itertuples(index=False, name=None)
        )
    )


result = pd.read_csv(O / "extended_pre_2017_results.csv")
result = result[result.spec.ne("event")].copy()
events = []
for kind, post, base, nums, earn in [
    ("qwi", POST_QWI, "Emp", ["HirN", "HirA", "Sep"], "EarnS"),
    ("j2j", POST_J2J, "MainB", ["NEHire", "ENSep", "J2JHire"], "JobStaySEarn_Dest"),
]:
    panel = pd.read_csv(
        O / (kind + "_extended_pre_industry_age_quarter.csv"), low_memory=False
    )
    for v in nums:
        panel["log_" + v + "_rate"] = np.log(
            panel[v].where(panel[v] > 0) / panel[base].where(panel[base] > 0)
        )
    panel["log_earnings"] = np.log(panel[earn].where(panel[earn] > 0))
    for age in ["22–24", "35–64", "22–24 relative to35–64"]:
        for y in ["log_" + v + "_rate" for v in nums] + ["log_earnings"]:
            if "relative" in age:
                d = (
                    panel.pivot(
                        index=["state", "sector", "qtime"], columns="age", values=y
                    )
                    .dropna()
                    .reset_index()
                )
                d[y] = d["22–24"] - d["35–64"]
                d["year"] = d.qtime // 4
                d["quarter"] = d.qtime % 4 + 1
                d = d.merge(
                    panel[["sector", "high_industry"]].drop_duplicates(),
                    on="sector",
                    validate="many_to_one",
                )
            else:
                d = panel[panel.age.eq(age)].copy()
            r = regress(d, y, list(range(2017 * 4, 2022 * 4 + 3)) + post, "event")
            r["age"] = age
            r["product"] = kind
            r["preperiod_start"] = "2017Q1"
            r["flag_policy"] = "strict"
            events.append(r)
result = pd.concat([result] + events, ignore_index=True)
assert not result.duplicated(["product", "age", "outcome", "spec", "term"]).any()
result.to_csv(O / "extended_pre_2017_results.csv", index=False)
main = result[result.spec.eq("main") & result.term.eq("DID")]
pre = (
    result[result.spec.eq("event")]
    .groupby(["product", "age", "outcome"])[
        [
            "pretrend_p",
            "pretrend_terms",
            "pretrend_original_quarterly_terms",
            "pretrend_quarterly_joint_singular",
        ]
    ]
    .first()
    .reset_index()
)
report = (
    """# Extended preperiod sensitivity

The same official files cover2017. This exploratory extension compares23prequarters2017Q1–2022Q3 with12QWI or11J2J postquarters;2022Q4 remains excluded. It is deliberately asymmetric and supplements, rather than replaces, the balanced primary comparison. Definitions, exposure, fixed effects, missingness rules and12industryclusters are unchanged.

All24main extended-window contrasts fail Holm24 correction. Youth new-hiring and nonemployment-entry estimates attenuate toward zero. The primary young-relative-to-older J2J hiring contrast also disappears. This reinforces sensitivity to the chosen preperiod, rather than establishing an AI-specific mechanism.

"""
    + table(
        main,
        ["product", "age", "outcome", "estimate_pct", "p_value", "p_Holm24_primary"],
    )
    + """

## Pretrend diagnostics

The extended event study has12nonpandemic quarterly leads. With only12industryclusters their joint covariance has insufficient rank, so a full12restriction cluster Wald test is not available. The reported lower-dimensional diagnostic tests three calendar-year average leads2017,2018,2019. This examines annual pre-event divergence and does not test every within-year quarterly movement. Four seasonal reference quarters2021Q4–2022Q3 remain omitted. Failure to reject these annual restrictions cannot establish parallel trends.

"""
    + table(
        pre,
        [
            "product",
            "age",
            "outcome",
            "pretrend_p",
            "pretrend_terms",
            "pretrend_original_quarterly_terms",
            "pretrend_quarterly_joint_singular",
        ],
    )
    + """

No images were displayed. Models remain exploratory with only three treated industry groups.
"""
)
(O / "ADMIN_EXTENDED_PRE_REPORT_EN.md").write_text(report)
print(pre.round(4).to_string(index=False))
print("EXTENDED PREPERIOD REPORT CHECKED. No plots displayed.")
