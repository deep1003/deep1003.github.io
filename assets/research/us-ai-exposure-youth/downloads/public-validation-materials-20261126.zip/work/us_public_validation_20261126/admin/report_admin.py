"""Check and summarize administrative mechanism estimates, without plotting."""

import hashlib
import json
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests
from run_admin_validation import O, ROOT, EX, PRE, POST_QWI, POST_J2J, regress

result = pd.read_csv(O / "administrative_DID_and_event_results.csv")
result = result[
    ~(
        result.age.eq("22–24 relative to35–64")
        & result.flag_policy.eq("strict")
        & result.spec.ne("main")
    )
].copy()
extra = []
descriptive = []
for kind, post, numerators, base in [
    ("qwi", POST_QWI, ["HirN", "HirA", "Sep"], "Emp"),
    ("j2j", POST_J2J, ["NEHire", "ENSep", "J2JHire"], "MainB"),
]:
    panel = pd.read_csv(
        O / (kind + "_industry_age_quarter_strict.csv"), low_memory=False
    )
    window = PRE + post
    for num in numerators:
        panel["log_" + num + "_rate"] = np.log(
            panel[num].where(panel[num] > 0) / panel[base].where(panel[base] > 0)
        )
    earn = "EarnS" if kind == "qwi" else "JobStaySEarn_Dest"
    panel["log_earnings"] = np.log(panel[earn].where(panel[earn] > 0))
    outcomes = ["log_" + num + "_rate" for num in numerators] + ["log_earnings"]
    for y in outcomes:
        wide = (
            panel.pivot(index=["state", "sector", "qtime"], columns="age", values=y)
            .dropna()
            .reset_index()
        )
        wide[y] = wide["22–24"] - wide["35–64"]
        wide["year"] = wide.qtime // 4
        wide["quarter"] = wide.qtime % 4 + 1
        wide = wide.merge(
            panel[["sector", "high_industry"]].drop_duplicates(),
            on="sector",
            validate="many_to_one",
        )
        for spec in ["no_covid", "trend", "event"]:
            w = (
                [q for q in window if not 2020 * 4 <= q < 2022 * 4]
                if spec == "no_covid"
                else window
            )
            r = regress(wide, y, w, spec)
            if r is not None:
                r["age"] = "22–24 relative to35–64"
                r["flag_policy"] = "strict"
                r["product"] = kind
                extra.append(r)
    for age in ["22–24", "35–64"]:
        for num in numerators:
            d = (
                panel[panel.age.eq(age) & panel.qtime.isin(window)]
                .dropna(subset=[num, base])
                .copy()
            )
            n = d.groupby(["state", "sector"]).qtime.nunique()
            good = n[n.eq(len(window))].index
            d = d.set_index(["state", "sector"]).loc[good].reset_index()
            for high, g in d.groupby("high_industry"):
                q = g.groupby("qtime")[[num, base]].sum()
                rate = q[num] / q[base]
                pre = rate.loc[rate.index.isin(PRE)].mean()
                after = rate.loc[rate.index.isin(post)].mean()
                descriptive.append(
                    {
                        "product": kind,
                        "age": age,
                        "high_industry": high,
                        "outcome": num + "_per_beginning_job",
                        "pre_mean": pre,
                        "post_mean": after,
                        "change_pct": 100 * (after / pre - 1),
                        "states": g.state.nunique(),
                        "state_industry_units": g[["state", "sector"]]
                        .drop_duplicates()
                        .shape[0],
                        "pre_quarters": len(PRE),
                        "post_quarters": len(post),
                    }
                )
    # Include every supplied state/DC, including those without2019+ observations.
    manifest = pd.read_csv(O / "source_manifest.csv")
    states = manifest[manifest.kind.eq(kind)].state.tolist()
    for policy in ["strict", "released"]:
        p = O / (kind + "_state_coverage_" + policy + ".csv")
        c = pd.read_csv(p)
        idx = pd.MultiIndex.from_product(
            [states, ["22–24", "35–64"]], names=["state", "age"]
        )
        c = c.set_index(["state", "age"]).reindex(idx).reset_index()
        c["quarters"] = c.quarters.fillna(0).astype(int)
        c["has_any_window_data"] = c.quarters.gt(0)
        c["full_calendar_span"] = c.quarters.eq(len(window))
        c.to_csv(p, index=False)
result = pd.concat([result] + extra, ignore_index=True)
primary = (
    result.spec.eq("main") & result.flag_policy.eq("strict") & result.term.eq("DID")
)
assert primary.sum() == 24
result["p_Holm24_primary"] = np.nan
result.loc[primary, "p_Holm24_primary"] = multipletests(
    result.loc[primary, "p_value"], method="holm"
)[1]
assert (
    np.isfinite(result.beta_log).all()
    and np.isfinite(result.se_industry).all()
    and result.se_industry.gt(0).all()
)
result.to_csv(O / "administrative_DID_and_event_results.csv", index=False)
main = result[primary].copy()
main.to_csv(O / "administrative_primary_results.csv", index=False)
result[result.term.eq("DID")].to_csv(
    O / "administrative_specification_comparison.csv", index=False
)
pd.DataFrame(descriptive).to_csv(O / "balanced_descriptive_changes.csv", index=False)
# Verify the frozen exposure directly against its2019 aggregation inputs.
a = pd.read_parquet(ROOT / "work/us_fe3/annual_exposure_2019.parquet")
a = (
    a[a.kind.eq("industry") & a.sector.between(1, 13)]
    .groupby("sector")[["emp", "numer_THAIE", "numer_coverage"]]
    .sum()
)
e = pd.read_csv(EX).set_index("industry").sort_index()
assert np.allclose(a.numer_THAIE / a.numer_coverage, e.THAIE, atol=1e-12)
assert np.allclose(a.numer_coverage / a.emp, e.coverage, atol=1e-12)
provenance = {
    "own_exposure_reaggregation_matches": True,
    "frozen_exposure_sha256": hashlib.sha256(EX.read_bytes()).hexdigest(),
    "aggregation_input_sha256": hashlib.sha256(
        (ROOT / "work/us_fe3/annual_exposure_2019.parquet").read_bytes()
    ).hexdigest(),
    "high_broad_industries": [7, 8, 9],
    "occupation_quintiles_not_assumed_equal_to_industry_quintiles": True,
}
(O / "exposure_provenance.json").write_text(json.dumps(provenance, indent=2))


def table(d, cols):
    z = d[cols].copy()
    for c in z.select_dtypes("number"):
        z[c] = z[c].map(lambda v: f"{v:.4f}")
    return (
        "| "
        + " | ".join(cols)
        + " |\n| "
        + " | ".join(["---"] * len(cols))
        + " |\n"
        + "\n".join(
            "| " + " | ".join(map(str, r)) + " |"
            for r in z.itertuples(index=False, name=None)
        )
    )


cols = [
    "product",
    "age",
    "outcome",
    "estimate_pct",
    "ci_low_pct",
    "ci_high_pct",
    "p_value",
    "p_Holm24_primary",
    "states",
    "industries",
]
pre = (
    result[result.spec.eq("event")]
    .groupby(["product", "age", "outcome"])[["pretrend_p", "pretrend_terms"]]
    .first()
    .reset_index()
)
report = (
    """# Independent public-administrative validation of entry and mobility mechanisms

Verified November26,2026. Free official QWI and J2J extracts were analyzed; no paid access or individual records were required. No figures were emitted.

## Data and exposure

The source manifest records102 official state/DC files and verified SHA256 hashes. Both products contain mutually exclusive NAICS sectors; all-industry rows, sex subtotals and age totals were excluded. Nineteen NAICS sectors were mapped to12 mutually exclusive CPS broad industry groups. Private-sector QWI ownershipA05 was used; public administration92 was excluded. J2J ownershipA00 represents its all-covered-ownership universe and differs from QWI private ownership. Agricultural and other UI coverage limits remain. Public LEHD estimates are modeled/noise-protected administrative aggregates, not error-free job counts.

Own frozen2019 industry THAIE was reaggregated and matched its original numerator/coverage inputs. High exposure comprises information, financial activities, and professional/business services. This INDUSTRY treatment is not occupational THAIEQ5 and must not be described as an exact replication of the CPS occupational result. The2019component is employment composition applied to retrospective task-based THAIE scores, not proof that those scores were observed in2019. Broad-industry bins do not guarantee exactly20% of jobs per bin. Frozen national occupational composition provides exposure, not observed adoption.

Public age categories permit22–24 and35–64, not the requested exact22–25 and40+ groups. Allstates/DC were inventoried, including missing coverage; outcome-specific balanced panels retain48–49 states/DC. Census age bins do not identify recent graduates or first jobs.

## Design

QWI compares12prequarters2019Q4–2022Q3 with12postquarters2023Q1–2025Q4. J2J has11postquarters through2025Q3. Transition2022Q4 is excluded. Data collected more recently are not silently treated as available for all indicators. Regressions require complete state–industry–age support for the outcome. Suppressed/unavailable cells remain missing, never zero. Strict released flags1,6,10 are primary; adding distorted released flags7,9,12 is sensitivity. Broad-industry totals require every NAICS×age component. Earnings averages use their appropriate employment weights.

Outcomes are log quarterly hires or separations divided by beginning-quarter employment, and log average earnings. The ratios are flows per beginning job, not individual hiring probabilities. QWI HirN excludes recalls but does not establish first-career entry. J2J nonemployment-to-employment is not the CPS unemployment category. QWI earnings are monthly averages and J2J earnings are quarterly averages. Earnings refer to stable/full-quarter jobs and are not hourly wages, FT status, contract permanence or total welfare. Common inflation is absorbed by state×date effects; reported raw earnings levels are nominal.

OLS uses state×industry, state×calendar-quarter and industry×quarter-of-year fixed effects, plus high-industry interactions with2020–2021 pandemic quarters. State–industry cells have equal regression weight; the coefficient is not a population-weighted national average. The young/older log-ratio model is a descriptive triple-difference analogue. Standard errors cluster by12broadindustries, with only3treatedindustries, using t11 working inference. Two-way state/industry SEs accompany outputs. They are not official administrative measurement-error uncertainty. All24primary contrasts receive Holm correction; per-product12test corrections are also retained.

Event studies retain the industry-specific seasonal FE and therefore omit four seasonal reference quarters2021Q4–2022Q3. A single reference quarter with saturated quarter effects is collinear with that seasonal structure. Four-reference normalization was checked for full rank/conditioning and positive variances. It leaves only one non-pandemic pre-event coefficient in this short window. Non-rejection is weak evidence and cannot validate parallel trends. Trend and no-pandemic sensitivities are exploratory.

## Primary results

"""
    + table(main, cols)
    + """

## Interpretation

No youth22–24 primary hiring, separation or earnings result survives the24test correction. The point estimates are consistent with weaker hiring in high-exposure industries, but their intervals do not establish a youth-specific AI effect. In the primary J2J model, older workers' nonemployment-entry and job-to-job hiring rates decline more than youth rates. The young-relative-to-older job-to-job hiring contrast is positive, not negative. That J2J relative contrast is +5.13% (raw p=.000749, Holm24 p=.0180), but becomes +0.64% (p=.703) after adding a high-industry linear trend; omitting2020–2021 gives +5.06% (p=.00112). Thus even the corrected primary contrast is not robust to the trend specification. This remains a descriptive industry-level mechanism result, with very few independent exposure clusters and incomplete pretrend information. It cannot be substituted for the original occupational CPS full-time outcome or interpreted as proof that older workers are harmed by AI.

A hiring-rate reduction may reflect ordinary churn, demand, industry-specific cycles or the denominator as well as entry opportunity. A separation ratio does not distinguish quits from layoffs here. Neither product observes full-time-to-part-time or permanent-to-contract transitions, AI adoption, training or benefits. Both products arise from overlapping LEHD infrastructure, so they are not independent replications of one another even though they are independent of CPS survey outcomes.

## Pretrend diagnostics

"""
    + table(pre, ["product", "age", "outcome", "pretrend_p", "pretrend_terms"])
    + """

## Sources and reproduction

- [Official LEHD public data and nonsampling-error statement](https://lehd.ces.census.gov/data/)
- [QWI definitions and aggregation guidance](https://lehd.ces.census.gov/doc/QWI_101.pdf)
- [J2J technical documentation](https://lehd.ces.census.gov/doc/jobtojob_documentation_long.pdf)
- Exact downloaded URLs, hashes and local source paths appear in source_manifest.csv.
- Run run_admin_validation.py and then report_admin.py using the project environment. Original official files are preserved under work/us_robustness_data_20261124/raw. No account or purchase is needed. The per-state release text files remain available alongside those sources.

No manuscript or homepage was changed by this module.
"""
)
(O / "ADMIN_VALIDATION_REPORT_EN.md").write_text(report)
print(main[cols].round(4).to_string(index=False))
print("ADMINISTRATIVE REPORT AND INPUT/OUTPUT CHECKS PASSED. No plots displayed.")
