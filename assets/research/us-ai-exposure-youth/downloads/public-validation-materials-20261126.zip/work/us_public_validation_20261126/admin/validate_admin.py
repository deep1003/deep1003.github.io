"""Independent reduced-panel OLS and release/support checks; no figures."""

import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.linalg import qr
from run_admin_validation import O, PRE, POST_QWI, regress

p = pd.read_csv(O / "qwi_industry_age_quarter_strict.csv", low_memory=False)
a = p[
    p.age.eq("22–24")
    & p.state.isin(["ca", "ny"])
    & p.sector.isin([3, 4, 5, 7, 8, 9])
    & p.qtime.isin(PRE + POST_QWI)
].copy()
a["log_HirN_rate"] = np.log(a.HirN / a.Emp)
assert a.log_HirN_rate.notna().all() and len(a) == 288
r = regress(a, "log_HirN_rate", PRE + POST_QWI, "main").iloc[0]
fields = [
    a.state + "_" + a.sector.astype(str),
    a.state + "_" + a.qtime.astype(str),
    a.sector.astype(str) + "_" + a.quarter.astype(str),
]
dummy = np.column_stack([pd.get_dummies(c, dtype=float).to_numpy() for c in fields])
_, rr, piv = qr(dummy, mode="economic", pivoting=True)
rank = int(np.sum(abs(np.diag(rr)) > 1e-8))
D = dummy[:, piv[:rank]]
h = a.high_industry.to_numpy(float)
x = np.column_stack(
    [h * a.qtime.ge(2023 * 4)] + [h * a.qtime.eq(q) for q in range(2020 * 4, 2022 * 4)]
)
full = np.column_stack([D, x])
assert np.linalg.matrix_rank(full) == full.shape[1]
ref = sm.OLS(a.log_HirN_rate.to_numpy(), full).fit()
delta = float(abs(ref.params[-9] - r.beta_log))
assert delta < 1e-8
results = pd.read_csv(O / "administrative_DID_and_event_results.csv")
assert not results.duplicated(
    ["product", "age", "outcome", "spec", "flag_policy", "term"]
).any()
assert np.isfinite(results.beta_log).all() and results.se_industry.gt(0).all()
assert (
    len(
        results[
            (results.spec == "main")
            & (results.flag_policy == "strict")
            & (results.term == "DID")
        ]
    )
    == 24
)
for kind in ["qwi", "j2j"]:
    c = pd.read_csv(O / (kind + "_state_coverage_strict.csv"))
    assert c.state.nunique() == 51
    q = pd.read_csv(O / (kind + "_industry_age_quarter_strict.csv"), low_memory=False)
    assert set(q.sector) == set(range(1, 13))
    assert not q.duplicated(["state", "sector", "age", "qtime"]).any()
    for v in (
        ["Emp", "HirN", "HirA", "Sep", "EarnS"]
        if kind == "qwi"
        else ["MainB", "NEHire", "ENSep", "J2JHire", "JobStaySEarn_Dest"]
    ):
        assert q.loc[~q[v + "_valid"], v].isna().all()
report = {
    "passed": True,
    "independent_reduced_panel_rows": len(a),
    "explicit_dummy_FE_rank": rank,
    "DID_coefficient_difference": delta,
    "state_DC_inventories_each": 51,
    "primary_tests": 24,
    "no_duplicate_result_terms": True,
    "no_graphs_displayed": True,
}
(O / "independent_validation.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report))
