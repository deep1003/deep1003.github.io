"""2017-start robustness and event leads from the same free official files."""

import json
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests
from run_admin_validation import (
    O,
    QWI,
    J2J,
    load,
    aggregate,
    regress,
    POST_QWI,
    POST_J2J,
)

rows = []
for kind, vars, post, base, nums, earn in [
    ("qwi", QWI, POST_QWI, "Emp", ["HirN", "HirA", "Sep"], "EarnS"),
    (
        "j2j",
        J2J,
        POST_J2J,
        "MainB",
        ["NEHire", "ENSep", "J2JHire"],
        "JobStaySEarn_Dest",
    ),
]:
    raw = load(kind, vars, firstyear=2017)
    panel = aggregate(raw, kind, vars)
    panel.to_csv(O / (kind + "_extended_pre_industry_age_quarter.csv"), index=False)
    for v in nums:
        panel["log_" + v + "_rate"] = np.log(
            panel[v].where(panel[v] > 0) / panel[base].where(panel[base] > 0)
        )
    panel["log_earnings"] = np.log(panel[earn].where(panel[earn] > 0))
    outcomes = ["log_" + v + "_rate" for v in nums] + ["log_earnings"]
    pre = list(range(2017 * 4, 2022 * 4 + 3))
    window = pre + post
    for age in ["22–24", "35–64", "22–24 relative to35–64"]:
        for y in outcomes:
            if "relative" in age:
                d = (
                    panel.pivot(
                        index=["state", "sector", "qtime"], columns="age", values=y
                    )
                    .dropna()
                    .reset_index()
                )
                d[y] = d["22–24"] - d["35–64"]
                d["year"] = d.qtime // 4
                d["quarter"] = d.qtime % 4 + 1
                d = d.merge(
                    panel[["sector", "high_industry"]].drop_duplicates(),
                    on="sector",
                    validate="many_to_one",
                )
            else:
                d = panel[panel.age.eq(age)].copy()
            for spec in ["main", "trend", "event"]:
                r = regress(d, y, window, spec)
                if r is not None:
                    r["product"] = kind
                    r["age"] = age
                    r["preperiod_start"] = "2017Q1"
                    r["flag_policy"] = "strict"
                    rows.append(r)
    print("EXTENDED COMPLETE", kind, flush=True)
result = pd.concat(rows, ignore_index=True)
m = result.spec.eq("main") & result.term.eq("DID")
result["p_Holm24_primary"] = np.nan
result.loc[m, "p_Holm24_primary"] = multipletests(
    result.loc[m, "p_value"], method="holm"
)[1]
result.to_csv(O / "extended_pre_2017_results.csv", index=False)
print(
    result[m][
        ["product", "age", "outcome", "estimate_pct", "p_value", "p_Holm24_primary"]
    ]
    .round(4)
    .to_string(index=False)
)
(O / "extended_pre_checks.json").write_text(
    json.dumps(
        {
            "passed": bool(
                np.isfinite(result.beta_log).all() and result.se_industry.gt(0).all()
            ),
            "prequarters": 23,
            "QWI_postquarters": 12,
            "J2J_postquarters": 11,
            "note": "Asymmetric exploratory2017preextension, not replacement for balanced primary",
            "graphs_displayed": False,
        },
        indent=2,
    )
)
