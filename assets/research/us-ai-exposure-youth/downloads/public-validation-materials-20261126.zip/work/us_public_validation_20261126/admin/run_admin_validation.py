"""Free public LEHD mechanisms under frozen own-THAIE industry exposure.

No person records, Stanford results, paid access, or graphical output are used.
"""

from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import pyhdfe
from scipy.stats import t, f
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[3]
W = Path(__file__).resolve().parent
O = ROOT / "outputs/US_Public_Validation_20261126/admin"
R = ROOT / "work/us_robustness_data_20261124/raw"
EX = (
    ROOT
    / "outputs/US_Paper_Evidence_Audit_20261124/tables/frozen_industry_exposure_2019.csv"
)
MAP = {
    "11": 1,
    "21": 2,
    "23": 3,
    "31-33": 4,
    "42": 5,
    "44-45": 5,
    "22": 6,
    "48-49": 6,
    "51": 7,
    "52": 8,
    "53": 8,
    "54": 9,
    "55": 9,
    "56": 9,
    "61": 10,
    "62": 10,
    "71": 11,
    "72": 11,
    "81": 12,
}
DIM = [
    "periodicity",
    "seasonadj",
    "geo_level",
    "geography",
    "ind_level",
    "industry",
    "ownercode",
    "sex",
    "agegrp",
    "race",
    "ethnicity",
    "education",
    "firmage",
    "firmsize",
    "year",
    "quarter",
]
QWI = ["Emp", "EmpS", "HirA", "HirN", "HirNS", "Sep", "EarnS", "EarnHirNS"]
J2J = [
    "MainB",
    "NEHire",
    "ENSep",
    "J2JHire",
    "J2JSep",
    "JobStayS",
    "NEPersistS",
    "NEHireSEarn_Dest",
    "JobStaySEarn_Dest",
]
GOOD = {1, 6, 10}
PRE = list(range(2019 * 4 + 3, 2022 * 4 + 3))
POST_QWI = list(range(2023 * 4, 2026 * 4))
POST_J2J = list(range(2023 * 4, 2025 * 4 + 3))
manifest = []


def load(kind, variables, firstyear=2019):
    chunks = []
    for path in sorted(R.glob(kind + "_??.csv.gz")):
        state = path.name[len(kind) + 1 : len(kind) + 3]
        if state == "us":
            continue
        meta = json.loads(path.with_name(path.name + ".meta.json").read_text())
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert digest == meta["sha256"], path
        manifest.append(
            {
                "kind": kind,
                "state": state,
                "file": str(path.relative_to(ROOT)),
                "url": meta["url"],
                "sha256": digest,
                "bytes": path.stat().st_size,
            }
        )
        cols = DIM + variables + ["s" + v for v in variables]
        d = pd.read_csv(
            path,
            usecols=cols,
            dtype={"industry": str, "sex": str, "geography": str},
            low_memory=False,
        )
        d = d[
            d.year.between(firstyear, 2026)
            & d.ind_level.eq("S")
            & d.industry.isin(MAP)
            & d.sex.eq("0")
            & d.agegrp.isin(["A03", "A05", "A06", "A07"])
            & d.seasonadj.eq("U")
            & d.geo_level.eq("S")
        ].copy()
        assert d.ownercode.eq("A05" if kind == "qwi" else "A00").all()
        assert d.periodicity.eq("Q").all()
        for field, value in [
            ("race", "A0"),
            ("ethnicity", "A0"),
            ("education", "E0"),
            ("firmage", 0),
            ("firmsize", 0),
        ]:
            assert d[field].eq(value).all()
        d["state"] = state
        d["sector"] = d.industry.map(MAP)
        d["qtime"] = d.year * 4 + d.quarter - 1
        d["age"] = d.agegrp.map(
            {"A03": "22–24", "A05": "35–64", "A06": "35–64", "A07": "35–64"}
        )
        assert not d.duplicated(["state", "industry", "agegrp", "qtime"]).any()
        chunks.append(d)
    raw = pd.concat(chunks, ignore_index=True)
    raw.to_parquet(
        O
        / (
            kind
            + ("_extended" if firstyear < 2019 else "")
            + "_selected_official_cells.parquet"
        ),
        index=False,
    )
    return raw


def aggregate(raw, kind, variables, permissive=False):
    rows = []
    allowed = GOOD | ({7, 9, 12} if permissive else set())
    for (state, sector, age, qtime), g in raw.groupby(
        ["state", "sector", "age", "qtime"], sort=False
    ):
        expected = sum(s == sector for s in MAP.values()) * (1 if age == "22–24" else 3)
        row = {
            "state": state,
            "sector": sector,
            "age": age,
            "qtime": qtime,
            "year": qtime // 4,
            "quarter": qtime % 4 + 1,
            "components_expected": expected,
            "components_present": len(g),
        }
        for v in variables:
            ok = (
                (len(g) == expected)
                and g["s" + v].isin(allowed).all()
                and g[v].notna().all()
                and g[v].ge(0).all()
            )
            row[v + "_valid"] = ok
            if v in ["EarnS", "EarnHirNS", "NEHireSEarn_Dest", "JobStaySEarn_Dest"]:
                base = {
                    "EarnS": "EmpS",
                    "EarnHirNS": "HirNS",
                    "NEHireSEarn_Dest": "NEPersistS",
                    "JobStaySEarn_Dest": "JobStayS",
                }[v]
                ok = (
                    ok
                    and g["s" + base].isin(allowed).all()
                    and g[base].notna().all()
                    and g[base].sum() > 0
                )
                row[v] = float(np.average(g[v], weights=g[base])) if ok else np.nan
                row[v + "_valid"] = ok
            else:
                row[v] = float(g[v].sum()) if ok else np.nan
            row[v + "_flags"] = "|".join(map(str, sorted(g["s" + v].unique())))
        rows.append(row)
    d = pd.DataFrame(rows)
    ex = pd.read_csv(EX).rename(columns={"industry": "sector"})
    d = d.merge(
        ex[
            ["sector", "THAIE", "THAIE_z", "high_industry", "industry_name", "coverage"]
        ],
        on="sector",
        validate="many_to_one",
    )
    assert not d.duplicated(["state", "sector", "age", "qtime"]).any()
    return d


def cluster_cov(scores, groups, bread, factor):
    codes, labels = pd.factorize(groups, sort=True)
    u = np.zeros((len(labels), scores.shape[1]))
    np.add.at(u, codes, scores)
    return bread @ (u.T @ u) @ bread * (len(labels) / (len(labels) - 1)) * factor, len(
        labels
    )


def regress(d, yname, window, variant):
    a = d[d.qtime.isin(window) & d[yname].notna()].copy()
    # Exact balanced state-industry support; missing/suppressed values are never zeros.
    n = a.groupby(["state", "sector"]).qtime.nunique()
    keep = n[n.eq(len(window))].index
    a = a.set_index(["state", "sector"]).loc[keep].reset_index()
    if a.empty:
        return None
    a["state_sector"] = a.state + "_" + a.sector.astype(str)
    a["state_date"] = a.state + "_" + a.qtime.astype(str)
    a["sector_season"] = a.sector.astype(str) + "_" + a.quarter.astype(str)
    ids = np.column_stack(
        [
            pd.factorize(a[c], sort=True)[0]
            for c in ["state_sector", "state_date", "sector_season"]
        ]
    )
    algo = pyhdfe.create(ids, drop_singletons=False)
    h = a.high_industry.to_numpy(float)
    names = ["DID"]
    X = [h * a.qtime.ge(2023 * 4)]
    for q in range(2020 * 4, 2022 * 4):
        if a.qtime.eq(q).any():
            names.append("covid_" + str(q))
            X.append(h * a.qtime.eq(q))
    if variant == "trend":
        names.append("Q5trend")
        X.append(h * (a.qtime - (2022 * 4 + 3)) / 4)
    if variant == "event":
        X = []
        names = []
        for q in sorted(a.qtime.unique()):
            if q in range(2021 * 4 + 3, 2022 * 4 + 3):
                continue
            names.append("event_" + str(q))
            X.append(h * a.qtime.eq(q))
    X = np.column_stack(X)
    Y = a[yname].to_numpy()
    z = algo.residualize(np.column_stack([Y, X]))
    yr = z[:, 0]
    xr = z[:, 1:]
    singular_values = np.linalg.svd(xr, compute_uv=False)
    rank = int(np.sum(singular_values > singular_values[0] * 1e-8))
    assert rank == xr.shape[1], (yname, variant, rank, xr.shape[1])
    assert np.linalg.cond(xr.T @ xr) < 1e12
    bread = np.linalg.inv(xr.T @ xr)
    bread = (bread + bread.T) / 2
    b = bread @ xr.T @ yr
    res = yr - xr @ b
    scores = xr * res[:, None]
    factor = (len(a) - 1) / (len(a) - algo.degrees - len(b))
    cov, G = cluster_cov(scores, a.sector, bread, factor)
    covst, Gs = cluster_cov(scores, a.state, bread, factor)
    covjoint, _ = cluster_cov(scores, a.state_sector, bread, factor)
    two = cov + covst - covjoint
    rows = []
    for j, name in enumerate(names):
        assert cov[j, j] > 0, (yname, variant, name, cov[j, j])
        se = float(np.sqrt(cov[j, j]))
        df = G - 1
        crit = t.ppf(0.975, df)
        rows.append(
            {
                "outcome": yname,
                "spec": variant,
                "term": name,
                "N": len(a),
                "states": a.state.nunique(),
                "industries": G,
                "treated_industries": a[a.high_industry].sector.nunique(),
                "pre_quarters": sum(q < 2022 * 4 + 3 for q in window),
                "post_quarters": sum(q > 2022 * 4 + 3 for q in window),
                "beta_log": b[j],
                "se_industry": se,
                "estimate_pct": 100 * np.expm1(b[j]),
                "ci_low_pct": 100 * np.expm1(b[j] - crit * se),
                "ci_high_pct": 100 * np.expm1(b[j] + crit * se),
                "p_value": 2 * t.sf(abs(b[j] / se), df),
                "two_way_SE": float(np.sqrt(two[j, j])) if two[j, j] > 0 else np.nan,
            }
        )
    if variant == "event":
        leads = [
            j
            for j, name in enumerate(names)
            if int(name.split("_")[1]) < 2022 * 4 + 3
            and not 2020 * 4 <= int(name.split("_")[1]) < 2022 * 4
        ]
        v = cov[np.ix_(leads, leads)]
        quarterly_rank = np.linalg.matrix_rank(v)
        C = np.eye(len(b))[leads]
        test_type = "all_nonpandemic_quarterly_leads"
        if quarterly_rank < len(leads):
            # With12industryclusters,12lead restrictions cannot have full cluster rank.
            # Test calendar-year mean leads instead; retain the full-test failure flag.
            years = sorted({int(names[j].split("_")[1]) // 4 for j in leads})
            C = []
            for year in years:
                indices = [j for j in leads if int(names[j].split("_")[1]) // 4 == year]
                row = np.zeros(len(b))
                row[indices] = 1 / len(indices)
                C.append(row)
            C = np.asarray(C)
            test_type = "calendar_year_mean_nonpandemic_leads"
        vc = C @ cov @ C.T
        zc = C @ b
        rank = np.linalg.matrix_rank(vc)
        if len(C) and rank == len(C):
            stat = zc @ np.linalg.solve(vc, zc) / len(C)
            p = float(f.sf(stat, len(C), G - 1))
        else:
            p = np.nan
        for r in rows:
            r.update(
                pretrend_p=p,
                pretrend_terms=len(C),
                pretrend_original_quarterly_terms=len(leads),
                pretrend_quarterly_joint_singular=quarterly_rank < len(leads),
                pretrend_test_type=test_type,
                pretrend_singular=rank < len(C),
            )
    return pd.DataFrame(rows)


def analyze(kind, raw, variables, post):
    results = []
    for permissive in [False, True]:
        label = "released" if permissive else "strict"
        panel = aggregate(raw, kind, variables, permissive)
        panel.to_csv(
            O / (kind + "_industry_age_quarter_" + label + ".csv"), index=False
        )
        base = "Emp" if kind == "qwi" else "MainB"
        numerators = (
            ["HirN", "HirA", "Sep"] if kind == "qwi" else ["NEHire", "ENSep", "J2JHire"]
        )
        outcomes = []
        for v in numerators:
            panel["log_" + v + "_rate"] = np.log(
                panel[v].where(panel[v] > 0) / panel[base].where(panel[base] > 0)
            )
            outcomes.append("log_" + v + "_rate")
        earn = "EarnS" if kind == "qwi" else "JobStaySEarn_Dest"
        panel["log_earnings"] = np.log(panel[earn].where(panel[earn] > 0))
        outcomes.append("log_earnings")
        window = PRE + post
        for age in ["22–24", "35–64"]:
            d = panel[panel.age.eq(age)]
            for y in outcomes:
                for variant in ["main", "no_covid", "trend", "event"]:
                    if permissive and variant != "main":
                        continue
                    usewindow = (
                        [q for q in window if not 2020 * 4 <= q < 2022 * 4]
                        if variant == "no_covid"
                        else window
                    )
                    r = regress(d, y, usewindow, variant)
                    if r is not None:
                        r["age"] = age
                        r["flag_policy"] = label
                        r["product"] = kind
                        results.append(r)
        # Within-state/industry young/older log ratio is a descriptive DDD analogue.
        for y in outcomes:
            wide = (
                panel.pivot(index=["state", "sector", "qtime"], columns="age", values=y)
                .dropna()
                .reset_index()
            )
            wide[y] = wide["22–24"] - wide["35–64"]
            wide["year"] = wide.qtime // 4
            wide["quarter"] = wide.qtime % 4 + 1
            wide = wide.merge(
                panel[["sector", "high_industry"]].drop_duplicates(),
                on="sector",
                validate="many_to_one",
            )
            r = regress(wide, y, window, "main")
            if r is not None:
                r["age"] = "22–24 relative to35–64"
                r["flag_policy"] = label
                r["product"] = kind
                results.append(r)
        coverage = (
            panel[panel.qtime.isin(window)]
            .groupby(["state", "age"])
            .agg(
                first_q=("qtime", "min"),
                last_q=("qtime", "max"),
                quarters=("qtime", "nunique"),
                Hir_or_entry_valid=(numerators[0] + "_valid", "mean"),
                earn_valid=(earn + "_valid", "mean"),
            )
            .reset_index()
        )
        coverage.to_csv(O / (kind + "_state_coverage_" + label + ".csv"), index=False)
        if not permissive:
            desc = []
            for (age, high), g in panel[panel.qtime.isin(window)].groupby(
                ["age", "high_industry"]
            ):
                for v in numerators:
                    q = g.dropna(subset=[v, base]).groupby("qtime")[[v, base]].sum()
                    q["rate"] = q[v] / q[base]
                    pre = q.loc[q.index.isin(PRE), "rate"].mean()
                    postmean = q.loc[q.index.isin(post), "rate"].mean()
                    desc.append(
                        {
                            "product": kind,
                            "age": age,
                            "high_industry": high,
                            "outcome": v + "_per_beginning_job",
                            "pre_mean": pre,
                            "post_mean": postmean,
                            "change_pct": 100 * (postmean / pre - 1),
                            "warning": "available cells; regression uses outcome-specific balanced support",
                        }
                    )
            pd.DataFrame(desc).to_csv(
                O / (kind + "_descriptive_changes.csv"), index=False
            )
    return pd.concat(results, ignore_index=True)


if __name__ == "__main__":
    q = load("qwi", QWI)
    print("Loaded QWI", len(q), flush=True)
    j = load("j2j", J2J)
    print("Loaded J2J", len(j), flush=True)
    pd.DataFrame(manifest).to_csv(O / "source_manifest.csv", index=False)
    ex = pd.read_csv(EX)
    assert set(ex.loc[ex.high_industry, "industry"]) == {7, 8, 9}
    pd.DataFrame(
        {"NAICS_sector": list(MAP), "CPS_broad_industry": list(MAP.values())}
    ).to_csv(O / "industry_crosswalk.csv", index=False)
    ex.to_csv(O / "own_THAIE_industry_exposure_2019.csv", index=False)
    out = pd.concat(
        [analyze("qwi", q, QWI, POST_QWI), analyze("j2j", j, J2J, POST_J2J)],
        ignore_index=True,
    )
    out["p_Holm12_within_product"] = np.nan
    for product in ["qwi", "j2j"]:
        m = (
            out["product"].eq(product)
            & out.spec.eq("main")
            & out.flag_policy.eq("strict")
            & out.term.eq("DID")
        )
        out.loc[m, "p_Holm12_within_product"] = multipletests(
            out.loc[m, "p_value"], method="holm"
        )[1]
    out.to_csv(O / "administrative_DID_and_event_results.csv", index=False)
    check = {
        "passed": True,
        "source_files": len(manifest),
        "all_hashes_match": True,
        "no_allindustry_or_supersector_doublecounts": True,
        "missing_or_suppressed_never_zero": True,
        "youth_age": "22–24, not22–25",
        "older_age": "35–64, not40+",
        "transition_quarter_excluded": "2022Q4",
        "QWI_prequarters": 12,
        "QWI_postquarters": 12,
        "J2J_prequarters": 12,
        "J2J_postquarters": 11,
        "no_graphs_displayed": True,
        "records": len(out),
    }
    (O / "validation_checks.json").write_text(json.dumps(check, indent=2))
    print(json.dumps(check), flush=True)
