"""Remove the mirrored pre-event month to match observed relative-month support."""

import json
import pandas as pd
from run_validation import prepare, design, fit, contrast, T

rows = []
for window in [47, 36]:
    a, _ = prepare("22–25", window)
    a = a[~a.k.eq(-35)].reset_index(drop=True)
    assert a[a.k.lt(0)].date.nunique() == a[a.k.gt(0)].date.nunique() == window - 1
    x, names = design(a)
    for outcome in ["FT", "PT"]:
        b, v, _, info, _, _ = fit(a, outcome, x, names)
        rows.append(
            dict(
                age="22–25",
                window=window,
                outcome=outcome,
                pre_months=window - 1,
                post_months=window - 1,
                excluded_mirrored_pre_month="2019-12",
                **info,
                **contrast(b, v, names, "DID", info["occupation_clusters"] - 1)
            )
        )
pd.DataFrame(rows).to_csv(T / "matched_observation_sensitivity.csv", index=False)
print(
    pd.DataFrame(rows)[["window", "outcome", "estimate_pct", "p_value"]].to_string(
        index=False
    )
)
