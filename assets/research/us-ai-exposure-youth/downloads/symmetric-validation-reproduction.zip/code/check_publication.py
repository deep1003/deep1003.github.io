"""Final data-I/O and publication checks. No images or graphs are displayed."""

from pathlib import Path
import hashlib, json, zipfile
from urllib.parse import urlsplit, unquote
import pandas as pd
from bs4 import BeautifulSoup
from run_validation import ROOT, W, T, prepare, AGES

S = ROOT / "work/homepage-monthly/assets/research/us-ai-exposure-youth"
soup = BeautifulSoup((S / "index.html").read_text(), "html.parser")
assert (
    soup.find(id="symmetric-validation")
    and len(soup.select("#results details[open]")) == 1
)
assert soup.select_one("#results details[open]").get("id") == "story-overall"
assert "current estimates" in soup.find(id="symmetric-validation").summary.get_text()
assert "archived" in soup.find(id="monthly-cps-did").summary.get_text()
missing = []
for n in soup.select("[href],[src]"):
    v = n.get("href") or n.get("src")
    u = urlsplit(v)
    if (
        not u.scheme
        and not u.netloc
        and u.path
        and not u.path.startswith("/")
        and not (S / unquote(u.path)).exists()
    ):
        missing.append(u.path)
assert not missing, missing
with zipfile.ZipFile(S / "downloads/symmetric-validation-reproduction.zip") as z:
    assert z.testzip() is None
original = json.loads(
    (
        ROOT
        / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/THAIE_input_provenance.json"
    ).read_text()
)["inputs"]
p = (
    ROOT
    / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/occupation_industry_monthly_counts.parquet"
)
assert hashlib.sha256(p.read_bytes()).hexdigest() == next(
    r["sha256"] for r in original if r["file"] == p.name
)
counts = []
for window in [47, 36]:
    for age in AGES:
        a, info = prepare(age, window)
        assert a.date.str[:7].ne("2022-11").all() and a.date.str[:7].ne("2025-10").all()
        assert info["pre_months"] == window and info["post_months"] == window - 1
        counts.append(
            dict(
                age=age, window=window, pre=info["pre_months"], post=info["post_months"]
            )
        )
d = pd.read_csv(T / "did_results.csv")
assert len(d) == 28
assert d[d.window.eq(47) & d.spec.eq("main")].p_Holm_primary12.notna().all()
assert pd.read_csv(T / "event_studies.csv").groupby(["age", "outcome"]).ngroups == 12
for name in [
    "input_validation.json",
    "independent_numerical_validation.json",
    "final_validation.json",
]:
    assert json.loads((T / name).read_text())["passed"]
result = dict(
    passed=True,
    original_counts_hash_unchanged=True,
    regression_month_support=counts,
    all_links_exist=True,
    replication_zip_integrity=True,
    first_result_only_open=True,
    old_models_labeled_archived=True,
    plots_displayed=False,
)
(T / "publication_checks.json").write_text(json.dumps(result, indent=2))
print("PUBLICATION AND DATA-I/O CHECKS PASSED. No plots displayed.")
