"""Check whether requiring common FT/PT support drives the FT contrast."""

import pandas as pd
from run_validation import prepare, design, fit, contrast, T

# Rebuild target windows with FT-only positive fixed-effect support directly from raw aggregates.
from run_validation import RAW

rows = []
for window in [47, 36]:
    d = RAW[
        RAW.age.eq("22–25") & RAW.band.ne("Unmapped") & RAW.industry.between(1, 13)
    ].copy()
    dt = pd.to_datetime(d.date)
    k = (dt.dt.year - 2022) * 12 + dt.dt.month - 11
    d = d[k.abs().between(1, window)]
    dates = sorted(d.date.unique())
    meta = d[["occupation", "industry", "band"]].drop_duplicates()
    g = d.groupby(["occupation", "industry", "date"], as_index=False)[
        ["E", "FT", "PT", "nE"]
    ].sum()
    a = meta.merge(pd.DataFrame({"date": dates}), how="cross").merge(
        g, on=["occupation", "industry", "date"], how="left"
    )
    a[["E", "FT", "PT", "nE"]] = a[["E", "FT", "PT", "nE"]].fillna(0)
    dt = pd.to_datetime(a.date)
    a["year"] = dt.dt.year
    a["month"] = dt.dt.month
    a["quarter"] = dt.dt.quarter
    a["k"] = (a.year - 2022) * 12 + a.month - 11
    a["high"] = a.band.eq("Q5").astype(float)
    a["occ_industry"] = a.occupation.astype(str) + "_" + a.industry.astype(str)
    a["occ_season"] = a.occupation.astype(str) + "_" + a.month.astype(str)
    a["industry_date"] = a.industry.astype(str) + "_" + a.date
    before = a.FT.sum()
    for _ in range(20):
        n = len(a)
        for fe in ["occ_industry", "occ_season", "industry_date"]:
            z = a.groupby(fe).FT.sum()
            a = a[a[fe].isin(z.index[z.gt(0)])]
        if len(a) == n:
            break
    a = a.reset_index(drop=True)
    x, names = design(a)
    b, v, _, info, _, _ = fit(a, "FT", x, names)
    rows.append(
        dict(
            window=window,
            age="22–25",
            outcome="FT",
            spec="FT_only_support",
            FT_retention=a.FT.sum() / before,
            **info,
            **contrast(b, v, names, "DID", info["occupation_clusters"] - 1)
        )
    )
pd.DataFrame(rows).to_csv(T / "FT_only_support_sensitivity.csv", index=False)
print(
    pd.DataFrame(rows)[["window", "FT_retention", "estimate_pct", "p_value"]].to_string(
        index=False
    )
)
