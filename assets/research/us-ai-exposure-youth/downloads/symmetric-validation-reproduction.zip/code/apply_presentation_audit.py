"""Apply independently audited presentation repairs after publish.py. No plots emitted."""

from pathlib import Path
import json
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[2]
SITE = ROOT / "work/homepage-monthly/assets/research/us-ai-exposure-youth"
OUT = ROOT / "outputs/US_Symmetric_Validation_20261125/tables"

soup = BeautifulSoup((SITE / "index.html").read_text(), "html.parser")
methods = soup.find(id="full-study-methods")
methods.clear()
fragment = BeautifulSoup(
    """<summary>Full data construction, support and estimation methods</summary><div class="method-full"><div class="prose">
<p><strong>Population and age groups.</strong> CPS estimates cover employed civilian noninstitutional people aged 16 and older in the 50 states and DC. The six focal groups are 22–25, 26–30, 31–34, 35–40, 41–49, and 50+. The all-worker series also includes ages 16–21. Employed people include those at work and those temporarily absent. Composite final weights produce employment counts, not employment-to-population rates. Full-time and part-time follow the CPS labor-force classification and do not identify permanent versus temporary contracts. Recorded sex is reported as women and men.</p>
<p><strong>Exposure.</strong> Occupational THAIE quintiles use frozen 2019 employment-based membership. Quintiles are not recalculated within age, sex, or employment-status groups. Scores are retrospective task-based measures, not observed employer adoption. Unmapped occupations remain unassigned.</p>
<div class="equation">Index<sub>g,t</sub> = 100 × Employment<sub>g,t</sub> / Employment<sub>g,November 2022</sub><small>Each displayed curve uses its own November 2022 baseline and begins in November 2022. All supported curves therefore equal 100 in that month. Pooling across occupations uses weighted counts before normalization.</small></div>
<p><strong>Display coverage and support.</strong> The underlying descriptive file spans January 2020–October 2026. The active charts display November 2022 onward. A displayed observation requires at least 30 employed sample records and sufficient underlying 2022 support, including at least 120 person-month records. A series also requires a supported, positive November 2022 baseline. Missing or low-support values remain unavailable. October 2025 is linearly interpolated between supported September and November observations for display only and drawn with dashed lines. Curves are not seasonally adjusted. Employment stocks do not identify hiring, separations, or individual transitions.</p>
<p><strong>Within-occupation comparisons.</strong> Software developers are Census occupation 1021 and THAIE Q4 in this mapping. A fixed occupation score cannot define five exposure strata inside one detailed occupation. The age buttons select one age-specific employment curve while occupation remains fixed. The broader computer and mathematical family can contain multiple exposure groups. Age does not directly measure experience or seniority.</p>
<details><summary>Current symmetric-window DID and event-study design</summary><p>The primary pre-period is December 2018–October 2022 and the post-period is December 2022–October 2026. November 2022 is excluded as the transition month. Each side spans 47 calendar months, with 47 observed pre-months and 46 observed post-months because October 2025 is unavailable. The 36-month robustness window uses November 2019–October 2022 and December 2022–November 2025, with 36 and 35 observed months. No interpolated value enters a regression. Earlier 2017-start specifications remain explicitly archived.</p>
<p>Age-specific Poisson quasi-likelihood models estimate Q5 versus Q1–Q4 contrasts in weighted full-time or part-time counts. Fixed effects are occupation×industry, occupation×month-of-year, and industry×calendar-date. Separate Q5 interactions cover pandemic quarters in 2020–2021. Earlier occupational codes are probabilistically bridged to the common classification. Industry controls do not remove every occupation-specific or local shock.</p>
<p>Main FT and PT models share supported rows within each age and window. For ages 22–25 in the long window, this retains 91.75% of weighted FT and 99.48% of PT employment. FT-only sensitivity restores all covered FT employment. Zero survey counts in supported model cells are not administrative proof of zero jobs. The descriptive chart threshold is not imposed on estimation.</p>
<p>Reported intervals use occupation-score cluster covariance and are working model-based intervals, not complete CPS survey-design intervals. The 12 primary age-by-outcome contrasts receive Holm correction. Event studies use monthly observations in three-month relative-time bins, with August–October 2022 as the omitted reference. Pandemic quarters have separate nuisance coefficients and are excluded from the flat-lead joint test. Intervals are pointwise rather than simultaneous; boundary bins can contain fewer months.</p>
<p>Population controls, rotation overlap, historical crosswalk error, retrospective exposure, support selection, and unobserved AI adoption remain limitations. Numerical reproduction does not establish parallel trends or a causal AI effect. The current results and their sensitivities are reported together rather than selected by statistical significance.</p></details>
</div></div>""",
    "html.parser",
)
for child in list(fragment.contents):
    methods.append(child)
(SITE / "index.html").write_text(str(soup))

sources = [
    SITE / "story.js",
    ROOT / "work/us_youth_significance_bridge_20261125/story.js",
]
for source in sources:
    text = source.read_text()
    # Missing/suppressed values must not be exported as observed measurements.
    text = text.replace(
        'p.estimated ? "interpolated" : "observed"]',
        'p.estimated ? "interpolated" : p.value === null ? "unavailable" : "observed"]',
    )
    # Sex charts previously inherited the occupation-only accessible description.
    text = text.replace(
        "rows.some((r) => r.isQ5)\n          ?",
        'rows.every((r) => r.sexLabel)\n          ? "Women and men within the selected age and exposure group. Each supported curve uses its own November 2022 baseline of 100. Gray shading marks a descriptive index gap, not uncertainty or a causal sex effect."\n          : rows.some((r) => r.isQ5)\n          ?',
    )
    source.write_text(text)

payload = json.loads((SITE / "data/monthly.json").read_text())
counts = dict(supported_baselines=0, unavailable_baselines=0, post_baseline_values=0)
for family, rows in payload.items():
    if not isinstance(rows, list):
        continue
    for row in rows:
        for idx in (1, 2, 3):
            base = next((p for p in row["points"] if p[0] == "2022-11-01"), None)
            supported = (
                base is not None
                and base[idx] is not None
                and base[idx] > 0
                and base[idx + 3] >= 30
            )
            counts["supported_baselines" if supported else "unavailable_baselines"] += 1
            if supported:
                assert base[idx] / base[idx] * 100 == 100
                counts["post_baseline_values"] += sum(
                    p[0] >= "2022-11-01" and p[idx] is not None and p[idx + 3] >= 30
                    for p in row["points"]
                )
assert "r.scope === scope" in (SITE / "story.js").read_text()
assert "r.age === state.age" in (SITE / "story.js").read_text()
assert "mean<sub>m∈2022" not in str(methods)
(OUT / "presentation_audit_checks.json").write_text(
    json.dumps(
        dict(
            passed=True,
            **counts,
            notes="Supported series rebase to exactly 100; unavailable baselines suppress curves. Raw JSON retains annual-base units which cancel during browser renormalization. Occupation selector filters both scope and age."
        ),
        indent=2,
    )
)
print("Presentation audit repairs and baseline checks passed. No plots displayed.")
