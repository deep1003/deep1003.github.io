"""Observed-month, symmetric-window validation of occupational THAIE contrasts."""

from pathlib import Path
import sys, json, hashlib, argparse
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "work/us_youth_significance_bridge_20261125"))
from ppml_model import fit, contrast, joint

W = Path(__file__).resolve().parent
T = ROOT / "outputs/US_Symmetric_Validation_20261125/tables"
SOURCE = ROOT / "outputs/US_CPS_Only_Monthly_DID_20261125/tables"
AGES = ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"]
RAW = pd.read_parquet(SOURCE / "occupation_industry_monthly_counts.parquet")


def prepare(age, window=47, spec="main"):
    a = RAW[
        RAW.age.eq(age) & RAW.band.ne("Unmapped") & RAW.industry.between(1, 13)
    ].copy()
    dt = pd.to_datetime(a.date)
    k = (dt.dt.year - 2022) * 12 + dt.dt.month - 11
    a = a[k.abs().between(1, window)].copy()
    assert "2022-11-01" not in set(a.date) and "2025-10-01" not in set(a.date)
    if spec == "no_covid":
        a = a[~a.date.str[:4].isin(["2020", "2021"])]
    dates = sorted(a.date.unique())
    meta = a[["occupation", "industry", "band"]].drop_duplicates()
    assert not meta.duplicated(["occupation", "industry"]).any()
    counts = a.groupby(["occupation", "industry", "date"], as_index=False)[
        ["E", "FT", "PT", "nE"]
    ].sum()
    a = meta.merge(pd.DataFrame({"date": dates}), how="cross").merge(
        counts, on=["occupation", "industry", "date"], how="left", validate="one_to_one"
    )
    a[["E", "FT", "PT", "nE"]] = a[["E", "FT", "PT", "nE"]].fillna(0)
    dt = pd.to_datetime(a.date)
    a["year"] = dt.dt.year
    a["month"] = dt.dt.month
    a["quarter"] = dt.dt.quarter
    a["k"] = (a.year - 2022) * 12 + a.month - 11
    a["occ_industry"] = a.occupation.astype(str) + "_" + a.industry.astype(str)
    a["occ_season"] = a.occupation.astype(str) + "_" + a.month.astype(str)
    a["industry_date"] = a.industry.astype(str) + "_" + a.date
    before = a[["E", "FT", "PT"]].sum()
    for _ in range(30):
        n = len(a)
        for fe in ["occ_industry", "occ_season", "industry_date"]:
            sums = a.groupby(fe)[["FT", "PT"]].sum()
            a = a[a[fe].isin(sums.index[sums.gt(0).all(axis=1)])]
        if len(a) == n:
            break
    else:
        raise ValueError("Support did not settle")
    a["high"] = a.band.eq("Q5").astype(float)
    info = dict(
        window=window,
        spec=spec,
        age=age,
        pre_months=a[a.k.lt(0)].date.nunique(),
        post_months=a[a.k.gt(0)].date.nunique(),
        first_month=min(a.date),
        last_month=max(a.date),
        missing_calendar_month="2025-10",
        transition_month_excluded="2022-11",
        rows=len(a),
        occupations=a.occupation.nunique(),
        FT_retention=float(a.FT.sum() / before.FT),
        PT_retention=float(a.PT.sum() / before.PT),
        sample_fingerprint=hashlib.sha256(
            pd.util.hash_pandas_object(
                a[["occupation", "industry", "date", "FT", "PT"]], index=False
            ).values.tobytes()
        ).hexdigest(),
    )
    assert np.allclose(a.E, a.FT + a.PT)
    assert info["pre_months"] == window - (24 if spec == "no_covid" else 0)
    assert info["post_months"] == window - 1
    return a.reset_index(drop=True), info


def design(a, spec="main", event=False):
    h = a.high.to_numpy()
    names = []
    cols = []

    def add(name, v):
        names.append(name)
        cols.append(np.asarray(v, float))

    if event:
        covid = a.year.isin([2020, 2021])
        bins = np.sign(a.k) * np.ceil(abs(a.k) / 3).astype(int)
        for q in sorted(bins[~covid].unique()):
            if q != -1:
                add("event_" + str(int(q)), h * (bins.eq(q) & ~covid))
    else:
        add("DID", h * a.k.gt(0))
    for year in [2020, 2021]:
        for quarter in range(1, 5):
            mask = a.year.eq(year) & a.quarter.eq(quarter)
            if mask.any():
                add(f"covid_{year}Q{quarter}", h * mask)
    if spec == "trend":
        add("Q5_linear_trend", h * a.k / 12)
    return np.column_stack(cols), names


def summarize():
    records = [json.loads(p.read_text())["row"] for p in W.glob("did_*.json")]
    if records:
        d = pd.DataFrame(records)
        d["p_Holm_primary12"] = np.nan
        d["p_Holm_within_window"] = np.nan
        mask = d.window.eq(47) & d.spec.eq("main")
        if mask.sum() == 12:
            d.loc[mask, "p_Holm_primary12"] = multipletests(
                d.loc[mask, "p_value"], method="holm"
            )[1]
        for window in [36, 47]:
            mask = d.window.eq(window) & d.spec.eq("main")
            if mask.sum() == 12:
                d.loc[mask, "p_Holm_within_window"] = multipletests(
                    d.loc[mask, "p_value"], method="holm"
                )[1]
        d.to_csv(T / "did_results.csv", index=False)
    pfs = list(W.glob("event_*.json"))
    if pfs:
        ps = pd.DataFrame([json.loads(p.read_text())["pre"] for p in pfs])
        ps["p_Holm12"] = np.nan
        if len(ps) == 12:
            ps["p_Holm12"] = multipletests(ps.pretrend_p, method="holm")[1]
        ps.to_csv(T / "pretrend_tests.csv", index=False)
        es = [r for p in pfs for r in json.loads(p.read_text())["events"]]
        pd.DataFrame(es).to_csv(T / "event_studies.csv", index=False)


def run(age, window, spec="main", event=False):
    kind = "event" if event else "did"
    a, support = prepare(age, window, spec)
    x, names = design(a, spec, event)
    (T / f"support_{age}_{window}_{spec}.json").write_text(
        json.dumps(support, indent=2)
    )
    for outcome in ["FT", "PT"]:
        cache = W / f"{kind}_{age}_{window}_{spec}_{outcome}.json"
        if cache.exists():
            summarize()
            continue
        print("START", kind, age, window, spec, outcome, len(a), flush=True)
        b, v, v2, info, inf, groups = fit(a, outcome, x, names, backend="cg")
        if not event:
            row = dict(
                age=age,
                window=window,
                spec=spec,
                outcome=outcome,
                **info,
                **contrast(b, v, names, "DID", info["occupation_clusters"] - 1),
            )
            two = (
                dict(
                    **contrast(
                        b,
                        v2,
                        names,
                        "DID",
                        min(info["occupation_clusters"], info["date_clusters"]) - 1,
                    )
                )
                if v2[0, 0] > 0
                else None
            )
            cache.write_text(
                json.dumps(dict(row=row, two_way=two, support=support), indent=2)
            )
            np.savez_compressed(
                W / f"influence_{age}_{window}_{spec}_{outcome}.npz",
                occupation=np.array(groups),
                influence=inf[:, names.index("DID")],
            )
            print(
                "RESULT",
                age,
                window,
                spec,
                outcome,
                row["estimate_pct"],
                row["p_value"],
                flush=True,
            )
        else:
            leads = [
                n for n in names if n.startswith("event_") and int(n.split("_")[1]) < 0
            ]
            pre = dict(
                age=age,
                outcome=outcome,
                window=window,
                **joint(b, v, names, leads, info["occupation_clusters"] - 1),
            )
            er = []
            bins = np.sign(a.k) * np.ceil(abs(a.k) / 3).astype(int)
            for term in names:
                if term.startswith("event_"):
                    q = int(term.split("_")[1])
                    months = sorted(
                        a.loc[bins.eq(q) & ~a.year.isin([2020, 2021]), "date"].unique()
                    )
                    er.append(
                        dict(
                            age=age,
                            outcome=outcome,
                            event_bin=q,
                            first_month=months[0],
                            last_month=months[-1],
                            months_in_bin=len(months),
                            **contrast(
                                b, v, names, term, info["occupation_clusters"] - 1
                            ),
                        )
                    )
            cache.write_text(json.dumps(dict(pre=pre, events=er, info=info), indent=2))
            print("PRETREND", pre, flush=True)
        summarize()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", default="primary")
    args = parser.parse_args()
    if args.phase == "primary":
        for age in AGES:
            run(age, 47)
    elif args.phase == "sensitivity":
        for age in AGES:
            run(age, 36)
        for spec in ["trend", "no_covid"]:
            run(AGES[0], 47, spec)
    elif args.phase == "events":
        for age in AGES:
            run(age, 47, event=True)
    print("PHASE COMPLETE", args.phase, flush=True)
