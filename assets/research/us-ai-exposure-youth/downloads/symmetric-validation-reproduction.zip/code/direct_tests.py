"""Direct contrasts retain shared occupation-score covariance across models."""

from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import t, f
from statsmodels.stats.multitest import multipletests
from run_validation import W, T, AGES


def analyze(window):
    keys = [(age, out) for age in AGES for out in ["FT", "PT"]]
    models = {
        k: json.loads((W / f"did_{k[0]}_{window}_main_{k[1]}.json").read_text())["row"]
        for k in keys
    }
    influences = {}
    for k in keys:
        p = np.load(W / f"influence_{k[0]}_{window}_main_{k[1]}.npz")
        influences[k] = pd.Series(p["influence"], index=p["occupation"])
    union = sorted(set().union(*(set(s.index) for s in influences.values())))
    U = np.array([influences[k].reindex(union, fill_value=0).to_numpy() for k in keys])
    b = np.array([models[k]["log_change"] for k in keys])
    vc = U @ U.T
    df = min(r["occupation_clusters"] for r in models.values()) - 1
    rank = np.linalg.matrix_rank(vc)
    assert rank == len(keys)
    stat = float(b @ np.linalg.solve(vc, b) / len(keys))
    globalrows = [
        dict(
            window=window,
            test="All 12 post coefficients jointly zero",
            F_statistic=stat,
            numerator_df=len(keys),
            denominator_df=df,
            p_value=float(f.sf(stat, len(keys), df)),
        )
    ]
    rows = []
    for out in ["FT", "PT"]:
        for age in AGES[1:]:
            c = np.zeros(len(keys))
            c[keys.index((AGES[0], out))] = 1
            c[keys.index((age, out))] = -1
            delta = float(c @ b)
            se = float(np.sqrt(c @ vc @ c))
            crit = t.ppf(0.975, df)
            rows.append(
                dict(
                    window=window,
                    test="Youth versus " + age,
                    outcome=out,
                    log_difference=delta,
                    se_log=se,
                    estimate_pct=100 * np.expm1(delta),
                    ci_low_pct=100 * np.expm1(delta - crit * se),
                    ci_high_pct=100 * np.expm1(delta + crit * se),
                    p_value=float(2 * t.sf(abs(delta / se), df)),
                )
            )
        C = []
        for age in AGES[1:]:
            c = np.zeros(len(keys))
            c[keys.index((AGES[0], out))] = -1
            c[keys.index((age, out))] = 1
            C.append(c)
        C = np.array(C)
        z = C @ b
        v = C @ vc @ C.T
        stat = float(z @ np.linalg.solve(v, z) / 5)
        globalrows.append(
            dict(
                window=window,
                test="Equal age effects " + out,
                F_statistic=stat,
                numerator_df=5,
                denominator_df=df,
                p_value=float(f.sf(stat, 5, df)),
            )
        )
    quality = []
    for age in AGES:
        c = np.zeros(len(keys))
        c[keys.index((age, "FT"))] = 1
        c[keys.index((age, "PT"))] = -1
        delta = float(c @ b)
        se = float(np.sqrt(c @ vc @ c))
        crit = t.ppf(0.975, df)
        quality.append(
            dict(
                window=window,
                age=age,
                log_difference=delta,
                se_log=se,
                estimate_pct=100 * np.expm1(delta),
                ci_low_pct=100 * np.expm1(delta - crit * se),
                ci_high_pct=100 * np.expm1(delta + crit * se),
                p_value=float(2 * t.sf(abs(delta / se), df)),
            )
        )
    # Rademacher occupation-score multiplier diagnostic for joint all-zero test.
    rng = np.random.default_rng(20261125)
    draws = 4999
    boot = U @ rng.choice([-1.0, 1.0], size=(len(union), draws))
    inv = np.linalg.inv(vc)
    bootstat = np.einsum("ib,ij,jb->b", boot, inv, boot) / len(keys)
    globalrows[0]["score_multiplier_p"] = (
        1 + int((bootstat >= globalrows[0]["F_statistic"]).sum())
    ) / (draws + 1)
    globalrows[0]["multiplier_draws"] = draws
    for name, rs in [
        ("direct_age_contrasts", rows),
        ("FT_PT_direct_contrasts", quality),
        ("global_tests", globalrows),
    ]:
        d = pd.DataFrame(rs)
        d["p_Holm_within_table"] = multipletests(d.p_value, method="holm")[1]
        d.to_csv(T / f"{name}_{window}.csv", index=False)
    print("GLOBAL", window, pd.DataFrame(globalrows).to_string(index=False), flush=True)


if __name__ == "__main__":
    for window in [47, 36]:
        if len(list(W.glob(f"did_*_{window}_main_*.json"))) == 12:
            analyze(window)
