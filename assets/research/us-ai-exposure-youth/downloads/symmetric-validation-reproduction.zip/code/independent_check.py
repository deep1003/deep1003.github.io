"""Independent explicit-dummy Poisson validation, without figure output."""

from pathlib import Path
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.linalg import qr
from run_validation import prepare, design, fit, T

a, _ = prepare("22–25", 47)
selected = []
for h in [0, 1]:
    selected += (
        a[a.high.eq(h)].groupby("occupation").FT.sum().nlargest(3).index.tolist()
    )
a = a[a.occupation.isin(selected) & a.industry.isin([4, 5, 9, 10])].copy()
for _ in range(20):
    n = len(a)
    for fe in ["occ_industry", "occ_season", "industry_date"]:
        z = a.groupby(fe).FT.sum()
        a = a[a[fe].isin(z.index[z.gt(0)])]
    if len(a) == n:
        break
a = a.reset_index(drop=True)
x, names = design(a)
b, v, _, info, _, _ = fit(a, "FT", x, names)
dummy = np.column_stack(
    [
        pd.get_dummies(a[c], dtype=float).to_numpy()
        for c in ["occ_industry", "occ_season", "industry_date"]
    ]
)
_, r, piv = qr(dummy, mode="economic", pivoting=True)
rank = int(np.sum(abs(np.diag(r)) > 1e-8))
full = np.column_stack([dummy[:, piv[:rank]], x])
assert np.linalg.matrix_rank(full) == full.shape[1]
ref = sm.GLM(a.FT.to_numpy() / 1e5, full, family=sm.families.Poisson()).fit(
    maxiter=100,
    tol=1e-11,
    cov_type="cluster",
    cov_kwds={"groups": a.occupation.to_numpy(), "use_correction": True},
)
se_ref = np.asarray(ref.bse)[-len(b) :] * np.sqrt(
    (len(a) - full.shape[1]) / (len(a) - info["FE_rank"] - len(b))
)
bref = np.asarray(ref.params)[-len(b) :]
assert np.allclose(b, bref, atol=1e-6)
assert np.allclose(np.sqrt(np.diag(v)), se_ref, rtol=1e-5, atol=1e-7)
result = dict(
    passed=True,
    N=len(a),
    occupations=a.occupation.nunique(),
    coefficient_max_difference=float(abs(b - bref).max()),
    SE_max_difference=float(abs(np.sqrt(np.diag(v)) - se_ref).max()),
    figures_displayed=False,
)
(T / "independent_numerical_validation.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result), flush=True)
