"""Freeze short-window FE support before changing its pre/post calendar span."""

import json
import numpy as np
import pandas as pd
from run_validation import prepare, design, fit, contrast, W, T

long, ls = prepare("22–25", 47)
short, ss = prepare("22–25", 36)
a = long[
    long.occ_industry.isin(short.occ_industry.unique())
    & long.occ_season.isin(short.occ_season.unique())
].copy()
for _ in range(20):
    n = len(a)
    for fe in ["occ_industry", "occ_season", "industry_date"]:
        z = a.groupby(fe)[["FT", "PT"]].sum()
        a = a[a[fe].isin(z.index[z.gt(0).all(axis=1)])]
    if len(a) == n:
        break
a = a.reset_index(drop=True)
x, names = design(a)
rows = []
for outcome in ["FT", "PT"]:
    b, v, _, info, _, _ = fit(a, outcome, x, names)
    rows.append(
        dict(
            age="22–25",
            window=47,
            spec="frozen_36_support",
            outcome=outcome,
            **info,
            **contrast(b, v, names, "DID", info["occupation_clusters"] - 1)
        )
    )
pd.DataFrame(rows).to_csv(T / "fixed_support_sensitivity.csv", index=False)
print(pd.DataFrame(rows)[["outcome", "estimate_pct", "p_value"]].to_string(index=False))
