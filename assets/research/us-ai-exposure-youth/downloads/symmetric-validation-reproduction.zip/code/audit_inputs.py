"""Verify raw files, mapping, aggregation identities and a fresh raw-file parse."""

from pathlib import Path
import importlib.util, json, hashlib
import numpy as np
import pandas as pd

R = Path(__file__).resolve().parents[2]
T = R / "outputs/US_CPS_Only_Monthly_DID_20261125/tables"
O = R / "outputs/US_Symmetric_Validation_20261125/tables"
manifest = json.loads(
    (
        R / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json"
    ).read_text()
)
selected = [
    x
    for x in manifest
    if x.get("available", True) and ((x["year"], x["month"]) >= (2018, 12))
]
checks = []
for r in selected:
    p = Path(r["path"])
    actual = hashlib.sha256(p.read_bytes()).hexdigest()
    assert actual == r["sha256"], p
    checks.append(dict(year=r["year"], month=r["month"], sha256=actual, passed=True))
assert (
    len(checks) == 94
)  # 95 calendar months including transition, less one missing month
score = pd.read_csv(T / "frozen_THAIE_occupation_assignments.csv")
assert not score.occ.duplicated().any()
assert score.THAIE_q.between(1, 5).all()
a = pd.read_parquet(T / "occupation_industry_monthly_counts.parquet")
assert np.allclose(a.E, a.FT + a.PT)
assert not a.duplicated(["date", "age", "occupation", "industry", "band"]).any()
for occ, group in a[a.band.ne("Unmapped")].groupby("occupation"):
    assert group.band.nunique() == 1
# Reparse independent selected endpoint files using their official layouts.
pth = (
    R
    / "outputs/US_THAIE_Regional_Youth_20261122/panel_fe3_20261122/scripts/prepare_panel.py"
)
sp = importlib.util.spec_from_file_location("raw_parser", pth)
parser = importlib.util.module_from_spec(sp)
sp.loader.exec_module(parser)
by = {(r["year"], r["month"]): r for r in selected}
parser.source = lambda y, m: (Path(by[y, m]["path"]), Path(by[y, m]["dictionary"]))
parse = []
for y, m in [(2022, 11), (2026, 10)]:
    d, info = parser.read(y, m)
    d = d[d.PRTAGE.between(22, 25) & d.nE.eq(1)].copy()
    d["occupation"] = d.occ
    d["industry"] = d.PRMJIND1
    expected = d.groupby(["occupation", "industry"])[["E", "FT", "PT"]].sum()
    actual = (
        a[a.age.eq("22–25") & a.date.eq(f"{y}-{m:02}-01")]
        .groupby(["occupation", "industry"])[["E", "FT", "PT"]]
        .sum()
    )
    merged = expected.join(
        actual, lsuffix="_raw", rsuffix="_stored", how="outer"
    ).fillna(0)
    err = max(
        float(abs(merged[c + "_raw"] - merged[c + "_stored"]).max())
        for c in ["E", "FT", "PT"]
    )
    assert err < 1e-6
    parse.append(dict(month=f"{y}-{m:02}", max_weighted_count_difference=err))
record = dict(
    passed=True,
    raw_files_verified=len(checks),
    file_hashes=checks,
    exposure_mapping_unique_and_frozen=True,
    FT_PT_sum_identity=True,
    duplicate_cells=False,
    fresh_endpoint_reparse=parse,
    interpolated_month_absent=True,
)
(O / "input_validation.json").write_text(json.dumps(record, indent=2))
print(
    "INPUT AUDIT PASSED",
    len(checks),
    "raw hashes and endpoint reparses",
    parse,
    flush=True,
)
