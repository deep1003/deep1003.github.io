"""Verify raw files, mapping, aggregation identities and a fresh raw-file parse."""

from pathlib import Path
import importlib.util, json, hashlib
import numpy as np
import pandas as pd

R = Path(__file__).resolve().parents[2]
T = R / "outputs/US_CPS_Only_Monthly_DID_20261125/tables"
O = R / "outputs/US_Symmetric_Validation_20261125/tables"
manifest = json.loads(
    (
        R / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json"
    ).read_text()
)
selected = [
    x
    for x in manifest
    if x.get("available", True) and ((x["year"], x["month"]) >= (2018, 12))
]
checks = []
for r in selected:
    p = Path(r["path"])
    actual = hashlib.sha256(p.read_bytes()).hexdigest()
    assert actual == r["sha256"], p
    checks.append(dict(year=r["year"], month=r["month"], sha256=actual, passed=True))
assert (
    len(checks) == 94
)  # 95 calendar months including transition, less one missing month
score = pd.read_csv(T / "frozen_THAIE_occupation_assignments.csv")
assert not score.occ.duplicated().any()
assert score.THAIE_q.between(1, 5).all()
# Rebuild the baseline weights and thresholds, rather than merely trusting labels.
project = R / "outputs/US_THAIE_Regional_Youth_20261122"
conversion = pd.read_csv(
    project / "extension_2019/derived/occupation_conversion_2010_2018.csv"
)
assert not conversion.duplicated(["old", "new"]).any()
assert np.allclose(conversion.groupby("old").rate.sum(), 1)
baseline = pd.read_csv(project / "extension_2019/derived/history_state_occupation.csv")
baseline = baseline[baseline.year.eq(2019)].merge(
    conversion, left_on="occ", right_on="old", validate="many_to_many"
)
baseline["allocated"] = baseline.emp * baseline.rate
weights = baseline.groupby("new").allocated.sum()
ordered = score.sort_values(["THAIE", "occ"]).copy()
ordered["weight2019"] = ordered.occ.map(weights).fillna(0)
cdf = ordered.weight2019.cumsum() / ordered.weight2019.sum()
thresholds = [
    float(ordered.iloc[np.searchsorted(cdf, q)].THAIE) for q in [0.2, 0.4, 0.6, 0.8]
]
assert np.array_equal(
    np.searchsorted(thresholds, score.THAIE, side="right") + 1, score.THAIE_q
)
assert not score.THAIE.isna().any()
a = pd.read_parquet(T / "occupation_industry_monthly_counts.parquet")
assert np.allclose(a.E, a.FT + a.PT)
assert "2025-10-01" not in set(a.date)
assert a[["E", "FT", "PT", "nE"]].ge(0).all().all()
joined = a[a.band.ne("Unmapped")].merge(
    score, left_on="occupation", right_on="occ", how="left", validate="many_to_one"
)
assert joined.THAIE_q.notna().all()
assert np.array_equal(joined.band.eq("Q5"), joined.THAIE_q.eq(5))
assert not a.duplicated(["date", "age", "occupation", "industry", "band"]).any()
for occ, group in a[a.band.ne("Unmapped")].groupby("occupation"):
    assert group.band.nunique() == 1
# Regenerate selected raw months with the original parser and official layouts.
pth = (
    R
    / "outputs/US_THAIE_Regional_Youth_20261122/panel_fe3_20261122/scripts/prepare_panel.py"
)
sp = importlib.util.spec_from_file_location("raw_parser", pth)
parser = importlib.util.module_from_spec(sp)
sp.loader.exec_module(parser)
by = {(r["year"], r["month"]): r for r in selected}
parser.source = lambda y, m: (Path(by[y, m]["path"]), Path(by[y, m]["dictionary"]))
parse = []
ages = ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"]
for y, m in [(2018, 12), (2019, 10), (2020, 1), (2022, 11), (2026, 10)]:
    d, info = parser.read(y, m)
    d = d[d.PRTAGE.ge(22) & d.nE.eq(1)].copy()
    # Separate official work-status recode confirms the usual-hours definition.
    mismatch = int((d.PRFTLF.eq(1) != d.PRWKSTAT.isin([2, 3, 4, 5])).sum())
    assert mismatch == 0
    d["age"] = pd.cut(d.PRTAGE, bins=[21, 25, 30, 34, 40, 49, 200], labels=ages).astype(
        str
    )
    if y < 2020:
        d = d.merge(
            conversion,
            left_on="occ",
            right_on="old",
            how="left",
            validate="many_to_many",
        )
        d["occupation"] = d.new.fillna(-1).astype(int)
        d[["E", "FT", "PT"]] = d[["E", "FT", "PT"]].multiply(d.rate.fillna(1), axis=0)
    else:
        d["occupation"] = d.occ
    d["industry"] = d.PRMJIND1
    expected = d.groupby(["age", "occupation", "industry"])[["E", "FT", "PT"]].sum()
    actual = (
        a[a.date.eq(f"{y}-{m:02}-01")]
        .groupby(["age", "occupation", "industry"])[["E", "FT", "PT"]]
        .sum()
    )
    merged = expected.merge(
        actual,
        left_index=True,
        right_index=True,
        suffixes=("_raw", "_stored"),
        how="outer",
    ).fillna(0)
    err = max(
        float(abs(merged[c + "_raw"] - merged[c + "_stored"]).max())
        for c in ["E", "FT", "PT"]
    )
    assert err < 1e-6
    parse.append(
        dict(
            month=f"{y}-{m:02}",
            age_groups=6,
            max_weighted_count_difference=err,
            usual_FT_vs_PRWKSTAT_mismatches=mismatch,
        )
    )

record = dict(
    passed=True,
    raw_files_verified=len(checks),
    file_hashes=checks,
    exposure_mapping_unique_and_frozen=True,
    baseline_weights_and_quintile_thresholds_reconstructed=True,
    THAIE_cutpoints=thresholds,
    score_vintage="Retrospective task and capability scores; 2019 employment weights only are historical",
    audit_scope="Hash identity plus same-parser regeneration and independent PRWKSTAT definition; not an independent parser or live official-source verification",
    FT_PT_sum_identity=True,
    duplicate_cells=False,
    fresh_endpoint_reparse=parse,
    expanded_five_month_all_six_age_reparse=parse,
    interpolated_month_absent="2025-10-01" not in set(a.date),
)
(O / "input_validation.json").write_text(json.dumps(record, indent=2))
print(
    "INPUT AUDIT PASSED",
    len(checks),
    "raw hashes and endpoint reparses",
    parse,
    flush=True,
)
