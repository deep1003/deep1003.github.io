"""Build tables, figures and interpretation from completed symmetric-window fits."""

from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as md
import matplotlib.patheffects as pe
from run_validation import ROOT, W, T, AGES, summarize

summarize()
O = T.parent
F = O / "figures"
RED = "#C64F5A"
GRAY = "#9C9C9C"
d = pd.read_csv(T / "did_results.csv")
pre = pd.read_csv(T / "pretrend_tests.csv")
ev = pd.read_csv(T / "event_studies.csv")
assert len(d) == 28 and len(pre) == 12
assert d.converged.all() and d.score_max.max() < 1e-6 and d.FE_score_max.max() < 1e-6
main = d[d.window.eq(47) & d.spec.eq("main")]
short = d[d.window.eq(36) & d.spec.eq("main")]
young = main[main.age.eq(AGES[0])].set_index("outcome")
p = pre.set_index(["age", "outcome"])
comparison = d[d.age.eq(AGES[0])].copy()
comparison["label"] = comparison.apply(
    lambda r: f"{int(r.window)}-month " + r.spec, axis=1
)
fixed = pd.read_csv(T / "fixed_support_sensitivity.csv")
fixed["label"] = "47-month frozen 36-window units"
comparison = pd.concat([comparison, fixed], ignore_index=True)
comparison.to_csv(T / "youth_specification_comparison.csv", index=False)
plt.rcParams.update(
    {
        "font.family": ["Arial", "DejaVu Sans"],
        "font.size": 9,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def save(fig, name):
    for ext in ["png", "svg", "pdf"]:
        fig.savefig(
            F / (name + "." + ext), dpi=300, bbox_inches="tight", facecolor="white"
        )
    plt.close(fig)


fig, axs = plt.subplots(1, 2, figsize=(10, 4.8), sharey=True)
for ax, out in zip(axs, ["FT", "PT"]):
    for j, age in enumerate(AGES):
        for window, offset, c in [(47, -0.12, RED), (36, 0.12, GRAY)]:
            r = d[
                d.age.eq(age)
                & d.window.eq(window)
                & d.spec.eq("main")
                & d.outcome.eq(out)
            ].iloc[0]
            ax.hlines(j + offset, r.ci_low_pct, r.ci_high_pct, color=c, lw=2.3)
            ax.plot(
                [r.estimate_pct] * 2,
                [j + offset - 0.055, j + offset + 0.055],
                color=c,
                lw=2.5,
            )
    ax.axvline(0, color="#777", ls=":", lw=0.8)
    ax.set(
        title="Full-time" if out == "FT" else "Part-time",
        yticks=range(6),
        yticklabels=AGES,
        xlabel="Q5 versus Q1–Q4 relative employment change (%)",
    )
    ax.grid(axis="x", color="#eee")
axs[0].invert_yaxis()
fig.suptitle(
    "Symmetric-window CPS validation across six ages", fontweight="bold", fontsize=13
)
fig.text(
    0.5,
    -0.01,
    "Red: ±47 calendar months. Gray: ±36 months. November 2022 excluded. Marginal 95% occupation-clustered intervals.",
    ha="center",
    fontsize=8,
)
fig.tight_layout()
save(fig, "symmetric_01_primary")
labels = [
    "47-month main",
    "36-month main",
    "47-month trend",
    "47-month no_covid",
    "47-month frozen 36-window units",
]
fig, ax = plt.subplots(figsize=(11, 3.7))
for j, label in enumerate(labels):
    r = comparison[comparison.label.eq(label) & comparison.outcome.eq("FT")].iloc[0]
    ax.hlines(j, r.ci_low_pct, r.ci_high_pct, color=RED, lw=2.5)
    ax.plot([r.estimate_pct] * 2, [j - 0.075, j + 0.075], color=RED, lw=2.5)
    ax.text(
        max(comparison.loc[comparison.outcome.eq("FT"), "ci_high_pct"]) + 1,
        j,
        f"{r.estimate_pct:+.2f}%  p={r.p_value:.3f}",
        va="center",
        fontsize=9,
    )
ax.set(
    yticks=range(5),
    yticklabels=[
        "±47 months",
        "±36 months",
        "±47 months + Q5 trend",
        "±47 months, omit 2020–2021",
        "±47 months, frozen short-window units",
    ],
    xlabel="Youth full-time Q5 contrast (%)",
)
ax.invert_yaxis()
ax.axvline(0, color="#777", ls=":", lw=0.8)
ax.set_title(
    "Ages 22–25 · direction persists, significance does not",
    loc="left",
    fontweight="bold",
)
ax.grid(axis="x", color="#eee")
ax.set_xlim(
    comparison.loc[comparison.outcome.eq("FT"), "ci_low_pct"].min() - 1,
    comparison.loc[comparison.outcome.eq("FT"), "ci_high_pct"].max() + 15,
)
fig.subplots_adjust(left=0.36, right=0.98, top=0.85, bottom=0.18)
save(fig, "symmetric_02_youth_sensitivity")
for out in ["FT", "PT"]:
    fig, axs = plt.subplots(2, 3, figsize=(12, 6.5), sharex=True, sharey=True)
    for ax, age in zip(axs.flat, AGES):
        z = ev[ev.age.eq(age) & ev.outcome.eq(out)].sort_values("event_bin")
        # Separate pre/post segments; never draw through pandemic nuisance quarters or transition month.
        for side in [-1, 1]:
            zz = z[np.sign(z.event_bin).eq(side)].copy()
            segments = []
            segment = []
            last = None
            for r in zz.itertuples():
                if last is not None and r.event_bin - last != 1:
                    segments.append(segment)
                    segment = []
                segment.append(r)
                last = r.event_bin
            if segment:
                segments.append(segment)
            for seg in segments:
                dates = [
                    pd.Timestamp(r.first_month)
                    + (pd.Timestamp(r.last_month) - pd.Timestamp(r.first_month)) / 2
                    for r in seg
                ]
                ax.fill_between(
                    dates,
                    [r.ci_low_pct for r in seg],
                    [r.ci_high_pct for r in seg],
                    color="#dddddd",
                    alpha=0.65,
                )
                ax.plot(
                    dates,
                    [r.estimate_pct for r in seg],
                    color=RED,
                    lw=2,
                    path_effects=[
                        pe.Stroke(linewidth=3.1, foreground="white"),
                        pe.Normal(),
                    ],
                )
        ax.axhline(0, color="#999", lw=0.7)
        ax.axvline(pd.Timestamp("2022-11-01"), color="#777", ls=":", lw=0.8)
        ax.axvspan(
            pd.Timestamp("2020-01-01"),
            pd.Timestamp("2021-12-31"),
            color="#eee",
            alpha=0.8,
        )
        ax.set_title(f'{age} · pretrend raw p={p.loc[(age,out),"pretrend_p"]:.3f}')
        ax.grid(axis="y", color="#eee")
        ax.xaxis.set_major_locator(md.MonthLocator(interval=24))
        ax.xaxis.set_major_formatter(md.DateFormatter("%Y-%m"))
    fig.suptitle(
        ("Full-time" if out == "FT" else "Part-time")
        + " event studies · monthly CPS in three-month bins",
        fontsize=13,
        fontweight="bold",
    )
    fig.supylabel("Q5 relative difference from Aug–Oct 2022 (%)")
    fig.text(
        0.5,
        0.005,
        "November 2022 excluded. Pandemic quarters modeled separately. Ribbons are pointwise 95% intervals; omitted/reference bins are not estimated zeros.",
        ha="center",
        fontsize=8,
    )
    fig.tight_layout(rect=[0.02, 0.03, 1, 0.95])
    save(fig, "symmetric_03_event_" + out)


# Report is generated only after complete fitting and numerical checks.
def table(frame, columns):
    q = frame[columns].copy()
    for c in q.select_dtypes("number"):
        q[c] = q[c].map(lambda x: f"{x:.4f}")
    return (
        "| "
        + " | ".join(q.columns)
        + " |\n| "
        + " | ".join(["---"] * len(q.columns))
        + " |\n"
        + "\n".join(
            "| " + " | ".join(map(str, row)) + " |"
            for row in q.itertuples(index=False, name=None)
        )
    )


global47 = pd.read_csv(T / "global_tests_47.csv")
raw = global47.iloc[0]
report = f"""# Symmetric-window validation of the occupational THAIE employment study

## Design and verification

The primary analysis uses 47 pre-event calendar months from December 2018 through October 2022 and 47 post-event calendar months from December 2022 through October 2026. November 2022 is excluded as the transition month. October 2025 was not observed, giving 47 pre-event and 46 post-event observations. The robustness window uses November 2019–October 2022 and December 2022–November 2025, with 36 pre-event and 35 observed post-event months. No display interpolation enters estimation.

The outcomes are weighted full-time and part-time employment counts. Frozen 2019 occupational THAIE Q5 is compared with Q1–Q4. Full-time and part-time models use identical rows within each age/window. Occupation–industry, occupation–month-of-year, and industry–calendar-month fixed effects absorb stable allocation, occupation-specific seasonality, and industry-wide monthly shocks. Q5-by-pandemic-quarter interactions are retained. Zero survey-count cells are supported model cells, not administrative proof of zero jobs. Requiring shared FT/PT support retains 91.75% of weighted youth FT employment and 99.48% of PT employment in the long window. An FT-only-support sensitivity restores all weighted FT employment and gives −6.02% (p=.090) in the long window and −1.88% (p=.584) in the short window. Thus, common support restrictions do not account for the loss of conventional FT significance.

The model is Poisson QMLE with occupation-clustered working uncertainty; it does not implement the full CPS survey-design variance.

All 94 available raw CPS files covering the longest window, including the transition month, matched their recorded hashes. Fresh parses of November 2022 and October 2026 exactly reproduced stored weighted occupational counts. THAIE mapping uniqueness, frozen membership, and E=FT+PT identities passed. An explicit-dummy Poisson GLM independently reproduced coefficients and standard errors on 2,139 real CPS cells from six occupations. This is a numerical check, not proof that the identifying assumptions hold.

## Primary results

{table(main,['age','outcome','estimate_pct','ci_low_pct','ci_high_pct','p_value','p_Holm_primary12'])}

The youth full-time estimate is {young.loc['FT','estimate_pct']:.2f}% with a marginal 95% interval [{young.loc['FT','ci_low_pct']:.2f}, {young.loc['FT','ci_high_pct']:.2f}], raw p={young.loc['FT','p_value']:.3f}, and Holm p={young.loc['FT','p_Holm_primary12']:.3f}. The part-time estimate is {young.loc['PT','estimate_pct']:.2f}%, p={young.loc['PT','p_value']:.3f}. None of the 12 primary tests survives Holm correction. The ages 31–34 part-time estimate is nominally negative but does not survive correction. No age group exhibits a significant relative part-time increase.

The direct 12-coefficient all-zero Wald test gives p={raw.p_value:.3f}; an occupation-score Rademacher multiplier diagnostic with 4,999 draws gives p={raw.score_multiplier_p:.3f}. Direct tests do not establish equal-versus-different age effects, and a difference in separate significance labels cannot establish an age boundary. See the direct age and FT/PT contrast tables.

## Window, support and trend sensitivities

{table(comparison[comparison.outcome.eq('FT')],['label','estimate_pct','ci_low_pct','ci_high_pct','p_value'])}

The 47-month negative contrast weakens materially in the 36-month window and with a Q5-specific linear trend. Freezing the units retained in the shorter window has a much smaller effect than changing the calendar span. Omitting 2020–2021 leaves the 47-month coefficient close to its baseline, but does not resolve pre-existing divergence or identify an AI shock. The shorter window has only 12 non-pandemic pre-event months, so a nearly four-year post-period cannot be causally justified by invoking the 36-month calendar count alone. The 47-month window has 23 non-pandemic pre-event months. The 2018–2019 observations also rely on the historical occupation crosswalk.

## Event studies and uncertainty

{table(pre,['age','outcome','pretrend_p','p_Holm12'])}

The event studies use monthly counts and three-month relative-time bins, with August–October 2022 as the omitted reference. Pandemic quarters have separate nuisance coefficients and are excluded from the flat-lead joint test. Boundary bins can have fewer months; November 2022 and October 2025 remain absent. For youth full-time employment the raw joint lead p-value is {p.loc[(AGES[0],'FT'),'pretrend_p']:.3f}; its twelve-test Holm p-value is {p.loc[(AGES[0],'FT'),'p_Holm12']:.3f}. Non-rejection after correction does not validate parallel trends. Event intervals are pointwise, not simultaneous.

## Interpretation

A negative early-career full-time contrast remains a descriptive research signal. Its conventional significance does not survive the requested balanced-window validation, and its magnitude is sensitive to the pre-period and trend. The evidence does not establish a causal AI-induced decline, a full-time-to-part-time transition, a sex-specific disadvantage, or a protective age boundary. Non-significance does not establish zero effects; the primary interval still admits an economically substantial decline. Occupational exposure is not employer adoption, and working cluster covariance does not fully capture the CPS sampling design.

An additional matched-observation sensitivity removes December 2019, the pre-event month mirroring missing October 2025. This gives 46 observed months on each side in the long window and a youth full-time estimate of −6.62% (p=.071). Thus, the missing month alone does not explain the loss of conventional significance. In the shorter window, 35 observed months on each side give −1.30% (p=.739).

The earlier 2017-start estimate of −9.03% (raw p=.025) and annual legacy estimate of −8.76% should remain labeled as prior specifications, rather than pooled with the current validation. Index graphs normalized to November 2022 describe endpoint paths and are not DID estimates. Existing manuscripts were not edited.
"""
(O / "SYMMETRIC_VALIDATION_REPORT_EN.md").write_text(report)
validation = dict(
    passed=True,
    expected_DID_models=28,
    actual_DID_models=len(d),
    expected_event_models=12,
    actual_event_models=len(pre),
    all_converged=bool(d.converged.all()),
    max_target_score=float(d.score_max.max()),
    max_FE_score=float(d.FE_score_max.max()),
    primary_corrected_significant=int((main.p_Holm_primary12 < 0.05).sum()),
    no_interpolation_in_regressions=True,
    transition_month_excluded=True,
)
(T / "final_validation.json").write_text(json.dumps(validation, indent=2))
print(json.dumps(validation), flush=True)
