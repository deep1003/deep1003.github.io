"""Retrospective attestation against an archived pre-audit reproduction bundle.

This does not claim that contemporaneous cache provenance existed.
"""

import ast
import hashlib
import inspect
import io
import json
import zipfile
import numpy as np
import pandas as pd
from run_validation import (
    W,
    ROOT,
    SOURCE,
    prepare,
    design,
    cache_signature,
    checked_cache,
)

archive = (
    ROOT
    / "work/homepage-monthly/assets/research/us-ai-exposure-youth/downloads/symmetric-validation-reproduction.zip"
)
archive_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
with zipfile.ZipFile(archive) as z:
    original = ast.parse(z.read("code/run_validation.py").decode())
    old_functions = {
        n.name: ast.dump(n, include_attributes=False)
        for n in original.body
        if isinstance(n, ast.FunctionDef)
    }
    for func in [prepare, design]:
        current = ast.parse(inspect.getsource(func)).body[0]
        assert (
            ast.dump(current, include_attributes=False) == old_functions[func.__name__]
        )
    for path, member in [
        (
            SOURCE / "occupation_industry_monthly_counts.parquet",
            "inputs/occupation_industry_monthly_counts.parquet",
        ),
        (
            SOURCE / "frozen_THAIE_occupation_assignments.csv",
            "inputs/frozen_THAIE_occupation_assignments.csv",
        ),
        (
            ROOT / "work/us_youth_significance_bridge_20261125/ppml_model.py",
            "code/ppml_model.py",
        ),
    ]:
        assert path.read_bytes() == z.read(member), member
    archived_did = pd.read_csv(io.BytesIO(z.read("tables/did_results.csv")))
    archived_events = pd.read_csv(io.BytesIO(z.read("tables/event_studies.csv")))
    archived_pre = pd.read_csv(io.BytesIO(z.read("tables/pretrend_tests.csv")))


def matches(record, frame):
    for key, value in record.items():
        if key not in frame.columns:
            continue
        actual = frame.iloc[0][key]
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            assert np.isclose(
                value, actual, rtol=1e-10, atol=1e-10, equal_nan=True
            ), key
        else:
            assert value == actual, (key, value, actual)


count = 0
for p in sorted(list(W.glob("did_*.json")) + list(W.glob("event_*.json"))):
    record = json.loads(p.read_text())
    if "row" in record:
        row = record["row"]
        age, window, spec = row["age"], row["window"], row["spec"]
        selected = archived_did[
            (archived_did.age == age)
            & (archived_did.window == window)
            & (archived_did.spec == spec)
            & (archived_did.outcome == row["outcome"])
        ]
        assert len(selected) == 1
        matches(row, selected)
        event = False
    else:
        row = record["pre"]
        age, window, spec, event = row["age"], row["window"], "main", True
        selected = archived_pre[
            (archived_pre.age == age) & (archived_pre.outcome == row["outcome"])
        ]
        assert len(selected) == 1
        matches(row, selected)
        for entry in record["events"]:
            selected = archived_events[
                (archived_events.age == age)
                & (archived_events.outcome == row["outcome"])
                & (archived_events.event_bin == entry["event_bin"])
            ]
            assert len(selected) == 1
            matches(entry, selected)
    a, support = prepare(age, window, spec)
    x, names = design(a, spec, event)
    if "support" in record:
        assert record["support"]["sample_fingerprint"] == support["sample_fingerprint"]
    signature = cache_signature(a, x, names)
    record["provenance"] = {
        "signature": signature,
        "attestation": "retrospective_archive_equality_not_contemporaneous",
        "archive_sha256": archive_sha,
        "verified": [
            "archived_prepare_and_design_AST",
            "backend_bytes",
            "aggregate_input_bytes",
            "mapping_input_bytes",
            "archived_output_values",
            "current_sample_fingerprint_when_recorded",
        ],
    }
    p.write_text(json.dumps(record, indent=2))
    checked_cache(p, signature)
    altered = dict(signature, design_sha256="deliberately_invalid")
    try:
        checked_cache(p, altered)
    except ValueError:
        pass
    else:
        raise AssertionError("Stale-cache rejection failed")
    count += 1
result = {
    "attested_caches": count,
    "attestation": "retrospective archive equality; no contemporaneous provenance claim",
    "stale_signature_rejection": True,
    "archive_sha256": archive_sha,
    "figures_displayed": False,
}
(W / "legacy_cache_attestation.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result))
