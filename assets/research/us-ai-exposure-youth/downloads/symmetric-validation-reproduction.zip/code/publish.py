"""Publish the completed validation while retaining earlier estimates as history."""

from pathlib import Path
import json, shutil, zipfile
import pandas as pd
from bs4 import BeautifulSoup

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Symmetric_Validation_20261125"
T = O / "tables"
S = R / "work/homepage-monthly/assets/research/us-ai-exposure-youth"
D = S / "downloads"
validation = json.loads((T / "final_validation.json").read_text())
assert validation["passed"]
assert (
    json.loads((T / "input_validation.json").read_text())["passed"]
    and json.loads((T / "independent_numerical_validation.json").read_text())["passed"]
)
x = pd.read_csv(T / "did_results.csv")
main = x[x.window.eq(47) & x.spec.eq("main")]
short = x[x.window.eq(36) & x.spec.eq("main")]
y = main[main.age.eq("22–25")].set_index("outcome")
p = pd.read_csv(T / "pretrend_tests.csv")
globaltests = pd.read_csv(T / "global_tests_47.csv")
AGES = ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"]


def estimate(row):
    return f"{row.estimate_pct:+.2f}% [{row.ci_low_pct:+.2f}, {row.ci_high_pct:+.2f}]"


rows = []
for age in AGES:
    a = main[main.age.eq(age)].set_index("outcome")
    rows.append(
        f'<tr><th>{age}</th><td>{estimate(a.loc["FT"])}</td><td>{a.loc["FT","p_value"]:.3f}</td><td>{a.loc["FT","p_Holm_primary12"]:.3f}</td><td>{estimate(a.loc["PT"])}</td><td>{a.loc["PT","p_value"]:.3f}</td><td>{a.loc["PT","p_Holm_primary12"]:.3f}</td></tr>'
    )
figs = "".join(
    f'<figure class="figure"><a href="figures/{name}.svg"><img loading="lazy" src="figures/{name}.png" alt="{alt}"/></a><figcaption>{caption}</figcaption></figure>'
    for name, alt, caption in [
        (
            "symmetric_01_primary",
            "New symmetric-window FT and PT DID by six age groups",
            "Red shows the 47-month calendar window; gray shows the 36-month window. Marginal 95% occupation-clustered working intervals. November 2022 is excluded.",
        ),
        (
            "symmetric_02_youth_sensitivity",
            "Youth full-time contrast across balanced-window and trend specifications",
            "The negative contrast is sensitive to the calendar window and Q5-specific trend. Freezing short-window units changes the long-window estimate only slightly.",
        ),
        (
            "symmetric_03_event_FT",
            "New full-time event studies with pre-event and post-event observations",
            "Monthly CPS counts in three-month event bins. Reference August–October 2022. November 2022 is excluded. Pandemic quarters are modeled separately; shading is not an assumed zero effect. Confidence ribbons are pointwise.",
        ),
        (
            "symmetric_03_event_PT",
            "New part-time event studies across six age groups",
            "Pointwise 95% working intervals. Display-only October 2025 interpolation is excluded from every regression.",
        ),
    ]
)
block = f"""<details class="result" id="symmetric-validation"><summary>Symmetric-window validation around November 2022 — current estimates</summary><div class="result-body"><p><strong>The original youth full-time decline is not conventionally significant in the requested balanced-window analysis.</strong> The 47-month estimate is −6.60% [−13.22, +0.53], raw p=.069 and Holm p=.756. The 36-month estimate is −1.82%, p=.618. These intervals do not establish zero effects.</p><p>The primary pre-period is December 2018–October 2022; the post-period is December 2022–October 2026. November 2022 is excluded as the transition month. Each side spans 47 calendar months, with 47 observed pre-months and 46 post-months because October 2025 was not collected. The 36-month robustness window uses November 2019–October 2022 and December 2022–November 2025. Interpolated display values are excluded.</p><div class="table-scroll"><table><caption>Current 47-month-window DID. Q5 relative to Q1–Q4. Marginal 95% intervals, raw and twelve-test Holm p-values.</caption><thead><tr><th>Age</th><th>FT %, 95% CI</th><th>Raw p</th><th>Holm p</th><th>PT %, 95% CI</th><th>Raw p</th><th>Holm p</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div><p>All 12 primary contrasts have Holm p&gt;.05. The 12-coefficient joint all-zero test gives p=.324; an occupation-score multiplier diagnostic gives p=.318. Direct age tests and the youth full-time-versus-part-time contrast (p=.518) do not establish an affected-age boundary or a relative shift into part-time work.</p>{figs}<p>The youth full-time pretrend test has raw p=.029 and twelve-test Holm p=.353. Non-rejection after correction does not validate parallel trends. Removing 2020–2021 gives −6.73%, p=.065; adding a Q5 linear trend gives −1.25%, p=.821. Dropping the mirrored pre-event month to match 46 observed months on each side gives −6.62%, p=.071. Thus, neither the missing month alone nor pandemic-quarter controls explain the main sensitivity.</p><p>All 94 raw-file hashes passed. Fresh endpoint parsing reproduced stored counts exactly. An independent explicit-dummy Poisson model reproduced coefficients and cluster standard errors on 2,139 real cells. These are data and numerical validations, not validation of causal identification. The intervals use occupation-score working covariance and do not implement the full CPS survey variance.</p><p><a href="downloads/SYMMETRIC_VALIDATION_REPORT_EN.md">Full validation report</a> · <a href="downloads/symmetric-did-results.csv">All new DID estimates</a> · <a href="downloads/symmetric-pretrend-tests.csv">Pretrend tests</a> · <a href="downloads/symmetric-event-studies.csv">Event coefficients</a> · <a href="downloads/symmetric-validation-reproduction.zip">Aggregate data, code, validation and figures</a></p></div></details>"""
soup = BeautifulSoup((S / "index.html").read_text(), "html.parser")
old = soup.find(id="symmetric-validation")
if old:
    old.decompose()
soup.find(id="monthly-story").insert_after(BeautifulSoup(block, "html.parser"))
for ident, title in [
    (
        "monthly-cps-did",
        "Earlier 2017-start monthly DID and event studies — archived specification",
    ),
    (
        "significance-bridge",
        "Earlier specification audit — why the original significance changed",
    ),
]:
    d = soup.find(id=ident)
    if d:
        summary = d.find("summary", recursive=False)
        if ident == "monthly-cps-did":
            summary.string = title
        else:
            h = summary.find("h3")
            if h:
                h.string = title
        body = d.find(class_="result-body") or d.find(class_="story-body")
        if body and not body.find(class_="archived-validation-note"):
            body.insert(
                0,
                BeautifulSoup(
                    '<p class="archived-validation-note"><strong>Earlier specification.</strong> These results are retained for comparison. The symmetric-window validation above contains the current estimates.</p>',
                    "html.parser",
                ),
            )
hero = soup.select_one(".hero .takeaway p")
if hero:
    hero.string = "The symmetric-window CPS validation estimates a −6.60% relative full-time contrast for ages 22–25 (raw p=.069; Holm p=.756). None of the 12 primary contrasts survives multiplicity correction. Window, pretrend and trend sensitivity prevent causal attribution to AI."
# Update only visible method summary; preserve full construction details.
methods = soup.find(id="methods")
for para in methods.find_all("p", recursive=False):
    if "chart series cover" in para.get_text():
        para.string = "Employment-index charts display November 2022 onward. DID validation retains the pre-period from December 2018 and uses symmetric windows around the excluded November 2022 transition month. The 36-month window is a robustness check. Regressions use observed months only."
# Replace the Discussion with interpretation of the newly fitted models.
disc = """<section id="discussion"><h2>Discussion</h2><h3>1. Early-career full-time weakness remains a signal, not a robust causal estimate</h3><p>The requested symmetric-window validation gives a −6.60% Q5 full-time contrast for ages 22–25 (95% CI, −13.22% to +0.53%; raw p=.069; twelve-test Holm p=.756). The 36-month result is −1.82% (p=.618). The earlier −9.03% estimate belongs to a different, longer pre-period. The negative direction remains worth investigating, but its conventional significance and magnitude do not survive the current validation. The interval still permits a substantial decline; non-significance does not establish no effect.</p><h3>2. A full-time-to-part-time shift and an affected-age boundary remain unproven</h3><p>The youth part-time contrast is −1.78% (p=.791). No age group shows a significant relative part-time increase. The ages 31–34 part-time decline is nominally significant (−15.98%; raw p=.016), but not after Holm correction (p=.197). The direct youth FT/PT difference has p=.518. Global age-effect heterogeneity tests give p=.498 for FT and p=.313 for PT. These results do not establish individual downgrading, an age cutoff, or protection for older workers. Linked hours, earnings and contract histories remain necessary to study worker adaptation.</p><h3>3. The pre-period and trend assumptions matter more than the one missing month</h3><p>Adding a Q5-specific linear trend to the 47-month model gives −1.25% (p=.821); omitting 2020–2021 gives −6.73% (p=.065). Freezing short-window units changes the 47-month result only slightly, to −6.46% (p=.077). Matching the number of observed months by omitting the mirrored pre-event month gives −6.62% (p=.071). Thus, the missing October 2025 observation alone does not account for the weakened significance. The historical occupation bridge and only 23 non-pandemic pre-months in the long window, versus 12 in the short window, remain substantive identification limits.</p><h3>4. Statistical and causal validation</h3><p>The new joint Wald test of all 12 post-period coefficients gives p=.324. An occupation-score Rademacher multiplier diagnostic with 4,999 draws gives p=.318. None of the 12 primary contrasts survives Holm correction. For youth full-time employment, the non-pandemic joint pretrend test has raw p=.029 and Holm p=.353; failure to reject after correction does not demonstrate parallel trends. These are newly fitted balanced-window models, distinct from the earlier archived minimum-p audit.</p><p>Raw-file hashes, aggregate identities, frozen exposure membership and fresh endpoint reparses passed. An independent explicit-dummy Poisson fit reproduced coefficients and cluster standard errors. This establishes numerical reproducibility, not an AI causal effect. Occupational exposure does not identify employer adoption, and concurrent shocks and CPS sampling uncertainty remain. Display indices and October 2025 interpolation are separate from the regression inputs. The current evidence supports continued investigation of entry opportunities, but not a quantified AI-caused employment loss or individual transition into inferior work.</p><p><a href="downloads/SYMMETRIC_VALIDATION_REPORT_EN.md">Full report and interpretation</a> · <a href="downloads/symmetric-global-tests-47.csv">Joint tests</a> · <a href="downloads/symmetric-input-validation.json">Input audit</a> · <a href="downloads/symmetric-independent-validation.json">Independent numerical check</a></p></section>"""
soup.find(id="discussion").replace_with(BeautifulSoup(disc, "html.parser"))
(R / "work/us_youth_significance_bridge_20261125/discussion.html").write_text(disc)
for panel in soup.select("#results details"):
    panel.attrs.pop("open", None)
soup.find(id="story-overall")["open"] = ""
materials = soup.find(id="materials")
old = materials.find(id="symmetric-materials")
if old:
    old.decompose()
materials.h2.insert_after(
    BeautifulSoup(
        '<div id="symmetric-materials"><h3>Current symmetric-window validation</h3><p><a href="downloads/SYMMETRIC_VALIDATION_REPORT_EN.md">English report</a> · <a href="downloads/symmetric-validation-reproduction.zip">Reproduction bundle</a> · <a href="downloads/symmetric-did-results.csv">DID table</a> · <a href="downloads/symmetric-final-validation.json">Final validation checks</a></p></div>',
        "html.parser",
    )
)
(S / "index.html").write_text(str(soup))
for f in (O / "figures").glob("*"):
    shutil.copy2(f, S / "figures" / f.name)
files = {
    "did_results.csv": "symmetric-did-results.csv",
    "pretrend_tests.csv": "symmetric-pretrend-tests.csv",
    "event_studies.csv": "symmetric-event-studies.csv",
    "global_tests_47.csv": "symmetric-global-tests-47.csv",
    "global_tests_36.csv": "symmetric-global-tests-36.csv",
    "direct_age_contrasts_47.csv": "symmetric-age-contrasts.csv",
    "FT_PT_direct_contrasts_47.csv": "symmetric-FT-PT-contrasts.csv",
    "input_validation.json": "symmetric-input-validation.json",
    "independent_numerical_validation.json": "symmetric-independent-validation.json",
    "final_validation.json": "symmetric-final-validation.json",
    "youth_specification_comparison.csv": "symmetric-youth-sensitivity.csv",
    "matched_observation_sensitivity.csv": "symmetric-matched-months.csv",
}
for src, dest in files.items():
    shutil.copy2(T / src, D / dest)
shutil.copy2(
    O / "SYMMETRIC_VALIDATION_REPORT_EN.md", D / "SYMMETRIC_VALIDATION_REPORT_EN.md"
)
with zipfile.ZipFile(
    D / "symmetric-validation-reproduction.zip", "w", zipfile.ZIP_DEFLATED
) as z:
    z.write(O / "SYMMETRIC_VALIDATION_REPORT_EN.md", "REPORT_EN.md")
    for f in T.iterdir():
        if f.is_file():
            z.write(f, "tables/" + f.name)
    for f in W.glob("*.py"):
        z.write(f, "code/" + f.name)
    z.write(
        R / "work/us_youth_significance_bridge_20261125/ppml_model.py",
        "code/ppml_model.py",
    )
    for name in [
        "occupation_industry_monthly_counts.parquet",
        "frozen_THAIE_occupation_assignments.csv",
    ]:
        z.write(
            R / "outputs/US_CPS_Only_Monthly_DID_20261125/tables" / name,
            "inputs/" + name,
        )
    for f in (O / "figures").glob("*.svg"):
        z.write(f, "figures/" + f.name)
    z.writestr(
        "README.txt",
        "Observed CPS aggregate counts and frozen THAIE assignments. The code retains original project-relative paths. Raw person-level records are not included. November 2022 is excluded; display interpolation is not used. Working occupation-cluster covariance does not implement the complete CPS survey design. Prior estimates remain archived, not overwritten.",
    )
print(
    "Published new symmetric-window results with prior specifications labeled archived.",
    flush=True,
)
