"""CPS-only source inventory and free acquisition of missing pre-period months."""

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import json, requests, zipfile, io, hashlib

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
P = ROOT / "outputs/US_THAIE_Regional_Youth_20261122"
prior = json.loads(
    (
        ROOT / "work/us_monthly_canaries_20261125/raw/cps_source_manifest.json"
    ).read_text()
)
old = json.loads((P / "robustness_2010_2026/audit/parse.json").read_text())
idx = {(a["year"], a["month"]): a for a in old}
mon = [
    "jan",
    "feb",
    "mar",
    "apr",
    "may",
    "jun",
    "jul",
    "aug",
    "sep",
    "oct",
    "nov",
    "dec",
]
for year in range(2017, 2020):
    for month in range(1, 13):
        rec = idx.get((year, month), idx[year, 1])
        name = f"{mon[month-1]}{str(year)[2:]}pub.zip"
        candidate = Path(rec["path"]).parent / name
        prior.append(
            dict(
                year=year,
                month=month,
                path=str(candidate if candidate.exists() else W / "raw" / name),
                dictionary=rec["layout"]["dictionary"],
                url=f"https://www2.census.gov/programs-surveys/cps/datasets/{year}/basic/{name}",
                reused=candidate.exists(),
            )
        )


def get(rec):
    if not rec.get("available", True):
        return rec
    f = Path(rec["path"])
    if not f.exists():
        r = requests.get(rec["url"], timeout=120)
        r.raise_for_status()
        assert zipfile.is_zipfile(io.BytesIO(r.content))
        f.write_bytes(r.content)
    rec["sha256"] = hashlib.sha256(f.read_bytes()).hexdigest()
    return rec


records = []
with ThreadPoolExecutor(max_workers=4) as pool:
    for future in as_completed([pool.submit(get, a) for a in prior]):
        records.append(future.result())
records = sorted(records, key=lambda x: (x["year"], x["month"]))
(W / "raw/cps_only_source_manifest.json").write_text(json.dumps(records, indent=2))
print(
    "CPS inventory",
    len(records),
    "calendar months, available",
    sum(r.get("available", True) for r in records),
    flush=True,
)
