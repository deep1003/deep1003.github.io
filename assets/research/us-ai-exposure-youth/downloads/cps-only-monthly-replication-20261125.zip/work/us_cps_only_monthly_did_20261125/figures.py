"""Scientific CPS-only figures saved to disk without interactive output."""

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
O = ROOT / "outputs/US_CPS_Only_Monthly_DID_20261125"
T = O / "tables"
F = O / "figures"
AGES = ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"]
red = "#a32535"
blue = "#347d99"
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "savefig.dpi": 180,
    }
)


def save(fig, name):
    for suffix in ["png", "svg"]:
        fig.savefig(F / (name + "." + suffix), bbox_inches="tight")
    plt.close(fig)


index = pd.read_csv(T / "Q5_vs_Q1_Q4_monthly_indices.csv")
r = pd.read_csv(T / "did_results.csv")
main = r[r.spec.eq("main")]
for out, title in [("FT", "Full-time"), ("PT", "Part-time")]:
    fig, axes = plt.subplots(2, 3, figsize=(14, 7.8), sharex=True, sharey=True)
    for ax, age in zip(axes.flat, AGES):
        for band, color in [("Q5", red), ("Q1–Q4", blue)]:
            z = index[index.age.eq(age) & index.band.eq(band)]
            ax.plot(
                pd.to_datetime(z.date),
                z["index_" + out],
                color=color,
                label=band,
                lw=1.5,
            )
        ax.axhline(100, color=".6", lw=0.7)
        ax.axvspan(
            pd.Timestamp("2020-01-01"),
            pd.Timestamp("2021-12-31"),
            color=".8",
            alpha=0.2,
        )
        ax.axvline(pd.Timestamp("2022-11-30"), color=".3", ls=":", lw=1)
        ax.set_title("Ages " + age)
        ax.grid(axis="y", alpha=0.14)
    axes.flat[0].legend(frameon=False)
    fig.supylabel("Employment count index, 2022 monthly mean = 100")
    fig.suptitle(
        f"{title} employment in THAIE Q5 versus Q1–Q4, independently aggregated CPS",
        fontsize=14,
    )
    fig.text(
        0.5,
        0.005,
        "Monthly descriptive counts, not seasonally adjusted. October 2025 remains missing. Curves cover all exposure-mapped workers in industries 1–13.",
        ha="center",
        fontsize=8,
    )
    fig.tight_layout(rect=[0.025, 0.035, 1, 0.96])
    save(fig, "CPS_only_" + out + "_monthly_trends")
fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.8), sharey=True)
for ax, out, title, color in zip(
    axes, ["FT", "PT"], ["Full-time", "Part-time"], [red, blue]
):
    z = main[main.outcome.eq(out)].set_index("age").loc[AGES]
    ax.errorbar(
        z.estimate_pct,
        np.arange(6),
        xerr=np.vstack([z.estimate_pct - z.ci_low_pct, z.ci_high_pct - z.estimate_pct]),
        fmt="o",
        color=color,
        capsize=3,
    )
    ax.axvline(0, color=".5", lw=0.8)
    ax.set(
        yticks=np.arange(6),
        yticklabels=["Ages " + a for a in AGES],
        title=title,
        xlabel="Q5 versus Q1–Q4 relative employment change (%)",
    )
axes[0].invert_yaxis()
fig.suptitle("Monthly CPS DID with occupation-level inference", fontsize=14)
fig.text(
    0.5,
    0.005,
    "Industry-by-calendar-date, occupation-by-industry and occupation-by-month-of-year fixed effects; Q5-specific pandemic-quarter controls. None survives Holm correction across 12 primary tests.",
    ha="center",
    fontsize=8,
)
fig.tight_layout(rect=[0, 0.04, 1, 0.95])
save(fig, "CPS_only_DID_primary")
if (T / "event_studies.csv").exists():
    ev = pd.read_csv(T / "event_studies.csv")
    pre = pd.read_csv(T / "pretrend_tests.csv")
    for out, title, color in [("FT", "Full-time", red), ("PT", "Part-time", blue)]:
        fig, axes = plt.subplots(2, 3, figsize=(14, 8), sharex=True, sharey=True)
        for ax, age in zip(axes.flat, AGES):
            z = ev[ev.age.eq(age) & ev.outcome.eq(out)].sort_values("event_quarter")
            if z.empty:
                continue
            dates = (
                pd.to_datetime(z.first_month)
                + (pd.to_datetime(z.last_month) - pd.to_datetime(z.first_month)) / 2
            )
            ax.errorbar(
                dates,
                z.estimate_pct,
                yerr=np.vstack(
                    [z.estimate_pct - z.ci_low_pct, z.ci_high_pct - z.estimate_pct]
                ),
                fmt="o",
                ms=3,
                lw=0.8,
                color=color,
                capsize=2,
            )
            ax.plot(
                [pd.Timestamp("2022-10-01")],
                [0],
                marker="o",
                mfc="white",
                mec=color,
                ls="none",
            )
            ax.axhline(0, color=".6", lw=0.7)
            ax.axvspan(
                pd.Timestamp("2020-01-01"),
                pd.Timestamp("2021-12-31"),
                color=".8",
                alpha=0.25,
            )
            ax.axvline(pd.Timestamp("2022-11-30"), color=".4", ls=":", lw=1)
            p = pre[pre.age.eq(age) & pre.outcome.eq(out)].pretrend_p.iloc[0]
            ax.set_title(f"Ages {age} · pretrend p={p:.3f}")
            ax.grid(axis="y", alpha=0.14)
        fig.supylabel("Q5 versus Q1–Q4 relative difference (%)")
        fig.suptitle(
            f"{title} event study from monthly CPS, three-month event bins", fontsize=14
        )
        fig.text(
            0.5,
            0.005,
            "Reference September–November 2022. Pandemic quarters are separate nuisance controls. Intervals are pointwise 95% occupation-clustered intervals, not simultaneous bands.",
            ha="center",
            fontsize=8,
        )
        fig.tight_layout(rect=[0.025, 0.035, 1, 0.95])
        save(fig, "CPS_only_" + out + "_event_study")
# Main-versus-trend comparison across all ages, once sensitivities finish.
if r.spec.eq("trend").sum() == 12:
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.5), sharex=True, sharey=True)
    for ax, out, title in zip(axes, ["FT", "PT"], ["Full-time", "Part-time"]):
        for offset, spec, marker, color, label in [
            (-0.12, "main", "o", red, "Main"),
            (0.12, "trend", "D", blue, "Q5 linear trend"),
        ]:
            z = r[r.spec.eq(spec) & r.outcome.eq(out)].set_index("age").loc[AGES]
            yy = np.arange(6) + offset
            ax.errorbar(
                z.estimate_pct,
                yy,
                xerr=np.vstack(
                    [z.estimate_pct - z.ci_low_pct, z.ci_high_pct - z.estimate_pct]
                ),
                fmt=marker,
                color=color,
                capsize=3,
                label=label,
                ms=5,
            )
        ax.axvline(0, color=".5", lw=0.8)
        ax.set(
            yticks=np.arange(6),
            yticklabels=["Ages " + a for a in AGES],
            title=title,
            xlabel="Relative employment contrast (%)",
        )
    axes[0].invert_yaxis()
    axes[1].legend(frameon=False)
    fig.suptitle("Sensitivity to an exposure-specific linear trend", fontsize=14)
    fig.tight_layout()
    save(fig, "CPS_only_trend_sensitivity")
print("Saved scientific figures without emitting any graph to the screen.")
