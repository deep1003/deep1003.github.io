"""Exploratory direct age and FT/PT contrasts with shared occupation-score covariance."""

import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t, f
from statsmodels.stats.multitest import multipletests
from run import ROOT, W, T, AGES

models = {}
influences = {}
for age in AGES:
    for outcome in ["FT", "PT"]:
        models[age, outcome] = json.loads(
            (W / f"fit_{age}_main_{outcome}.json").read_text()
        )["row"]
        influences[age, outcome] = (
            pd.read_csv(W / f"influence_{age}_{outcome}.csv")
            .set_index("occupation")
            .influence
        )


def calc(first, second):
    a = models[first]
    b = models[second]
    ix = influences[first].index.union(influences[second].index)
    delta = influences[first].reindex(ix, fill_value=0) - influences[second].reindex(
        ix, fill_value=0
    )
    se = float(np.sqrt(np.sum(delta**2)))
    beta = a["log_change"] - b["log_change"]
    df = min(a["occupation_clusters"], b["occupation_clusters"]) - 1
    crit = t.ppf(0.975, df)
    return dict(
        log_difference=beta,
        se_log=se,
        estimate_pct=100 * np.expm1(beta),
        ci_low_pct=100 * np.expm1(beta - crit * se),
        ci_high_pct=100 * np.expm1(beta + crit * se),
        p_value=float(2 * t.sf(abs(beta / se), df)),
    )


rows = []
quality = []
globaltests = []
for outcome in ["FT", "PT"]:
    for older in AGES[1:]:
        rows.append(
            dict(
                outcome=outcome,
                comparison="22–25 versus " + older,
                **calc(("22–25", outcome), (older, outcome)),
            )
        )
    union = sorted(set().union(*(set(influences[age, outcome].index) for age in AGES)))
    u = np.vstack(
        [influences[age, outcome].reindex(union, fill_value=0) for age in AGES]
    )
    b = np.array([models[age, outcome]["log_change"] for age in AGES])
    c = np.column_stack([-np.ones(5), np.eye(5)])
    vc = c @ u @ u.T @ c.T
    v = c @ b
    stat = float(v @ np.linalg.solve(vc, v) / 5)
    df = min(models[age, outcome]["occupation_clusters"] for age in AGES) - 1
    globaltests.append(
        dict(
            outcome=outcome,
            F_statistic=stat,
            numerator_df=5,
            denominator_df=df,
            p_value=float(f.sf(stat, 5, df)),
        )
    )
for age in AGES:
    quality.append(
        dict(
            age=age,
            contrast="Full-time versus part-time relative Q5 effect",
            **calc((age, "FT"), (age, "PT")),
        )
    )
for name, records in [
    ("direct_age_contrasts", rows),
    ("FT_PT_direct_contrasts", quality),
    ("global_age_heterogeneity", globaltests),
]:
    d = pd.DataFrame(records)
    d["p_holm_family"] = multipletests(d.p_value, method="holm")[1]
    d.to_csv(T / (name + ".csv"), index=False)
    print(name)
    print(d.to_string(index=False))
