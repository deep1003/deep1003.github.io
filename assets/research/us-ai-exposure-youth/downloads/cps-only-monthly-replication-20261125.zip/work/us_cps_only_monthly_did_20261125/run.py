"""Six exact age groups, THAIE-only employment DID and quarterly-binned event studies."""

from pathlib import Path
import json
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests
from model import fit, contrast, joint

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
T = ROOT / "outputs/US_CPS_Only_Monthly_DID_20261125/tables"
AGES = ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"]


def prepare(age, spec="main"):
    a = pd.read_parquet(T / "occupation_industry_monthly_counts.parquet")
    a = a[a.age.eq(age) & a.band.ne("Unmapped") & a.industry.between(1, 13)].copy()
    if spec == "short2020":
        a = a[a.date.ge("2020-01-01")]
    if spec == "no_covid":
        a = a[~a.date.str[:4].isin(["2020", "2021"])]
    if spec == "placebo2019":
        a = a[a.date.lt("2020-01-01")]
    dates = sorted(a.date.unique())
    meta = a[["occupation", "industry", "band"]].drop_duplicates()
    assert not meta.duplicated(["occupation", "industry"]).any()
    a = a.groupby(["occupation", "industry", "date"], as_index=False)[
        ["E", "FT", "PT", "nE"]
    ].sum()
    grid = meta.merge(pd.DataFrame({"date": dates}), how="cross")
    a = grid.merge(
        a, on=["occupation", "industry", "date"], how="left", validate="one_to_one"
    )
    a[["E", "FT", "PT", "nE"]] = a[["E", "FT", "PT", "nE"]].fillna(0)
    dt = pd.to_datetime(a.date)
    a["month"] = dt.dt.month
    a["year"] = dt.dt.year
    a["quarter"] = dt.dt.quarter
    a["t"] = (dt.dt.year - 2022) * 12 + dt.dt.month - 12
    a["occ_industry"] = a.occupation.astype(str) + "_" + a.industry.astype(str)
    a["occ_season"] = a.occupation.astype(str) + "_" + a.month.astype(str)
    a["industry_date"] = a.industry.astype(str) + "_" + a.date
    before = a[["FT", "PT", "E"]].sum()
    rows_before = len(a)
    for _ in range(20):
        n = len(a)
        for fe in ["occ_industry", "occ_season", "industry_date"]:
            support_columns = ["FT"] if spec == "FT_only_support" else ["FT", "PT"]
            totals = a.groupby(fe)[support_columns].sum()
            keep = totals.index[totals.gt(0).all(axis=1)]
            a = a[a[fe].isin(keep)]
        if len(a) == n:
            break
    else:
        raise ValueError("Support pruning failed to settle")
    support = {
        y + "_retention": float(a[y].sum() / before[y]) for y in ["FT", "PT", "E"]
    }
    support["rows_before_support"] = rows_before
    support["occupation_count"] = a.occupation.nunique()
    support["months"] = a.date.nunique()
    a["high"] = a.band.eq("Q5").astype(float)
    return a.reset_index(drop=True), support


def design(a, spec, event=False):
    h = a.high.to_numpy()
    cols = []
    names = []

    def add(name, v):
        names.append(name)
        cols.append(np.asarray(v, float))

    if event:
        covid = a.year.isin([2020, 2021])
        binq = np.floor(a.t / 3).astype(int)
        for q in sorted(binq[~covid].unique()):
            if q != -1:
                add("event_" + str(q), h * (binq.eq(q) & ~covid))
    else:
        add(
            "DID",
            h * a.date.ge("2019-01-01" if spec == "placebo2019" else "2022-12-01"),
        )
    for year in [2020, 2021]:
        for q in range(1, 5):
            mask = a.year.eq(year) & a.quarter.eq(q)
            if mask.any():
                add(f"covid_{year}Q{q}", h * mask)
    if spec == "trend":
        add("Q5_linear_trend", h * a.t / 12)
    return np.column_stack(cols), names


if __name__ == "__main__":
    rows = []
    events = []
    pre = []
    supports = []
    twoway = []
    for spec in ["main", "trend", "no_covid", "short2020", "placebo2019"]:
        for age in AGES:
            a, support = prepare(age, spec)
            supports.append(dict(age=age, spec=spec, **support))
            x, names = design(a, spec)
            for outcome in ["FT", "PT"]:
                cache = W / f"fit_{age}_{spec}_{outcome}.json"
                if cache.exists():
                    result = json.loads(cache.read_text())
                    rows.append(result["row"])
                    twoway.append(result["two_way"])
                    continue
                print("Fitting", age, spec, outcome, "N", len(a), flush=True)
                b, v, v2, info, inf, groups = fit(a, outcome, x, names)
                row = dict(
                    age=age,
                    spec=spec,
                    outcome=outcome,
                    **info,
                    **contrast(b, v, names, "DID", info["occupation_clusters"] - 1),
                )
                rows.append(row)
                two = dict(
                    age=age,
                    spec=spec,
                    outcome=outcome,
                    **contrast(
                        b,
                        v2,
                        names,
                        "DID",
                        min(info["occupation_clusters"], info["date_clusters"]) - 1,
                    ),
                )
                twoway.append(two)
                cache.write_text(json.dumps({"row": row, "two_way": two}, indent=2))
                if spec == "main":
                    j = names.index("DID")
                    pd.DataFrame({"occupation": groups, "influence": inf[:, j]}).to_csv(
                        W / f"influence_{age}_{outcome}.csv", index=False
                    )
                print(
                    "Result",
                    round(row["estimate_pct"], 3),
                    round(row["p_value"], 6),
                    flush=True,
                )
            pd.DataFrame(rows).to_csv(T / "did_results.csv", index=False)
    for age in AGES:
        a, _ = prepare(age, "main")
        x, names = design(a, "main", event=True)
        for outcome in ["FT", "PT"]:
            file = W / f"events_{age}_{outcome}.csv"
            pf = W / f"pretest_{age}_{outcome}.json"
            if file.exists():
                events.extend(pd.read_csv(file).to_dict("records"))
                pre.append(json.loads(pf.read_text()))
                continue
            print("Event study", age, outcome, "N", len(a), flush=True)
            b, v, v2, info, _, _ = fit(a, outcome, x, names)
            leads = [
                s for s in names if s.startswith("event_") and int(s.split("_")[1]) < 0
            ]
            pr = dict(
                age=age,
                outcome=outcome,
                **joint(b, v, names, leads, info["occupation_clusters"] - 1),
            )
            pre.append(pr)
            pf.write_text(json.dumps(pr, indent=2))
            er = []
            for term in names:
                if term.startswith("event_"):
                    q = int(term.split("_")[1])
                    mask = np.floor(a.t / 3).eq(q) & ~a.year.isin([2020, 2021])
                    dates = sorted(a.loc[mask, "date"].unique())
                    row = dict(
                        age=age,
                        outcome=outcome,
                        event_quarter=q,
                        first_month=dates[0],
                        last_month=dates[-1],
                        months_in_bin=len(dates),
                        **contrast(b, v, names, term, info["occupation_clusters"] - 1),
                    )
                    er.append(row)
            pd.DataFrame(er).to_csv(file, index=False)
            events.extend(er)
        pd.DataFrame(events).to_csv(T / "event_studies.csv", index=False)
        pd.DataFrame(pre).to_csv(T / "pretrend_tests.csv", index=False)
    r = pd.DataFrame(rows)
    r["p_holm_primary12"] = np.nan
    ix = r.spec.eq("main")
    r.loc[ix, "p_holm_primary12"] = multipletests(r.loc[ix, "p_value"], method="holm")[
        1
    ]
    r["p_holm_all60"] = multipletests(r.p_value, method="holm")[1]
    r.to_csv(T / "did_results.csv", index=False)
    q = pd.DataFrame(twoway)
    q["p_holm_primary12"] = np.nan
    ix = q.spec.eq("main")
    q.loc[ix, "p_holm_primary12"] = multipletests(q.loc[ix, "p_value"], method="holm")[
        1
    ]
    q.to_csv(T / "two_way_cluster_sensitivity.csv", index=False)
    pd.DataFrame(supports).to_csv(T / "common_FT_PT_support.csv", index=False)
    print(
        r[r.spec.eq("main")][
            ["age", "outcome", "estimate_pct", "p_value", "p_holm_primary12"]
        ].to_string(index=False),
        flush=True,
    )
