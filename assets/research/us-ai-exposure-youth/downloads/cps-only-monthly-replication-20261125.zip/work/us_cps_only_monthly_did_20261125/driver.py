"""Run primary DID and event studies before the predefined sensitivity grid."""

from pathlib import Path
import json
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests
from run import ROOT, W, T, AGES, prepare, design
from model import fit, contrast, joint

rows = []
twoway = []
supports = []
events = []
pre = []
failures = []


def persist():
    if rows:
        r = pd.DataFrame(rows)
        r["p_holm_primary12"] = np.nan
        mask = r.spec.eq("main")
        if mask.sum() == 12:
            r.loc[mask, "p_holm_primary12"] = multipletests(
                r.loc[mask, "p_value"], method="holm"
            )[1]
        padded = np.r_[r.p_value.to_numpy(), np.ones(60 - len(r))]
        r["p_holm_planned60"] = multipletests(padded, method="holm")[1][: len(r)]
        r.to_csv(T / "did_results.csv", index=False)
        q = pd.DataFrame(twoway)
        q["p_holm_primary12"] = np.nan
        mask = q.spec.eq("main")
        if mask.sum() == 12:
            q.loc[mask, "p_holm_primary12"] = multipletests(
                q.loc[mask, "p_value"], method="holm"
            )[1]
        q.to_csv(T / "two_way_cluster_sensitivity.csv", index=False)
    if events:
        pd.DataFrame(events).to_csv(T / "event_studies.csv", index=False)
    if pre:
        pd.DataFrame(pre).to_csv(T / "pretrend_tests.csv", index=False)
    pd.DataFrame(supports).to_csv(T / "common_FT_PT_support.csv", index=False)
    (T / "numerical_status.json").write_text(
        json.dumps(
            {
                "planned_DID": 60,
                "valid_DID_so_far": len(rows),
                "event_studies_so_far": len(pre),
                "failed_sensitivities": failures,
            },
            indent=2,
        )
    )


def did(age, spec):
    a, support = prepare(age, spec)
    supports.append(dict(age=age, spec=spec, **support))
    x, names = design(a, spec)
    for outcome in ["FT", "PT"]:
        cache = W / f"fit_{age}_{spec}_{outcome}.json"
        if cache.exists():
            result = json.loads(cache.read_text())
            rows.append(result["row"])
            twoway.append(result["two_way"])
            continue
        print("DID", age, spec, outcome, "N", len(a), flush=True)
        try:
            b, v, v2, info, inf, groups = fit(
                a,
                outcome,
                x,
                names,
                backend="cg" if spec in ["short2020", "placebo2019"] else "map",
            )
            row = dict(
                age=age,
                spec=spec,
                outcome=outcome,
                **info,
                **contrast(b, v, names, "DID", info["occupation_clusters"] - 1),
            )
            two = dict(
                age=age,
                spec=spec,
                outcome=outcome,
                **contrast(
                    b,
                    v2,
                    names,
                    "DID",
                    min(info["occupation_clusters"], info["date_clusters"]) - 1,
                ),
            )
        except (ValueError, RuntimeError) as error:
            if spec == "main":
                raise
            failures.append(dict(age=age, spec=spec, outcome=outcome, error=str(error)))
            print("Numerical sensitivity unavailable", str(error), flush=True)
            persist()
            continue
        rows.append(row)
        twoway.append(two)
        cache.write_text(json.dumps({"row": row, "two_way": two}, indent=2))
        if spec == "main":
            pd.DataFrame(
                {"occupation": groups, "influence": inf[:, names.index("DID")]}
            ).to_csv(W / f"influence_{age}_{outcome}.csv", index=False)
        print(
            "Estimate",
            round(row["estimate_pct"], 3),
            "p",
            round(row["p_value"], 6),
            flush=True,
        )
    persist()


for age in AGES:
    did(age, "main")
for age in AGES:
    a, _ = prepare(age, "main")
    x, names = design(a, "main", event=True)
    for outcome in ["FT", "PT"]:
        file = W / f"events_{age}_{outcome}.csv"
        pf = W / f"pretest_{age}_{outcome}.json"
        if file.exists():
            events.extend(pd.read_csv(file).to_dict("records"))
            pre.append(json.loads(pf.read_text()))
            continue
        print("Event study", age, outcome, "parameters", len(names), flush=True)
        b, v, v2, info, _, _ = fit(a, outcome, x, names)
        leads = [
            s for s in names if s.startswith("event_") and int(s.split("_")[1]) < 0
        ]
        pr = dict(
            age=age,
            outcome=outcome,
            **joint(b, v, names, leads, info["occupation_clusters"] - 1),
        )
        pre.append(pr)
        pf.write_text(json.dumps(pr, indent=2))
        er = []
        for term in names:
            if term.startswith("event_"):
                q = int(term.split("_")[1])
                mask = np.floor(a.t / 3).eq(q) & ~a.year.isin([2020, 2021])
                dates = sorted(a.loc[mask, "date"].unique())
                er.append(
                    dict(
                        age=age,
                        outcome=outcome,
                        event_quarter=q,
                        first_month=dates[0],
                        last_month=dates[-1],
                        months_in_bin=len(dates),
                        **contrast(b, v, names, term, info["occupation_clusters"] - 1),
                    )
                )
        pd.DataFrame(er).to_csv(file, index=False)
        events.extend(er)
        print("Pretrend p", pr["pretrend_p"], flush=True)
    persist()
for spec in ["trend", "no_covid", "short2020", "placebo2019"]:
    for age in AGES:
        did(age, spec)
persist()
print("All requested CPS-only models and diagnostics completed.", flush=True)
