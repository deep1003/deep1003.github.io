"""Construct CPS-only monthly occupation-industry and state-industry panels."""

from pathlib import Path
import importlib.util, json
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = ROOT / "outputs/US_CPS_Only_Monthly_DID_20261125"
T = O / "tables"
P = ROOT / "outputs/US_THAIE_Regional_Youth_20261122"
s = importlib.util.spec_from_file_location(
    "parser", P / "panel_fe3_20261122/scripts/prepare_panel.py"
)
parser = importlib.util.module_from_spec(s)
s.loader.exec_module(parser)
records = json.loads((W / "raw/cps_only_source_manifest.json").read_text())
idx = {(a["year"], a["month"]): a for a in records if a.get("available", True)}
parser.source = lambda y, m: (Path(idx[y, m]["path"]), Path(idx[y, m]["dictionary"]))
scores = pd.read_csv(P / "high_exposure_quality/derived/occupation_quintiles.csv")[
    ["occ", "THAIE", "THAIE_q"]
]
scores.to_csv(T / "frozen_THAIE_occupation_assignments.csv", index=False)
conversion = pd.read_csv(
    P / "extension_2019/derived/occupation_conversion_2010_2018.csv"
).rename(columns={"old": "occ", "new": "occupation", "rate": "probability"})
assert np.allclose(conversion.groupby("occ").probability.sum(), 1, atol=1e-5)
AGES = ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"]
values = ["E", "FT", "PT", "nE", "nFT", "nPT"]
parts = []
stateparts = []
audits = []
pops = []
for (year, month), rec in sorted(idx.items()):
    file = W / f"counts_{year}_{month:02}.parquet"
    st = W / f"states_{year}_{month:02}.parquet"
    au = W / f"audit_{year}_{month:02}.json"
    popfile = W / f"population_{year}_{month:02}.parquet"
    if file.exists():
        parts.append(pd.read_parquet(file))
        stateparts.append(pd.read_parquet(st))
        audits.append(json.loads(au.read_text()))
        pops.append(pd.read_parquet(popfile))
        continue
    d, audit = parser.read(year, month)
    d = d[d.PRTAGE.ge(22)].copy()
    d["age"] = pd.cut(d.PRTAGE, bins=[21, 25, 30, 34, 40, 49, 200], labels=AGES).astype(
        str
    )
    d["date"] = f"{year}-{month:02}-01"
    pop = d.groupby(["date", "age"])[["P", "E", "U", "FT", "PT"]].sum().reset_index()
    pop.to_parquet(popfile, index=False)
    pops.append(pop)
    d = d[d.nE.eq(1)].copy()
    d["nFT"] = d.PRFTLF.eq(1).astype(int)
    d["nPT"] = d.PRFTLF.eq(2).astype(int)
    if year < 2020:
        d = d.merge(conversion, on="occ", how="left", validate="many_to_many")
        d["probability"] = d.probability.fillna(1)
        d["occupation"] = d.occupation.fillna(-1).astype(int)
        d[values] = d[values].multiply(d.probability, axis=0)
    else:
        d["occupation"] = d.occ
    d = d.merge(
        scores.rename(columns={"occ": "occupation"}),
        on="occupation",
        how="left",
        validate="many_to_one",
    )
    d["band"] = np.where(
        d.THAIE_q.eq(5), "Q5", np.where(d.THAIE_q.between(1, 4), "Q1–Q4", "Unmapped")
    )
    a = (
        d.groupby(["date", "age", "occupation", "PRMJIND1", "band"], as_index=False)[
            values
        ]
        .sum()
        .rename(columns={"PRMJIND1": "industry"})
    )
    a.to_parquet(file, index=False)
    parts.append(a)
    a = (
        d.groupby(["date", "age", "GESTFIPS", "PRMJIND1", "band"], as_index=False)[
            values
        ]
        .sum()
        .rename(columns={"PRMJIND1": "industry"})
    )
    a.to_parquet(st, index=False)
    stateparts.append(a)
    au.write_text(json.dumps(audit, indent=2))
    audits.append(audit)
    print("CPS-only aggregation", year, month, flush=True)
a = pd.concat(parts, ignore_index=True)
a.to_parquet(T / "occupation_industry_monthly_counts.parquet", index=False)
b = pd.concat(stateparts, ignore_index=True)
b.to_parquet(T / "state_industry_monthly_counts.parquet", index=False)
pop = pd.concat(pops, ignore_index=True)
pop.to_csv(T / "monthly_age_population_and_employment.csv", index=False)
assert np.allclose(a.E, a.FT + a.PT)
assert np.allclose(
    a.groupby(["date", "age"]).E.sum().sort_index(),
    pop.set_index(["date", "age"]).E.sort_index(),
)
coverage = a.groupby(["date", "age"]).E.sum().to_frame("all_employed")
coverage["supported_exposure_E"] = (
    a[a.band.ne("Unmapped")].groupby(["date", "age"]).E.sum()
)
coverage["supported_exposure_share"] = (
    coverage.supported_exposure_E / coverage.all_employed
)
coverage.to_csv(T / "exposure_linkage_coverage.csv")
(T / "cps_only_parse_audit.json").write_text(json.dumps(audits, indent=2))
print("CPS-only monthly cells", a.shape, "dates", a.date.nunique(), flush=True)
