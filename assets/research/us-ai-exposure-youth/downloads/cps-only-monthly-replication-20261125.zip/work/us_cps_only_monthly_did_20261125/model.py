"""Poisson QMLE with absorbed fixed effects and occupation-level score inference."""

import numpy as np
import pandas as pd
import pyhdfe
from scipy.stats import t, f
from scipy import sparse
from scipy.sparse.linalg import cg


def codes(a):
    return pd.factorize(a, sort=True)[0]


def clusters(scores, group, bread, df_factor):
    g = codes(group)
    G = int(g.max() + 1)
    s = np.zeros((G, scores.shape[1]))
    np.add.at(s, g, scores)
    adj = G / (G - 1) * df_factor
    inf = s @ bread * np.sqrt(adj)
    return inf.T @ inf, inf, G


def fit(d, outcome, x, names, backend="map"):
    y = d[outcome].to_numpy(float) / 1e5
    ids = np.column_stack(
        [codes(d[c]) for c in ["occ_industry", "occ_season", "industry_date"]]
    )
    holder = {"mu": np.ones(len(d))}

    def weighted_convergence(last, current):
        delta = last - current
        return (
            np.sqrt(
                np.max(np.sum(holder["mu"][:, None] * delta * delta, axis=0))
                / np.sum(holder["mu"])
            )
            < 1e-10
        )

    algo = pyhdfe.create(
        ids,
        drop_singletons=False,
        compute_degrees=True,
        residualize_method="map",
        options={"converged": weighted_convergence, "iteration_limit": 3000},
    )
    if backend == "cg":
        sizes = ids.max(axis=0) + 1
        offsets = np.r_[0, np.cumsum(sizes)[:-1]]
        dummy = sparse.csr_matrix(
            (
                np.ones(ids.size),
                (np.repeat(np.arange(len(d)), ids.shape[1]), (ids + offsets).ravel()),
            ),
            shape=(len(d), int(sizes.sum())),
        )

    def residualize(matrix, weights):
        if backend == "map":
            return algo.residualize(matrix, weights=weights[:, None])
        # Solve the consistent weighted FE normal equations in their column space.
        # Null gauge directions do not affect fitted values. Jacobi scaling improves conditioning.
        sums = np.asarray(dummy.T @ weights).ravel()
        scale = 1 / np.sqrt(sums)
        weighted_dummy = dummy.multiply(np.sqrt(weights)[:, None])
        gram = (weighted_dummy.T @ weighted_dummy).tocsr()
        gram = gram.multiply(scale[:, None]).multiply(scale[None, :]).tocsr()
        rhs = np.asarray(dummy.T @ (weights[:, None] * matrix)) * scale[:, None]
        coefficients = np.empty_like(rhs)
        for column in range(rhs.shape[1]):
            solution, flag = cg(
                gram, rhs[:, column], rtol=1e-11, atol=1e-12, maxiter=10000
            )
            if flag != 0:
                raise ValueError(
                    f"Weighted FE CG did not converge, column {column}, status {flag}"
                )
            coefficients[:, column] = scale * solution
        result = matrix - dummy @ coefficients
        return np.asarray(result)

    eta = np.log(
        np.maximum(
            d.groupby("occ_industry")[outcome].transform("mean").to_numpy() / 1e5, 1e-6
        )
    )
    b = np.zeros(x.shape[1])
    converged = False
    warm_x = x.copy()

    def loss(e):
        return np.sum(np.exp(np.clip(e, -35, 20)) - y * e)

    for iteration in range(150):
        mu = np.exp(np.clip(eta, -35, 20))
        holder["mu"] = mu
        z = eta + (y - mu) / mu
        # Subtracting an existing FE component leaves the weighted residual unchanged.
        z_start = (y - mu) / mu + warm_x @ b
        res = residualize(np.column_stack([z_start, warm_x]), mu)
        zr = res[:, 0]
        xr = res[:, 1:]
        warm_x = xr
        h = xr.T @ (mu[:, None] * xr)
        rank = np.linalg.matrix_rank(h)
        if rank < len(b):
            raise ValueError(f"Absorbed or singular columns {rank}/{len(b)}")
        newb = np.linalg.solve(h, xr.T @ (mu * zr))
        neweta = z - zr + xr @ newb
        step = 1.0
        before = loss(eta)
        while step > 1e-7 and loss(eta + step * (neweta - eta)) > before + 1e-9:
            step /= 2
        change = float(np.max(abs(step * (newb - b))))
        eta = eta + step * (neweta - eta)
        b = b + step * (newb - b)
        if iteration % 10 == 0:
            print(
                "  IRLS",
                outcome,
                iteration,
                "beta",
                round(float(b[0]), 5),
                "delta",
                round(change, 8),
                flush=True,
            )
        current_residual = y - np.exp(np.clip(eta, -35, 20))
        current_score = max(
            float(np.max(abs(x.T @ current_residual))),
            max(
                float(np.max(abs(np.bincount(ids[:, j], weights=current_residual))))
                for j in range(ids.shape[1])
            ),
        )
        if change < 1e-7 and current_score < 1e-6 and iteration > 2:
            converged = True
            break
    if not converged:
        raise ValueError("PPML did not converge")
    mu = np.exp(np.clip(eta, -35, 20))
    holder["mu"] = mu
    xr = residualize(warm_x, mu)
    h = xr.T @ (mu[:, None] * xr)
    bread = np.linalg.inv(h)
    residual = y - mu
    scores = xr * residual[:, None]
    score_max = float(np.max(abs(x.T @ residual)))
    fe_score = max(
        float(np.max(abs(np.bincount(ids[:, j], weights=residual))))
        for j in range(ids.shape[1])
    )
    if max(score_max, fe_score) > 1e-6:
        raise ValueError(f"Unconverged score target={score_max}, FE={fe_score}")
    n = len(d)
    dfres = n - algo.degrees - len(b)
    if dfres <= 0:
        raise ValueError("No residual degrees of freedom")
    factor = (n - 1) / dfres
    cov, inf, G = clusters(scores, d.occupation, bread, factor)
    vc_date, _, gt = clusters(scores, d.date, bread, factor)
    vc_joint, _, _ = clusters(
        scores, d.occupation.astype(str) + "_" + d.date, bread, factor
    )
    v2 = cov + vc_date - vc_joint
    info = dict(
        backend=backend,
        N=n,
        occupation_clusters=G,
        date_clusters=gt,
        FE_rank=int(algo.degrees),
        parameters=len(b),
        iterations=iteration + 1,
        score_max=score_max,
        FE_score_max=fe_score,
        converged=converged,
        zero_outcome_cells=int(np.sum(y == 0)),
    )
    return b, cov, v2, info, inf, sorted(d.occupation.unique())


def contrast(b, v, names, term, df):
    j = names.index(term)
    se2 = float(v[j, j])
    if se2 <= 0:
        raise ValueError("Nonpositive contrast variance")
    se = np.sqrt(se2)
    crit = t.ppf(0.975, df)
    p = 2 * t.sf(abs(b[j] / se), df)
    return dict(
        log_change=float(b[j]),
        se_log=float(se),
        estimate_pct=float(100 * np.expm1(b[j])),
        ci_low_pct=float(100 * np.expm1(b[j] - crit * se)),
        ci_high_pct=float(100 * np.expm1(b[j] + crit * se)),
        p_value=float(p),
    )


def joint(b, v, names, terms, df):
    ix = [names.index(s) for s in terms]
    vv = v[np.ix_(ix, ix)]
    rank = np.linalg.matrix_rank(vv)
    if rank < len(ix):
        return dict(pretrend_p=np.nan, pretrend_terms=len(ix), singular=True)
    stat = float(b[ix] @ np.linalg.solve(vv, b[ix]) / len(ix))
    return dict(
        pretrend_p=float(f.sf(stat, len(ix), df)),
        pretrend_terms=len(ix),
        singular=False,
    )
