"""CPS-only descriptive indices and seasonally matched endpoint decompositions."""

from pathlib import Path
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
O = ROOT / "outputs/US_CPS_Only_Monthly_DID_20261125"
T = O / "tables"
a = pd.read_parquet(T / "occupation_industry_monthly_counts.parquet")
a = a[a.industry.between(1, 13) & a.band.ne("Unmapped")]
z = (
    a.groupby(["age", "band", "date"])[["E", "FT", "PT", "nE", "nFT", "nPT"]]
    .sum()
    .reset_index()
)
records = []
for (age, band), g in z.groupby(["age", "band"]):
    g = g.set_index("date").reindex(
        pd.date_range("2017-01-01", "2026-10-01", freq="MS").strftime("%Y-%m-%d")
    )
    g["age"] = age
    g["band"] = band
    g["date"] = g.index
    for outcome in ["E", "FT", "PT"]:
        baseline = g[g.index.str.startswith("2022-")][outcome].mean()
        assert g[g.index.str.startswith("2022-")][outcome].count() == 12
        g["index_" + outcome] = 100 * g[outcome] / baseline
    records.append(g.reset_index(drop=True))
pd.concat(records, ignore_index=True).to_csv(
    T / "Q5_vs_Q1_Q4_monthly_indices.csv", index=False
)
rows = []
for (age, band), g in z.groupby(["age", "band"]):
    dt = pd.to_datetime(g.date)
    m = g[dt.dt.month.le(9)]
    for outcome in ["FT", "PT"]:
        base = m[m.date.str.startswith("2022-")][outcome].mean()
        end = m[m.date.str.startswith("2026-")][outcome].mean()
        rows.append(
            dict(
                age=age,
                band=band,
                outcome=outcome,
                monthly_mean_2022_JanSep=base,
                monthly_mean_2026_JanSep=end,
                change_pct=100 * (end / base - 1),
            )
        )
pd.DataFrame(rows).to_csv(T / "seasonally_matched_descriptive_changes.csv", index=False)
print(pd.DataFrame(rows).query("age=='22–25'").to_string(index=False))
