"""Check whether requiring part-time support selects the full-time result."""

import json
import pandas as pd
from run import prepare, design, AGES, W, T
from model import fit, contrast

rows = []
for age in AGES:
    cache = W / f"full_FT_support_{age}.json"
    if cache.exists():
        rows.append(json.loads(cache.read_text()))
        continue
    a, support = prepare(age, "FT_only_support")
    x, names = design(a, "main")
    print("FT-only support", age, len(a), flush=True)
    b, v, v2, info, _, _ = fit(a, "FT", x, names)
    row = dict(
        age=age,
        **support,
        **info,
        **contrast(b, v, names, "DID", info["occupation_clusters"] - 1),
    )
    rows.append(row)
    cache.write_text(json.dumps(row, indent=2))
    pd.DataFrame(rows).to_csv(T / "full_FT_support_sensitivity.csv", index=False)
pd.DataFrame(rows).to_csv(T / "full_FT_support_sensitivity.csv", index=False)
print("FT-only support checks completed.", flush=True)
