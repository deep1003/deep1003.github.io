"""Independent explicit-dummy GLM validation on real CPS cells. No plot output."""

from pathlib import Path
import json
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.linalg import qr
from run import prepare, design
from model import fit

ROOT = Path(__file__).resolve().parents[2]
O = ROOT / "outputs/US_CPS_Only_Monthly_DID_20261125"
a, _ = prepare("22–25", "placebo2019")
selected = []
for h in [0, 1]:
    selected += (
        a[a.high.eq(h)].groupby("occupation").FT.sum().nlargest(4).index.tolist()
    )
a = a[
    a.occupation.isin(selected)
    & a.industry.isin([4, 5, 9, 10])
    & a.date.ge("2018-01-01")
].copy()
for _ in range(10):
    n = len(a)
    for fe in ["occ_industry", "occ_season", "industry_date"]:
        keep = a.groupby(fe).FT.sum()
        a = a[a[fe].isin(keep.index[keep.gt(0)])]
    if len(a) == n:
        break
a = a.reset_index(drop=True)
x, names = design(a, "placebo2019")
b, v, _, info, _, _ = fit(a, "FT", x, names, backend="cg")
parts = [
    pd.get_dummies(a[c], dtype=float, prefix=c).to_numpy()
    for c in ["occ_industry", "occ_season", "industry_date"]
]
dummy = np.column_stack(parts)
_, r, piv = qr(dummy, mode="economic", pivoting=True)
rank = int(np.sum(abs(np.diag(r)) > 1e-8))
full = np.column_stack([dummy[:, piv[:rank]], x])
assert np.linalg.matrix_rank(full) == full.shape[1]
reference = sm.GLM(a.FT.to_numpy() / 1e5, full, family=sm.families.Poisson()).fit(
    maxiter=100,
    tol=1e-11,
    cov_type="cluster",
    cov_kwds={"groups": a.occupation.to_numpy(), "use_correction": True},
)
assert np.allclose(b, reference.params[-len(b) :], atol=1e-6)
# Adjust the reference finite-sample factor to the explicitly documented FE-rank convention.
se_ref = reference.bse[-len(b) :] * np.sqrt(
    (len(a) - full.shape[1]) / (len(a) - info["FE_rank"] - len(b))
)
assert np.allclose(np.sqrt(np.diag(v)), se_ref, rtol=1e-5, atol=1e-7)
result = {
    "passed": True,
    "N": len(a),
    "independent_explicit_dummy_FE_rank": rank,
    "absorbed_FE_rank_convention": info["FE_rank"],
    "coefficient_max_abs_difference": float(
        np.max(abs(b - reference.params[-len(b) :]))
    ),
    "SE_max_abs_difference_after_same_DF_convention": float(
        np.max(abs(np.sqrt(np.diag(v)) - se_ref))
    ),
    "plots_emitted": 0,
}
(O / "independent-model-validation.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
