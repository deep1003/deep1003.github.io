"""Validate occupation-score covariance against a disaggregated weighted GLM. No plots."""

from pathlib import Path
import sys, importlib.util, json, warnings
import numpy as np
import pandas as pd
from scipy.special import expit
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[2]
L = ROOT / "work/us_thaie_22_25_focus_20261124"
T = ROOT / "outputs/US_Youth_Significance_Bridge_20261125/tables"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


model = load("old_model_check", L / "model.py")
sys.modules["model"] = model
old = load("old_run_check", L / "run.py")
del sys.modules["model"]
a = old.select(old.prep(old.state, "state", "common49"), "basic")
states = a.groupby("GESTFIPS").FT_high.sum().nlargest(21).index
a = a[a.GESTFIPS.isin(states)].reset_index(drop=True)
x, names = old.design(a, "basic")
a["high"] = a.FT_high
a["other"] = a.FT_other
b, vc, info, _, _ = model.fit(a, x, names)
fine = pd.read_parquet(T / "state_occupation_industry_monthly_counts.parquet")
fine = fine[fine.state.isin(states) & fine.month.le(9) & fine.FT.gt(0)]
index = a[["GESTFIPS", "year"]].rename(columns={"GESTFIPS": "state"})
index["rowid"] = np.arange(len(a))
fine = fine.merge(index, on=["state", "year"], validate="many_to_one", how="inner")
xx = x[fine.rowid.to_numpy()].toarray()
weight = fine.FT.to_numpy() / 1e5
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    ref = sm.GLM(fine.high, xx, family=sm.families.Binomial(), freq_weights=weight).fit(
        maxiter=100,
        tol=1e-11,
        cov_type="cluster",
        cov_kwds={"groups": fine.occupation.to_numpy(), "use_correction": True},
    )
p = expit(x @ b)
total = (a.high + a.other).to_numpy() / 1e5
H = (x.T @ x.multiply((total * p * (1 - p))[:, None])).toarray()
bread = np.linalg.inv(H)
j = names.index("DID")
rr = fine.rowid.to_numpy()
fine["u"] = (
    np.asarray(x @ bread[:, j]).ravel()[rr] * (fine.high.to_numpy() - p[rr]) * weight
)
s = fine.groupby("occupation").u.sum()
G = len(s)
N = len(a)
K = len(names)
se = np.sqrt(np.sum(s**2) * G / (G - 1) * (N - 1) / (N - K))
reference_se = np.asarray(ref.bse)[j] * np.sqrt(
    ((N - 1) / (N - K)) / ((len(fine) - 1) / (len(fine) - K))
)
assert np.allclose(b, ref.params, atol=1e-7)
assert np.isclose(se, reference_se, rtol=1e-6)
result = {
    "passed": True,
    "source": "real CPS ages22–25; 21states; legacy basic specification",
    "aggregate_rows": N,
    "disaggregated_rows": len(fine),
    "coefficient_max_difference": float(np.max(abs(b - ref.params))),
    "occupation_SE_difference_after_same_finite_correction": float(
        abs(se - reference_se)
    ),
    "plots_emitted": 0,
    "working_covariance_not_official_survey_variance": True,
}
(T / "independent_cluster_score_validation.json").write_text(
    json.dumps(result, indent=2)
)
print(json.dumps(result, indent=2))
