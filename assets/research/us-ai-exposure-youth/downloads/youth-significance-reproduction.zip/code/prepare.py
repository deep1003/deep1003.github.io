"""Retain state and occupation jointly for CPS-only score-cluster diagnostics."""

from pathlib import Path
import importlib.util, json
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = ROOT / "outputs/US_Youth_Significance_Bridge_20261125"
P = ROOT / "outputs/US_THAIE_Regional_Youth_20261122"
s = importlib.util.spec_from_file_location(
    "parser", P / "panel_fe3_20261122/scripts/prepare_panel.py"
)
parser = importlib.util.module_from_spec(s)
s.loader.exec_module(parser)
records = json.loads(
    (
        ROOT / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json"
    ).read_text()
)
idx = {(r["year"], r["month"]): r for r in records if r.get("available", True)}
parser.source = lambda y, m: (Path(idx[y, m]["path"]), Path(idx[y, m]["dictionary"]))
conv = pd.read_csv(
    P / "extension_2019/derived/occupation_conversion_2010_2018.csv"
).rename(columns={"old": "occ", "new": "occupation", "rate": "probability"})
scores = pd.read_csv(P / "high_exposure_quality/derived/occupation_quintiles.csv")[
    ["occ", "THAIE_q"]
].rename(columns={"occ": "occupation"})
frames = []
audits = []
for (year, month), rec in sorted(idx.items()):
    f = W / f"counts_{year}_{month:02}.parquet"
    if f.exists():
        frames.append(pd.read_parquet(f))
        continue
    d, audit = parser.read(year, month)
    d = d[d.PRTAGE.between(22, 25) & d.nE.eq(1)].copy()
    if year < 2020:
        d = d.merge(conv, on="occ", how="left", validate="many_to_many")
        d["occupation"] = d.occupation.fillna(-1).astype(int)
        d["probability"] = d.probability.fillna(1)
        d[["E", "FT", "PT"]] = d[["E", "FT", "PT"]].multiply(d.probability, axis=0)
    else:
        d["occupation"] = d.occ
    d = d.merge(scores, on="occupation", how="left", validate="many_to_one")
    d = d[d.THAIE_q.between(1, 5)]
    d["high"] = d.THAIE_q.eq(5).astype(int)
    a = (
        d.groupby(["GESTFIPS", "occupation", "PRMJIND1", "high"], as_index=False)[
            ["E", "FT", "PT"]
        ]
        .sum()
        .rename(columns={"GESTFIPS": "state", "PRMJIND1": "industry"})
    )
    a["year"] = year
    a["month"] = month
    a["date"] = f"{year}-{month:02}-01"
    a.to_parquet(f, index=False)
    frames.append(a)
    audits.append(audit)
    print("CPS bridge", year, month, flush=True)
a = pd.concat(frames, ignore_index=True)
a.to_parquet(O / "tables/state_occupation_industry_monthly_counts.parquet", index=False)
new = pd.read_parquet(
    ROOT
    / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/occupation_industry_monthly_counts.parquet"
)
new = new[new.age.eq("22–25") & new.band.ne("Unmapped")]
x = a.groupby(["date", "occupation", "industry"])[["FT", "PT"]].sum().sort_index()
y = new.groupby(["date", "occupation", "industry"])[["FT", "PT"]].sum().sort_index()
assert x.index.equals(y.index)
assert np.allclose(x, y)
(O / "tables/input_audit.json").write_text(
    json.dumps(
        {
            "CPS_only": True,
            "THAIE_only": True,
            "ages": "22–25",
            "months": a.date.nunique(),
            "national_overlap_matches": True,
            "frozen_score_1021_Q": int(
                scores.set_index("occupation").loc[1021, "THAIE_q"]
            ),
        },
        indent=2,
    )
)
print("Bridge source built and matched independently to previous national counts.")
