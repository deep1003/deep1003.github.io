"""Reproduce legacy estimates and change one count-model component at a time."""

from pathlib import Path
import importlib.util, sys, json
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.special import expit
from scipy.stats import t

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
T = ROOT / "outputs/US_Youth_Significance_Bridge_20261125/tables"
L = ROOT / "work/us_thaie_22_25_focus_20261124"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


lm = load("legacy_model", L / "model.py")
sys.modules["model"] = lm
old = load("legacy_run", L / "run.py")
del sys.modules["model"]
fine = pd.read_parquet(T / "state_occupation_industry_monthly_counts.parquet")
ctx = old.ctx.rename(columns={"GESTFIPS": "state"})
rows = []
proof = []


def inference(beta, se, G):
    p = float(2 * t.sf(abs(beta / se), G - 1))
    crit = t.ppf(0.975, G - 1)
    return dict(
        log_change=float(beta),
        se_log=float(se),
        estimate_pct=float(100 * np.expm1(beta)),
        ci_low_pct=float(100 * np.expm1(beta - crit * se)),
        ci_high_pct=float(100 * np.expm1(beta + crit * se)),
        p_value=p,
        clusters=G,
    )


def evaluate(panel, x, names, data, keys, label, meta):
    a = panel.copy()
    a["high"] = a.FT_high
    a["other"] = a.FT_other
    b, v, info, _, _ = lm.fit(a, x, names)
    j = names.index("DID")
    p = expit(x @ b)
    total = (a.high + a.other).to_numpy() / 1e5
    h = (x.T @ x.multiply((total * p * (1 - p))[:, None])).toarray()
    bread = np.linalg.inv(h)
    effective = np.asarray(x @ bread[:, j]).ravel()
    index = a[keys].copy()
    index["rowid"] = np.arange(len(a))
    d = data.merge(index, on=keys, validate="many_to_one", how="inner")
    by = (
        d.groupby(["rowid", "high"])
        .FT.sum()
        .unstack("high", fill_value=0)
        .reindex(range(len(a)), fill_value=0)
    )
    assert np.allclose(by[1], a.high) and np.allclose(by[0], a.other)
    rr = d.rowid.to_numpy()
    d["score"] = effective[rr] * (d.high.to_numpy() - p[rr]) * d.FT.to_numpy() / 1e5
    n, k = len(a), len(b)
    cf = (n - 1) / (n - k)
    stats = {}
    nonnzero = d[d.FT.gt(0)].copy()
    for cluster, group in [("state", "state"), ("occupation", "occupation")]:
        ss = nonnzero.groupby(group).score.sum()
        G = len(ss)
        se = float(np.sqrt(np.sum(ss**2) * G / (G - 1) * cf))
        stats[cluster] = inference(b[j], se, G)
        rows.append(
            dict(
                id=label,
                framework="Legacy conditional count ratio",
                cluster=cluster,
                N=n,
                parameters=k,
                finite_scale=cf,
                **meta,
                **stats[cluster],
            )
        )
    ss = nonnzero.groupby(["state", "occupation"]).score.sum()
    Gso = len(ss)
    st = nonnzero.groupby("state").score.sum()
    oc = nonnzero.groupby("occupation").score.sum()
    vs = np.sum(st**2) * len(st) / (len(st) - 1)
    vo = np.sum(oc**2) * len(oc) / (len(oc) - 1)
    vso = np.sum(ss**2) * Gso / (Gso - 1)
    two = (vs + vo - vso) * cf
    if two > 0:
        rows.append(
            dict(
                id=label,
                framework="Legacy conditional count ratio",
                cluster="state_and_occupation",
                N=n,
                parameters=k,
                finite_scale=cf,
                **meta,
                **inference(b[j], np.sqrt(two), min(len(st), len(oc))),
            )
        )
    assert np.isclose(stats["state"]["se_log"], np.sqrt(v[j, j]), rtol=1e-8)
    proof.append(
        dict(
            id=label,
            old_solver_log_beta=float(b[j]),
            direct_state_score_SE=stats["state"]["se_log"],
            old_solver_SE=float(np.sqrt(v[j, j])),
            score_reconstruction_matches=True,
        )
    )
    print(
        label,
        round(stats["state"]["estimate_pct"], 4),
        "state p",
        round(stats["state"]["p_value"], 6),
        "occupation p",
        round(stats["occupation"]["p_value"], 6),
        flush=True,
    )
    pd.DataFrame(rows).to_csv(T / "legacy_one_factor_results.csv", index=False)
    return b[j], stats


for level, source in [("state", old.state), ("industry", old.industry)]:
    for scope in ["common49", "national51"]:
        a = old.select(old.prep(source, level, scope), "adjusted")
        a["state"] = a.state_fips.astype(int)
        a["industry"] = a.PRMJIND1 if level == "industry" else 0
        keys = ["state", "year"] + (["industry"] if level == "industry" else [])
        d = fine[fine.month.le(9) & fine.year.ge(2017)]
        if scope == "common49":
            d = d[~d.state.isin([2, 26])]
        if level == "industry":
            d = d[d.industry.between(1, 13)]
        x, names = old.design(a, "adjusted")
        beta, stats = evaluate(
            a,
            x,
            names,
            d,
            keys,
            f"annual_{level}_{scope}",
            dict(
                geography=scope,
                level=level,
                months="Jan–Sep",
                start=2017,
                post="2023-01",
                seasonality=False,
                covid="year",
                legacy_context=True,
            ),
        )
        if scope == "common49":
            expected = pd.read_csv(old.T / "did_results.csv")
            row = expected[
                (expected.level == level)
                & (expected.spec == "adjusted")
                & (expected.outcome == "FT")
            ].iloc[0]
            assert np.isclose(
                stats["state"]["estimate_pct"], row.estimate_pct, atol=1e-7
            )
            assert np.isclose(stats["state"]["p_value"], row.p_value, rtol=1e-6)


# The monthly bridge keeps the legacy state-ratio estimator and context controls.
def monthly(
    tag,
    monthset="jansep",
    start=2017,
    season=False,
    covid="year",
    post="2023-01",
    context=True,
):
    d = fine[fine.year.ge(start)].copy()
    if monthset == "jansep":
        d = d[d.month.le(9)]
    a = (
        d.groupby(["state", "year", "month", "date", "high"])
        .agg(FT=("FT", "sum"), PT=("PT", "sum"))
        .unstack("high", fill_value=0)
    )
    a.columns = [
        name + ("_high" if high == 1 else "_other") for name, high in a.columns
    ]
    a = a.reset_index().sort_values(["state", "date"])
    a["stratum"] = a.state.astype(str)
    a["state_fips"] = a.state.astype(str).str.zfill(2)
    a = a.merge(ctx, on="state", validate="many_to_one").reset_index(drop=True)
    x, names = old.design(a, "adjusted" if context else "basic")
    if covid == "quarter":
        keep = [j for j, name in enumerate(names) if not name.startswith("pandemic_")]
        x = x[:, keep]
        names = [names[j] for j in keep]
        for year in [2020, 2021]:
            for q in range(1, 5):
                values = (a.year.eq(year) & ((a.month - 1) // 3 + 1).eq(q)).to_numpy()
                x = sparse.hstack([x, sparse.csr_matrix(values[:, None])], format="csr")
                names.append(f"covid_{year}_{q}")
    if season:
        for month in sorted(a.month.unique())[1:]:
            x = sparse.hstack(
                [x, sparse.csr_matrix(a.month.eq(month).to_numpy()[:, None])],
                format="csr",
            )
            names.append("season_" + str(month))
    if post == "2022-12":
        x = x.tolil()
        x[:, names.index("DID")] = a.date.ge("2022-12-01").to_numpy()[:, None]
        x = x.tocsr()
    return evaluate(
        a,
        x,
        names,
        d,
        ["state", "year", "month", "date"],
        tag,
        dict(
            geography="national51",
            level="state",
            months=monthset,
            start=start,
            post=post,
            seasonality=season,
            covid=covid,
            legacy_context=context,
        ),
    )


monthly("monthly_same_months")
monthly("monthly_full_calendar", monthset="all")
monthly("monthly_add_seasonality", monthset="all", season=True)
monthly("monthly_pandemic_quarters", monthset="all", season=True, covid="quarter")
monthly(
    "monthly_Dec2022_cutoff",
    monthset="all",
    season=True,
    covid="quarter",
    post="2022-12",
)
monthly(
    "monthly_start2020",
    monthset="all",
    start=2020,
    season=True,
    covid="quarter",
    post="2022-12",
)
(T / "legacy_reproduction_validation.json").write_text(json.dumps(proof, indent=2))
print("Legacy reproduction and state/occupation cluster comparisons completed.")
