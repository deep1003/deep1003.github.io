"""Build auditable one-factor contrasts and separate coefficient and inference changes."""

from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import t
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[2]
O = ROOT / "outputs/US_Youth_Significance_Bridge_20261125"
T = O / "tables"
L = pd.read_csv(T / "legacy_one_factor_results.csv")
M = pd.read_csv(T / "modern_one_factor_results.csv").set_index("id")
legacy = L[(L.id == "annual_state_common49") & (L.cluster == "state")].iloc[0]
occ = L[(L.id == "annual_state_common49") & (L.cluster == "occupation")].iloc[0]
modern = M.loc["reference"]
prior = pd.read_csv(
    ROOT / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/did_results.csv"
)
primary = prior[prior.spec == "main"]
p_ft = modern.p_value
p_pt = primary[(primary.age == "22–25") & (primary.outcome == "PT")].p_value.iloc[0]
mult = []
for name, m, p, rule in [
    ("Current raw", 1, p_ft, "Unadjusted"),
    (
        "Current two-outcome family",
        2,
        multipletests([p_ft, p_pt], method="holm")[1][0],
        "Holm",
    ),
    (
        "Current six-age primary family",
        12,
        primary[
            (primary.age == "22–25") & (primary.outcome == "FT")
        ].p_holm_primary12.iloc[0],
        "Holm",
    ),
    (
        "Current full sensitivity family",
        60,
        prior[
            (prior.age == "22–25") & (prior.spec == "main") & (prior.outcome == "FT")
        ].p_holm_planned60.iloc[0],
        "Holm",
    ),
]:
    crit = t.ppf(1 - 0.05 / (2 * m), int(modern.occupation_clusters) - 1)
    mult.append(
        dict(
            model="Current reference",
            family=name,
            tests=m,
            adjusted_p=p,
            rule=rule,
            estimate_pct=modern.estimate_pct,
            ci_low_pct=100 * np.expm1(modern.log_change - crit * modern.se_log),
            ci_high_pct=100 * np.expm1(modern.log_change + crit * modern.se_log),
            interval="Bonferroni simultaneous 95%" if m > 1 else "Marginal95%",
        )
    )
oldrows = pd.read_csv(
    ROOT / "outputs/US_THAIE_22_25_FT_PT_DID_20261124/tables/did_results.csv"
)
oldft = oldrows[
    (oldrows.level == "state")
    & (oldrows.spec == "adjusted")
    & (oldrows.outcome == "FT")
].iloc[0]
for name, m, p, rule in [
    ("Legacy raw", 1, legacy.p_value, "Unadjusted"),
    ("Legacy actual two-outcome family", 2, oldft.p_holm_two_outcomes, "Holm"),
    ("Legacy actual 36-specification family", 36, oldft.p_holm_all36_focus, "Holm"),
    (
        "Legacy 12-test upper bound",
        12,
        min(1, legacy.p_value * 12),
        "Bonferroni bound; not a fabricated Holm family",
    ),
]:
    mult.append(
        dict(
            model="Legacy state-clustered",
            family=name,
            tests=m,
            adjusted_p=p,
            rule=rule,
            estimate_pct=legacy.estimate_pct,
        )
    )
pd.DataFrame(mult).to_csv(T / "multiplicity_audit.csv", index=False)
freq = L[L.id.isin(["annual_state_national51", "monthly_same_months"])].copy()
freq["SE_without_row_df_scaling"] = freq.se_log / np.sqrt(freq.finite_scale)
freq["p_without_row_df_scaling"] = 2 * t.sf(
    abs(freq.log_change / freq.SE_without_row_df_scaling), freq.clusters - 1
)
freq.to_csv(T / "frequency_invariance.csv", index=False)
for cl in ["state", "occupation", "state_and_occupation"]:
    a = freq[(freq.id == "annual_state_national51") & (freq.cluster == cl)].iloc[0]
    b = freq[(freq.id == "monthly_same_months") & (freq.cluster == cl)].iloc[0]
    assert np.isclose(a.log_change, b.log_change, atol=1e-8)
    assert np.isclose(
        a.SE_without_row_df_scaling, b.SE_without_row_df_scaling, rtol=1e-6
    )
transitions = [
    (
        "Add occupation-specific seasonality",
        "simple_FE",
        "add_season_FE",
        "Recurring seasonality FE",
    ),
    (
        "Replace common date FE with industry-date FE",
        "add_season_FE",
        "reference",
        "Industry-specific monthly shocks",
    ),
    (
        "Remove seasonality from reference",
        "reference",
        "remove_season",
        "Recurring seasonality FE",
    ),
    (
        "Remove Q5 pandemic-quarter controls",
        "reference",
        "remove_covid",
        "Differential pandemic controls",
    ),
    (
        "Exclude Alaska and Michigan",
        "reference",
        "scope49",
        "Geography with support rebuilt",
    ),
    ("Keep January–September months", "reference", "JanSep", "Calendar-month coverage"),
    (
        "Move post start from Dec2022 to Jan2023",
        "reference",
        "Jan2023",
        "Availability cutoff",
    ),
    ("End in2025 instead of2026", "reference", "end2025", "Post-period endpoint"),
    (
        "Freeze units to short-window support",
        "reference",
        "frozen_short_support",
        "Estimation support",
    ),
    (
        "Shorten pre-period, with units held fixed",
        "frozen_short_support",
        "short2020",
        "Remove2017–2019 observations",
    ),
    (
        "Add exposure-specific linear trend",
        "reference",
        "trend",
        "Differential linear trend",
    ),
    ("Require FT support only", "reference", "FT_only_support", "Paired FT/PT support"),
    (
        "Restrict to one-to-one historical links",
        "frozen_short_support",
        "stable_links_long",
        "Crosswalk-composition sample",
    ),
    (
        "Shorten period on one-to-one links",
        "stable_links_long",
        "stable_links_short",
        "Remove2017–2019 observations",
    ),
]
rows = []
for label, first, last, changed in transitions:
    a = M.loc[first]
    b = M.loc[last]
    rows.append(
        dict(
            change=label,
            from_model=first,
            to_model=last,
            changed=changed,
            before_pct=a.estimate_pct,
            after_pct=b.estimate_pct,
            delta_percentage_points=b.estimate_pct - a.estimate_pct,
            before_SE=a.se_log,
            after_SE=b.se_log,
            SE_ratio=b.se_log / a.se_log,
            before_p=a.p_value,
            after_p=b.p_value,
            same_rows=a.sample_hash == b.sample_hash,
        )
    )
pd.DataFrame(rows).to_csv(T / "one_factor_contrasts.csv", index=False)
facts = {
    "legacy_pct": legacy.estimate_pct,
    "legacy_state_SE": legacy.se_log,
    "legacy_state_p": legacy.p_value,
    "legacy_occupation_SE": occ.se_log,
    "legacy_occupation_p": occ.p_value,
    "legacy_SE_multiplier": occ.se_log / legacy.se_log,
    "current_pct": modern.estimate_pct,
    "current_p": modern.p_value,
    "current_Holm2": float(mult[1]["adjusted_p"]),
    "current_Holm12": float(mult[2]["adjusted_p"]),
    "frozen_support_long_pct": M.loc["frozen_short_support", "estimate_pct"],
    "short2020_pct": M.loc["short2020", "estimate_pct"],
    "short2020_p": M.loc["short2020", "p_value"],
    "period_change_fixed_support_pp": M.loc["short2020", "estimate_pct"]
    - M.loc["frozen_short_support", "estimate_pct"],
    "trend_pct": M.loc["trend", "estimate_pct"],
    "trend_p": M.loc["trend", "p_value"],
    "same_frequency_point_and_cluster_scores": True,
    "no_unique_additive_attribution": True,
    "CPS_and_own_THAIE_only": True,
}
(O / "key_facts.json").write_text(json.dumps(facts, indent=2))
print(json.dumps(facts, indent=2))
# Full quantile paths for the requested Q5-focused graphics.
fine = pd.read_parquet(T / "state_occupation_industry_monthly_counts.parquet")
scores = pd.read_csv(
    ROOT
    / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/frozen_THAIE_occupation_assignments.csv"
)[["occ", "THAIE_q"]].rename(columns={"occ": "occupation"})
fine = fine.merge(scores, on="occupation", validate="many_to_one")
d = (
    fine[fine.industry.between(1, 13)]
    .groupby(["date", "THAIE_q"])[["FT", "PT", "E"]]
    .sum()
    .reset_index()
)
out = []
for q, g in d.groupby("THAIE_q"):
    g = g.set_index("date").reindex(
        pd.date_range("2017-01-01", "2026-10-01", freq="MS").strftime("%Y-%m-%d")
    )
    g["date"] = g.index
    g["quintile"] = int(q)
    for outcome in ["FT", "PT", "E"]:
        g["index_" + outcome] = (
            100 * g[outcome] / g[g.index.str.startswith("2022-")][outcome].mean()
        )
    out.append(g.reset_index(drop=True))
pd.concat(out).to_csv(T / "Q1_Q5_monthly_youth_paths.csv", index=False)
print("Controlled contrast tables and all-five-quintile paths saved.")
