"""Nature-inspired CPS-only scientific figures with a warm-red Q5 and white line halos."""

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.ticker import MaxNLocator

ROOT = Path(__file__).resolve().parents[2]
O = ROOT / "outputs/US_Youth_Significance_Bridge_20261125"
T = O / "tables"
F = O / "figures"
RED = "#C64F5A"
PAL = ["#B8B8B8", "#DDDDDD", "#F3D4D7", "#E5A2AA", RED]
AGES = ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"]
OLD = ROOT / "outputs/US_CPS_Only_Monthly_DID_20261125/tables"
plt.rcParams.update(
    {
        "font.family": ["Arial", "DejaVu Sans"],
        "font.size": 8.5,
        "axes.titlesize": 10,
        "axes.labelsize": 8.5,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "axes.linewidth": 0.6,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white",
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "savefig.dpi": 360,
    }
)


def line(ax, x, y, q, label=None, **kwargs):
    high = q == 5
    lw = 3.15 if high else 1.8
    return ax.plot(
        x,
        y,
        color=PAL[q - 1],
        lw=lw,
        alpha=1 if high else 0.83,
        zorder=12 if high else q,
        label=label or f"Q{q}",
        solid_capstyle="round",
        path_effects=[pe.Stroke(linewidth=lw + 1.35, foreground="white"), pe.Normal()],
        **kwargs,
    )


def save(fig, name):
    for ext in ["png", "svg", "pdf"]:
        fig.savefig(F / (name + "." + ext), bbox_inches="tight")
    plt.close(fig)


def forest(rows, labels, title, name, foot=""):
    fig, ax = plt.subplots(figsize=(7.2, max(2.6, 0.42 * len(rows) + 1.1)))
    yy = np.arange(len(rows))
    for y, r in zip(yy, rows):
        bar = ax.errorbar(
            r["estimate_pct"],
            y,
            xerr=[
                [r["estimate_pct"] - r["ci_low_pct"]],
                [r["ci_high_pct"] - r["estimate_pct"]],
            ],
            fmt="o",
            color=RED,
            lw=1.8,
            capsize=3,
            ms=6,
            mec="white",
            mew=0.7,
            zorder=4,
        )
        for collection in bar[2]:
            collection.set_path_effects(
                [pe.Stroke(linewidth=3.0, foreground="white"), pe.Normal()]
            )
    ax.set(
        yticks=yy,
        yticklabels=labels,
        xlabel="Q5 relative to Q1–Q4 employment change (%)",
    )
    ax.axvline(0, color="#999999", lw=0.7, ls=(0, (2, 3)))
    ax.invert_yaxis()
    ax.grid(axis="x", color="#eeeeee", lw=0.5)
    ax.set_title(title, loc="left", fontweight="bold", pad=12)
    fig.tight_layout()
    if foot:
        fig.text(0.01, -0.025, foot, fontsize=7, color="#555555")
    save(fig, name)


L = pd.read_csv(T / "legacy_one_factor_results.csv")
M = pd.read_csv(T / "modern_one_factor_results.csv").set_index("id")
clusters = L[L.id.eq("annual_state_common49")].set_index("cluster")
forest(
    [
        clusters.loc[x].to_dict()
        for x in ["state", "occupation", "state_and_occupation"]
    ],
    [
        "State clusters · p=.00043",
        "Occupation-score clusters · p=.098",
        "State + occupation · p=.075",
    ],
    "Same −8.76% estimate, different uncertainty",
    "bridge_01_clustering",
    "Same legacy data, coefficient, controls and finite-row scaling. Working covariance sensitivities; not official CPS survey intervals.",
)
ids = ["reference", "frozen_short_support", "short2020", "trend"]
labels = [
    "2017 start · current sample",
    "2017 start · short-window units",
    "2020 start · same retained units",
    "2017 start · add Q5 linear trend",
]
forest(
    [M.loc[x].to_dict() for x in ids],
    labels,
    "The pre-period changes the magnitude",
    "bridge_02_period_support",
    "The first three rows form a sample-then-period sequence. The trend row is a separate comparison with the first row.",
)
mult = pd.read_csv(T / "multiplicity_audit.csv")
d = mult[mult.model.eq("Current reference")]
fig, ax = plt.subplots(figsize=(7.2, 3.1))
xx = np.arange(len(d))
ax.plot(
    xx,
    d.adjusted_p,
    color=RED,
    lw=3.15,
    marker="o",
    ms=6,
    mec="white",
    mew=0.8,
    path_effects=[pe.Stroke(linewidth=4.5, foreground="white"), pe.Normal()],
)
ax.axhline(0.05, color="#929292", lw=0.8, ls=(0, (3, 3)))
ax.text(3.04, 0.05, ".05", va="center", fontsize=8, color="#777777")
ax.set(
    yscale="log",
    xticks=xx,
    xticklabels=["Raw", "2 outcomes", "12 primary tests", "60 sensitivities"],
    ylabel="p-value under the stated testing family",
    ylim=(0.015, 1.6),
)
for j, p in enumerate(d.adjusted_p):
    ax.annotate(
        f"{p:.3f}",
        (j, p),
        xytext=(0, 8),
        textcoords="offset points",
        ha="center",
        fontsize=9,
        color=RED,
    )
ax.set_title(
    "Multiplicity changes the decision, not the −9.03% estimate",
    loc="left",
    fontweight="bold",
    pad=12,
)
fig.tight_layout()
save(fig, "bridge_03_multiplicity")
ids = ["simple_FE", "add_season_FE", "reference", "remove_season", "remove_covid"]
forest(
    [M.loc[x].to_dict() for x in ids],
    [
        "Occupation–industry + common date FE",
        "Add occupation-by-month seasonality",
        "Add industry-specific date FE · reference",
        "Reference without occupation seasonality",
        "Reference without Q5 pandemic quarters",
    ],
    "Fixed effects do not remove the roughly −9% contrast",
    "bridge_04_fixed_effects",
    "All rows use identical observations and occupation clustering. They are controlled specifications, not additive causal contributions.",
)
ids = [
    "reference",
    "scope49",
    "JanSep",
    "Jan2023",
    "end2025",
    "FT_only_support",
    "frozen_short_support",
    "short2020",
    "stable_links_long",
    "stable_links_short",
    "trend",
]
forest(
    [M.loc[x].to_dict() for x in ids],
    [
        "Current monthly reference",
        "Exclude Alaska and Michigan",
        "January–September only",
        "Post starts January2023",
        "End in2025",
        "Full-time-only support",
        "2017 · frozen short support",
        "2020 · same retained units",
        "One-to-one links ·2017",
        "One-to-one links ·2020",
        "Add Q5 linear trend",
    ],
    "One-factor diagnostics around the current specification",
    "bridge_05_full_audit",
    "All estimates concern THAIE Q5 versus Q1–Q4. Different diagnostics have different anchors; see the contrast table.",
)
paths = pd.read_csv(T / "Q1_Q5_monthly_youth_paths.csv")
fig, ax = plt.subplots(figsize=(7.2, 3.8))
for q in range(1, 6):
    g = paths[paths.quintile.eq(q)]
    line(ax, pd.to_datetime(g.date), g.index_FT, q)
ax.axhline(100, color="#a9a9a9", lw=0.6)
ax.axvline(pd.Timestamp("2022-11-30"), color="#8c8c8c", ls=(0, (2, 3)), lw=0.8)
ax.axvspan(
    pd.Timestamp("2017-01-01"), pd.Timestamp("2019-12-31"), color="#c9c9c9", alpha=0.12
)
ax.set(
    ylabel="Full-time employment index (2022 mean = 100)",
    xlabel="Month",
    title="Ages22–25 · the Q5 path in context",
)
ax.legend(ncol=5, frameon=False, loc="upper left")
ax.grid(axis="y", color="#eeeeee", lw=0.5)
fig.tight_layout()
save(fig, "bridge_06_Q5_paths")
# Restyle current age-specific results without changing any estimates.
current = pd.read_csv(OLD / "did_results.csv")
main = current[current.spec.eq("main")]
fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.8), sharey=True)
for ax, out, title in zip(axs, ["FT", "PT"], ["Full-time", "Part-time"]):
    z = main[main.outcome.eq(out)].set_index("age").loc[AGES]
    bar = ax.errorbar(
        z.estimate_pct,
        np.arange(6),
        xerr=np.vstack([z.estimate_pct - z.ci_low_pct, z.ci_high_pct - z.estimate_pct]),
        fmt="o",
        color=RED,
        lw=1.7,
        capsize=2.5,
        ms=5,
        mec="white",
        mew=0.7,
    )
    for collection in bar[2]:
        collection.set_path_effects(
            [pe.Stroke(linewidth=2.9, foreground="white"), pe.Normal()]
        )
    ax.axvline(0, color="#999999", ls=":", lw=0.7)
    ax.set(title=title, yticks=np.arange(6), yticklabels=AGES, xlabel="Q5 contrast (%)")
    ax.grid(axis="x", color="#eeeeee", lw=0.5)
axs[0].invert_yaxis()
fig.suptitle("Monthly CPS DID across six ages", fontweight="bold", fontsize=11)
fig.tight_layout()
save(fig, "nature_CPS_only_DID_primary")
ev = pd.read_csv(OLD / "event_studies.csv")
pre = pd.read_csv(OLD / "pretrend_tests.csv")
for out, title in [("FT", "Full-time"), ("PT", "Part-time")]:
    fig, axs = plt.subplots(2, 3, figsize=(7.2, 5.3), sharex=True, sharey=True)
    for ax, age in zip(axs.flat, AGES):
        z = ev[ev.age.eq(age) & ev.outcome.eq(out)].sort_values("event_quarter")
        dates = (
            pd.to_datetime(z.first_month)
            + (pd.to_datetime(z.last_month) - pd.to_datetime(z.first_month)) / 2
        )
        ax.errorbar(
            dates,
            z.estimate_pct,
            yerr=np.vstack(
                [z.estimate_pct - z.ci_low_pct, z.ci_high_pct - z.estimate_pct]
            ),
            fmt="o",
            color=RED,
            ms=3.5,
            mec="white",
            mew=0.45,
            lw=1.35,
            capsize=1.6,
        )
        ax.plot(
            [pd.Timestamp("2022-10-01")], [0], marker="o", mfc="white", mec=RED, ms=3.5
        )
        ax.axhline(0, color="#999999", lw=0.6)
        ax.axvspan(
            pd.Timestamp("2020-01-01"),
            pd.Timestamp("2021-12-31"),
            color="#dddddd",
            alpha=0.35,
        )
        ax.axvline(pd.Timestamp("2022-11-30"), color="#999999", ls=":", lw=0.6)
        p = pre[pre.age.eq(age) & pre.outcome.eq(out)].pretrend_p.iloc[0]
        ax.set_title(f"{age} · pre p={p:.3f}", fontsize=8.5)
        ax.grid(axis="y", color="#eeeeee", lw=0.4)
        ax.xaxis.set_major_locator(matplotlib.dates.YearLocator(3))
        ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%Y"))
    fig.supylabel("Q5 relative difference (%)", fontsize=8)
    fig.suptitle(
        title + " event study · monthly CPS in three-month bins",
        fontsize=10,
        fontweight="bold",
    )
    fig.tight_layout(rect=[0.02, 0.02, 1, 0.96])
    save(fig, "nature_CPS_only_" + out + "_event_study")
Q = pd.read_csv(
    ROOT
    / "outputs/US_Monthly_Canaries_20261125/tables/cps_monthly_exposure_indices.csv"
)
Q = Q[Q.measure.eq("THAIE")]
for out, title in [("FT", "Full-time"), ("PT", "Part-time")]:
    fig, axs = plt.subplots(2, 3, figsize=(7.2, 5.2), sharex=True, sharey=True)
    for ax, age in zip(axs.flat, AGES):
        for q in range(1, 6):
            z = Q[Q.age.eq(age) & Q.sex.eq("All") & Q.quintile.eq(q)]
            line(
                ax,
                pd.to_datetime(z.date),
                z["index_" + out].where(z["supported_" + out]),
                q,
            )
        ax.axhline(100, color="#aaaaaa", lw=0.5)
        ax.axvline(pd.Timestamp("2022-11-30"), color="#999999", ls=":", lw=0.6)
        ax.set_title(age, fontsize=9)
        ax.grid(axis="y", color="#eeeeee", lw=0.4)
        ax.xaxis.set_major_locator(matplotlib.dates.YearLocator(2))
        ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%Y"))
    axs.flat[0].legend(ncol=3, fontsize=6.8, frameon=False)
    fig.supylabel("Employment index (2022 mean=100)", fontsize=8)
    fig.suptitle(
        title + " employment · six age groups · our CPS and THAIE",
        fontsize=10,
        fontweight="bold",
    )
    fig.tight_layout(rect=[0.025, 0, 1, 0.96])
    save(fig, "nature_CPS_only_" + out + "_monthly_trends")
print(
    "Saved vector/PDF/PNG figures. No plot displayed. Q5 color",
    RED,
    "with white stroke halos.",
)
fig, axs = plt.subplots(1, 2, figsize=(7.2, 4), sharey=True)
for ax, outcome in zip(axs, ["FT", "PT"]):
    for spec, offset, marker, fill in [
        ("main", -0.12, "o", RED),
        ("trend", 0.12, "D", "white"),
    ]:
        z = (
            current[current.spec.eq(spec) & current.outcome.eq(outcome)]
            .set_index("age")
            .loc[AGES]
        )
        ax.errorbar(
            z.estimate_pct,
            np.arange(6) + offset,
            xerr=np.vstack(
                [z.estimate_pct - z.ci_low_pct, z.ci_high_pct - z.estimate_pct]
            ),
            fmt=marker,
            color=RED,
            mfc=fill,
            mec=RED,
            ms=4.5,
            lw=1.7,
            capsize=2,
            label="Reference" if spec == "main" else "Q5 linear trend",
        )
    ax.axvline(0, color="#999999", ls=":", lw=0.7)
    ax.set(
        title="Full-time" if outcome == "FT" else "Part-time",
        yticks=np.arange(6),
        yticklabels=AGES,
        xlabel="Q5 contrast (%)",
    )
    ax.grid(axis="x", color="#eeeeee", lw=0.5)
axs[0].invert_yaxis()
axs[0].legend(frameon=False, fontsize=7)
fig.suptitle(
    "Sensitivity to a Q5-specific linear trend", fontsize=11, fontweight="bold"
)
fig.tight_layout()
save(fig, "nature_CPS_only_trend_sensitivity")
