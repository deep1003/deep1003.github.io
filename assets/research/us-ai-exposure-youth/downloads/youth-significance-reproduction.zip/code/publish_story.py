"""Rebuild the research Results as an original CPS-only visual narrative."""

from pathlib import Path
import json, hashlib, shutil, zipfile
import numpy as np
import pandas as pd
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = ROOT / "outputs/US_Youth_Significance_Bridge_20261125"
T = O / "tables"
S = ROOT / "work/homepage-monthly/assets/research/us-ai-exposure-youth"
D = S / "downloads"
facts = json.loads((O / "key_facts.json").read_text())
L = pd.read_csv(T / "legacy_one_factor_results.csv")
M = pd.read_csv(T / "modern_one_factor_results.csv")
C = pd.read_csv(T / "one_factor_contrasts.csv")
payload = json.loads((S / "data/monthly.json").read_text())
original = {
    k: hashlib.sha256(json.dumps(payload[k], sort_keys=True).encode()).hexdigest()
    for k in [
        "cps_exposure",
        "cps_occupation",
        "cps_computer",
        "cps_contrast",
        "cps_computer_contrast",
    ]
}
# The all-mapped line pools weighted counts before rebasing; it is not a mean of quintile indices.
q = pd.read_csv(
    ROOT
    / "outputs/US_Monthly_Canaries_20261125/tables/cps_monthly_exposure_indices.csv"
)
q = q[q.measure.eq("THAIE")]
values = ["E", "FT", "PT", "nE", "nFT", "nPT"]
allmapped = q.groupby(["age", "sex", "date"], as_index=False)[values].sum(min_count=1)
series = []
for (age, sex), z in allmapped.groupby(["age", "sex"]):
    baselines = {
        out: z[z.date.str.startswith("2022-")][out].mean() for out in ["E", "FT", "PT"]
    }
    qualified = {
        out: z[z.date.str.startswith("2022-")]["n" + out].sum() >= 120
        for out in ["E", "FT", "PT"]
    }
    points = []
    for row in z.sort_values("date").itertuples():
        point = [row.date]
        for out in ["E", "FT", "PT"]:
            v = getattr(row, out)
            point.append(
                None
                if pd.isna(v) or not qualified[out] or baselines[out] <= 0
                else round(float(100 * v / baselines[out]), 3)
            )
        point.extend(
            None if pd.isna(getattr(row, "n" + out)) else float(getattr(row, "n" + out))
            for out in ["E", "FT", "PT"]
        )
        points.append(point)
    series.append(dict(age=age, sex=sex, points=points))
payload["cps_allmapped"] = series
payload["metadata"]["visual_style"] = {
    "Q5": "#C64F5A",
    "Q1_Q4": ["#B8B8B8", "#DDDDDD", "#F3D4D7", "#E5A2AA"],
    "line_halo": "white",
    "data_unchanged": True,
}
(S / "data/monthly.json").write_text(
    json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
)
assert all(
    hashlib.sha256(json.dumps(payload[k], sort_keys=True).encode()).hexdigest() == h
    for k, h in original.items()
)
(T / "visual_data_invariance.json").write_text(
    json.dumps(
        {
            "passed": True,
            "unchanged_series_hashes": original,
            "new_allmapped_line": "Weighted counts pooled before own2022 rebasing",
            "outside_data_used": False,
        },
        indent=2,
    )
)
# The page is edited in place; the original research question, IMRD sections and downloads remain.
soup = BeautifulSoup((S / "index.html").read_text(), "html.parser")
soup.body["class"] = list(set(soup.body.get("class", []) + ["q5-story"]))
for node in soup.select("script[src]"):
    if node["src"].startswith(("monthly.js", "story.js")):
        node.decompose()
script = soup.new_tag("script", src="story.js?v=sex-by-quintile-20261125")
script["defer"] = ""
soup.head.append(script)
for node in soup.select("link[href]"):
    if node["href"].startswith("story.css"):
        node.decompose()
link = soup.new_tag(
    "link", rel="stylesheet", href="story.css?v=sex-by-quintile-20261125"
)
soup.head.append(link)
soup.find("meta", attrs={"name": "description"})["content"] = (
    "Independent CPS and own THAIE. Follow employment paths across exposure, age, occupation and sex, then inspect a controlled audit of why statistical significance changes."
)
for sub in soup.select(".hero .subtitle"):
    sub.string = "Follow monthly employment paths across exposure, age, occupation, and sex. Then examine what changes when the statistical assumptions change."
results = soup.find(id="results")
# Remove the old descriptive explorer and duplicated raw-figure block, retaining the model tables.
for detail in list(results.find_all("details", recursive=False)):
    summary = detail.find("summary", recursive=False)
    if summary and any(
        s in summary.get_text()
        for s in [
            "Monthly employment indices by exposure",
            "Monthly Q5 versus Q1–Q4",
            "All six age groups",
        ]
    ):
        detail.decompose()
for node in list(
    results.select("#monthly-story,#significance-bridge,#publication-gallery")
):
    node.decompose()
ages = ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"]
ageopts = (
    "".join(f"<option>{age}</option>" for age in ages)
    + "<option>All ages (16+)</option>"
)
pills = "".join(
    f'<button type="button" data-age="{age}" aria-pressed="{str(i==0).lower()}">{age}</button>'
    for i, age in enumerate(ages)
)
occupations = (
    "".join(
        f'<option value="{code}">{name}</option>'
        for code, name in payload["metadata"]["occupations"].items()
    )
    + '<option value="computer_math">Computer and mathematical occupations</option>'
)


def actions(chart):
    return f'<div class="story-actions"><button type="button" data-csv="{chart}">Data</button><button type="button" data-svg="{chart}">Save SVG</button></div>'


source = '<p class="story-source">Our Basic Monthly CPS reconstruction · own frozen THAIE classification · each curve uses its own 2022 monthly mean · no seasonal adjustment · gaps remain unfilled.</p>'
story = f"""<div id="monthly-story"><div class="story-intro"><p class="eyebrow">Monthly evidence</p><h3>From employment paths to robust evidence</h3><p>The highlighted Q5 line is a starting point for comparison. The panels below describe employment counts; the audit that follows separates changes in the estimate from changes in statistical confidence.</p></div><p id="story-loading" role="status">Loading our CPS aggregates…</p><div id="story-controls" hidden><div class="story-toolbar"><label>Employment view<select id="outcome"><option value="FT">Full-time employment</option><option value="PT">Part-time employment</option><option value="E">Total employment</option></select></label><div class="age-button-control"><span>Select an age group</span><div class="age-tabs" role="group" aria-label="Age selection">{pills}<button type="button" data-age="All ages (16+)" aria-pressed="false">All ages (16+)</button></div></div><label>Exposure view<select id="comparison"><option value="quintiles">All five THAIE quintiles</option><option value="contrast">Q5 versus pooled Q1–Q4</option></select></label><button type="button" id="expand-stories">Open all chart panels</button></div><p id="story-status" class="story-status" role="status"></p>
<details class="story-card" data-story="overall" id="story-overall" open><summary><span class="story-kicker">Across exposure groups</span><h3>Start with the national picture</h3><span class="summary-note">All workers aged16 and older, grouped by their occupation's THAIE.</span></summary><div class="story-body"><p id="overview-reading" class="story-reading"></p>{actions('chart-overall')}<div id="chart-overall" class="story-chart"></div>{source}<details class="chart-method"><summary>How to read this view</summary><p>Q5 is the warm-red line. All quintile lines have equal width. Q1–Q4 use light gray for Q1, a still lighter gray for Q2, very pale red for Q3, and pale red for Q4. Each line has a thin white edge so overlaps remain visible. Indices compare growth within groups, not their employment levels. The all-worker series includes ages16–21 as well as the six focal age groups.</p></details></div></details>
<details class="story-card" data-story="age" id="story-age"><summary><span class="story-kicker">Across ages</span><h3>Hold age fixed before comparing exposure</h3><span class="summary-note">Select one of the six exact age groups. Quintile assignments remain unchanged.</span></summary><div class="story-body"><div class="age-tabs" role="group" aria-label="Age groups">{pills}</div><p id="age-reading" class="story-reading"></p>{actions('chart-age')}<div id="chart-age" class="story-chart"></div>{source}<p class="story-note">A different-looking line is not itself a significant age difference. The direct age tests and event studies are available below.</p></div></details>
<details class="story-card" data-story="occupation" id="story-occupation"><summary><span class="story-kicker">Within an occupation</span><h3>Check a named occupation without changing its exposure</h3><span class="summary-note">Software developers are THAIE Q4 in our mapping. This is an age comparison, not a fabricated five-quintile comparison.</span></summary><div class="story-body"><div class="age-tabs" role="group" aria-label="Occupation panel age selection">{pills}</div><div class="occupation-control"><label>Occupation<select id="occupation">{occupations}</select></label><span id="occupation-classification" class="exposure-badge"></span></div><p id="occupation-reading" class="story-reading"></p>{actions('chart-occupation')}<div id="chart-occupation" class="story-chart"></div><div id="computer-wrap" hidden><h4>Available exposure groups within the broader family</h4><p>Absent exposure groups are not zero employment. The family panel uses the selected age group.</p>{actions('chart-computer')}<div id="chart-computer" class="story-chart"></div></div>{source}<p class="story-note">Here, muted colors identify ages because exposure is held fixed. Monthly cells below30 observations, or with insufficient2022 baseline support, remain gaps. Age is not a direct measure of experience or seniority.</p></div></details>
<details class="story-card" data-story="sex" id="story-sex"><summary><span class="story-kicker">Across women and men</span><h3>Compare exposure within the same age group</h3><span class="summary-note">Compare women and men within each THAIE quintile and across all mapped occupations. All panels share a vertical scale.</span></summary><div class="story-body"><div class="age-tabs" role="group" aria-label="Age groups for women and men">{pills}</div><p id="sex-reading" class="story-reading"></p><div class="gender-panels quintile-sex-panels">{''.join('<div>'+actions('chart-sex-'+str(q))+'<div id="chart-sex-'+str(q)+'" class="story-chart"></div></div>' for q in range(1,7))}</div>{source}<p class="story-note">These panels cover all exposure-mapped occupations, not only the occupation selected above. Recorded CPS sex is not a measure of gender identity. This descriptive view does not identify AI-caused differences between women and men.</p></div></details></div></div>"""
# The audit cards hold the outcome and age fixed; chart controls never refit or relabel those estimates.
cluster = L[L.id.eq("annual_state_common49")].set_index("cluster")
rows = []
for key, label in [
    ("state", "State clusters"),
    ("occupation", "Occupation-score clusters"),
    ("state_and_occupation", "State and occupation"),
]:
    r = cluster.loc[key]
    rows.append(
        f"<tr><td>{label}</td><td>{r.estimate_pct:+.2f}%</td><td>{r.se_log:.5f}</td><td>{r.p_value:.5f}</td></tr>"
    )
period = M.set_index("id")
period_rows = []
for key, label in [
    ("reference", "Current2017-start reference"),
    ("frozen_short_support", "2017 start, short-window units"),
    ("short2020", "2020 start, same retained units"),
    ("trend", "2017 start, add Q5 trend"),
]:
    r = period.loc[key]
    period_rows.append(
        f"<tr><td>{label}</td><td>{r.estimate_pct:+.2f}%</td><td>[{r.ci_low_pct:+.2f}, {r.ci_high_pct:+.2f}]</td><td>{r.p_value:.3f}</td></tr>"
    )
audit = (
    """<details class="story-card" id="significance-bridge"><summary><span class="story-kicker">From pattern to inference</span><h3>Why did the significant youth finding become less certain?</h3><span class="summary-note">The roughly −9% long-window estimate persists. Clustering, the pre-period and the testing family change what can be claimed.</span></summary><div class="story-body"><p class="audit-scope">This audit holds ages22–25 and full-time employment fixed. The descriptive chart controls above do not alter these fitted models.</p><h4>Separate the coefficient from its uncertainty</h4><p>The earlier −8.76% estimate is reproduced exactly. Holding its data, coefficient and controls fixed, grouping score contributions by occupation rather than state increases the working standard error2.28-fold. The coefficient stays the same; its nominal p-value changes from.00043 to.098.</p><div class="table-scroll"><table><caption>Same legacy fitted model. Standard errors are on the log-ratio scale.</caption><thead><tr><th>Working score grouping</th><th>Estimate</th><th>SE</th><th>Raw p</th></tr></thead><tbody>"""
    + "".join(rows)
    + """</tbody></table></div><figure class="figure"><a href="figures/bridge_01_clustering.svg"><img loading="lazy" src="figures/bridge_01_clustering.png" alt="Same legacy Q5 estimate under state, occupation-score and two-way working covariance"></a><figcaption>Working covariance sensitivities of the same estimating equations, not official CPS survey-design intervals. The occupation-score calculation was independently checked against a disaggregated weighted GLM.</figcaption></figure><h4>Change the pre-period without changing the retained units</h4><p>Moving to monthly observations alone does not remove the negative coefficient. In the current framework, freezing the short-window units changes −9.03% to−8.70%. Removing2017–2019 on those units changes it to−2.38%, p=.572. Adding a separate Q5 linear trend to the long-window reference gives −0.44%, p=.924.</p><div class="table-scroll"><table><caption>The first three rows form a sample-then-period comparison. The trend is a separate comparison with the reference.</caption><thead><tr><th>Specification</th><th>Estimate</th><th>95% interval</th><th>Raw p</th></tr></thead><tbody>"""
    + "".join(period_rows)
    + """</tbody></table></div><figure class="figure"><a href="figures/bridge_02_period_support.svg"><img loading="lazy" src="figures/bridge_02_period_support.png" alt="Q5 effects when support, pre-period and linear-trend assumptions change"></a><figcaption>Removing the earlier period also removes historical bridged occupation codes. The one-to-one-link sensitivity is reported in the full audit; it does not uniquely separate coding error from occupational composition or economic history.</figcaption></figure><h4>Keep the same coefficient while changing the testing family</h4><p>The current −9.03% estimate has raw p=.02524. Holm correction gives p=.05048 for the two-outcome family and.27916 for the six-age12-test family. These corrections do not change the coefficient. Multiplicity alone cannot explain the earlier tiny state-clustered p-value; its12-test Bonferroni upper bound would still be about.00521.</p><figure class="figure"><a href="figures/bridge_03_multiplicity.svg"><img loading="lazy" src="figures/bridge_03_multiplicity.png" alt="The same current Q5 estimate under raw, two-outcome, twelve-test and sixty-test inference"></a><figcaption>The line tracks the decision rule for one Q5 coefficient. Testing families are stated explicitly; no selective family is presented as preregistered.</figcaption></figure><h4>Other changes are smaller</h4><p>On the same rows, occupation-specific seasonality and industry-date effects leave the estimate near−9%. Geography, calendar-month coverage, the December-versus-January cutoff and the end date have smaller impacts than the pre-period and trend. The legacy ratio and detailed-occupation Poisson models remain distinct frameworks; the audit does not assign unique additive causal shares to their entire difference.</p><details class="chart-method"><summary>Inspect every one-factor comparison</summary><figure class="figure"><a href="figures/bridge_04_fixed_effects.svg"><img loading="lazy" src="figures/bridge_04_fixed_effects.png" alt="Same-row fixed-effects comparisons for Q5 full-time employment"></a></figure><figure class="figure"><a href="figures/bridge_05_full_audit.svg"><img loading="lazy" src="figures/bridge_05_full_audit.png" alt="Full controlled specification audit including samples, periods and one-to-one code links"></a></figure><p><a href="downloads/youth-significance-one-factor.csv">One-factor contrast table</a> · <a href="downloads/youth-significance-legacy.csv">Legacy reproductions and cluster sensitivities</a> · <a href="downloads/youth-significance-modern.csv">Current-model diagnostics</a> · <a href="downloads/youth-significance-multiplicity.csv">Testing-family audit</a> · <a href="downloads/youth-significance-frequency.csv">Frequency and finite-sample correction check</a></p></details><p class="story-reading"><strong>What remains supportable.</strong> The CPS paths show relative early-career full-time weakness. A robust AI-caused decline is not established across covariance, pre-period, trend and multiplicity choices. Stocks do not identify hiring or individual movement into part-time or contract work.</p><p><a href="downloads/SIGNIFICANCE_BRIDGE_REPORT_EN.md">Full controlled-audit report</a> · <a href="downloads/youth-significance-reproduction.zip">Aggregate data, code and figures</a></p></div></details>"""
)
# Insert the narrative before the complete model tables.
results.h2.insert_after(BeautifulSoup(story + audit, "html.parser"))
for p in list(results.find_all("p", recursive=False)):
    if "Open a result below." in p.get_text():
        p.decompose()
# Restyle active existing CPS figures while preserving the numerical result tables.
for tag in soup.select("[src],[href]"):
    attr = "src" if tag.has_attr("src") else "href"
    value = tag[attr]
    for filename in [
        "CPS_only_DID_primary",
        "CPS_only_FT_event_study",
        "CPS_only_PT_event_study",
        "CPS_only_FT_monthly_trends",
        "CPS_only_PT_monthly_trends",
        "CPS_only_trend_sensitivity",
    ]:
        if value.startswith("figures/" + filename + "."):
            tag[attr] = value.replace(
                "figures/" + filename + ".", "figures/nature_" + filename + "."
            )
# The old two-color trend picture is replaced with the controlled-audit figure.
for tag in soup.select("[src],[href]"):
    attr = "src" if tag.has_attr("src") else "href"
    if tag[attr].startswith("figures/CPS_only_trend_sensitivity."):
        tag[attr] = tag[attr].replace(
            "CPS_only_trend_sensitivity", "bridge_05_full_audit"
        )
# Archive the separate BLS productivity figure rather than treating it as part of a CPS-only story.
for detail in results.find_all("details", recursive=False):
    summary = detail.find("summary", recursive=False)
for detail in list(results.find_all("details", recursive=False)):
    summary = detail.find("summary", recursive=False)
    if summary and "Productivity and the proposed" in summary.get_text():
        detail.clear()
        detail.append(
            BeautifulSoup(
                '<summary>Earlier productivity hypothesis, separate data source</summary><div class="result-body"><p>The earlier BLS productivity analysis is retained as a separate archived exercise. It is not an input to this CPS-only audit.</p><p><a href="downloads/evidence-audit-20261124.md">Earlier productivity and employment evidence audit</a></p></div>',
                "html.parser",
            )
        )
# Condense visible methods; retain the complete existing method text in a disclosure.
methods = soup.find(id="methods")
if methods.find(id="full-study-methods") is None:
    keep = list(methods.contents)
    heading = methods.h2.extract()
    methods.clear()
    methods.append(heading)
    methods.append(
        BeautifulSoup(
            '<p>We independently aggregate official CPS employment counts and link occupations to our frozen THAIE classification. Six exact age groups are retained. Descriptive indices use each group’s2022 monthly mean as100; they are not employment rates or causal effects.</p><p>The chart series cover January2020–October2026, with October2025 unavailable. The estimation audit extends the pre-period to2017. Only our CPS and THAIE inputs are used.</p><details id="full-study-methods"><summary>Full data construction, support and estimation methods</summary><div class="method-full"></div></details>',
            "html.parser",
        )
    )
    target = methods.find(class_="method-full")
    for node in keep:
        if getattr(node, "name", None) != "h2":
            target.append(node)
# Add audit downloads without duplicating older links.
materials = soup.find(id="materials")
existing = materials.find(id="bridge-materials")
if existing:
    existing.decompose()
materials.h2.insert_after(
    BeautifulSoup(
        '<div id="bridge-materials"><h3>Significance audit and visual narrative</h3><p><a href="downloads/SIGNIFICANCE_BRIDGE_REPORT_EN.md">English audit report</a> · <a href="downloads/youth-significance-one-factor.csv">Controlled contrast table</a> · <a href="downloads/youth-significance-reproduction.zip">Reproduction bundle</a> · <a href="downloads/youth-significance-validation.json">Clustering validation</a></p></div>',
        "html.parser",
    )
)
# Clean spacing in newly authored narrative without changing formal identifiers or data.
text = str(soup)
for first, last in [
    ("aged16", "aged 16"),
    ("ages16", "ages 16"),
    ("below30", "below 30"),
    ("insufficient2022", "insufficient 2022"),
    ("group’s2022", "group’s 2022"),
    ("as100", "as 100"),
    ("January2020", "January 2020"),
    ("October2026", "October 2026"),
    ("October2025", "October 2025"),
    ("to2017", "to 2017"),
    ("ages22", "ages 22"),
    ("error2.28", "error 2.28"),
    ("from.00043", "from .00043"),
    ("to.098", "to .098"),
    ("to−", "to −"),
    ("Removing2017", "Removing 2017"),
    ("and.27916", "and .27916"),
    ("six-age12-test", "six-age 12-test"),
    ("its12-test", "its 12-test"),
    ("about.00521", "about .00521"),
    ("near−9", "near −9"),
]:
    text = text.replace(first, last)
(S / "index.html").write_text(text)
for f in (O / "figures").glob("*"):
    shutil.copy2(f, S / "figures" / f.name)
shutil.copy2(W / "story.js", S / "story.js")
shutil.copy2(W / "story.css", S / "story.css")
files = {
    "one_factor_contrasts.csv": "youth-significance-one-factor.csv",
    "legacy_one_factor_results.csv": "youth-significance-legacy.csv",
    "modern_one_factor_results.csv": "youth-significance-modern.csv",
    "multiplicity_audit.csv": "youth-significance-multiplicity.csv",
    "frequency_invariance.csv": "youth-significance-frequency.csv",
    "Q1_Q5_monthly_youth_paths.csv": "youth-significance-Q1-Q5-paths.csv",
    "independent_cluster_score_validation.json": "youth-significance-validation.json",
}
for src, dest in files.items():
    shutil.copy2(T / src, D / dest)
shutil.copy2(
    O / "SIGNIFICANCE_BRIDGE_REPORT_EN.md", D / "SIGNIFICANCE_BRIDGE_REPORT_EN.md"
)
with zipfile.ZipFile(
    D / "youth-significance-reproduction.zip", "w", zipfile.ZIP_DEFLATED
) as z:
    z.write(O / "SIGNIFICANCE_BRIDGE_REPORT_EN.md", "REPORT_EN.md")
    for f in T.iterdir():
        if f.is_file():
            z.write(f, "tables/" + f.name)
    for f in W.glob("*.py"):
        z.write(f, "code/" + f.name)
    for f in [W / "story.js", W / "story.css"]:
        z.write(f, "web/" + f.name)
    for f in (O / "figures").glob("*.svg"):
        z.write(f, "figures/" + f.name)
    z.writestr(
        "README.txt",
        "Our CPS and frozen THAIE only. Detailed state-occupation-month inputs are aggregate weighted counts, not person records. Code preserves original project-relative dependencies on the earlier count-model and context files. The provided tables and report document each controlled contrast. This is an exploratory specification audit, not a causal decomposition or a preregistered result. Figures use original palettes and thin white line halos; no numerical series are modified by styling.",
    )
print(
    "Story-driven CPS research page rebuilt. Q5 warm red with white halo; all original numerical series unchanged."
)
