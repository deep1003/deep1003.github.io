"""Silent artifact and data-I/O checks; never displays figures."""
from pathlib import Path
import json
import zipfile
from urllib.parse import urlsplit, unquote
from bs4 import BeautifulSoup
R=Path(__file__).resolve().parents[2]
S=R/'work/homepage-monthly/assets/research/us-ai-exposure-youth'
O=R/'outputs/US_Youth_Significance_Bridge_20261125'
soup=BeautifulSoup((S/'index.html').read_text(),'html.parser')
missing=[]
for n in soup.select('[src],[href]'):
    v=n.get('src') or n.get('href')
    p=urlsplit(v)
    if p.scheme or p.netloc or not p.path or p.path.startswith('/'):continue
    if not (S/unquote(p.path)).exists():missing.append(p.path)
assert not missing, missing
assert len(soup.select('[data-story]'))==4
assert soup.select_one('#significance-bridge')
assert json.loads((O/'tables/visual_data_invariance.json').read_text())['passed']
payload=json.loads((S/'data/monthly.json').read_text())
assert not any('stanford' in k.lower() for k in payload)
js=(S/'story.js').read_text()
assert '#C64F5A' in js and 'lw + 1.9' in js and 'stroke: "white"' in js
with zipfile.ZipFile(S/'downloads/youth-significance-reproduction.zip') as z:assert z.testzip() is None
for f in (O/'figures').glob('*.svg'):
    assert f.with_suffix('.png').exists() and f.with_suffix('.pdf').exists()
result={'passed':True,'local_asset_links_valid':True,'four_story_cards':True,'original_CPS_arrays_unchanged':True,'Q5_warm_red_and_white_halo':True,'zip_integrity':True,'plots_displayed':False}
(O/'tables/publication_smoke.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
