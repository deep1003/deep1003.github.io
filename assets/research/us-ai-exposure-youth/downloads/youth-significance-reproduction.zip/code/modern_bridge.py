"""One-at-a-time diagnostics around the monthly occupation PPML specification."""

from pathlib import Path
import importlib.util, sys, json, hashlib
import numpy as np
import pandas as pd
from scipy.stats import t
from ppml_model import fit, contrast

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
T = ROOT / "outputs/US_Youth_Significance_Bridge_20261125/tables"
MOD = ROOT / "work/us_cps_only_monthly_did_20261125"
s = importlib.util.spec_from_file_location("current_model", MOD / "model.py")
mm = importlib.util.module_from_spec(s)
s.loader.exec_module(mm)
sys.modules["model"] = mm
s = importlib.util.spec_from_file_location("current_run", MOD / "run.py")
current = importlib.util.module_from_spec(s)
s.loader.exec_module(current)
del sys.modules["model"]
base, support = current.prepare("22–25", "main")
short, shortsupport = current.prepare("22–25", "short2020")
base["calendar_date"] = base.date
short["calendar_date"] = short.date


def positive_ft(a):
    a = a.copy()
    for _ in range(15):
        n = len(a)
        for fe in ["occ_industry", "occ_season", "industry_date"]:
            counts = a.groupby(fe).FT.sum()
            a = a[a[fe].isin(counts.index[counts.gt(0)])]
        if len(a) == n:
            return a.reset_index(drop=True)
    raise ValueError("Unstable FT support")


def from_fine_scope49():
    fine = pd.read_parquet(T / "state_occupation_industry_monthly_counts.parquet")
    fine = fine[~fine.state.isin([2, 26]) & fine.industry.between(1, 13)]
    counts = fine.groupby(["occupation", "industry", "date", "high"], as_index=False)[
        ["E", "FT", "PT"]
    ].sum()
    meta = counts[["occupation", "industry", "high"]].drop_duplicates()
    grid = meta.merge(pd.DataFrame({"date": sorted(counts.date.unique())}), how="cross")
    a = grid.merge(
        counts,
        on=["occupation", "industry", "date", "high"],
        how="left",
        validate="one_to_one",
    )
    a[["E", "FT", "PT"]] = a[["E", "FT", "PT"]].fillna(0)
    a["year"] = pd.to_datetime(a.date).dt.year
    a["month"] = pd.to_datetime(a.date).dt.month
    a["quarter"] = pd.to_datetime(a.date).dt.quarter
    a["t"] = (a.year - 2022) * 12 + a.month - 12
    a["occ_industry"] = a.occupation.astype(str) + "_" + a.industry.astype(str)
    a["occ_season"] = a.occupation.astype(str) + "_" + a.month.astype(str)
    a["industry_date"] = a.industry.astype(str) + "_" + a.date
    a["calendar_date"] = a.date
    for _ in range(15):
        n = len(a)
        for fe in ["occ_industry", "occ_season", "industry_date"]:
            sums = a.groupby(fe)[["FT", "PT"]].sum()
            a = a[a[fe].isin(sums.index[sums.gt(0).all(axis=1)])]
        if len(a) == n:
            break
    return a.reset_index(drop=True)


# Freeze the short-window occupation-industry and occupation-season support before changing time.
fixed = base[
    base.occ_industry.isin(short.occ_industry.unique())
    & base.occ_season.isin(short.occ_season.unique())
].copy()
fixed = positive_ft(fixed)
keys = ["occupation", "industry", "date"]
a = fixed[fixed.date.ge("2020-01-01")].set_index(keys)[["FT", "PT"]].sort_index()
b = short.set_index(keys)[["FT", "PT"]].sort_index()
assert a.index.equals(b.index) and np.allclose(a, b)
(T / "support_freeze_validation.json").write_text(
    json.dumps(
        {
            "2020_rows_identical_after_long_support_freeze": True,
            "long_full_N": len(base),
            "long_frozen_N": len(fixed),
            "short_N": len(short),
        },
        indent=2,
    )
)
standard = ["occ_industry", "occ_season", "industry_date"]
jobs = []


def add(
    name,
    label,
    data,
    fes=standard,
    covid=True,
    trend=False,
    cutoff="2022-12-01",
    factor="fixed effects",
):
    jobs.append((name, label, data.copy(), fes, covid, trend, cutoff, factor))


add("reference", "Current monthly reference", base, factor="reference")
add(
    "simple_FE",
    "Occupation–industry + date FE",
    base,
    ["occ_industry", "calendar_date"],
)
add(
    "add_season_FE",
    "Add occupation-specific seasonality",
    base,
    ["occ_industry", "occ_season", "calendar_date"],
)
add(
    "remove_season",
    "Reference without occupation-season FE",
    base,
    ["occ_industry", "industry_date"],
)
add(
    "remove_covid",
    "Reference without Q5 pandemic-quarter terms",
    base,
    covid=False,
    factor="pandemic controls",
)
add(
    "scope49",
    "Exclude Alaska and Michigan",
    from_fine_scope49(),
    factor="geographic sample",
)
add(
    "JanSep",
    "Use January–September only",
    positive_ft(base[base.month.le(9)]),
    factor="month coverage",
)
add(
    "Jan2023",
    "Move post start to January2023",
    base,
    cutoff="2023-01-01",
    factor="event cutoff",
)
add(
    "end2025",
    "End in December2025",
    positive_ft(base[base.year.le(2025)]),
    factor="post-period end",
)
add(
    "frozen_short_support",
    "Long window on short-window support",
    fixed,
    factor="support sample",
)
add(
    "short2020",
    "Start in January2020, same retained units",
    short,
    factor="pre-period start",
)
add(
    "trend",
    "Add Q5-specific linear trend",
    base,
    trend=True,
    factor="differential trend",
)
full, _ = current.prepare("22–25", "FT_only_support")
full["calendar_date"] = full.date
add(
    "FT_only_support",
    "Require full-time support only",
    full,
    factor="outcome-support sample",
)
# Test the pre-period contrast on one-to-one historical occupation links only.
conversion = pd.read_csv(
    ROOT
    / "outputs/US_THAIE_Regional_Youth_20261122/extension_2019/derived/occupation_conversion_2010_2018.csv"
)
old_degree = conversion.groupby("old").new.nunique()
new_degree = conversion.groupby("new").old.nunique()
stable = set(
    conversion.loc[
        conversion.old.map(old_degree).eq(1)
        & conversion.new.map(new_degree).eq(1)
        & np.isclose(conversion.rate, 1),
        "new",
    ]
)
stable_long = positive_ft(fixed[fixed.occupation.isin(stable)])
stable_short = positive_ft(short[short.occupation.isin(stable)])
add(
    "stable_links_long",
    "One-to-one occupation links, long window",
    stable_long,
    factor="crosswalk sample",
)
add(
    "stable_links_short",
    "Same one-to-one occupations, start2020",
    stable_short,
    factor="pre-period on one-to-one links",
)
rows = []
for name, label, d, fes, covid, trend, cutoff, factor in jobs:
    cache = W / ("modern_" + name + ".json")
    if cache.exists():
        rows.append(json.loads(cache.read_text()))
        continue
    x, names = current.design(d, "trend" if trend else "main")
    x[:, 0] = d.date.ge(cutoff).to_numpy() * d.high
    if not covid:
        x = x[:, :1]
        names = names[:1]
    print("Modern bridge", name, "N", len(d), flush=True)
    b, v, v2, info, _, _ = fit(d, "FT", x, names, backend="cg", fe_fields=fes)
    estimate = contrast(b, v, names, "DID", info["occupation_clusters"] - 1)
    two = contrast(
        b, v2, names, "DID", min(info["occupation_clusters"], info["date_clusters"]) - 1
    )
    row = dict(
        id=name,
        label=label,
        factor=factor,
        FE=" + ".join(fes),
        Q5_pandemic_quarters=covid,
        linear_trend=trend,
        post_start=cutoff,
        first=d.date.min(),
        last=d.date.max(),
        months=d.date.nunique(),
        sample_hash=hashlib.sha256(
            pd.util.hash_pandas_object(
                d[["occupation", "industry", "date"]], index=False
            ).values.tobytes()
        ).hexdigest(),
        FT_population_sum=float(d.FT.sum()),
        **info,
        **estimate,
        two_way_SE=two["se_log"],
        two_way_p=two["p_value"]
    )
    rows.append(row)
    cache.write_text(json.dumps(row, indent=2))
    pd.DataFrame(rows).to_csv(T / "modern_one_factor_results.csv", index=False)
    if name == "reference":
        original = pd.read_csv(
            ROOT / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/did_results.csv"
        )
        r = original[
            (original.age == "22–25")
            & (original.spec == "main")
            & (original.outcome == "FT")
        ].iloc[0]
        assert np.isclose(row["log_change"], r.log_change, atol=1e-7)
        assert np.isclose(row["se_log"], r.se_log, rtol=1e-5)
    print("Result", round(row["estimate_pct"], 4), round(row["p_value"], 6), flush=True)
pd.DataFrame(rows).to_csv(T / "modern_one_factor_results.csv", index=False)
print("Modern OAT decomposition completed.")
