"""Explain the significance bridge with controlled comparisons, not a selected-significance narrative."""

from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
O = ROOT / "outputs/US_Youth_Significance_Bridge_20261125"
T = O / "tables"
F = json.loads((O / "key_facts.json").read_text())
L = pd.read_csv(T / "legacy_one_factor_results.csv")
M = pd.read_csv(T / "modern_one_factor_results.csv")
C = pd.read_csv(T / "one_factor_contrasts.csv")
P = pd.read_csv(T / "multiplicity_audit.csv")


def table(d, cols):
    def val(v):
        return f"{v:.4f}" if isinstance(v, float) else str(v)

    return (
        "| "
        + " | ".join(cols)
        + " |\n| "
        + " | ".join(["---"] * len(cols))
        + " |\n"
        + "\n".join(
            "| " + " | ".join(val(v) for v in row) + " |"
            for row in d[cols].itertuples(index=False, name=None)
        )
    )


legacy = L[L.id.eq("annual_state_common49")]
current = M.set_index("id")
core = table(
    legacy,
    ["cluster", "estimate_pct", "se_log", "ci_low_pct", "ci_high_pct", "p_value"],
)
oat = table(M, ["label", "estimate_pct", "se_log", "p_value", "N"])
mult = table(P, ["model", "family", "tests", "adjusted_p", "rule"])
text = f"""# Why did the youth full-time employment finding become less significant?

## CPS-only controlled specification audit

### Main finding

The approximately −9% coefficient does not disappear simply because the data become monthly or because more seasonal and industry controls are added. Statistical confidence changes substantially with the working covariance assumption and testing family. The coefficient itself becomes much smaller when the pre-period begins in2020 or an exposure-specific linear trend is added.

All empirical inputs are our official CPS reconstruction, our frozen THAIE classification, and the existing official occupation-code bridge. Ages remain exactly22–25; the outcome remains full-time employment; Q5 membership remains unchanged.

## 1. Reproduce the earlier result

The published legacy state-level annual January–September specification for2017–2026 is reproduced exactly. It excludes Alaska and Michigan, uses49 state clusters, and includes baseline state industry composition and adult pandemic/recovery context interacted with year. The estimate is −8.7636%, with a95% interval of −13.1082% to −4.2017% and p=.000434. The earlier industry-cell variant is also reproduced.

Reaggregating the official CPS records while retaining state and detailed occupation jointly reproduces the legacy count totals and the newer national monthly totals. No change in the frozen THAIE exposure definition is needed to explain the difference.

## 2. Change clustering while holding the fitted model fixed

{core}

The same legacy coefficient has a working occupation-score standard error {F['legacy_SE_multiplier']:.2f} times the state-clustered standard error. Its p-value becomes .098. Two-way state-and-occupation score aggregation gives p=.075. The coefficient, sample, outcome, controls, and residual-row finite-sample scaling are held fixed; only the score grouping and associated cluster correction/degrees of freedom change.

The occupation grouping allows contributions from the same detailed occupation across states and years to move together. State-only grouping does not represent that particular dependence. This is a sensitivity of the same estimating equations, not proof that one grouping supplies the exact CPS survey variance. Both are working sandwich calculations. Complex household sampling, cross-occupation movement, code-bridge uncertainty, and remaining cross-cluster dependence are not fully modeled.

For a conditional count model, the contribution from a detailed-occupation employment cell is x(state,time) × [Q5(occupation) − fitted_Q5_share(state,time)] × weighted_FT_count. Contributions are summed by the requested cluster, and the same model Hessian is used. Recombining by state reproduces the original state covariance. An independent weighted binary GLM on real disaggregated CPS cells reproduces the occupation covariance after aligning the finite-sample convention.

## 3. Frequency alone is not new identifying information

The annual and monthly January–September legacy specifications have the same coefficient and the same cluster score sums when their predictors are held constant within state–year. Changing the number of grouped rows changes the software-style (N−1)/(N−K) correction, even though it has not added independent variation in the design. Removing that row-count correction makes the corresponding cluster standard errors invariant to annual versus monthly representation. The frequency audit reports both conventions rather than attributing this bookkeeping difference to new evidence.

Adding the actual October–December observations is different from relabeling frequency. The audit separately adds those observations, seasonal terms, flexible pandemic quarters, and the December2022 rather than January2023 cutoff. The complete legacy table reports every step.

## 4. Change one component around the current monthly model

{oat}

The monthly reference is the occupation–industry Poisson quasi-mean model with occupation–industry, occupation–month-of-year and industry–calendar-date fixed effects, Q5-specific pandemic-quarter terms, and occupation-clustered inference. Its estimate is −9.0258%, p=.02524. The new implementation reproduces its coefficient and standard error.

### Fixed effects and pandemic controls

On identical retained observations, adding occupation-specific seasonality changes the simpler fixed-effects estimate from −9.8948% to −9.9019%. Replacing common date effects with industry-specific date effects yields −9.0258%. Omitting occupation seasonality from the reference yields −9.0758%; omitting Q5 pandemic-quarter controls yields −8.6368%. Thus, these controls do not account for a disappearance of the negative point estimate.

### Geography, month coverage, cutoff, and endpoint

Excluding Alaska and Michigan gives −9.3450%. Keeping January–September only gives −9.4493%. Moving the post start from December2022 to January2023 gives −8.9814%. Ending in2025 gives −8.0153%. These changes are materially smaller than the change associated with the pre-period or linear trend. They concern distinct controlled comparisons and should not be added together as causal shares.

### Separate support changes from the pre-period

The full monthly reference is −9.0258%. Restricting the long window to the occupation–industry and occupation-season support retained in the short window gives −8.7028%. On those retained units, removing2017–2019 yields −2.3848%, p=.5724. Thus the support adjustment accounts for about +0.32 percentage points in this sequence, while the period change accounts for +6.32 percentage points. The2020-onward rows and employment counts are verified identical after freezing support.

A full-time-only-support check gives −8.1244%, retaining all covered full-time employment rather than requiring part-time support as well. This does not restore a multiplicity-robust or trend-robust finding.

### Historical occupation-code links

On the short-window support further restricted to one-to-one historical occupation links, the long-window estimate is −5.9745%, p=.1586, and the2020-start estimate is −2.7074%, p=.6028. The restriction changes the occupational sample as well as removing split links. It therefore cannot uniquely identify a code-bridge error. Removing2017–2019 simultaneously removes an earlier economic period and historical bridged observations; those explanations are not fully separated here.

### Differential linear trend

Adding a Q5-specific linear trend to the long-window reference produces −0.4376%, p=.924. This is strong sensitivity to the trend assumption. It does not prove the AI effect is zero, because a fitted trend can absorb a gradual response as well as pre-existing divergence. The previous joint pretrend p-value for young full-time employment was approximately .037 before correction across pretrend tests.

## 5. Multiple testing changes the decision, not the coefficient

{mult}

For the current reference, the raw p-value is .02524. It becomes .05048 in the two-outcome family, .27916 in the six-age12-test primary family, and1.000 in the60-test sensitivity family. The −9.0258% coefficient does not change. Bonferroni simultaneous intervals are reported separately and are not mislabeled as Holm-inverted intervals.

Multiplicity alone cannot explain away the earlier very small state-clustered p-value. Even its conservative12-test Bonferroni bound is about .00521. The change in the underlying inference, particularly score grouping, precedes the additional effect of the larger testing family.

## Interpretation

The earlier descriptive Q5 full-time weakness remains visible. The stronger claim of a robust AI-induced youth full-time decline is not sustained across the working covariance, pre-period, trend, and testing-family choices. The audit distinguishes a coefficient that stays near−9% but has wider uncertainty from specifications in which the estimated magnitude itself approaches zero.

The legacy state-ratio model and the detailed-occupation Poisson model are different mean models and aggregation units. The audit provides controlled comparisons within each framework; it does not pretend that their entire difference is a uniquely additive decomposition. Results depend on the chosen path and anchor. No variant is selected as a causal estimate because its p-value is smaller.

The data are repeated cross-sectional employment stocks. They do not identify hiring, layoffs, individual full-time-to-part-time movement, or permanent-to-contract transitions. THAIE measures potential exposure, not observed adoption. Working cluster intervals are not official CPS survey-design intervals.

## Visual and reproduction notes

Figures use a white publication background and editable SVG/PDF text. Q5 is a moderately saturated warm red, #C64F5A, and a thicker line with a thin white halo. Q1–Q4 use muted sage, slate, lavender and sand tones with white halos. Color identifies age rather than exposure in fixed-occupation age charts; software developers remain THAIE Q4 under our method. No numerical data are changed by styling.

The accompanying files contain all controlled contrasts, exact legacy reproductions, frequency-invariance checks, clustering validation, and figure data. Scientific figures are generated with a noninteractive backend and closed after saving. Data-and-I/O smoke checks emit no images.
"""
(O / "SIGNIFICANCE_BRIDGE_REPORT_EN.md").write_text(text)
(O / "RESULTS_KO.md").write_text(
    """# 청년 전일제 유의성 변화 점검\n\n기존 −8.7636%를 정확히 재현했다. 같은계수·같은표본에서 주군집 SE=.02427, p=.000434였지만 직업점수 기여분을 직업별로 묶으면 SE=.05539, p=.09833이다. 이 값은 공식CPS설계분산이 아니라 같은추정방정식의 작업 군집화 민감도다.\n\n2017년을 유지한 월별추정은 −9.0258%로 점추정치 자체가 사라지지 않았다. 계절성·산업월별고정효과 변화는 작았다. 동일유지단위를 맞춘 후 2017–2019년을 빼면 −8.7028%에서 −2.3848%로 줄었다. Q5 선형추세 추가시 −.4376%다.\n\n현재 p=.02524는 2개검정 Holm=.05048, 12개검정 Holm=.27916이 된다. 보정은 계수를 바꾸지 않는다. 기존의 작은p를 그대로12개 보정했을 때도 Bonferroni상한=.00521이므로, 다중검정만으로 기존유의성 약화를 설명할 수 없다.\n\n모형변경의 순수효과와 함께바뀐집계단위를 구분했다. 전체과정의 유일한기여율을 주장하지 않는다. 모든입력은 CPS와 우리의THAIE다.\n"""
)
print("Full controlled audit report saved.")
