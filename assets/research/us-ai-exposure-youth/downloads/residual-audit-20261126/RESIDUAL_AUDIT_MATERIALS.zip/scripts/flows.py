"""Flow conclusions under residual-reduction and reference-period diagnostics."""

from pathlib import Path
import sys, json
import numpy as np
import pandas as pd

R = Path(__file__).resolve().parents[2]
O = R / "outputs/US_Residual_Audit_20261126"
W = Path(__file__).resolve().parent
OLD = R / "outputs/US_Stock_Flow_20261126"
sys.path.insert(0, str(R / "work/us_stock_flow_20261126"))
from build import components, BEHAVIOR

GROUPS = {
    "Nonemployment entry": ["entry_from_U", "entry_from_N"],
    "Nonemployment exit": ["exit_to_U", "exit_to_N"],
    "Full-/part-time balance": ["PT_to_FT", "FT_to_PT"],
    "Recorded occupation balance": ["occupation_in", "occupation_out"],
    "Age-boundary balance": ["age_in", "age_out"],
    "Classification boundary": ["classification_net"],
    "Mapping coverage": ["mapping_net"],
}


def main():
    m = pd.read_parquet(W / "matched_with_dual_weights.parquet")
    s = pd.read_csv(OLD / "MONTHLY_STATE_STOCKS.csv", parse_dates=["date"])
    s = s[s.measure.eq("FT")]
    monthly = []
    reject = []
    check = []
    for date, g in m.groupby("date"):
        dt = pd.Timestamp(date)
        prior = pd.Timestamp(g.origin_date.iloc[0])
        for band in ["q5", "q14"]:
            vals, b0, b1 = components(g, "FT", band, "age_first")
            delta = float(
                s[s.band.eq(band) & s.date.eq(dt)].stock.sum()
                - s[s.band.eq(band) & s.date.eq(prior)].stock.sum()
            )
            for method, w in [
                ("ipw", g.w_ipw.to_numpy()),
                ("origin_calibrated", g.w_calibrated.to_numpy()),
                ("dual_endpoint", g.w_dual.to_numpy()),
                (
                    "symmetric_common_weight",
                    g.w_ipw.to_numpy()
                    * (0.5 + 0.5 * g.P_next.to_numpy() / g.P.to_numpy()),
                ),
            ]:
                x = pd.DataFrame({k: v * w for k, v in vals.items()})
                x["GESTFIPS"] = g.GESTFIPS.to_numpy()
                x = x.groupby("GESTFIPS").sum().reset_index()
                x["date"], x["origin_date"], x["band"], x["method"] = (
                    dt,
                    prior,
                    band,
                    method,
                )
                monthly.append(x)
                residual = delta - float(np.sum(w * (b1 - b0)))
                check.append(
                    dict(
                        date=dt,
                        band=band,
                        method=method,
                        combined_survey_residual=residual,
                        stock_delta=delta,
                        weighted_behavior=float(np.sum(w * (b1 - b0))),
                    )
                )
    monthly = pd.concat(monthly)
    monthly.to_parquet(O / "MONTHLY_FLOW_SENSITIVITIES.parquet", index=False)
    check = pd.DataFrame(check)
    check.to_csv(O / "RESIDUAL_REDUCTION_CHECK.csv", index=False)
    base = s[["date", "GESTFIPS", "band", "stock"]].rename(
        columns={"date": "origin_date"}
    )
    monthly = monthly.merge(
        base, on=["origin_date", "GESTFIPS", "band"], validate="many_to_one"
    )
    states = sorted(s.GESTFIPS.unique())
    rng = np.random.default_rng(7358)
    draws = rng.multinomial(len(states), np.ones(len(states)) / len(states), 999)
    cases = [
        ("primary", "2019-01-01", "2022-10-01", "2023-01-01", "2026-10-01"),
        ("single_code_era", "2020-01-01", "2022-10-01", "2023-01-01", "2026-10-01"),
        ("matched_22months", "2021-01-01", "2022-10-01", "2023-01-01", "2024-10-01"),
    ]
    rows = []
    for case, p0, p1, z0, z1 in cases:
        for method in monthly.method.unique():
            for component, keys in GROUPS.items():
                vals = {}
                for band in ["q5", "q14"]:
                    for label, lo, hi in [("pre", p0, p1), ("post", z0, z1)]:
                        x = monthly[
                            monthly.method.eq(method)
                            & monthly.band.eq(band)
                            & monthly.date.between(lo, hi)
                        ].copy()
                        x["flow"] = x[keys].sum(axis=1)
                        x["month"] = x.date.dt.month
                        points = []
                        boots = []
                        for month, g in x.groupby("month"):
                            a = (
                                g.groupby("GESTFIPS")[["flow", "stock"]]
                                .sum()
                                .reindex(states, fill_value=0)
                                .to_numpy()
                            )
                            points.append(100 * a[:, 0].sum() / a[:, 1].sum())
                            b = draws @ a
                            boots.append(100 * b[:, 0] / b[:, 1])
                        vals[band, label] = (np.mean(points), np.mean(boots, axis=0))
                v = (vals["q5", "post"][0] - vals["q5", "pre"][0]) - (
                    vals["q14", "post"][0] - vals["q14", "pre"][0]
                )
                bt = (vals["q5", "post"][1] - vals["q5", "pre"][1]) - (
                    vals["q14", "post"][1] - vals["q14", "pre"][1]
                )
                rows.append(
                    dict(
                        period=case,
                        method=method,
                        component=component,
                        relative_change_pp=v,
                        ci_low=np.quantile(bt, 0.025),
                        ci_high=np.quantile(bt, 0.975),
                    )
                )
    out = pd.DataFrame(rows)
    out.to_csv(O / "FLOW_PATHWAY_SENSITIVITIES.csv", index=False)
    print(
        out[
            out.period.eq("primary")
            & ~out.component.isin(["Classification boundary", "Mapping coverage"])
        ].to_string(index=False)
    )
    print(
        check.groupby("method")
        .combined_survey_residual.agg(
            ["mean", lambda x: np.mean(np.abs(x)), lambda x: np.max(np.abs(x))]
        )
        .to_string()
    )


if __name__ == "__main__":
    main()
