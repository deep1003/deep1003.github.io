"""Residual attribution, non-tautological stock sensitivities and flow diagnostics."""

from pathlib import Path
import sys, json
import numpy as np
import pandas as pd

R = Path(__file__).resolve().parents[2]
O = R / "outputs/US_Residual_Audit_20261126"
W = Path(__file__).resolve().parent
OLD = R / "outputs/US_Stock_Flow_20261126"
sys.path.insert(0, str(R / "work/us_stock_flow_20261126"))
from build import components, BEHAVIOR
from decompose import PERIODS, lm

SCORE = (
    R
    / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/frozen_THAIE_occupation_assignments.csv"
)
BRIDGE = (
    R
    / "outputs/US_THAIE_Regional_Youth_20261122/extension_2019/derived/occupation_conversion_2010_2018.csv"
)
RAW = R / "work/us_entry_did_20261126"
states = None


def main():
    s = pd.read_csv(OLD / "MONTHLY_STATE_STOCKS.csv", parse_dates=["date"])
    s = s[s.measure.eq("FT")]
    dates = pd.DatetimeIndex(sorted(s.date.unique()))
    states = sorted(s.GESTFIPS.unique())
    rng = np.random.default_rng(20261127)
    draws = rng.multinomial(len(states), np.ones(len(states)) / len(states), 999)
    res = pd.read_parquet(O / "MONTHLY_RESIDUAL_COMPONENTS.parquet")
    res["date"] = pd.to_datetime(res.date)
    original = pd.read_parquet(OLD / "MONTHLY_STATE_COMPONENTS.parquet")
    original["date"] = pd.to_datetime(original.date)
    original = original[original.measure.eq("FT") & original.ordering.eq("age_first")]
    keys = [
        "rotation_replacement",
        "unlinked_eligible",
        "matched_weight_change",
        "response_rotation_expansion_correction",
    ]
    totals = []
    monthly = []
    for period, (p0, p1, z0, z1) in PERIODS.items():
        pre = (dates >= p0) & (dates <= p1)
        post = (dates >= z0) & (dates <= z1)
        if period == "DID_calendar":
            post &= dates != pd.Timestamp("2025-11-01")
        w = np.where(post, 1 / post.sum(), 0) - np.where(pre, 1 / pre.sum(), 0)
        edge = pd.Series(np.cumsum(w[::-1])[::-1], index=dates)
        stocks = {}
        for band in ["q5", "q14"]:
            a = s[s.band.eq(band)]
            stocks[band] = [
                a[a.date.isin(dates[mask])]
                .groupby("GESTFIPS")
                .stock.mean()
                .reindex(states)
                .to_numpy()
                for mask in [pre, post]
            ]
        for method, g in res.groupby("method"):
            mat = {}
            for band in ["q5", "q14"]:
                a = g[g.band.eq(band)].copy()
                a[keys] = a[keys].mul(a.date.map(edge), axis=0)
                mat[band] = a.groupby("GESTFIPS")[keys].sum().reindex(states).to_numpy()
            bs = {b: [draws @ v for v in stocks[b]] for b in stocks}
            val = mat["q5"].sum(axis=0) / lm(
                stocks["q5"][1].sum(), stocks["q5"][0].sum()
            ) - mat["q14"].sum(axis=0) / lm(
                stocks["q14"][1].sum(), stocks["q14"][0].sum()
            )
            boot = (draws @ mat["q5"]) / lm(bs["q5"][1], bs["q5"][0])[:, None] - (
                draws @ mat["q14"]
            ) / lm(bs["q14"][1], bs["q14"][0])[:, None]
            for j, k in enumerate(keys):
                totals.append(
                    dict(
                        period=period,
                        method=method,
                        component=k,
                        relative_log_points=100 * val[j],
                        ci_low=100 * np.quantile(boot[:, j], 0.025),
                        ci_high=100 * np.quantile(boot[:, j], 0.975),
                    )
                )
            old = original[original.method.eq(method)].copy()
            old["value"] = old.classification_net * old.date.map(edge)
            v = old.groupby("band").value.sum()
            term = 100 * (
                v["q5"] / lm(stocks["q5"][1].sum(), stocks["q5"][0].sum())
                - v["q14"] / lm(stocks["q14"][1].sum(), stocks["q14"][0].sum())
            )
            totals.append(
                dict(
                    period=period,
                    method=method,
                    component="classification_boundary_already_separate",
                    relative_log_points=term,
                )
            )
    pd.DataFrame(totals).to_csv(O / "RESIDUAL_ATTRIBUTION.csv", index=False)
    # Connected occupation-code components containing only one exposure band.
    conv = pd.read_csv(BRIDGE)
    score = pd.read_csv(SCORE)
    groups = dict(
        zip(
            score.occ,
            np.where(
                score.THAIE_q.eq(5), 5, np.where(score.THAIE_q.between(1, 4), 1, 0)
            ),
        )
    )
    parent = {}

    def root(x):
        parent.setdefault(x, x)
        if parent[x] != x:
            parent[x] = root(parent[x])
        return parent[x]

    for r in conv.itertuples():
        if r.rate > 0:
            parent[root(("o", r.old))] = root(("n", r.new))
    nodes = {}
    for node in list(parent):
        nodes.setdefault(root(node), []).append(node)
    goodold = set()
    goodnew = set()
    info = []
    for nodeset in nodes.values():
        bands = {groups.get(n, 0) for t, n in nodeset if t == "n"}
        good = len(bands) == 1 and 0 not in bands
        for t, n in nodeset:
            if good:
                (goodold if t == "o" else goodnew).add(n)
            info.append(dict(system=t, occupation=n, component_unambiguous=good))
    pd.DataFrame(info).to_csv(O / "UNAMBIGUOUS_OCCUPATION_SUPPORT.csv", index=False)
    pure = []
    for path in sorted(RAW.glob("raw_selected_*.parquet")):
        yr, mo = map(int, path.stem.split("_")[-2:])
        date = pd.Timestamp(yr, mo, 1)
        d = pd.read_parquet(
            path,
            columns=["GESTFIPS", "PRTAGE", "PEMLR", "PRFTLF", "P", "occ", "q5", "q14"],
        )
        d = d[d.PRTAGE.between(22, 25) & d.occ.isin(goodold if yr < 2020 else goodnew)]
        ft = d.PEMLR.isin([1, 2]) & d.PRFTLF.eq(1)
        for b in ["q5", "q14"]:
            a = (
                d.assign(stock=d.P * ft * d[b])
                .groupby("GESTFIPS")
                .stock.sum()
                .reindex(states, fill_value=0)
                .reset_index()
            )
            a["date"], a["band"] = date, b
            pure.append(a)
    pure = pd.concat(pure)
    pure.to_csv(O / "UNAMBIGUOUS_STATE_STOCKS.csv", index=False)
    cells = pd.read_parquet(O / "ROTATION_STOCK_CELLS.parquet")
    cells["date"] = pd.to_datetime(cells.date)
    variants = []
    cases = [
        ("original", "2019-01-01", "2022-10-01", "2023-01-01", "2026-10-01"),
        ("equal_rotation_mix", "2019-01-01", "2022-10-01", "2023-01-01", "2026-10-01"),
        (
            "unambiguous_code_components",
            "2019-01-01",
            "2022-10-01",
            "2023-01-01",
            "2026-10-01",
        ),
        (
            "single_code_era_2020_start",
            "2020-01-01",
            "2022-10-01",
            "2023-01-01",
            "2026-10-01",
        ),
        (
            "single_code_era_matched_22months",
            "2021-01-01",
            "2022-10-01",
            "2023-01-01",
            "2024-10-01",
        ),
    ]
    for case, p0, p1, z0, z1 in cases:
        pre = (dates >= p0) & (dates <= p1)
        post = (dates >= z0) & (dates <= z1) & (dates != pd.Timestamp("2025-11-01"))
        values = {}
        for b in ["q5", "q14"]:
            if case == "equal_rotation_mix":
                a = (
                    cells.pivot(
                        index=["date", "GESTFIPS"],
                        columns="HRMIS",
                        values=["pop", b + "_stock"],
                    )
                    .reindex(
                        pd.MultiIndex.from_product(
                            [dates, states], names=["date", "GESTFIPS"]
                        )
                    )
                    .fillna(0)
                )
                pop = a["pop"].to_numpy().reshape(len(dates), len(states), 8)
                stock = a[b + "_stock"].to_numpy().reshape(len(dates), len(states), 8)
                den = np.einsum("bs,tsm->btm", draws, pop)
                num = np.einsum("bs,tsm->btm", draws, stock)
                assert (den > 0).all()
                v = (num / den).mean(axis=2) * den.sum(axis=2)
                point = (stock.sum(axis=1) / pop.sum(axis=1)).mean(axis=1) * pop.sum(
                    axis=(1, 2)
                )
                values[b] = (point, v)
            else:
                source = pure if case == "unambiguous_code_components" else s
                a = (
                    source[source.band.eq(b)]
                    .pivot(index="date", columns="GESTFIPS", values="stock")
                    .reindex(index=dates, columns=states)
                    .fillna(0)
                    .to_numpy()
                )
                values[b] = (a.sum(axis=1), draws @ a.T)
        pt = np.log(
            values["q5"][0][post].mean() / values["q5"][0][pre].mean()
        ) - np.log(values["q14"][0][post].mean() / values["q14"][0][pre].mean())
        bt = np.log(
            values["q5"][1][:, post].mean(axis=1) / values["q5"][1][:, pre].mean(axis=1)
        ) - np.log(
            values["q14"][1][:, post].mean(axis=1)
            / values["q14"][1][:, pre].mean(axis=1)
        )
        variants.append(
            dict(
                variant=case,
                pre_months=int(pre.sum()),
                post_months=int(post.sum()),
                relative_percent=100 * np.expm1(pt),
                ci_low=100 * np.expm1(np.quantile(bt, 0.025)),
                ci_high=100 * np.expm1(np.quantile(bt, 0.975)),
                q5_pre=values["q5"][0][pre].mean(),
                q5_post=values["q5"][0][post].mean(),
            )
        )
    pd.DataFrame(variants).to_csv(O / "STOCK_SENSITIVITIES.csv", index=False)
    print(pd.DataFrame(variants).to_string(index=False))
    print(
        pd.DataFrame(totals)
        .query("period=='DID_calendar' and method=='ipw'")
        .to_string(index=False)
    )


if __name__ == "__main__":
    main()
