"""Separate raw stock coverage accounting from response-weight corrections."""

from pathlib import Path
import sys, json, hashlib
import numpy as np
import pandas as pd
from scipy.linalg import qr

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Residual_Audit_20261126"
sys.path.insert(0, str(R / "work/us_stock_flow_20261126"))
from build import components, calibration_features, KEY, BEHAVIOR
from decompose import PERIODS, lm

RAW = R / "work/us_entry_did_20261126"
OLD = R / "outputs/US_Stock_Flow_20261126"


def entropy(x, target, base, total):
    b = np.asarray(base) / total
    target = np.asarray(target) / total
    _, r, pivot = qr(x * np.sqrt(b)[:, None], mode="economic", pivoting=True)
    rank = int((np.abs(np.diag(r)) > 1e-9).sum())
    keep = pivot[:rank]
    xx = x[:, keep]
    tt = target[keep]
    beta = np.zeros(rank)

    def loss(v):
        return (b * np.exp(np.clip(xx @ v, -25, 25))).sum() - tt @ v

    for it in range(80):
        mu = b * np.exp(np.clip(xx @ beta, -25, 25))
        g = xx.T @ mu - tt
        if np.max(np.abs(g)) < 2e-10:
            break
        step = np.linalg.solve(xx.T @ (mu[:, None] * xx), g)
        a = 1.0
        while a > 1e-8 and loss(beta - a * step) > loss(beta) + 1e-13:
            a /= 2
        beta -= a * step
    weight = total * b * np.exp(np.clip(xx @ beta, -25, 25))
    error = np.max(np.abs(x.T @ weight / total - target))
    if error > 1e-7:
        raise ValueError(("dual calibration", error))
    return weight, dict(
        iterations=it + 1,
        moment_error=error,
        multiplier_min=np.min(weight / base),
        multiplier_max=np.max(weight / base),
        rank=rank,
    )


def destfeatures(d, suffix=""):
    a = d["PRTAGE" + suffix].between(22, 25).to_numpy()
    e = d["PEMLR" + suffix].isin([1, 2]).to_numpy()
    ft = e & d["PRFTLF" + suffix].eq(1).to_numpy()
    return np.column_stack(
        [
            a * ft * d["q5" + suffix],
            a * ft * d["q14" + suffix],
            a * (e & ~ft) * d["q5" + suffix],
            a * (e & ~ft) * d["q14" + suffix],
        ]
    )


def main():
    m = pd.read_parquet(
        R / "work/us_stock_flow_20261126/matched_all_status_21_26.parquet"
    )
    data = {}
    hashes = []
    stockcells = []
    for path in sorted(RAW.glob("raw_selected_*.parquet")):
        meta = json.loads(path.with_suffix(".json").read_text())
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        assert sha == meta["cache_sha256"]
        yr, mo = map(int, path.stem.split("_")[-2:])
        date = pd.Timestamp(yr, mo, 1)
        d = pd.read_parquet(path)
        d = d[d.PRTAGE.between(21, 26)].copy()
        assert not d.duplicated(KEY).any()
        data[date] = d
        hashes.append(dict(date=str(date.date()), sha256=sha))
        a = d[d.PRTAGE.between(22, 25)].copy()
        ft = a.PEMLR.isin([1, 2]) & a.PRFTLF.eq(1)
        a["pop"] = a.P
        a["q5_stock"] = a.P * ft * a.q5
        a["q14_stock"] = a.P * ft * a.q14
        z = (
            a.groupby(["GESTFIPS", "HRMIS"])[["pop", "q5_stock", "q14_stock"]]
            .sum()
            .reset_index()
        )
        z["date"] = date
        stockcells.append(z)
    dates = sorted(data)
    res = []
    dualparts = []
    calaudit = []
    reject = []
    mass = []
    original = pd.read_parquet(OLD / "MONTHLY_STATE_COMPONENTS.parquet")
    original = original[original.measure.eq("FT") & original.ordering.eq("age_first")]
    for date_str, g in m.groupby("date"):
        date = pd.Timestamp(date_str)
        prior = pd.Timestamp(g.origin_date.iloc[0])
        d0 = data[prior]
        d1 = data[date]
        keys = pd.MultiIndex.from_frame(g[KEY])
        i0 = pd.MultiIndex.from_frame(d0[KEY])
        i1 = pd.MultiIndex.from_frame(d1[KEY])
        valid0 = i0.isin(keys)
        valid1 = i1.isin(keys)
        a0 = d0.PRTAGE.between(22, 25)
        a1 = d1.PRTAGE.between(22, 25)
        f0 = d0.PEMLR.isin([1, 2]) & d0.PRFTLF.eq(1)
        f1 = d1.PEMLR.isin([1, 2]) & d1.PRFTLF.eq(1)
        for band in ["q5", "q14"]:
            v0 = d0.P * a0 * f0 * d0[band]
            v1 = d1.P * a1 * f1 * d1[band]
            # Exclusive unmatched endpoints; valid matches use common origin weights.
            c, b0, b1 = components(g, "FT", band, "age_first")
            rawflow = g.P.to_numpy() * sum(c.values())
            weight = (g.P_next - g.P).to_numpy() * b1
            match = pd.DataFrame(
                {
                    "GESTFIPS": g.GESTFIPS,
                    "raw_matched_flow": rawflow,
                    "matched_weight_change": weight,
                }
            )
            rotation0 = d0.HRMIS.isin([4, 8])
            rotation1 = d1.HRMIS.isin([1, 5])
            x0 = pd.DataFrame(
                {
                    "GESTFIPS": d0.GESTFIPS,
                    "rotation_replacement": -v0 * (~valid0 & rotation0),
                    "unlinked_eligible": -v0 * (~valid0 & ~rotation0),
                    "stock_delta": -v0,
                }
            )
            x1 = pd.DataFrame(
                {
                    "GESTFIPS": d1.GESTFIPS,
                    "rotation_replacement": v1 * (~valid1 & rotation1),
                    "unlinked_eligible": v1 * (~valid1 & ~rotation1),
                    "stock_delta": v1,
                }
            )
            z = pd.concat([match, x0, x1]).groupby("GESTFIPS").sum().fillna(0)
            err = (
                z[
                    [
                        "raw_matched_flow",
                        "matched_weight_change",
                        "rotation_replacement",
                        "unlinked_eligible",
                    ]
                ].sum(axis=1)
                - z.stock_delta
            )
            assert err.abs().max() < 1e-6
            for method in ["design_only", "ipw", "trim99", "calibrated"]:
                weighted = (
                    pd.Series(
                        g["w_" + method].to_numpy() * sum(c.values()), index=g.GESTFIPS
                    )
                    .groupby(level=0)
                    .sum()
                )
                t = z.copy()
                t["method"] = method
                t["response_rotation_expansion_correction"] = (
                    t.raw_matched_flow - weighted
                )
                t["reconstructed_frame_residual"] = (
                    t.rotation_replacement
                    + t.unlinked_eligible
                    + t.response_rotation_expansion_correction
                )
                old = original[
                    original.date.eq(date_str)
                    & original.band.eq(band)
                    & original.method.eq(method)
                ].set_index("GESTFIPS")
                assert (
                    np.max(
                        np.abs(
                            t.reconstructed_frame_residual - old.frame_reconciliation
                        )
                    )
                    < 1e-5
                )
                t["date"], t["band"] = date, band
                res.append(t.reset_index())
            mass.append(
                dict(
                    date=date,
                    band=band,
                    origin_rotation_stock=float(v0[~valid0 & rotation0].sum()),
                    destination_rotation_stock=float(v1[~valid1 & rotation1].sum()),
                    origin_unlinked_stock=float(v0[~valid0 & ~rotation0].sum()),
                    destination_unlinked_stock=float(v1[~valid1 & ~rotation1].sum()),
                )
            )
        # Identify causes for link rejection among scheduled origin overlap, without reclassifying them as economic transitions.
        elig = d0[d0.HRMIS.isin([1, 2, 3, 5, 6, 7])]
        right = pd.read_parquet(
            RAW / f"raw_selected_{date.year}_{date.month:02}.parquet",
            columns=KEY + ["PEMLR", "HRMIS", "PESEX", "PTDTRACE", "GESTFIPS", "PRTAGE"],
        )
        j = elig.merge(
            right, on=KEY, how="left", suffixes=("", "_next"), validate="one_to_one"
        )
        reason = np.select(
            [
                j.PEMLR_next.isna(),
                j.HRMIS_next.ne(j.HRMIS + 1),
                j.PESEX.ne(j.PESEX_next),
                j.PTDTRACE.ne(j.PTDTRACE_next),
                j.GESTFIPS.ne(j.GESTFIPS_next),
                ~(j.PRTAGE_next - j.PRTAGE).between(0, 1),
            ],
            [
                "key_absent",
                "rotation_mismatch",
                "sex_mismatch",
                "race_mismatch",
                "state_mismatch",
                "age_mismatch",
            ],
            default="valid",
        )
        rr = (
            j.assign(reason=reason)
            .groupby("reason")
            .agg(records=("P", "size"), weighted_origin=("P", "sum"))
            .reset_index()
        )
        rr["date"] = date
        reject.append(rr)
        # Dual-endpoint calibration is a constrained diagnostic, not an independent validation.
        states = sorted(d0.GESTFIPS.unique())
        e = d0.PEMLR.isin([1, 2])
        ft = e & d0.PRFTLF.eq(1)
        st = np.select([ft, e, d0.PEMLR.isin([3, 4])], ["FT", "PT", "U"], default="N")
        cells = sorted(
            set(d0.PRTAGE.astype(str).to_numpy() + np.array([":" + x for x in st]))
        )
        x0 = calibration_features(d0, states, cells)
        x = calibration_features(g, states, cells)
        target = np.r_[x0.T @ d0.P.to_numpy(), destfeatures(d1).T @ d1.P.to_numpy()]
        xx = np.column_stack([x, destfeatures(g, "_next")])
        weight, info = entropy(xx, target, g.w_calibrated.to_numpy(), d0.P.sum())
        g = g.copy()
        g["w_dual"] = weight
        dualparts.append(g)
        info["date"] = date
        calaudit.append(info)
        if len(calaudit) % 12 == 0:
            print("Audited", date.date(), flush=True)
    pd.concat(res, ignore_index=True).to_parquet(
        O / "MONTHLY_RESIDUAL_COMPONENTS.parquet", index=False
    )
    pd.concat(stockcells, ignore_index=True).to_parquet(
        O / "ROTATION_STOCK_CELLS.parquet", index=False
    )
    pd.DataFrame(mass).to_csv(O / "UNLINKED_ENDPOINT_MASS.csv", index=False)
    pd.concat(reject, ignore_index=True).to_csv(
        O / "LINK_REJECTION_AUDIT.csv", index=False
    )
    pd.DataFrame(calaudit).to_csv(O / "DUAL_CALIBRATION_AUDIT.csv", index=False)
    pd.concat(dualparts, ignore_index=True).to_parquet(
        W / "matched_with_dual_weights.parquet", index=False
    )
    (O / "INPUT_HASHES.json").write_text(json.dumps(hashes, indent=2))
    print("Audit reconstruction and dual calibration passed", flush=True)


if __name__ == "__main__":
    main()
