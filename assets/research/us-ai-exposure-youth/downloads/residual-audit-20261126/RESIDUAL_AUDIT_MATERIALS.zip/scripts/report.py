"""Evidence-bounded residual diagnosis with saved, non-emitted figures."""

from pathlib import Path
import json, ast, hashlib
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = Path(__file__).resolve().parents[2]
O = R / "outputs/US_Residual_Audit_20261126"
W = Path(__file__).resolve().parent
s = pd.read_csv(O / "STOCK_SENSITIVITIES.csv")
r = pd.read_csv(O / "RESIDUAL_ATTRIBUTION.csv")
f = pd.read_csv(O / "FLOW_PATHWAY_SENSITIVITIES.csv")
q = pd.read_csv(O / "RESIDUAL_REDUCTION_CHECK.csv")
ca = pd.read_csv(O / "DUAL_CALIBRATION_AUDIT.csv")
reason = pd.read_csv(O / "LINK_REJECTION_AUDIT.csv").groupby("reason").records.sum()
channels = [
    "Nonemployment entry",
    "Nonemployment exit",
    "Full-/part-time balance",
    "Recorded occupation balance",
    "Age-boundary balance",
]
# Independent reconstruction of the previously published combined residual.
a = (
    r[r.period.eq("DID_calendar") & r.method.eq("ipw")]
    .set_index("component")
    .relative_log_points
)
b = (
    r[r.period.eq("DID_calendar") & r.method.eq("design_only")]
    .set_index("component")
    .relative_log_points
)
terms = [
    a.rotation_replacement,
    a.unlinked_eligible,
    b.response_rotation_expansion_correction,
    a.response_rotation_expansion_correction - b.response_rotation_expansion_correction,
    a.matched_weight_change,
]
old = pd.read_csv(
    R / "outputs/US_Stock_Flow_20261126/PERIOD_COMPONENT_DECOMPOSITION.csv"
)
oldv = old[
    old.period.eq("DID_calendar")
    & old.measure.eq("FT")
    & old.method.eq("ipw")
    & old.ordering.eq("age_first")
    & old.component.eq("Survey/coverage reconciliation")
].relative_log_points.iloc[0]
assert abs(sum(terms) - oldv) < 1e-8
names = [
    "Scheduled rotation replacement",
    "Eligible but unlinked endpoints",
    "Planned rotation expansion correction",
    "Additional inverse-response correction",
    "Observed matched-weight change",
]
attribution = pd.DataFrame({"component": names, "relative_log_points": terms})
attribution.to_csv(O / "PRIMARY_RESIDUAL_BREAKDOWN.csv", index=False)
labels = [
    "Original full CPS stock",
    "Equal rotation-group mix",
    "Unambiguous code components",
    "Single code era, 2020 start",
    "Single code era, matched 22 months",
]
fig, ax = plt.subplots(figsize=(9, 4.3))
v = s.relative_percent.to_numpy()
y = np.arange(len(v))
ax.errorbar(
    v,
    y,
    xerr=np.vstack([v - s.ci_low, s.ci_high - v]),
    fmt="s",
    markersize=6,
    color="#C64F5A",
    markeredgecolor="white",
    capsize=3,
    lw=1.6,
)
ax.set_yticks(y, labels)
ax.invert_yaxis()
ax.axvline(0, color="#AAA", lw=1)
ax.set_xlabel("Q5/Q1–Q4 relative full-time employment change (%)")
ax.set_title(
    "Long-window weakness persists; the shorter window is inconclusive",
    loc="left",
    fontweight="bold",
    fontsize=12,
)
ax.spines[["top", "right"]].set_visible(False)
fig.text(
    0.01,
    0.01,
    "Ages 22–25 · conditional 95% state-bootstrap intervals · descriptive comparisons",
    fontsize=8,
    color="#66717A",
)
fig.tight_layout(rect=[0, 0.035, 1, 1])
fig.savefig(O / "STOCK_RESIDUAL_SENSITIVITY.png", dpi=220)
fig.savefig(O / "STOCK_RESIDUAL_SENSITIVITY.pdf")
plt.close(fig)
fig, ax = plt.subplots(figsize=(9, 4.3))
v = np.array(terms)
y = np.arange(len(v))
ax.barh(y, v, color=np.where(v < 0, "#C64F5A", "#AEB6BC"), edgecolor="white")
ax.set_yticks(y, names)
ax.invert_yaxis()
ax.axvline(0, color="#AAA", lw=0.8)
ax.set_xlabel("Contribution to combined survey reconciliation (additive log points)")
ax.set_title("Large coverage terms offset each other", loc="left", fontweight="bold")
ax.spines[["top", "right"]].set_visible(False)
fig.text(
    0.01,
    0.01,
    "Primary IPW accounting · total −22.60 log points · these are not shares of an AI effect",
    fontsize=8,
    color="#66717A",
)
fig.tight_layout(rect=[0, 0.035, 1, 1])
fig.savefig(O / "RESIDUAL_COMPONENTS.png", dpi=220)
fig.savefig(O / "RESIDUAL_COMPONENTS.pdf")
plt.close(fig)


def mdtable(headers, rows):
    return (
        "| "
        + " | ".join(headers)
        + " |\n| "
        + " | ".join(["---"] * len(headers))
        + " |\n"
        + "\n".join("| " + " | ".join(map(str, row)) + " |" for row in rows)
    )


stable = mdtable(
    ["Sensitivity", "Pre/post months", "Relative change", "Conditional 95% interval"],
    [
        [
            label,
            f"{row.pre_months}/{row.post_months}",
            f"{row.relative_percent:+.2f}%",
            f"[{row.ci_low:+.2f}, {row.ci_high:+.2f}]",
        ]
        for label, row in zip(labels, s.itertuples())
    ],
)
flow = f[f.period.eq("primary") & f.component.isin(channels)]
flowtable = mdtable(
    [
        "Pathway",
        "IPW contrast, pp",
        "Dual-endpoint contrast, pp",
        "Dual conditional 95% interval",
    ],
    [
        [
            name,
            f'{flow[flow.method.eq("ipw")&flow.component.eq(name)].relative_change_pp.iloc[0]:+.3f}',
            f'{flow[flow.method.eq("dual_endpoint")&flow.component.eq(name)].relative_change_pp.iloc[0]:+.3f}',
            f'[{flow[flow.method.eq("dual_endpoint")&flow.component.eq(name)].ci_low.iloc[0]:+.3f}, {flow[flow.method.eq("dual_endpoint")&flow.component.eq(name)].ci_high.iloc[0]:+.3f}]',
        ]
        for name in channels
    ],
)
residtable = mdtable(
    ["Accounting component", "Additive log points"],
    [[k, f"{v:+.3f}"] for k, v in zip(names, terms)]
    + [["Combined reconciliation", f"{sum(terms):+.3f}"]],
)
mae = q.groupby(["band", "method"]).combined_survey_residual.apply(
    lambda x: x.abs().mean()
)
stockcoverage = (
    pd.read_csv(O / "UNLINKED_ENDPOINT_MASS.csv")
    .groupby("band")
    .mean(numeric_only=True)
)
all_primary_cross = ((flow.ci_low <= 0) & (flow.ci_high >= 0)).all()
all_tested = f[f.component.isin(channels)]
all_cross = ((all_tested.ci_low <= 0) & (all_tested.ci_high >= 0)).all()
assert all_primary_cross and all_cross
text = (
    """# Auditing the CPS survey reconciliation and the robustness of relative employment weakness

## Main findings

The large survey reconciliation is a difference between sizable endpoint-coverage and weighting terms, not a measured economic outflow. Scheduled rotation replacement supplies the largest negative accounting contribution, while eligible-but-unlinked endpoints supply a large positive offset. Reweighting corrections and observed CPS weight changes add further offsets. Occupational code-system changes were already excluded from the residual and remain a separate behavioral-classification bookkeeping term.

Long-window Q5/Q1–Q4 full-time employment weakness remains about 9% after rotation standardization, restriction to unambiguous historical occupational-code components, and a single-code-era reference period. However, a shorter, genuinely matched 22-month comparison yields −4.23% with an interval spanning zero. Thus the direction is consistent but statistical resolution is not robust to every period choice.

No individual flow pathway is statistically resolved by these conditional diagnostics, including after an endpoint-calibration diagnostic almost eliminates the national residual. Eliminating a residual by forcing endpoint margins to match does not identify missing transitions or validate an AI mechanism.

## Data and scope

We reuse the verified, hashed monthly CPS caches and frozen THAIE mapping. The target is civilian noninstitutional adults aged 22–25. Full-time employment is PEMLR 1/2 and PRFTLF 1 at each endpoint and in the stocks. Linkage uses an origin-age-21–26 domain to capture aging boundaries, unique household/person keys, rotation progression, stable recorded sex/race/state, and age progression of zero or one year. There are 115 actual adjacent-month pairs and 538,185 linked person-transition observations; repeated observations are not distinct people. The missing October 2025 is not imputed, and September–November 2025 is not linked as an individual transition.

The primary stock comparison is January 2019–October 2022 versus January 2023–October 2026, excluding October and November 2025 from the latter because adjacent flows are unavailable. The first window has 46 and the latter 44 observed target months. All changes below concern headcounts or flow intensities, not employment-to-population rates or causal AI effects. The ACS-calendar sensitivity is retained in the downloadable residual-attribution table.

## Exact residual identity

Let `B` denote target-age, full-time, exposure-group membership. Let `M` be valid matched persons and `U0,U1` unmatched endpoint records. Let `P0,P1` be the original CPS weights and `w` a common adjusted origin-based weight. Then the repeated-cross-section stock change satisfies

`ΔS = ΣM w(B1−B0) + ΣM(P1−P0)B1 + Rrotation + Runlinked + ΣM(P0−w)(B1−B0)`.

`Rrotation` is destination MIS 1/5 stock minus origin MIS 4/8 stock. `Runlinked` is the remaining unmatched destination stock minus unmatched origin stock among the scheduled overlap. These categories are exclusive. The last term is split into the planned six-of-eight rotation expansion and the additional response adjustment. The original matched weight-change term is a raw accounting convention, not the causal effect of changing survey weights. The combined reconciliation equals all terms after the weighted behavioral flow. This identity is checked by state, month, exposure group and weight method against the prior output.

The terms are integrated with the exact same period-mean telescoping coefficients and log-mean denominators as the previous decomposition.

"""
    + residtable
    + """

These additive log-point contributions sum to the previously reported combined survey reconciliation. They are not percentages of a causal effect or additive employment-change percentages. Scheduled rotation is random by design, but realized weighted group stocks differ between outgoing and incoming panels. Large signed terms can accumulate across many months and offset. Treating the −34.37 rotation contribution alone as the share of employment weakness explained by rotation would be misleading. The separately recorded January 2020 occupation-classification boundary contributes +0.840 log points to the primary overall employment accounting; it is not included in this residual total.

## Why coverage terms are large

The planned nonoverlap changes roughly one quarter of the interview sample each month. Across these pairs, Q5 origin scheduled-rotation full-time stock averages approximately 482,500 and incoming stock 472,319. Eligible-but-unlinked origin and destination Q5 stocks average approximately 178,915 and 198,868. These are repeated monthly weighted stocks, not unique workers, observed hiring, or job separations. The corresponding control-group stocks are much larger. Taking differences between such quantities creates sizable noise relative to the net stock change.

The linkage audit identifies """
    + f"{int(reason.sum()):,}"
    + """ eligible origin records. Of these, """
    + f'{int(reason["valid"]):,}'
    + """ validate, """
    + f'{int(reason.get("key_absent",0)):,}'
    + """ have no destination key, """
    + f'{int(reason.get("age_mismatch",0)):,}'
    + """ fail the age-progression rule, """
    + f'{int(reason.get("race_mismatch",0)):,}'
    + """ fail stable recorded race, and """
    + f'{int(reason.get("sex_mismatch",0)):,}'
    + """ fail stable recorded sex, under an ordered rejection hierarchy. A missing key does not tell us whether the cause is nonresponse, moving, household replacement, or another coverage issue. Invalid matches are not accepted merely to reduce the residual, and unmatched respondents are not coded as nonemployment. These records cannot reveal their unobserved job transitions without assumptions.

## Non-tautological stock sensitivities

"""
    + stable
    + """

Equal rotation mix standardizes each month's eight MIS-specific weighted occupational full-time shares to equal rotation-group weights, preserving the same-age population total. It directly checks whether changing rotation composition drives the long-window stock contrast; its result is virtually identical to the original estimate. It cannot remove all rotation-group response or classification errors.

The unambiguous-code restriction builds connected components of the 2010→2018 occupation crosswalk. A component is retained only when every linked new-code occupation has the same mapped Q5-versus-Q1–Q4 status and none is unmapped. This avoids fabricated individual old-code assignments or selectively treating fractional records as known identities. It changes the supported occupation universe, so its estimate is a robustness contrast rather than the identical population estimand. The negative result persists. The single-code-era comparisons additionally avoid the historical bridge altogether. The shorter 22-month comparison is substantially weaker and imprecise; pandemic recovery, endpoint selection and sampling precision remain material limitations.

## Reducing the residual without claiming to observe missing behavior

Origin-only entropy calibration reduces Q5's national mean absolute monthly combined reconciliation from """
    + f'{mae["q5","ipw"]:,.0f}'
    + """ to """
    + f'{mae["q5","origin_calibrated"]:,.0f}'
    + """ persons, about """
    + f'{100*(1-mae["q5","origin_calibrated"]/mae["q5","ipw"]):.1f}%'
    + """. For Q1–Q4 it falls from """
    + f'{mae["q14","ipw"]:,.0f}'
    + """ to """
    + f'{mae["q14","origin_calibrated"]:,.0f}'
    + """. Thus observed-response adjustment improves reconciliation only modestly; it does not repair all missing outcomes or panel coverage.

We also construct an explicitly constrained diagnostic. Starting with origin-calibrated weights, positive entropy calibration matches the original origin state/population/status margins and national destination Q5/Q1–Q4 FT/PT margins. The new relative calibration multipliers range from """
    + f"{ca.multiplier_min.min():.3f}"
    + """ to """
    + f"{ca.multiplier_max.max():.3f}"
    + """. The maximum normalized margin discrepancy is """
    + f"{ca.moment_error.max():.3g}"
    + """. National combined full-time reconciliation then falls below """
    + f'{q[q.method.eq("dual_endpoint")].combined_survey_residual.abs().max():.4f}'
    + """ persons per pair/group.

This near-zero residual is guaranteed by matching both endpoint stock margins. It is not an independent successful recovery of missing transitions. It does not prove ignorability, identify movers, validate occupation histories, or create new observations. Raw cross-sectional stocks remain unchanged by this flow-weight diagnostic, so their unchanged relative change is also guaranteed. We use it only to ask whether an allocation consistent with both sets of observed margins leads to a newly resolved mechanism.

## Do pathway conclusions change?

Flow intensities use signed weighted transitions per 100 origin full-time workers, with equal weight for each calendar month. They are replenishment/depletion intensities, not probabilities among the nonemployed or verified first-job hiring rates. Positive entries add to the stock; exits are signed negatively. The reported contrast is the Q5 post-minus-pre change minus the Q1–Q4 post-minus-pre change.

"""
    + flowtable
    + """

Every pathway interval spans zero under primary IPW, origin-only calibration, the dual-endpoint diagnostic, and symmetric common weights based on the average endpoint CPS weights. This also holds for the tested single-code-era and matched-22-month flow comparisons. The large residual therefore does not conceal a mechanism that becomes statistically resolved by these tested adjustments. This is not proof that all mechanisms are zero or absent. Wide intervals allow substantively important effects, and the constrained calibration cannot establish the true distribution of unobserved transitions.

## Statistical and causal limits

Intervals use 999 common state-resampling draws, with 51 states including DC. They condition on fitted propensity weights, fixed mapping, and the fitted calibration, rather than refitting those stages in each draw. They do not recover official CPS survey strata/PSUs, all occupation-level common shocks, bridge uncertainty, or nonignorable selection. They are working diagnostics, not publication-grade causal inference or a multiplicity-adjusted set of confirmatory tests. The stock and flow tests use independent fixed bootstrap seeds, so working interval endpoints may differ slightly from the prior report.

These diagnostics do not replace the previously estimated controlled entry DID. Equal calendar-month weighting addresses seasonal composition, not differential COVID recovery or industry-specific demand shocks. A shorter comparison changes both the period and precision. The occupation-code audit addresses known crosswalk ambiguity and the January 2020 boundary, not every occupation misreporting or dependent-interviewing error. Geographic mobility is incompletely observed because valid links require stable state. Forced margin agreement should never be presented as evidence of AI-caused displacement.

## Defensible conclusion

Within the long-window comparisons, young Q5 full-time employment remains weaker relative to Q1–Q4 after rotation and occupation-code checks. The finding is sensitive in magnitude and statistical resolution to the comparison period. No specific entry, exit, schedule-switch, occupational-movement, or aging pathway is established by the available linked CPS, even under tested residual-reduction adjustments. The evidence supports relative employment weakness with an unresolved mechanism; it does not establish AI causation or a contract-quality deterioration.

## Reproduction

- `audit.py` verifies hashed caches, constructs the exact coverage/weight residual identity, audits link rejection, and fits the constrained dual-margin diagnostic.
- `summarize.py` integrates the residual terms and estimates rotation/code/period stock sensitivities.
- `flows.py` compares flow pathways across weighting and reference-period alternatives.
- `report.py` checks agreement with the prior accounting and writes saved figures without image emission during smoke checks.

Only aggregate outputs should be shared. The private matched-record cache is excluded from the materials bundle. Existing website and manuscript files are not modified by this audit.
"""
)
(O / "RESIDUAL_AUDIT_REPORT_EN.md").write_text(text)
for p in W.glob("*.py"):
    ast.parse(p.read_text())
checks = dict(
    passed=True,
    valid_link_records=int(reason["valid"]),
    eligible_records=int(reason.sum()),
    prior_residual_reconstruction_error=float(abs(sum(terms) - oldv)),
    dual_max_absolute_national_residual_persons=float(
        q[q.method.eq("dual_endpoint")].combined_survey_residual.abs().max()
    ),
    all_tested_pathway_intervals_span_zero=bool(all_cross),
    long_window_original_percent=float(s.relative_percent.iloc[0]),
    equal_rotation_percent=float(s.relative_percent.iloc[1]),
    unambiguous_codes_percent=float(s.relative_percent.iloc[2]),
    matched_short_window_interval_spans_zero=bool(
        s.ci_low.iloc[4] < 0 < s.ci_high.iloc[4]
    ),
    figures_displayed=0,
    website_modified=False,
    manuscript_modified=False,
)
(O / "FINAL_CHECKS.json").write_text(json.dumps(checks, indent=2))
print(json.dumps(checks, indent=2))
