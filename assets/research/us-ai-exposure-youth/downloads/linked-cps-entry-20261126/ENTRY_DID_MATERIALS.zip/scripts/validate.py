"""Real-input smoke checks and explicit-dummy reference fits. No plots emitted."""

from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd
from scipy.linalg import qr
import statsmodels.api as sm
from statsmodels.stats.sandwich_covariance import cov_cluster

from models import fit
from run import relative_data, select, design

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Entry_DID_20261126"


def main():
    micro = pd.read_parquet(W / "entry_risksets.parquet")
    assert not micro.duplicated(["HRHHID", "HRHHID2", "PULINENO", "date"]).any()
    previous = pd.to_datetime(micro.origin_date).dt.to_period("M").astype(int)
    current = pd.to_datetime(micro.date).dt.to_period("M").astype(int)
    assert np.all(current - previous == 1)
    assert not micro.date.isin(["2025-10-01", "2025-11-01"]).any()
    assert micro.PRTAGE.between(22, 25).all()
    assert micro.PEMLR.between(3, 7).all()
    assert micro.linked.all()
    for cache in W.glob("raw_selected_*.parquet"):
        meta = json.loads(cache.with_suffix(".json").read_text())
        assert hashlib.sha256(cache.read_bytes()).hexdigest() == meta["cache_sha256"]
    flow = pd.read_parquet(O / "industry_state_month_entry_counts.parquet")
    for method in ["origin", "ipw", "trim99", "calibrated"]:
        expected = float((micro["w_" + method] * micro.entry_mapped).sum())
        got = flow[flow.method.eq(method)][["q5_count", "q14_count"]].sum().sum()
        assert abs(expected - got) < 1e-5
    # Verify the exact PPML FE structure on a real-data subset, with a separate
    # explicit-dummy statsmodels implementation and pivoted-QR gauge removal.
    a, fes, support = relative_data("ipw", "main")
    a = a[a.GESTFIPS.isin([6, 12, 36, 48]) & a.industry.isin([7, 8, 9])].copy()
    for _ in range(20):
        n = len(a)
        for fe in fes:
            a = a[a.groupby(fe).entries.transform("sum").gt(0)]
        if len(a) == n:
            break
    a = a.reset_index(drop=True)
    x, names = design(a, "main", relative=True)
    own = fit(a, a.entries.to_numpy(), x, names, fes, poisson=True)
    z = pd.get_dummies(a[fes].astype(str), drop_first=False, dtype=float).to_numpy()
    _, upper, pivot = qr(z, mode="economic", pivoting=True)
    rank = int((np.abs(np.diag(upper)) > 1e-8).sum())
    full = np.column_stack([x, z[:, pivot[:rank]]])
    assert np.linalg.matrix_rank(full) == full.shape[1]
    ref = sm.GLM(a.entries.to_numpy() / 1e4, full, family=sm.families.Poisson()).fit(
        maxiter=150, tol=1e-11
    )
    delta = float(np.max(np.abs(ref.params[: len(names)] - own["beta"])))
    assert ref.converged and delta < 2e-6
    # Match finite-sample convention before comparing the two-way sandwich.
    factor = (len(a) - 1) / (len(a) - own["info"]["FE_rank"] - len(names))

    def corrected(labels):
        count = pd.Series(labels).nunique()
        return (
            cov_cluster(ref, labels, use_correction=False)
            * count
            / (count - 1)
            * factor
        )

    vc = (
        corrected(a.GESTFIPS)
        + corrected(a.calendar_quarter)
        - corrected(a.GESTFIPS.astype(str) + ":" + a.calendar_quarter)
    )
    covariance_error = float(
        np.max(np.abs(vc[: len(names), : len(names)] - own["cov"]["state_quarter"]))
    )
    assert covariance_error < 2e-5
    # The paired-outcome LPM is algebraically checked using explicit OLS too.
    d = select(micro, "main")
    d = d[d.GESTFIPS.isin([6, 36])].reset_index(drop=True)
    fes2 = ["GESTFIPS", "month", "PRMJIND1", "PEMLR"]
    xx, nn = design(d, "main")
    y = 100 * (d.entry_q5 - d.entry_q14).to_numpy()
    ww = d.w_ipw.to_numpy()
    own2 = fit(d, y, xx, nn, fes2, ww.copy())
    zz = pd.get_dummies(d[fes2].astype(str), drop_first=False, dtype=float).to_numpy()
    _, uu, pp = qr(zz, mode="economic", pivoting=True)
    rr = int((np.abs(np.diag(uu)) > 1e-8).sum())
    ref2 = sm.WLS(y, np.column_stack([xx, zz[:, pp[:rr]]]), weights=ww).fit()
    linear_error = float(np.max(np.abs(ref2.params[: len(nn)] - own2["beta"])))
    assert linear_error < 1e-7
    checks = dict(
        passed=True,
        adjacent_pair_count=int(micro.date.nunique()),
        risk_pairs=len(micro),
        raw_cache_hashes_verified=len(list(W.glob("raw_selected_*.parquet"))),
        figures_displayed=0,
        ppml_reference_rows=len(a),
        ppml_explicit_dummy_beta_max_difference=delta,
        ppml_two_way_covariance_max_difference=covariance_error,
        linear_explicit_dummy_beta_max_difference=linear_error,
        expected_fractional_allocations_preserve_counts=True,
        October2025_not_imputed=True,
        November2025_not_bridged=True,
    )
    (O / "INDEPENDENT_NUMERICAL_CHECKS.json").write_text(json.dumps(checks, indent=2))
    print(json.dumps(checks))


if __name__ == "__main__":
    main()
