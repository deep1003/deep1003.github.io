"""Absorbed PPML and WLS with state/quarter score covariance; no figure output."""

import numpy as np
import pandas as pd
import pyhdfe
from scipy.stats import t, f


def code(values):
    return pd.factorize(values, sort=True)[0]


def cluster(scores, labels, bread, factor):
    ids = code(labels)
    n = int(ids.max() + 1)
    if n < 2:
        raise ValueError("Fewer than two clusters")
    sums = np.zeros((n, scores.shape[1]))
    np.add.at(sums, ids, scores)
    influence = sums @ bread
    return influence.T @ influence * n / (n - 1) * factor, n


def inference(d, score, bread, factor):
    state, gs = cluster(score, d.GESTFIPS, bread, factor)
    quarter, gt = cluster(score, d.calendar_quarter, bread, factor)
    joint, _ = cluster(
        score, d.GESTFIPS.astype(str) + ":" + d.calendar_quarter, bread, factor
    )
    year, gy = cluster(score, d.year, bread, factor)
    stateyear, _ = cluster(
        score, d.GESTFIPS.astype(str) + ":" + d.year.astype(str), bread, factor
    )
    return dict(
        state=state,
        state_quarter=state + quarter - joint,
        state_year=state + year - stateyear,
    ), dict(state=gs - 1, state_quarter=min(gs, gt) - 1, state_year=min(gs, gy) - 1)


def fit(d, y, x, names, fes, weight=None, poisson=False):
    ids = np.column_stack([code(d[col]) for col in fes])
    holder = {"w": np.ones(len(d))}

    def converged(last, current):
        delta = last - current
        return (
            np.sqrt(
                np.max(np.sum(holder["w"][:, None] * delta**2, axis=0))
                / holder["w"].sum()
            )
            < 1e-10
        )

    algo = pyhdfe.create(
        ids,
        drop_singletons=False,
        compute_degrees=True,
        options={"converged": converged, "iteration_limit": 5000},
    )
    y = np.asarray(y, float)
    if poisson:
        # Scaling population totals is numerically convenient and does not alter beta.
        y = y / 1e4
        eta = np.log(
            np.maximum(
                pd.Series(y).groupby(ids[:, 0]).transform("mean").to_numpy(), 1e-7
            )
        )
        beta = np.zeros(x.shape[1])
        warm = x.copy()

        def loss(e):
            return np.sum(np.exp(np.clip(e, -35, 20)) - y * e)

        for iteration in range(150):
            mu = np.exp(np.clip(eta, -35, 20))
            holder["w"] = mu
            z = eta + (y - mu) / mu
            residual = algo.residualize(
                np.column_stack([(y - mu) / mu + warm @ beta, warm]),
                weights=mu[:, None],
            )
            zr, xr = residual[:, 0], residual[:, 1:]
            warm = xr
            h = xr.T @ (mu[:, None] * xr)
            if np.linalg.matrix_rank(h) < len(names):
                raise ValueError("Absorbed model columns")
            proposed = np.linalg.solve(h, xr.T @ (mu * zr))
            proposed_eta = z - zr + xr @ proposed
            step = 1.0
            while (
                step > 1e-7
                and loss(eta + step * (proposed_eta - eta)) > loss(eta) + 1e-9
            ):
                step /= 2
            change = np.max(np.abs(step * (proposed - beta)))
            eta += step * (proposed_eta - eta)
            beta += step * (proposed - beta)
            raw = y - np.exp(np.clip(eta, -35, 20))
            score_max = max(
                float(np.abs(x.T @ raw).max()),
                *(
                    float(np.abs(np.bincount(ids[:, j], weights=raw)).max())
                    for j in range(ids.shape[1])
                )
            )
            if change < 1e-7 and score_max < 1e-6 and iteration > 2:
                break
        else:
            raise ValueError("PPML failed score convergence")
        w = np.exp(np.clip(eta, -35, 20))
        holder["w"] = w
        xr = algo.residualize(x, weights=w[:, None])
        residual = y - w
    else:
        w = np.asarray(weight, float)
        w /= w.mean()
        holder["w"] = w
        residualized = algo.residualize(np.column_stack([y, x]), weights=w[:, None])
        yr, xr = residualized[:, 0], residualized[:, 1:]
        h = xr.T @ (w[:, None] * xr)
        if np.linalg.matrix_rank(h) < len(names):
            raise ValueError("Absorbed linear model columns")
        beta = np.linalg.solve(h, xr.T @ (w * yr))
        residual = yr - xr @ beta
        iteration = 0
        score_max = float(np.abs(xr.T @ (w * residual)).max())
    h = xr.T @ (w[:, None] * xr)
    bread = np.linalg.inv(h)
    scores = xr * (residual if poisson else w * residual)[:, None]
    dof = len(d) - algo.degrees - len(names)
    assert dof > 0
    cov, dfs = inference(d, scores, bread, (len(d) - 1) / dof)
    return dict(
        beta=beta,
        cov=cov,
        dfs=dfs,
        names=names,
        info=dict(
            rows=len(d),
            FE_rank=int(algo.degrees),
            parameters=len(names),
            iterations=iteration + 1,
            maximum_score=score_max,
            condition_number=float(np.linalg.cond(h)),
            poisson=poisson,
        ),
    )


def contrast(result, term, metric, covariance="state_quarter"):
    i = result["names"].index(term)
    beta = float(result["beta"][i])
    variance = result["cov"][covariance][i, i]
    df = result["dfs"][covariance]
    se = float(np.sqrt(variance)) if variance > 0 else np.nan
    crit = t.ppf(0.975, df)
    transform = (
        (lambda z: 100 * np.expm1(z)) if metric == "relative_pct" else lambda z: z
    )
    return dict(
        term=term,
        covariance=covariance,
        metric=metric,
        coefficient=beta,
        SE=se,
        df=df,
        estimate=float(transform(beta)),
        CI_low=float(transform(beta - crit * se)),
        CI_high=float(transform(beta + crit * se)),
        p_value=float(2 * t.sf(abs(beta / se), df)) if se > 0 else np.nan,
        variance_valid=bool(variance > 0),
    )


def joint(result, terms, covariance="state_quarter"):
    ix = [result["names"].index(name) for name in terms]
    v = result["cov"][covariance][np.ix_(ix, ix)]
    rank = int(np.linalg.matrix_rank(v))
    positive = bool(len(ix) and np.linalg.eigvalsh(v).min() > 0)
    if not positive or rank < len(ix):
        return dict(
            terms=len(ix), rank=rank, covariance_positive=positive, p_value=np.nan
        )
    b = result["beta"][ix]
    stat = float(b @ np.linalg.solve(v, b) / len(ix))
    return dict(
        terms=len(ix),
        rank=rank,
        covariance_positive=True,
        p_value=float(f.sf(stat, len(ix), result["dfs"][covariance])),
    )
