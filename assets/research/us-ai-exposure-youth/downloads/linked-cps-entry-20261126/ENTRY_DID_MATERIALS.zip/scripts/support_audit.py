"""Verify eligible-to-linked support and expose unrecoverable response cells."""

from pathlib import Path
import json

import numpy as np
import pandas as pd

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Entry_DID_20261126"


def main():
    d = pd.read_parquet(W / "entry_risksets.parquet")
    audit = pd.read_csv(O / "linkage_audit.csv")
    matched = d.groupby(["date", "GESTFIPS"]).agg(
        matched_records=("P", "size"),
        matched_origin_population=("P", "sum"),
        calibrated_population=("w_calibrated", "sum"),
    )
    rows = []
    for date in audit.date:
        prior = pd.Timestamp(date) - pd.offsets.MonthBegin(1)
        z = pd.read_parquet(W / f"raw_selected_{prior.year}_{prior.month:02}.parquet")
        z = z[
            z.PRTAGE.between(22, 25)
            & z.PEMLR.between(3, 7)
            & z.HRMIS.isin([1, 2, 3, 5, 6, 7])
        ]
        eligible = z.groupby("GESTFIPS").agg(
            eligible_records=("P", "size"), eligible_population=("P", "sum")
        )
        eligible["date"] = date
        rows.append(eligible.reset_index())
    allcells = (
        pd.concat(rows, ignore_index=True).set_index(["date", "GESTFIPS"]).join(matched)
    )
    allcells["no_observed_response"] = allcells.matched_records.isna()
    supported = ~allcells.no_observed_response
    assert np.allclose(
        allcells.loc[supported, "eligible_population"],
        allcells.loc[supported, "calibrated_population"],
    )
    allcells["record_retention"] = allcells.matched_records / allcells.eligible_records
    allcells.to_csv(O / "STATE_MONTH_RESPONSE_SUPPORT.csv")
    lost = allcells[allcells.no_observed_response]
    lost.to_csv(O / "UNRECOVERABLE_RESPONSE_CELLS.csv")
    checks = dict(
        passed=True,
        state_month_cells=len(allcells),
        no_response_cells=len(lost),
        eligible_person_month_records_in_missing_cells=int(lost.eligible_records.sum()),
        eligible_population_weight_in_missing_cells=float(
            lost.eligible_population.sum()
        ),
        share_of_eligible_weight_missing_pct=float(
            100 * lost.eligible_population.sum() / allcells.eligible_population.sum()
        ),
        calibration_only_claimed_for_supported_cells=True,
        figures_displayed=0,
    )
    (O / "RESPONSE_SUPPORT_CHECKS.json").write_text(json.dumps(checks, indent=2))
    print(json.dumps(checks))


if __name__ == "__main__":
    main()
