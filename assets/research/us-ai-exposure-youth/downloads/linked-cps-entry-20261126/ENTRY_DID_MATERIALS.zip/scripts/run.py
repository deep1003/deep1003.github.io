"""Co-primary proportional and percentage-point entry DID and event studies."""

from pathlib import Path
import json
import hashlib

import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests

from models import fit, contrast, joint

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Entry_DID_20261126"
COUNTS = pd.read_parquet(O / "industry_state_month_entry_counts.parquet")
RISK = pd.read_csv(O / "state_month_risk_denominators.csv")
MICRO = pd.read_parquet(W / "entry_risksets.parquet")
SIGNATURE = hashlib.sha256(
    Path(__file__).read_bytes()
    + (W / "models.py").read_bytes()
    + (W / "entry_risksets.parquet").read_bytes()
    + (O / "industry_state_month_entry_counts.parquet").read_bytes()
    + (O / "state_month_risk_denominators.csv").read_bytes()
).hexdigest()


def select(d, spec):
    start = (
        "2017-02-01"
        if spec == "extended_pre"
        else "2020-02-01" if spec == "no_bridge" else "2019-01-01"
    )
    d = d[
        d.date.ge(start)
        & (
            d.date.le("2022-10-01")
            | d.date.ge("2023-01-01" if spec != "first_post_Dec22" else "2022-12-01")
        )
    ].copy()
    if spec == "exclude_covid":
        d = d[~d.date.str[:4].isin(["2020", "2021"])]
    if spec == "matched_missing":
        d = d[~d.date.isin(["2021-10-01", "2021-11-01"])]
    dt = pd.to_datetime(d.date)
    d["year"] = dt.dt.year
    d["quarter"] = dt.dt.quarter
    d["month"] = dt.dt.month
    d["calendar_quarter"] = dt.dt.to_period("Q").astype(str)
    d["t"] = ((dt.dt.year - 2022) * 12 + dt.dt.month - 11) / 12
    d["post"] = d.date.ge("2022-12-01").astype(float)
    return d


def relative_data(method, spec):
    risk = select(RISK[RISK.method.eq(method)], spec)
    if spec == "no_industry":
        a = (
            COUNTS[COUNTS.method.eq(method)]
            .groupby(["GESTFIPS", "date"])[["q5_count", "q14_count"]]
            .sum()
            .reset_index()
        )
        a["industry"] = 1
        inds = [1]
    else:
        a = COUNTS[COUNTS.method.eq(method)]
        inds = list(range(1, 14))
    grid = risk.merge(pd.DataFrame({"industry": inds}), how="cross")
    grid = grid.merge(
        a.drop(columns="method", errors="ignore"),
        on=["GESTFIPS", "date", "industry"],
        how="left",
        validate="one_to_one",
    )
    grid[["q5_count", "q14_count"]] = grid[["q5_count", "q14_count"]].fillna(0)
    d = grid.melt(
        id_vars=[x for x in grid if x not in ["q5_count", "q14_count"]],
        value_vars=["q5_count", "q14_count"],
        var_name="band",
        value_name="entries",
    )
    d["high"] = d.band.eq("q5_count").astype(float)
    d["state_band"] = d.GESTFIPS.astype(str) + ":" + d.band
    d["industry_band"] = d.industry.astype(str) + ":" + d.band
    d["state_date"] = d.GESTFIPS.astype(str) + ":" + d.date
    d["industry_date"] = d.industry.astype(str) + ":" + d.date
    d["band_season"] = d.band + ":" + d.month.astype(str)
    fes = ["state_band", "state_date", "band_season"]
    if spec != "no_industry":
        fes += ["industry_band", "industry_date"]
    before = d.entries.sum()
    n0 = len(d)
    for iteration in range(30):
        n = len(d)
        for fe in fes:
            keep = d.groupby(fe).entries.transform("sum").gt(0)
            d = d[keep]
        if len(d) == n:
            break
    else:
        raise ValueError("Poisson support pruning failed")
    assert abs(before - d.entries.sum()) < 1e-6
    return (
        d.reset_index(drop=True),
        fes,
        dict(
            initial_rows=n0,
            retained_rows=len(d),
            entry_weight_retention=1.0,
            zero_cells=int(d.entries.eq(0).sum()),
            date_count=d.date.nunique(),
            states=d.GESTFIPS.nunique(),
            industries=d.industry.nunique(),
            risk_state_months=len(risk),
        ),
    )


def design(d, spec, event=False, relative=False):
    h = d.high.to_numpy() if relative else np.ones(len(d))
    names, cols = [], []

    def add(name, vector):
        names.append(name)
        cols.append(h * np.asarray(vector, float))

    if event:
        # Four seasonal references avoid collinearity with group-specific seasonality.
        for q in sorted(d.calendar_quarter.unique()):
            if not q.startswith(("2020", "2021", "2022")):
                add("event_" + q, d.calendar_quarter.eq(q))
    else:
        add("DID", d.post)
    if spec not in ["no_covid_controls", "exclude_covid"]:
        for year in [2020, 2021]:
            for q in [1, 2, 3, 4]:
                mask = d.year.eq(year) & d.quarter.eq(q)
                if mask.any():
                    add(f"pandemic_{year}Q{q}", mask)
    elif event:
        raise ValueError("Event study requires pandemic controls")
    if spec == "recovery_2022":
        for q in [1, 2, 3]:
            add(f"recovery2022Q{q}", d.year.eq(2022) & d.quarter.eq(q))
    if spec == "trend":
        add("differential_linear_trend", d.t)
    return np.column_stack(cols), names


def estimate(metric, method, spec, event=False):
    label = f"{metric}_{method}_{spec}_{'event' if event else 'did'}"
    cache = W / (label + ".json")
    if cache.exists():
        previous = json.loads(cache.read_text())
        if previous.get("signature") == SIGNATURE:
            return previous
    if metric == "relative_pct":
        d, fes, support = relative_data(method, spec)
        y, weights = d.entries.to_numpy(), None
    else:
        d = select(MICRO, spec).reset_index(drop=True)
        fes = ["GESTFIPS", "month", "PRMJIND1", "PEMLR"]
        if spec == "demographics":
            fes += ["PRTAGE", "PESEX", "PEEDUCA", "PTDTRACE", "PEHSPNON", "PESCHENR"]
        if spec == "no_industry":
            fes = ["GESTFIPS", "month", "PEMLR"]
        y = 100 * (d.entry_q5 - d.entry_q14).to_numpy()
        weights = d["w_" + method].to_numpy().copy()
        support = dict(
            risk_pairs=len(d),
            dates=d.date.nunique(),
            weighted_risk=float(weights.sum()),
            Q5_fractional_entries=float(d.entry_q5.sum()),
            Q14_fractional_entries=float(d.entry_q14.sum()),
        )
    x, names = design(d, spec, event, metric == "relative_pct")
    print("Fit", label, len(d), len(names), flush=True)
    result = fit(d, y, x, names, fes, weights, poisson=metric == "relative_pct")
    out = dict(
        signature=SIGNATURE,
        metric=metric,
        method=method,
        spec=spec,
        event=event,
        support=support,
        fit=result["info"],
    )
    if event:
        terms = [name for name in names if name.startswith("event_")]
        out["coefficients"] = [
            dict(quarter=term.removeprefix("event_"), **contrast(result, term, metric))
            for term in terms
        ]
        leads = [term for term in terms if term.removeprefix("event_") < "2022Q1"]
        out["pretrend"] = {
            kind: joint(result, leads, kind)
            for kind in ["state_quarter", "state", "state_year"]
        }
        post = [term for term in terms if term.removeprefix("event_") > "2022Q4"]
        out["post_joint"] = joint(result, post)
    else:
        out["contrasts"] = [
            contrast(result, "DID", metric, kind)
            for kind in ["state_quarter", "state", "state_year"]
        ]
    cache.write_text(json.dumps(out, indent=2))
    print("Complete", label, out.get("contrasts", [{}])[0].get("estimate"), flush=True)
    return out


def main():
    results, events, pretrends, diagnostics = [], [], [], []
    configs = [(method, "main") for method in ["origin", "ipw", "trim99", "calibrated"]]
    configs += [
        ("ipw", s)
        for s in [
            "no_industry",
            "no_covid_controls",
            "trend",
            "exclude_covid",
            "recovery_2022",
            "extended_pre",
            "no_bridge",
            "matched_missing",
            "first_post_Dec22",
        ]
    ]
    for metric in ["relative_pct", "absolute_pp"]:
        for method, spec in configs + (
            [("ipw", "demographics")] if metric == "absolute_pp" else []
        ):
            a = estimate(metric, method, spec)
            for c in a["contrasts"]:
                results.append(dict(method=method, spec=spec, **c))
            diagnostics.append({k: v for k, v in a.items() if k != "contrasts"})
            pd.DataFrame(results).to_csv(O / "DID_RESULTS.csv", index=False)
        for spec in ["main", "extended_pre"]:
            a = estimate(metric, "ipw", spec, event=True)
            events += [{**c, "metric": metric, "spec": spec} for c in a["coefficients"]]
            pretrends += [
                dict(metric=metric, spec=spec, covariance=c, **v)
                for c, v in a["pretrend"].items()
            ]
            diagnostics.append(
                {k: v for k, v in a.items() if k not in ["coefficients", "pretrend"]}
            )
            pd.DataFrame(events).to_csv(O / "EVENT_STUDY.csv", index=False)
            pd.DataFrame(pretrends).to_csv(O / "PRETREND_TESTS.csv", index=False)
    result = pd.DataFrame(results)
    result["p_Holm_two_coprimary"] = np.nan
    mask = (
        result.method.eq("ipw")
        & result.spec.eq("main")
        & result.covariance.eq("state_quarter")
    )
    assert mask.sum() == 2
    result.loc[mask, "p_Holm_two_coprimary"] = multipletests(
        result.loc[mask, "p_value"], method="holm"
    )[1]
    result.to_csv(O / "DID_RESULTS.csv", index=False)
    (O / "MODEL_DIAGNOSTICS.json").write_text(json.dumps(diagnostics, indent=2))


if __name__ == "__main__":
    main()
