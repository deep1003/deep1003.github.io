"""Retain valid state-cluster ES intervals when two-way covariance is indefinite."""

import json
import numpy as np
import pandas as pd

from run import W, O, MICRO, relative_data, select, design
from models import fit, contrast


def main():
    rows = []
    original = pd.read_csv(O / "EVENT_STUDY.csv")
    for metric in ["relative_pct", "absolute_pp"]:
        for spec in ["main", "extended_pre"]:
            if metric == "relative_pct":
                d, fes, _ = relative_data("ipw", spec)
                y, weights = d.entries.to_numpy(), None
            else:
                d = select(MICRO, spec).reset_index(drop=True)
                fes = ["GESTFIPS", "month", "PRMJIND1", "PEMLR"]
                y = 100 * (d.entry_q5 - d.entry_q14).to_numpy()
                weights = d.w_ipw.to_numpy().copy()
            x, names = design(d, spec, event=True, relative=metric == "relative_pct")
            result = fit(d, y, x, names, fes, weights, poisson=metric == "relative_pct")
            for term in [name for name in names if name.startswith("event_")]:
                q = term.removeprefix("event_")
                check = original[
                    original.metric.eq(metric)
                    & original.spec.eq(spec)
                    & original.quarter.eq(q)
                ].iloc[0]
                value = contrast(result, term, metric, "state")
                assert abs(value["coefficient"] - check.coefficient) < 1e-7
                rows.append(dict(spec=spec, quarter=q, **value))
    pd.DataFrame(rows).to_csv(O / "EVENT_STUDY_STATE_INTERVALS.csv", index=False)
    (O / "EVENT_INTERVALS_NOTE.json").write_text(
        json.dumps(
            dict(
                state_intervals_valid=True,
                coefficient_identity_verified=True,
                reason="State-plus-quarter covariance is indefinite for some event contrasts and all full pretrend blocks. Invalid two-way intervals/tests are not repaired or used. State-cluster intervals are a separately labeled conditional diagnostic, not full survey or global-shock inference.",
                figures_displayed=0,
            ),
            indent=2,
        )
    )
    print("Saved state-cluster diagnostic intervals; coefficients unchanged")


if __name__ == "__main__":
    main()
