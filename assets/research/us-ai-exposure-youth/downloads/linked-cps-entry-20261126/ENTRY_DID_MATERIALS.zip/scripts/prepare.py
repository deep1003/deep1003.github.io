"""Build real adjacent-month jobless risk sets, common response models and flows."""

from pathlib import Path
import hashlib
import importlib.util
import json

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OneHotEncoder

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Entry_DID_20261126"
KEY = ["HRHHID", "HRHHID2", "PULINENO"]
SCORE = (
    R
    / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/frozen_THAIE_occupation_assignments.csv"
)
BRIDGE = (
    R
    / "outputs/US_THAIE_Regional_Youth_20261122/extension_2019/derived/occupation_conversion_2010_2018.csv"
)
PARSER = (
    R
    / "outputs/US_THAIE_Regional_Youth_20261122/panel_fe3_20261122/scripts/prepare_panel.py"
)
MANIFEST = R / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json"
FIELDS = KEY + [
    "GESTFIPS",
    "HRMIS",
    "HRMONTH",
    "PRTAGE",
    "PESEX",
    "PTDTRACE",
    "PEHSPNON",
    "PEEDUCA",
    "PEMLR",
    "PRMJIND1",
    "PESCHENR",
    "P",
    "PRFTLF",
    "occ",
]
CAT = [
    "GESTFIPS",
    "agegroup",
    "PESEX",
    "PTDTRACE",
    "PEHSPNON",
    "PEEDUCA",
    "PEMLR",
    "HRMIS",
    "HRMONTH",
    "PRMJIND1",
    "PESCHENR",
]
METHODS = ["origin", "ipw", "trim99", "calibrated"]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    s = importlib.util.spec_from_file_location("entry_parser", PARSER)
    parser = importlib.util.module_from_spec(s)
    s.loader.exec_module(parser)
    parser.FIELDS += KEY
    records = {
        (x["year"], x["month"]): x
        for x in json.loads(MANIFEST.read_text())
        if x.get("available", True)
    }
    parser.source = lambda y, m: (
        Path(records[y, m]["path"]),
        Path(records[y, m]["dictionary"]),
    )
    scores = pd.read_csv(SCORE)
    conv = pd.read_csv(BRIDGE).merge(
        scores[["occ", "THAIE_q"]],
        left_on="new",
        right_on="occ",
        how="left",
        validate="many_to_one",
    )
    assert np.allclose(conv.groupby("old").rate.sum(), 1, atol=1e-5)
    fractions = {
        "q5": conv[conv.THAIE_q.eq(5)].groupby("old").rate.sum(),
        "q14": conv[conv.THAIE_q.between(1, 4)].groupby("old").rate.sum(),
    }
    signature = hashlib.sha256(
        Path(__file__).read_bytes()
        + PARSER.read_bytes()
        + SCORE.read_bytes()
        + BRIDGE.read_bytes()
    ).hexdigest()

    def raw(y, m):
        cache = W / f"raw_selected_{y}_{m:02}.parquet"
        side = cache.with_suffix(".json")
        rec = records[y, m]
        valid = side.exists() and cache.exists()
        if valid:
            a = json.loads(side.read_text())
            valid = (
                a.get("signature") == signature
                and a.get("source_sha256") == rec["sha256"]
                and a.get("dictionary_sha256") == digest(rec["dictionary"])
                and a.get("cache_sha256") == digest(cache)
            )
        if valid:
            return pd.read_parquet(cache)
        d, audit = parser.read(y, m)
        assert audit["sha256"] == rec["sha256"]
        d = d[FIELDS].copy()
        if y < 2020:
            for band in ["q5", "q14"]:
                d[band] = d.occ.map(fractions[band]).fillna(0)
        else:
            d = d.merge(
                scores[["occ", "THAIE_q"]], on="occ", how="left", validate="many_to_one"
            )
            d["q5"] = d.THAIE_q.eq(5).astype(float)
            d["q14"] = d.THAIE_q.between(1, 4).astype(float)
            d = d.drop(columns="THAIE_q")
        assert not d.duplicated(KEY).any()
        d.to_parquet(cache, index=False)
        side.write_text(
            json.dumps(
                dict(
                    signature=signature,
                    source_sha256=rec["sha256"],
                    dictionary_sha256=digest(rec["dictionary"]),
                    cache_sha256=digest(cache),
                ),
                indent=2,
            )
        )
        return d

    audits, yearly = [], {}
    previous = None
    for y, m in sorted(records):
        current = raw(y, m)
        date = pd.Timestamp(y, m, 1)
        prior = date - pd.offsets.MonthBegin(1)
        if (prior.year, prior.month) not in records:
            previous = current
            continue
        if previous is None:
            previous = raw(prior.year, prior.month)
        left = previous[
            previous.HRMIS.isin([1, 2, 3, 5, 6, 7]) & previous.PEMLR.between(3, 7)
        ].copy()
        right = current[
            KEY
            + [
                "GESTFIPS",
                "HRMIS",
                "PESEX",
                "PTDTRACE",
                "PRTAGE",
                "PEMLR",
                "PRFTLF",
                "PRMJIND1",
                "q5",
                "q14",
            ]
        ]
        d = left.merge(
            right, on=KEY, suffixes=("", "_next"), how="left", validate="one_to_one"
        )
        d["linked"] = (
            d.PEMLR_next.notna()
            & d.HRMIS_next.eq(d.HRMIS + 1)
            & d.PESEX.eq(d.PESEX_next)
            & d.PTDTRACE.eq(d.PTDTRACE_next)
            & d.GESTFIPS.eq(d.GESTFIPS_next)
            & (d.PRTAGE_next - d.PRTAGE).between(0, 1)
        )
        d["origin_date"] = str(prior.date())
        d["date"] = str(date.date())
        d["agegroup"] = pd.cut(
            d.PRTAGE,
            [15, 21, 25, 30, 34, 40, 49, 200],
            labels=["16–21", "22–25", "26–30", "31–34", "35–40", "41–49", "50+"],
        ).astype(str)
        d["fold"] = ((d.HRHHID ^ d.HRHHID2) % 2).astype(int)
        d["household"] = (
            d.GESTFIPS.astype(str)
            + ":"
            + d.HRHHID.astype(str)
            + ":"
            + d.HRHHID2.astype(str)
        )
        yearly.setdefault(y, []).append(d)
        audits.append(
            dict(
                date=str(date.date()),
                eligible_jobless=len(d),
                linked_jobless=int(d.linked.sum()),
                eligible_youth=int(d.PRTAGE.between(22, 25).sum()),
                linked_youth=int((d.linked & d.PRTAGE.between(22, 25)).sum()),
            )
        )
        previous = current
        print("Parsed adjacent pair", date.date(), flush=True)
    youth, response = [], []
    for year, frames in yearly.items():
        d = pd.concat(frames, ignore_index=True)
        encoder = OneHotEncoder(handle_unknown="ignore")
        x = encoder.fit_transform(d[CAT].astype(str))
        prob = np.zeros(len(d))
        iters = []
        for fold in [0, 1]:
            train = d.fold.ne(fold).to_numpy()
            model = LogisticRegression(
                C=1, solver="newton-cholesky", max_iter=100, tol=1e-7
            )
            model.fit(
                x[train],
                d.linked.to_numpy()[train],
                sample_weight=d.P.to_numpy()[train] / d.P.to_numpy()[train].mean(),
            )
            prob[~train] = model.predict_proba(x[~train])[:, 1]
            iters.append(int(model.n_iter_[0]))
            assert model.n_iter_[0] < 100
        d["p_link"] = np.clip(prob, 0.05, 0.995)
        target = d[d.PRTAGE.between(22, 25)].copy()
        eligible_total = target.groupby(["GESTFIPS", "date"]).P.sum()
        z = target[target.linked].copy()
        z["w_origin"] = z.P
        z["w_ipw"] = z.P / z.p_link
        inv_cap = np.quantile(1 / d.loc[d.linked, "p_link"], 0.99)
        z["w_trim99"] = z.P * np.minimum(1 / z.p_link, inv_cap)
        observed_total = z.groupby(["GESTFIPS", "date"]).w_ipw.sum()
        calibration = eligible_total / observed_total
        z["w_calibrated"] = (
            z.w_ipw
            * pd.MultiIndex.from_frame(z[["GESTFIPS", "date"]])
            .map(calibration)
            .to_numpy()
        )
        assert np.isfinite(z.w_calibrated).all()
        assert np.allclose(
            z.groupby(["GESTFIPS", "date"]).w_calibrated.sum(),
            eligible_total.reindex(observed_total.index),
        )
        ft = z.PEMLR_next.isin([1, 2]) & z.PRFTLF_next.eq(1)
        z["entry_q5"] = ft * z.q5_next
        z["entry_q14"] = ft * z.q14_next
        z["entry_mapped"] = z.entry_q5 + z.entry_q14
        z["entry_any_FT"] = ft.astype(float)
        z["industry"] = z.PRMJIND1_next.where(ft, 0).fillna(0).astype(int)
        youth.append(z)
        response.append(
            dict(
                year=year,
                eligible=len(d),
                matched=int(d.linked.sum()),
                youth_eligible=len(target),
                youth_matched=len(z),
                youth_weighted_retention=float(
                    np.average(target.linked, weights=target.P)
                ),
                model_iterations=iters,
                propensity_min=float(target.p_link.min()),
                propensity_max=float(target.p_link.max()),
                calibration_min=float(calibration.min()),
                calibration_max=float(calibration.max()),
                zero_response_cells=int(
                    (eligible_total.index.difference(observed_total.index)).size
                ),
            )
        )
        print("Response fit", year, len(z), flush=True)
    d = pd.concat(youth, ignore_index=True)
    assert not d.duplicated(KEY + ["date"]).any()
    d.to_parquet(W / "entry_risksets.parquet", index=False)
    aggregate, risk, coverage = [], [], []
    for method in METHODS:
        d["q5_count"] = d["w_" + method] * d.entry_q5
        d["q14_count"] = d["w_" + method] * d.entry_q14
        a = (
            d[d.industry.between(1, 13)]
            .groupby(["GESTFIPS", "date", "industry"])[["q5_count", "q14_count"]]
            .sum()
            .reset_index()
        )
        a["method"] = method
        aggregate.append(a)
        q = (
            d.groupby(["GESTFIPS", "date"])["w_" + method]
            .agg(["sum", "size"])
            .reset_index()
            .rename(columns={"sum": "risk_weight", "size": "risk_records"})
        )
        q["method"] = method
        risk.append(q)
        coverage.append(
            dict(
                method=method,
                FT_total=float((d["w_" + method] * d.entry_any_FT).sum()),
                mapped_FT=float((d["w_" + method] * d.entry_mapped).sum()),
                modeled_FT=float(a[["q5_count", "q14_count"]].sum().sum()),
                youth_risk_pairs=len(d),
            )
        )
    pd.concat(aggregate, ignore_index=True).to_parquet(
        O / "industry_state_month_entry_counts.parquet", index=False
    )
    pd.concat(risk, ignore_index=True).to_csv(
        O / "state_month_risk_denominators.csv", index=False
    )
    pd.DataFrame(audits).to_csv(O / "linkage_audit.csv", index=False)
    pd.DataFrame(response).to_csv(O / "response_audit.csv", index=False)
    pd.DataFrame(coverage).to_csv(O / "exposure_industry_coverage.csv", index=False)
    (O / "PREPARATION_CHECKS.json").write_text(
        json.dumps(
            dict(
                passed=True,
                adjacent_pairs=len(audits),
                youth_risk_pairs=len(d),
                first_date=d.date.min(),
                last_date=d.date.max(),
                source_manifest_sha256=digest(MANIFEST),
                frozen_THAIE_sha256=digest(SCORE),
                bridge_sha256=digest(BRIDGE),
                raw_caches_hash_verified=True,
                no_imputed_persons=True,
                no_missing_month_bridge=True,
                destination_exposure_is_outcome=True,
                calibration_matches_observed_origin_margins=True,
                propensity_covariates=CAT,
                private_microdata_published=False,
                figures_displayed=0,
            ),
            indent=2,
        )
    )


if __name__ == "__main__":
    O.mkdir(parents=True, exist_ok=True)
    main()
