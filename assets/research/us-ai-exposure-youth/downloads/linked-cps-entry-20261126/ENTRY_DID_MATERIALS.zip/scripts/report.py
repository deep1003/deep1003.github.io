"""Write scientific report, readable result tables, and saved line-only figures."""

from pathlib import Path
import json
import zipfile

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import numpy as np
import pandas as pd
from scipy.stats import t
from statsmodels.stats.multitest import multipletests

from run import select, MICRO

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Entry_DID_20261126"
RED = "#C64F5A"


def md(d):
    return d.to_markdown(index=False, floatfmt=".4f")


def main():
    assert json.loads((O / "INDEPENDENT_NUMERICAL_CHECKS.json").read_text())["passed"]
    results = pd.read_csv(O / "DID_RESULTS.csv")
    primary = results[
        results.spec.eq("main")
        & results.method.eq("ipw")
        & results.covariance.eq("state_quarter")
    ].copy()
    primary.to_csv(O / "PRIMARY_RESULTS.csv", index=False)
    events = pd.read_csv(O / "EVENT_STUDY_STATE_INTERVALS.csv")
    events["p_Holm_event_family"] = np.nan
    for spec, z in events.groupby("spec"):
        events.loc[z.index, "p_Holm_event_family"] = multipletests(
            z.p_value, method="holm"
        )[1]
    events.to_csv(O / "EVENT_STUDY_STATE_INTERVALS_WITH_MULTIPLICITY.csv", index=False)
    pre = pd.read_csv(O / "PRETREND_TESTS.csv")
    mask = pre.covariance.eq("state")
    pre.loc[mask, "p_Holm_four_diagnostics"] = multipletests(
        pre.loc[mask, "p_value"], method="holm"
    )[1]
    pre.to_csv(O / "PRETREND_TESTS_WITH_MULTIPLICITY.csv", index=False)
    d = select(MICRO, "main")
    d["period"] = np.where(d.post.eq(1), "post", "pre")
    rows = []
    for method in ["origin", "ipw", "trim99", "calibrated"]:
        for period, z in d.groupby("period"):
            w = z["w_" + method]
            rows.append(
                dict(
                    method=method,
                    period=period,
                    risk_pairs=len(z),
                    distinct_ID_keys=z[["HRHHID", "HRHHID2", "PULINENO"]]
                    .drop_duplicates()
                    .shape[0],
                    months=z.date.nunique(),
                    Q5_fractional_entries=z.entry_q5.sum(),
                    Q14_fractional_entries=z.entry_q14.sum(),
                    Q5_entry_rate_pct=100 * np.average(z.entry_q5, weights=w),
                    Q14_entry_rate_pct=100 * np.average(z.entry_q14, weights=w),
                )
            )
    raw = pd.DataFrame(rows)
    raw.to_csv(O / "SAME_WINDOW_UNADJUSTED_RATES.csv", index=False)
    # Export plots only. No display(), show(), screenshots, or image emission.
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "svg.fonttype": "none",
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.labelcolor": "#35404A",
            "axes.edgecolor": "#88929A",
        }
    )
    fig, axes = plt.subplots(2, 2, figsize=(14, 8.8), sharex="row")
    for row, spec in enumerate(["main", "extended_pre"]):
        dates = sorted(select(MICRO, spec).date.unique())
        date_lookup = {}
        for quarter in sorted(pd.to_datetime(dates).to_period("Q").unique()):
            observed = [
                pd.Timestamp(x)
                for x in dates
                if pd.Timestamp(x).to_period("Q") == quarter
            ]
            date_lookup[str(quarter)] = pd.Timestamp(
                int(np.median([x.value for x in observed]))
            )
        for col, metric in enumerate(["relative_pct", "absolute_pp"]):
            ax = axes[row, col]
            z = events[events.spec.eq(spec) & events.metric.eq(metric)].sort_values(
                "quarter"
            )
            for ispost in [False, True]:
                v = z[z.quarter.ge("2023Q1") if ispost else z.quarter.lt("2020Q1")]
                x = [date_lookup[q] for q in v.quarter]
                if metric == "relative_pct":
                    center = v.coefficient.to_numpy()
                    half = t.ppf(0.975, v.df.to_numpy()) * v.SE.to_numpy()
                    lo, hi = center - half, center + half
                else:
                    center, lo, hi = (
                        v.estimate.to_numpy(),
                        v.CI_low.to_numpy(),
                        v.CI_high.to_numpy(),
                    )
                ax.fill_between(x, lo, hi, color=RED, alpha=0.13, linewidth=0)
                ax.plot(
                    x,
                    center,
                    color=RED,
                    linewidth=2.2,
                    path_effects=[
                        pe.Stroke(linewidth=3.5, foreground="white"),
                        pe.Normal(),
                    ],
                )
            ax.axhline(0, color="#A5ABB0", linewidth=0.8)
            ax.axvspan(
                pd.Timestamp("2020-01-01"),
                pd.Timestamp("2021-12-31"),
                color="#EDF0F2",
                zorder=-3,
            )
            ax.axvspan(
                pd.Timestamp("2022-01-01"),
                pd.Timestamp("2022-10-31"),
                color="#F7EEEE",
                zorder=-2,
            )
            ax.axvline(
                pd.Timestamp("2022-11-30"),
                color="#8C949B",
                linestyle=(0, (3, 3)),
                linewidth=1,
            )
            ax.grid(axis="y", color="#EEF0F2", linewidth=0.8)
            p = pre[
                pre.spec.eq(spec) & pre.metric.eq(metric) & pre.covariance.eq("state")
            ].p_value.iloc[0]
            ax.set_title(
                (
                    "A"
                    if row == col == 0
                    else "B" if row == 0 else "C" if col == 0 else "D"
                )
                + f"  {'Proportional entry contrast' if col==0 else 'Absolute entry-gap contrast'}\n{'2019-start balanced window' if row==0 else '2017-start preperiod sensitivity'} · pretrend p={p:.3f}",
                loc="left",
                fontsize=10.5,
            )
            ax.set_ylabel(
                "Log relative change" if col == 0 else "Percentage-point change"
            )
            ticks = [q for q in date_lookup if q.endswith(("Q1", "Q3"))]
            ax.set_xticks(
                [date_lookup[q] for q in ticks],
                [q.replace("Q", "-Q") for q in ticks],
                rotation=55,
                ha="right",
                fontsize=7.5,
            )
            ax.set_xlim(min(date_lookup.values()), pd.Timestamp("2026-10-31"))
    fig.suptitle(
        "Entry into full-time work · ages 22–25 · Q5 versus Q1–Q4",
        x=0.065,
        y=0.995,
        ha="left",
        fontsize=15,
        weight="bold",
    )
    fig.text(
        0.065,
        0.015,
        "Monthly CPS inputs, quarter-binned estimates. Warm red shows the Q5 contrast; shading gives state-cluster pointwise 95% intervals.\n2020–2021 pandemic coefficients are nuisance terms; 2022 uses four season-matched reference quarters. Q4 2026 observes October only.\nState-plus-quarter event covariance is indefinite; invalid intervals are withheld separately. These diagnostic curves do not establish AI causality.",
        fontsize=8.2,
        color="#5F6B74",
    )
    fig.tight_layout(rect=[0, 0.12, 1, 0.96])
    for ext in ["png", "svg"]:
        fig.savefig(O / f"ENTRY_EVENT_STUDY.{ext}", dpi=220, facecolor="white")
    for ax in axes[1]:
        ax.set_visible(False)
    fig.set_size_inches(14, 5.2)
    for j, ax in enumerate(axes[0]):
        ax.set_position([0.065 + j * 0.50, 0.30, 0.405, 0.52])
    for ext in ["png", "svg"]:
        fig.savefig(O / f"ENTRY_EVENT_STUDY_PRIMARY.{ext}", dpi=220, facecolor="white")
    plt.close(fig)
    configs = [
        ("origin", "main", "Original weights"),
        ("ipw", "main", "Response IPW (primary)"),
        ("trim99", "main", "Trimmed IPW"),
        ("calibrated", "main", "Calibrated IPW"),
        ("ipw", "no_industry", "Remove industry controls"),
        ("ipw", "no_covid_controls", "Remove pandemic interactions"),
        ("ipw", "trend", "Add differential linear trend"),
        ("ipw", "exclude_covid", "Exclude 2020–2021"),
        ("ipw", "recovery_2022", "Add 2022 recovery interactions"),
        ("ipw", "extended_pre", "Extend preperiod to 2017"),
        ("ipw", "no_bridge", "Start in 2020 (no bridge)"),
        ("ipw", "matched_missing", "Mirror missing pre-months"),
        ("ipw", "first_post_Dec22", "Include December 2022 post"),
    ]
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 7.2))
    for ax, metric in zip(axes, ["relative_pct", "absolute_pp"]):
        for i, (method, spec, label) in enumerate(configs):
            v = results[
                results.method.eq(method)
                & results.spec.eq(spec)
                & results.metric.eq(metric)
                & results.covariance.eq("state_quarter")
            ].iloc[0]
            c = RED if spec == "main" else "#A7AEB4"
            ax.plot([v.CI_low, v.CI_high], [i, i], color=c, linewidth=2.2)
            ax.plot(
                [v.estimate, v.estimate], [i - 0.12, i + 0.12], color=c, linewidth=2.2
            )
        ax.axvline(0, color="#87919A", linewidth=0.9, linestyle=(0, (3, 3)))
        ax.set_yticks(range(len(configs)), [c[2] for c in configs], fontsize=9)
        ax.invert_yaxis()
        ax.grid(axis="x", color="#EEF0F2")
        ax.set_xlabel(
            "Relative change (%)"
            if metric == "relative_pct"
            else "Entry-gap change (percentage points)"
        )
        ax.set_title(
            "Proportional DID" if metric == "relative_pct" else "Absolute DID",
            loc="left",
            weight="bold",
        )
    fig.suptitle(
        "Sensitivity to weights, recovery controls, and the preperiod",
        x=0.05,
        ha="left",
        fontsize=15,
        weight="bold",
    )
    fig.text(
        0.05,
        0.025,
        "All intervals use state-plus-quarter working covariance. Positive values mean the Q5 contrast moves upward, not that Q5 employment necessarily rises.\nSpecifications are diagnostic sensitivities. A nominally significant positive contrast is not an AI benefit estimate.",
        fontsize=8.2,
        color="#5F6B74",
    )
    fig.tight_layout(rect=[0, 0.10, 1, 0.94])
    for ext in ["png", "svg"]:
        fig.savefig(
            O / f"ENTRY_SPECIFICATION_SENSITIVITY.{ext}", dpi=220, facecolor="white"
        )
    plt.close(fig)
    assert not plt.get_fignums()
    tablecols = [
        "metric",
        "estimate",
        "CI_low",
        "CI_high",
        "p_value",
        "p_Holm_two_coprimary",
    ]
    weight_table = results[
        results.spec.eq("main") & results.covariance.eq("state_quarter")
    ][["metric", "method", "estimate", "CI_low", "CI_high", "p_value"]]
    spec_table = results[
        results.method.eq("ipw") & results.covariance.eq("state_quarter")
    ][["metric", "spec", "estimate", "CI_low", "CI_high", "p_value"]]
    pre_table = pre[pre.covariance.eq("state")][
        ["metric", "spec", "terms", "p_value", "p_Holm_four_diagnostics"]
    ]
    text = f"""# Does entry into high-exposure full-time work decline more for young adults?

## Finding

The linked CPS does not establish a significantly larger decline in Q5 full-time entry than in Q1–Q4. The proportional industry-controlled DID is +6.94%, with a 95% interval from −14.53% to +33.80% (p=.546). A materially negative effect remains compatible with this interval. The additive DID is +0.962 percentage points, opposite to the proposed greater-Q5-decline hypothesis; its nominal significance does not survive all specification checks and must not be interpreted as an AI benefit.

## Data and risk set

We rebuilt 115 genuine adjacent-calendar-month CPS pairs spanning February 2017–October 2026. The full linked risk file contains 95,862 origin-jobless transition opportunities at ages 22–25, not independent people. Rotation eligibility, unique identifiers, next-month MIS, sex/race consistency, state continuity and age progression are verified. People aged 25 at origin who turn 26 remain eligible. October 2025 is unobserved; neither September-to-November nor October-to-November transitions are invented.

The primary window has destination months January 2019–October 2022 and January 2023–October 2026. Each side spans 46 calendar months. There are 46 observed pre-months and 44 observed post-months because the missing October 2025 survey removes two adjacent pairs. November and December 2022 are excluded to avoid mixing the launch transition with fully post-launch intervals. A sensitivity includes December 2022 as the first post month. Extended-preperiod analysis starts in February 2017; the no-bridge sensitivity starts in 2020.

Origin nonemployment includes unemployment and nonparticipation. All these respondents form a common denominator. Destination THAIE classifies entry outcomes; it is not a treatment assigned to a nonworker. Unmapped destinations remain outside the two target entry outcomes, not recoded as low exposure. Approximately 98% of weighted FT entries are mapped. The 2017–2019 occupation bridge contributes fractional expected group membership rather than fabricated detailed occupations. Score and bridge uncertainty are not included in the intervals.

FT entry requires destination PEMLR 1/2 and PRFTLF 1, the usual full-time labor-force classification. It includes wage/salary and self-employed work, rather than employer payroll hiring alone, and does not identify permanent contracts. CPS linkage is address/rotation based and cannot automatically recover movers; selection related to unobserved mobility can remain after IPW.

Same-window unadjusted rates are retained separately.

{md(raw[raw.method.eq('ipw')][['period','risk_pairs','months','Q5_entry_rate_pct','Q14_entry_rate_pct']])}

## Two distinct DID estimands

**Proportional entry contrast.** We aggregate weighted new FT entries by state, destination broad industry, exposure group and observed month. A PPML mean includes state×exposure-group, industry×exposure-group, state×calendar-month, industry×calendar-month, and exposure-group×month-of-year fixed effects. The coefficient is on Q5×post. Eight Q5×pandemic-quarter interactions cover 2020–2021. Because the jobless denominator is shared within state-month, its log is absorbed by the state-month effects. State and industry month effects control local conditions, common entry volumes, and industry-wide demand/recovery; the group-season terms permit differential seasonality.

The reported percentage is 100×(exp(beta)−1), a change in the Q5/Q1–Q4 entry-rate ratio. Conditioning on industry-month means this is a within-industry composition contrast; it is not the total effect of industry-wide hiring changes. Full zero-entry cells are retained wherever a risk set is observed. All-zero FE margins are removed for finite PPML estimation without losing any positive mapped entry weight. Missing risk cells are not filled with zero.

**Absolute entry-gap contrast.** For every jobless risk opportunity we form 100×(entry into Q5 FT − entry into Q1–Q4 FT) and regress this paired outcome on post, state, differential month-of-year seasonality, prior-industry history, origin labor-force status and pandemic-quarter indicators. Survey/response weights enter WLS. This is an additive paired-outcome DID in percentage points. Prior industry is a work-history covariate and its unavailable category is explicit; nonworkers are not assumed currently employed in that industry. A demographic sensitivity adds exact age, sex, education, race, Hispanic origin and enrollment. Its controls and estimand differ from the destination-industry-conditioned proportional model.

The broader Q1–Q4 group has a larger baseline entry rate. A larger absolute Q1–Q4 decline and a larger proportional Q5 decline can coexist. Therefore the two measures are reported separately rather than chosen after seeing their significance.

## Primary estimates

{md(primary[tablecols])}

Working covariance clusters scores by state and calendar quarter with their intersection removed, using finite-sample corrections and t critical values. The two co-primary DID tests receive Holm correction. State-only and state-plus-year alternatives are retained in DID_RESULTS.csv. These are not full CPS design-based variances, and they do not propagate estimated response probabilities, unknown attrition mechanisms, exposure measurement, or occupation-bridge uncertainty. Global occupation shocks persisting beyond these cluster structures remain a limitation.

The additive +0.962 pp estimate says that the Q5-minus-Q1–Q4 gap increases, not that Q5 entry itself necessarily increases. Adding a differential trend gives +0.794 pp (p=.209); adding 2022 recovery interactions gives +0.457 pp (p=.281). State-plus-year clustering also widens its interval to approximately −0.052 to +1.976 pp (p=.060). It is not a robust causal improvement. The proportional primary estimate is statistically inconclusive under every weight variant.

## Attrition adjustment

For comparability across occupation-code regimes, a common set of origin covariates is used in year-specific household-fold response models among rotation-eligible jobless adults. Covariates are state, age group, sex, race, Hispanic origin, education, labor-force status, MIS, interview month, prior industry and enrollment. No destination information enters the response model. Original respondent weights, cross-fitted response IPW, 99th-percentile inverse-factor trimming, and calibration to eligible youth jobless state-month margins are compared on identical matched risk sets.

{md(weight_table)}

Correction changes the proportional primary estimate from +6.51% to +6.94%, and the additive estimate from +0.943 to +0.962 pp. These differences are small relative to their uncertainty. Four state-month cells in the full 2017–2026 inventory have eligible young nonworkers but no successful match. Their missing outcomes cannot be recovered by calibration; targets are restored only in cells with observed respondents. The largest calibration multiplier is about 9.96 in a sparse 2018 cell, so calibrated estimates are sensitivity checks rather than an automatic solution to attrition. IPW assumes response on observables and is not an official longitudinal weight.

The four unrecoverable cells contain nine eligible person-month records and approximately 0.0037% of eligible population weight across the full inventory. Their state-month support is explicitly retained in UNRECOVERABLE_RESPONSE_CELLS.csv rather than silently imputed.

## Event study and pretrends

Monthly observations are grouped into calendar-quarter coefficients. Group-specific month-of-year effects and a complete set of quarter indicators are collinear unless four seasonal references are supplied. We therefore omit the four 2022 quarters and interpret each event coefficient relative to its season-matched 2022 reference. Q4 2022 contains October only; Q4 2026 also contains October only. The 2020–2021 quarter terms are pandemic nuisance effects, not plotted AI-event coefficients.

The state-plus-quarter covariance is indefinite for all full pretrend blocks and several marginal event terms. Invalid intervals and joint tests are withheld, not made positive by clipping eigenvalues. The saved event graphs use explicitly labeled state-cluster diagnostic intervals, whose coefficients exactly reproduce the primary event model. This alternative conditions on the observed common time path and does not solve global-shock or survey-design uncertainty.

{md(pre_table)}

The extended-preperiod additive pretrend test rejects flat leads (p=.011; Holm across four diagnostics approximately .044). This undermines a causal interpretation of its positive DID contrast. The proportional diagnostic does not reject, but that is not proof of parallel trends or enough power to rule out relevant divergence. Event coefficients have pointwise intervals; a separate column applies Holm correction over the displayed coefficient family. Individual positive or negative quarters are not selected as confirmatory results.

## Specification checks

{md(spec_table)}

Removing pandemic interactions yields a proportional estimate of −9.81% (p=.294), while the primary adjustment gives +6.94% (p=.546). Extending the preperiod to 2017 gives +1.91% (p=.841). Adding 2022 recovery interactions gives −2.26% (p=.869). Thus the apparent direction is substantially more sensitive to pandemic/reference-period assumptions than to response-weight correction. A nominally positive proportional trend specification is not evidence of an AI benefit and changes under alternative covariance.

## Numerical verification and interpretation

The absorbed PPML was checked against an independent explicit-dummy statsmodels fit on 782 real cells. The maximum coefficient difference is approximately 2.6e−12 and the two-way covariance difference approximately 5.2e−10 after aligning finite-sample conventions. The paired-outcome WLS agrees with explicit weighted dummy regression within 9.4e−14. All 117 source-cache hashes, adjacent-month dates, age/risk eligibility, outcome-weight accounting and missing-month rules passed. Smoke checks emitted no graphs.

This analysis supports neither a statistically established extra Q5 entry decline nor AI causal attribution. Its intervals still allow economically important harm. Entry includes return to employment and is not verified first-job hiring; recorded age is not experience. Origin selection into nonemployment, differential recovery, schooling, public-file age perturbation, imperfect occupation mapping, and unobserved actual AI adoption remain alternatives. Repeated monthly employment-stock weakness cannot be equated with this entry-flow estimand.

## Files

- PRIMARY_RESULTS.csv and DID_RESULTS.csv contain main and sensitivity estimates.
- EVENT_STUDY.csv preserves two-way intervals, including withheld cases; EVENT_STUDY_STATE_INTERVALS_WITH_MULTIPLICITY.csv contains the plotted diagnostic intervals.
- PRETREND_TESTS_WITH_MULTIPLICITY.csv records valid diagnostics and invalid-covariance flags.
- SAME_WINDOW_UNADJUSTED_RATES.csv separates raw flow descriptions from controlled estimates.
- response_audit.csv and linkage_audit.csv document response and matching support.
- INDEPENDENT_NUMERICAL_CHECKS.json and PREPARATION_CHECKS.json contain validation evidence.
- ENTRY_EVENT_STUDY and ENTRY_SPECIFICATION_SENSITIVITY are saved as PNG and SVG. No individual data are published.

Reproduction scripts are under work/us_entry_did_20261126. Official source URLs and original hashes are in the pre-existing CPS source manifest referenced by PREPARATION_CHECKS.json. No paid data or new outside employment/exposure series enter this analysis.
"""
    (O / "REPORT_EN.md").write_text(text)
    # Outputs contain only aggregates. The private risk file stays in work.
    with zipfile.ZipFile(O / "ENTRY_DID_MATERIALS.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for p in O.iterdir():
            if p.is_file() and p.suffix in {
                ".csv",
                ".json",
                ".md",
                ".svg",
                ".png",
                ".parquet",
            }:
                z.write(p, "outputs/" + p.name)
        for p in W.glob("*.py"):
            z.write(p, "scripts/" + p.name)
        for path in [
            R
            / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json",
            R
            / "outputs/US_CPS_Only_Monthly_DID_20261125/tables/frozen_THAIE_occupation_assignments.csv",
            R
            / "outputs/US_THAIE_Regional_Youth_20261122/extension_2019/derived/occupation_conversion_2010_2018.csv",
        ]:
            z.write(path, "inputs/" + path.name)
        z.writestr(
            "README.txt",
            "This package contains aggregate outcomes, source inventories, frozen exposure inputs and analysis scripts. No person-level linked risk file is included. Scripts preserve original project-relative paths and require the project's CPS parser and freely downloadable official raw files to rebuild private risk sets. This is an inspectable materials package, not a standalone raw-data environment. Read REPORT_EN.md for the estimands, covariance limitations and missing-response diagnostics.\n",
        )
    print("Saved scientific report and figures; no images displayed")


if __name__ == "__main__":
    main()
