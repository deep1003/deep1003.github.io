# Prespecified stock–flow accounting

Use only existing official CPS files and frozen THAIE assignments. Main outcome is current usual FT employment, with total employment as a separate outcome. Ages 22–25 define each endpoint's stock; ages 21–26 at origin provide the age-boundary risk frame.

Two comparisons are fixed before inspecting component estimates. The ACS-calendar comparison uses 2017–2019 versus 2023–2024. The entry-DID-calendar comparison uses January 2019–October 2022 versus January 2023–October 2026, omitting November 2025 from the latter mean to retain identical destination dates to the earlier entry model. CPS FT is used consistently for all stocks and flows; it is not falsely equated with the ACS past-year hours proxy.

Main accounting allocates age-boundary changes first, then nonemployment entry/exit, then FT/PT schedule changes, and finally recorded exposure-group reclassification among people remaining in the target employment state. An age-versus-employment symmetric allocation is a sensitivity, not a uniquely causal attribution. Historical split-code flows remain expected fractional reclassifications. January 2020's occupation-system boundary and mapped/unmapped movements are separate components. Recorded occupation change is not assumed to be a verified employer/job change.

Reestimate origin-only match probabilities among rotation-eligible ages 21–26, including employed and nonemployed people. Compare design-only weights, response IPW, trimmed IPW and origin-margin calibrated IPW. The standard six-of-eight rotation expansion is explicit. Calibration uses origin information only, never destination stocks; it must not manufacture stock–flow closure.

At every pair, retain exact reconciliation terms between matched behavioral flows and the full repeated cross-sections. Separate observed matched survey-weight changes and the remaining frame/rotation/nonresponse/calibration reconciliation. Do not attribute the latter to economic behavior. The September–November 2025 observed stock difference is an unobserved-flow gap, not a two-month individual match.

Period-average stock differences are exactly expressed as cumulative monthly component differences with deterministic time weights. Log-mean Divisia conversion then decomposes the log change in Q5/Q1–Q4 relative stocks. Contributions are additive log points, not counts of unique affected people. Do not infer a channel is identified if reconciliation dominates or weights/order sensitivities reverse it.

State-cluster bootstrap intervals condition on fitted response/calibration weights and fixed mapping, and are working diagnostics rather than official CPS design or AI-causal inference. Check recorded occupational-move persistence where a genuine third interview is observable. No graph or image is emitted during input/output smoke checks. Save figures separately.
