"""Season-balanced descriptive transition intensities; no causal interpretation."""

from pathlib import Path
import numpy as np
import pandas as pd
from decompose import COMP, PERIODS, GROUPS

R = Path(__file__).resolve().parents[2]
O = R / "outputs/US_Stock_Flow_20261126"
s = pd.read_csv(O / "MONTHLY_STATE_STOCKS.csv", parse_dates=["date"])
c = pd.read_parquet(O / "MONTHLY_STATE_COMPONENTS.parquet")
c["date"] = pd.to_datetime(c.date)
c["origin_date"] = pd.to_datetime(c.origin_date)
c = c[c.measure.eq("FT") & c.method.eq("ipw") & c.ordering.eq("age_first")].copy()
base = s[s.measure.eq("FT")][["date", "GESTFIPS", "band", "stock"]].rename(
    columns={"date": "origin_date"}
)
c = c.merge(base, on=["origin_date", "GESTFIPS", "band"], validate="many_to_one")
states = sorted(c.GESTFIPS.unique())
rng = np.random.default_rng(5731)
draws = rng.multinomial(len(states), np.ones(len(states)) / len(states), 999)
channels = {
    **{k: [k] for k in COMP[:12]},
    **{k: v for k, v in GROUPS.items() if "unobserved_flow_gap" not in v},
}
rows = []
for period, (p0, p1, z0, z1) in PERIODS.items():
    for name, keys in channels.items():
        vals = {}
        for band in ["q5", "q14"]:
            for label, lo, hi in [("pre", p0, p1), ("post", z0, z1)]:
                x = c[c.date.between(lo, hi) & c.band.eq(band)].copy()
                x["flow"] = x[keys].sum(axis=1)
                x["month"] = x.date.dt.month
                # Equal weight for each observed calendar month. State resampling is common across windows/bands.
                rates = []
                boots = []
                for month, g in x.groupby("month"):
                    a = (
                        g.groupby("GESTFIPS")[["flow", "stock"]]
                        .sum()
                        .reindex(states, fill_value=0)
                        .to_numpy()
                    )
                    rates.append(100 * a[:, 0].sum() / a[:, 1].sum())
                    b = draws @ a
                    boots.append(100 * b[:, 0] / b[:, 1])
                vals[(band, label)] = (
                    np.mean(rates),
                    np.mean(boots, axis=0),
                    x.date.nunique(),
                )
        change = (vals[("q5", "post")][0] - vals[("q5", "pre")][0]) - (
            vals[("q14", "post")][0] - vals[("q14", "pre")][0]
        )
        boot = (vals[("q5", "post")][1] - vals[("q5", "pre")][1]) - (
            vals[("q14", "post")][1] - vals[("q14", "pre")][1]
        )
        rows.append(
            dict(
                period=period,
                component=name,
                q5_pre=vals[("q5", "pre")][0],
                q5_post=vals[("q5", "post")][0],
                q14_pre=vals[("q14", "pre")][0],
                q14_post=vals[("q14", "post")][0],
                relative_change_pp=change,
                working_ci_low=np.quantile(boot, 0.025),
                working_ci_high=np.quantile(boot, 0.975),
                pre_flow_months=vals[("q5", "pre")][2],
                post_flow_months=vals[("q5", "post")][2],
            )
        )
out = pd.DataFrame(rows)
out.to_csv(O / "SEASON_BALANCED_FLOW_INTENSITIES.csv", index=False)
print(
    out[
        out.component.isin(
            [
                "Nonemployment entry",
                "Nonemployment exit",
                "Full-/part-time balance",
                "Recorded occupation balance",
                "Age-boundary balance",
                "FT_to_PT",
                "PT_to_FT",
                "age_in",
                "age_out",
            ]
        )
    ].to_string(index=False)
)
