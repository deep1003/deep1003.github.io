"""Exact period-mean CPS accounting; conditional state-bootstrap diagnostics."""

from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

R = Path(__file__).resolve().parents[2]
O = R / "outputs/US_Stock_Flow_20261126"
COMP = [
    "entry_from_U",
    "entry_from_N",
    "exit_to_U",
    "exit_to_N",
    "PT_to_FT",
    "FT_to_PT",
    "occupation_in",
    "occupation_out",
    "mapping_net",
    "classification_net",
    "age_in",
    "age_out",
    "weight_change",
    "frame_reconciliation",
    "unobserved_flow_gap",
]
GROUPS = {
    "Nonemployment entry": ["entry_from_U", "entry_from_N"],
    "Nonemployment exit": ["exit_to_U", "exit_to_N"],
    "Full-/part-time balance": ["PT_to_FT", "FT_to_PT"],
    "Recorded occupation balance": ["occupation_in", "occupation_out"],
    "Age-boundary balance": ["age_in", "age_out"],
    "Mapping coverage": ["mapping_net"],
    "2020 classification boundary": ["classification_net"],
    "Survey/coverage reconciliation": ["weight_change", "frame_reconciliation"],
    "Unobserved 2025 flow gap": ["unobserved_flow_gap"],
}
PERIODS = {
    "ACS_calendar": ("2017-01-01", "2019-12-01", "2023-01-01", "2024-12-01"),
    "DID_calendar": ("2019-01-01", "2022-10-01", "2023-01-01", "2026-10-01"),
}


def lm(a, b):
    a, b = np.asarray(a), np.asarray(b)
    return np.divide(
        a - b,
        np.log(a / b),
        out=np.array((a + b) / 2, dtype=float),
        where=np.abs(a - b) > 1e-8,
    )


def main():
    s = pd.read_csv(O / "MONTHLY_STATE_STOCKS.csv", parse_dates=["date"])
    c = pd.read_parquet(O / "MONTHLY_STATE_COMPONENTS.parquet")
    c["date"] = pd.to_datetime(c.date)
    c["unobserved_flow_gap"] = 0.0
    dates = pd.DatetimeIndex(sorted(s.date.unique()))
    states = sorted(s.GESTFIPS.unique())
    # Do not fabricate individual transitions across a missing survey month.
    gap_rows = []
    for i in range(1, len(dates)):
        if dates[i - 1] + pd.offsets.MonthBegin() != dates[i]:
            prev = (
                s[s.date.eq(dates[i - 1])]
                .set_index(["GESTFIPS", "measure", "band"])
                .stock
            )
            now = (
                s[s.date.eq(dates[i])].set_index(["GESTFIPS", "measure", "band"]).stock
            )
            delta = (now - prev).rename("unobserved_flow_gap").reset_index()
            for method in c.method.unique():
                for order in c.ordering.unique():
                    x = delta.copy()
                    for k in COMP[:-1]:
                        x[k] = 0.0
                    x["date"], x["origin_date"], x["method"], x["ordering"] = (
                        dates[i],
                        dates[i - 1],
                        method,
                        order,
                    )
                    gap_rows.append(x)
    c = pd.concat([c, *gap_rows], ignore_index=True)
    all_components = []
    summary = []
    rate_rows = []
    closure = []
    rng = np.random.default_rng(20261126)
    draws = rng.multinomial(len(states), np.ones(len(states)) / len(states), size=999)
    for period, (p0, p1, z0, z1) in PERIODS.items():
        pre = (dates >= p0) & (dates <= p1)
        post = (dates >= z0) & (dates <= z1)
        if period == "DID_calendar":
            post &= dates != pd.Timestamp("2025-11-01")
        weights = np.where(post, 1 / post.sum(), 0) - np.where(pre, 1 / pre.sum(), 0)
        edge = pd.Series(np.cumsum(weights[::-1])[::-1], index=dates)
        cc = c.copy()
        cc[COMP] = cc[COMP].mul(cc.date.map(edge), axis=0)
        integrated = (
            cc.groupby(["GESTFIPS", "measure", "band", "method", "ordering"])[COMP]
            .sum()
            .reset_index()
        )
        means = {}
        for label, mask in [("pre", pre), ("post", post)]:
            means[label] = (
                s[s.date.isin(dates[mask])]
                .groupby(["GESTFIPS", "measure", "band"])
                .stock.mean()
            )
        for measure in ["E", "FT"]:
            a = np.column_stack(
                [
                    means[x]
                    .xs((measure, b), level=["measure", "band"])
                    .reindex(states)
                    .to_numpy()
                    for x, b in [
                        ("pre", "q5"),
                        ("post", "q5"),
                        ("pre", "q14"),
                        ("post", "q14"),
                    ]
                ]
            )
            totals = a.sum(axis=0)
            theta = np.log(totals[1] / totals[0]) - np.log(totals[3] / totals[2])
            bs = draws @ a
            bt = np.log(bs[:, 1] / bs[:, 0]) - np.log(bs[:, 3] / bs[:, 2])
            summary.append(
                dict(
                    period=period,
                    measure=measure,
                    pre_months=int(pre.sum()),
                    post_months=int(post.sum()),
                    q5_pre=totals[0],
                    q5_post=totals[1],
                    q14_pre=totals[2],
                    q14_post=totals[3],
                    relative_percent=100 * np.expm1(theta),
                    working_ci_low=100 * np.expm1(np.quantile(bt, 0.025)),
                    working_ci_high=100 * np.expm1(np.quantile(bt, 0.975)),
                )
            )
            for (method, order), sub in integrated[
                integrated.measure.eq(measure)
            ].groupby(["method", "ordering"]):
                matrices = [
                    sub[sub.band.eq(b)]
                    .set_index("GESTFIPS")[COMP]
                    .reindex(states)
                    .to_numpy()
                    for b in ["q5", "q14"]
                ]
                for j, m in enumerate(matrices):
                    expected = (a[:, 1] - a[:, 0]) if j == 0 else (a[:, 3] - a[:, 2])
                    closure.append(float(np.max(np.abs(m.sum(axis=1) - expected))))
                net = matrices[0].sum(axis=0) / lm(totals[1], totals[0]) - matrices[
                    1
                ].sum(axis=0) / lm(totals[3], totals[2])
                assert abs(net.sum() - theta) < 1e-9
                boot = (draws @ matrices[0]) / lm(bs[:, 1], bs[:, 0])[:, None] - (
                    draws @ matrices[1]
                ) / lm(bs[:, 3], bs[:, 2])[:, None]
                for name, keys in {**{k: [k] for k in COMP}, **GROUPS}.items():
                    idx = [COMP.index(k) for k in keys]
                    vals = 100 * boot[:, idx].sum(axis=1)
                    all_components.append(
                        dict(
                            period=period,
                            measure=measure,
                            method=method,
                            ordering=order,
                            component=name,
                            grouped=name in GROUPS,
                            q5_persons=matrices[0][:, idx].sum(),
                            q14_persons=matrices[1][:, idx].sum(),
                            relative_log_points=100 * net[idx].sum(),
                            working_ci_low=np.quantile(vals, 0.025),
                            working_ci_high=np.quantile(vals, 0.975),
                        )
                    )
        # Common genuinely observed destination months only. January 2017 unavailable as a flow.
        for label, mask in [("pre", pre), ("post", post)]:
            flow = c[c.date.isin(dates[mask]) & c.unobserved_flow_gap.eq(0)]
            n = flow.date.nunique()
            avg = (
                flow.groupby(["measure", "band", "method", "ordering"])[COMP[:-1]].sum()
                / n
            )
            for ix, row in avg.iterrows():
                for name, keys in GROUPS.items():
                    if "unobserved_flow_gap" in keys:
                        continue
                    rate_rows.append(
                        dict(
                            period=period,
                            window=label,
                            measure=ix[0],
                            band=ix[1],
                            method=ix[2],
                            ordering=ix[3],
                            component=name,
                            flow_months=n,
                            monthly_persons=row[keys].sum(),
                        )
                    )
    out = pd.DataFrame(all_components)
    out.to_csv(O / "PERIOD_COMPONENT_DECOMPOSITION.csv", index=False)
    pd.DataFrame(summary).to_csv(O / "PERIOD_STOCK_COMPARISON.csv", index=False)
    pd.DataFrame(rate_rows).to_csv(O / "PERIOD_MONTHLY_FLOW_AVERAGES.csv", index=False)
    assert max(closure) < 1e-5
    audit = pd.read_csv(O / "RESPONSE_CALIBRATION_AUDIT.csv")
    checks = dict(
        passed=True,
        max_period_state_closure_error=max(closure),
        bootstrap_draws=999,
        bootstrap_scope="Conditional on fitted response weights and frozen mapping; state resampling, not official CPS design inference",
        min_propensity=float(audit.propensity_min.min()),
        max_calibration_multiplier=float(audit.multiplier_max.max()),
        min_calibration_multiplier=float(audit.multiplier_min.min()),
        figures_displayed=0,
    )
    (O / "DECOMPOSITION_CHECKS.json").write_text(json.dumps(checks, indent=2))
    primary = out[out.grouped & out.method.eq("ipw") & out.ordering.eq("age_first")]
    for period in PERIODS:
        x = primary[primary.period.eq(period) & primary.measure.eq("FT")].copy()
        fig, ax = plt.subplots(figsize=(10, 5.5))
        y = np.arange(len(x))
        v = x.relative_log_points.to_numpy()
        ax.barh(
            y,
            v,
            color=np.where(v < 0, "#C64F5A", "#9DA7AC"),
            edgecolor="white",
            linewidth=0.7,
        )
        ax.errorbar(
            v,
            y,
            xerr=np.vstack([v - x.working_ci_low, x.working_ci_high - v]),
            fmt="none",
            ecolor="#45515A",
            elinewidth=0.8,
            capsize=2,
        )
        ax.set_yticks(y, x.component)
        ax.invert_yaxis()
        ax.axvline(0, color="#45515A", lw=0.8)
        ax.set_xlabel("Contribution to Q5/Q1–Q4 change (additive log points)")
        ax.set_title(
            "Ages 22–25 · Full-time employment stock–flow accounting\n"
            + period.replace("_", " "),
            loc="left",
            fontweight="bold",
        )
        ax.spines[["top", "right"]].set_visible(False)
        fig.text(
            0.01,
            0.01,
            "IPW · origin age 21–26 · conditional state-bootstrap intervals · descriptive accounting",
            fontsize=8,
            color="#66717A",
        )
        fig.tight_layout(rect=[0, 0.035, 1, 1])
        fig.savefig(O / f"FT_DECOMPOSITION_{period}.png", dpi=220)
        fig.savefig(O / f"FT_DECOMPOSITION_{period}.pdf")
        plt.close(fig)
    print(pd.DataFrame(summary).to_string(index=False))
    print(
        primary[primary.measure.eq("FT")][
            [
                "period",
                "component",
                "relative_log_points",
                "working_ci_low",
                "working_ci_high",
            ]
        ].to_string(index=False)
    )
    print(json.dumps(checks))


if __name__ == "__main__":
    main()
