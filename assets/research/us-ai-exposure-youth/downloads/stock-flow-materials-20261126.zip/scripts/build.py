"""Observed CPS stock–flow accounting with explicit nonbehavioral reconciliation."""

from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd
from scipy.linalg import qr
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OneHotEncoder

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = R / "outputs/US_Stock_Flow_20261126"
RAW = R / "work/us_entry_did_20261126"
KEY = ["HRHHID", "HRHHID2", "PULINENO"]
CAT = [
    "GESTFIPS",
    "PRTAGE",
    "PESEX",
    "PTDTRACE",
    "PEHSPNON",
    "PEEDUCA",
    "PEMLR",
    "PRFTLF",
    "HRMIS",
    "HRMONTH",
    "PRMJIND1",
    "PESCHENR",
]
METHODS = ["design_only", "ipw", "trim99", "calibrated"]
BEHAVIOR = [
    "entry_from_U",
    "entry_from_N",
    "exit_to_U",
    "exit_to_N",
    "PT_to_FT",
    "FT_to_PT",
    "occupation_in",
    "occupation_out",
    "mapping_net",
    "classification_net",
    "age_in",
    "age_out",
]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def calibration_features(d, states, cells):
    e = d.PEMLR.isin([1, 2]).to_numpy()
    ft = e & d.PRFTLF.eq(1).to_numpy()
    a = d.PRTAGE.between(22, 25).to_numpy()
    status = np.select([ft, e, d.PEMLR.isin([3, 4])], ["FT", "PT", "U"], default="N")
    code = d.PRTAGE.astype(str).to_numpy() + np.array([":" + x for x in status])
    x = np.column_stack(
        [
            d.GESTFIPS.to_numpy()[:, None] == np.array(states)[None, :],
            code[:, None] == np.array(cells)[None, :],
            a * ft * d.q5,
            a * ft * d.q14,
            a * (e & ~ft) * d.q5,
            a * (e & ~ft) * d.q14,
        ]
    ).astype(float)
    return x


def calibrate(origin, matched, base):
    states = sorted(origin.GESTFIPS.unique())
    e = origin.PEMLR.isin([1, 2])
    ft = e & origin.PRFTLF.eq(1)
    st = np.select([ft, e, origin.PEMLR.isin([3, 4])], ["FT", "PT", "U"], default="N")
    cells = sorted(
        set(origin.PRTAGE.astype(str).to_numpy() + np.array([":" + x for x in st]))
    )
    full = calibration_features(origin, states, cells)
    x = calibration_features(matched, states, cells)
    total = origin.P.sum()
    target = full.T @ origin.P.to_numpy() / total
    b = np.asarray(base) / total
    _, upper, pivot = qr(x * np.sqrt(b)[:, None], mode="economic", pivoting=True)
    rank = int((np.abs(np.diag(upper)) > 1e-9).sum())
    keep = pivot[:rank]
    xx = x[:, keep]
    tt = target[keep]
    beta = np.zeros(rank)

    def loss(v):
        return float((b * np.exp(np.clip(xx @ v, -25, 25))).sum() - tt @ v)

    for iteration in range(60):
        mu = b * np.exp(np.clip(xx @ beta, -25, 25))
        gradient = xx.T @ mu - tt
        if np.max(np.abs(gradient)) < 2e-10:
            break
        h = xx.T @ (mu[:, None] * xx)
        step = np.linalg.solve(h, gradient)
        scale = 1.0
        while scale > 1e-8 and loss(beta - scale * step) > loss(beta) + 1e-13:
            scale /= 2
        beta -= scale * step
    weights = total * b * np.exp(np.clip(xx @ beta, -25, 25))
    error = float(np.max(np.abs(x.T @ weights / total - target)))
    if error > 1e-7:
        raise ValueError(f"Origin calibration infeasible, moment error {error}")
    return weights, dict(
        iterations=iteration + 1,
        moment_error=error,
        multiplier_min=float((weights / base).min()),
        multiplier_max=float((weights / base).max()),
        origin_margin_rank=rank,
    )


def components(d, measure, band, ordering):
    age0 = d.PRTAGE.between(22, 25).to_numpy().astype(float)
    age1 = d.PRTAGE_next.between(22, 25).to_numpy().astype(float)
    e0 = d.PEMLR.isin([1, 2]).to_numpy()
    e1 = d.PEMLR_next.isin([1, 2]).to_numpy()
    f0 = e0 & d.PRFTLF.eq(1).to_numpy()
    f1 = e1 & d.PRFTLF_next.eq(1).to_numpy()
    q0 = d[band].to_numpy()
    q1 = d[band + "_next"].to_numpy()
    v0 = (f0 if measure == "FT" else e0) * q0
    v1 = (f1 if measure == "FT" else e1) * q1
    if ordering == "age_first":
        factor = age0 * age1
        aging_in = (1 - age0) * age1 * v1
        aging_out = -age0 * (1 - age1) * v0
    else:
        factor = (age0 + age1) / 2
        aging_in = np.maximum(age1 - age0, 0) * (v0 + v1) / 2
        aging_out = np.minimum(age1 - age0, 0) * (v0 + v1) / 2
    z = {key: np.zeros(len(d)) for key in BEHAVIOR}
    z["age_in"], z["age_out"] = aging_in, aging_out
    target1 = f1 if measure == "FT" else e1
    target0 = f0 if measure == "FT" else e0
    for group, mask in [
        ("U", d.PEMLR.isin([3, 4]).to_numpy()),
        ("N", d.PEMLR.between(5, 7).to_numpy()),
    ]:
        z["entry_from_" + group] = factor * mask * target1 * q1
    for group, mask in [
        ("U", d.PEMLR_next.isin([3, 4]).to_numpy()),
        ("N", d.PEMLR_next.between(5, 7).to_numpy()),
    ]:
        z["exit_to_" + group] = -factor * target0 * mask * q0
    if measure == "FT":
        z["PT_to_FT"] = factor * (e0 & ~f0) * f1 * q1
        z["FT_to_PT"] = -factor * f0 * (e1 & ~f1) * q0
        persistent = f0 & f1
    else:
        persistent = e0 & e1
    movement = factor * persistent * (q1 - q0)
    boundary = d.date.eq("2020-01-01").to_numpy()
    mapped = (d.q5 + d.q14).ge(0.9999).to_numpy() & (d.q5_next + d.q14_next).ge(
        0.9999
    ).to_numpy()
    z["classification_net"] = movement * boundary
    z["mapping_net"] = movement * ~boundary * ~mapped
    ordinary = movement * ~boundary * mapped
    z["occupation_in"] = np.maximum(ordinary, 0)
    z["occupation_out"] = np.minimum(ordinary, 0)
    target = age1 * v1 - age0 * v0
    assert np.max(np.abs(sum(z.values()) - target)) < 1e-10
    return z, age0 * v0, age1 * v1


def main():
    stocks, rawaudit = [], []
    data = {}
    for path in sorted(RAW.glob("raw_selected_*.parquet")):
        meta = json.loads(path.with_suffix(".json").read_text())
        assert digest(path) == meta["cache_sha256"]
        year, month = map(int, path.stem.split("_")[-2:])
        date = f"{year}-{month:02}-01"
        d = pd.read_parquet(path)
        d = d[d.PRTAGE.between(21, 26)].copy()
        assert not d.duplicated(KEY).any()
        data[date] = d
        age = d.PRTAGE.between(22, 25)
        e = d.PEMLR.isin([1, 2])
        ft = e & d.PRFTLF.eq(1)
        for measure, mask in [("E", e), ("FT", ft)]:
            for band in ["q5", "q14"]:
                z = (
                    d.assign(stock=d.P * age * mask * d[band])
                    .groupby("GESTFIPS")
                    .stock.sum()
                    .reset_index()
                )
                z["date"], z["measure"], z["band"] = date, measure, band
                stocks.append(z)
        rawaudit.append(
            dict(
                date=date,
                cache_sha256=meta["cache_sha256"],
                source_sha256=meta["source_sha256"],
            )
        )
    stocks = pd.concat(stocks, ignore_index=True)
    stocks.to_csv(O / "MONTHLY_STATE_STOCKS.csv", index=False)
    yearly = {}
    linkaudit = []
    rightcols = KEY + [
        "GESTFIPS",
        "PRTAGE",
        "PEMLR",
        "PRFTLF",
        "PESEX",
        "PTDTRACE",
        "HRMIS",
        "occ",
        "q5",
        "q14",
        "P",
    ]
    # Destination age 27 is irrelevant for the target stock but can occur for an
    # origin aged26; join from full cache to preserve valid aging-out identities.
    for date, cur_domain in data.items():
        dt = pd.Timestamp(date)
        prior = str((dt - pd.offsets.MonthBegin(1)).date())
        if prior not in data:
            continue
        y, m = dt.year, dt.month
        cur = pd.read_parquet(
            RAW / f"raw_selected_{y}_{m:02}.parquet", columns=rightcols
        )
        left = data[prior][data[prior].HRMIS.isin([1, 2, 3, 5, 6, 7])].copy()
        d = left.merge(
            cur, on=KEY, how="left", suffixes=("", "_next"), validate="one_to_one"
        )
        d["linked"] = (
            d.PEMLR_next.notna()
            & d.HRMIS_next.eq(d.HRMIS + 1)
            & d.PESEX.eq(d.PESEX_next)
            & d.PTDTRACE.eq(d.PTDTRACE_next)
            & d.GESTFIPS.eq(d.GESTFIPS_next)
            & (d.PRTAGE_next - d.PRTAGE).between(0, 1)
        )
        d["date"] = date
        d["origin_date"] = prior
        d["fold"] = ((d.HRHHID ^ d.HRHHID2) % 2).astype(int)
        yearly.setdefault(y, []).append(d)
        linkaudit.append(
            dict(
                date=date,
                eligible=len(d),
                matched=int(d.linked.sum()),
                weighted_retention=float(np.average(d.linked, weights=d.P)),
            )
        )
    response, allmatched = [], []
    for year, frames in yearly.items():
        d = pd.concat(frames, ignore_index=True)
        enc = OneHotEncoder(handle_unknown="ignore")
        x = enc.fit_transform(d[CAT].astype(str))
        probability = np.zeros(len(d))
        iterations = []
        for fold in [0, 1]:
            train = d.fold.ne(fold).to_numpy()
            fit = LogisticRegression(
                C=1, solver="newton-cholesky", max_iter=100, tol=1e-7
            )
            fit.fit(
                x[train],
                d.linked.to_numpy()[train],
                sample_weight=d.P.to_numpy()[train] / d.P.to_numpy()[train].mean(),
            )
            probability[~train] = fit.predict_proba(x[~train])[:, 1]
            iterations.append(int(fit.n_iter_[0]))
            assert iterations[-1] < 100
        d["p_match"] = np.clip(probability, 0.05, 0.995)
        z = d[d.linked].copy()
        z["w_design_only"] = z.P / 0.75
        z["w_ipw"] = z.P / 0.75 / z.p_match
        cap = float(np.quantile(1 / z.p_match, 0.99))
        z["w_trim99"] = z.P / 0.75 * np.minimum(1 / z.p_match, cap)
        calparts = []
        for date, part in z.groupby("date"):
            original = data[part.origin_date.iloc[0]]
            weights, info = calibrate(original, part, part.w_ipw.to_numpy())
            part = part.copy()
            part["w_calibrated"] = weights
            calparts.append(part)
            response.append(
                dict(
                    date=date,
                    year=year,
                    model_iterations=max(iterations),
                    propensity_min=float(part.p_match.min()),
                    propensity_max=float(part.p_match.max()),
                    trim_inverse_cap=cap,
                    **info,
                )
            )
        z = pd.concat(calparts, ignore_index=True)
        allmatched.append(z)
        print("Response and origin calibration", year, len(z), flush=True)
    matched = pd.concat(allmatched, ignore_index=True)
    matched.to_parquet(W / "matched_all_status_21_26.parquet", index=False)
    pd.DataFrame(linkaudit).to_csv(O / "LINKAGE_AUDIT.csv", index=False)
    pd.DataFrame(response).to_csv(O / "RESPONSE_CALIBRATION_AUDIT.csv", index=False)
    values = []
    identity_errors = []
    stocklookup = stocks.set_index(["date", "GESTFIPS", "measure", "band"]).stock
    for date, d in matched.groupby("date"):
        for measure in ["FT", "E"]:
            for band in ["q5", "q14"]:
                for order in ["age_first", "symmetric_age"]:
                    c, a0, a1 = components(d, measure, band, order)
                    original_weight_change = (d.P_next - d.P) * a1
                    for method in METHODS:
                        w = d["w_" + method].to_numpy()
                        out = pd.DataFrame({k: w * v for k, v in c.items()})
                        out["GESTFIPS"] = d.GESTFIPS.to_numpy()
                        out["weight_change"] = original_weight_change.to_numpy()
                        agg = out.groupby("GESTFIPS").sum()
                        for state in sorted(data[date].GESTFIPS.unique()):
                            if state not in agg.index:
                                agg.loc[state] = 0
                            before = float(
                                stocklookup.loc[
                                    (d.origin_date.iloc[0], state, measure, band)
                                ]
                            )
                            after = float(stocklookup.loc[(date, state, measure, band)])
                            delta = after - before
                            flow = float(agg.loc[state, BEHAVIOR].sum())
                            agg.loc[state, "frame_reconciliation"] = (
                                delta - flow - agg.loc[state, "weight_change"]
                            )
                            error = abs(
                                float(
                                    agg.loc[
                                        state,
                                        BEHAVIOR
                                        + ["weight_change", "frame_reconciliation"],
                                    ].sum()
                                )
                                - delta
                            )
                            identity_errors.append(error)
                        agg = agg.reset_index()
                        (
                            agg["date"],
                            agg["origin_date"],
                            agg["measure"],
                            agg["band"],
                            agg["method"],
                            agg["ordering"],
                        ) = (date, d.origin_date.iloc[0], measure, band, method, order)
                        values.append(agg)
        print("Accounted", date, flush=True)
    result = pd.concat(values, ignore_index=True)
    result.to_parquet(O / "MONTHLY_STATE_COMPONENTS.parquet", index=False)
    (O / "BUILD_CHECKS.json").write_text(
        json.dumps(
            dict(
                passed=True,
                source_months=len(data),
                adjacent_pairs=len(linkaudit),
                matched_pairs=len(matched),
                age_domain=[21, 26],
                target_age=[22, 25],
                primary_weight="ipw",
                rotation_probability=0.75,
                all_origin_calibrations_passed=True,
                maximum_state_pair_closure_error=max(identity_errors),
                no_individual_gap_imputation=True,
                source_cache_audit=rawaudit,
                figures_displayed=0,
            ),
            indent=2,
        )
    )
    assert max(identity_errors) < 1e-6
    print("Stock-flow build passed", len(matched), max(identity_errors), flush=True)


if __name__ == "__main__":
    O.mkdir(parents=True, exist_ok=True)
    main()
