"""Restrict young-worker DID to bijective unchanged occupation codes."""

from pathlib import Path
import sys, json
import pandas as pd

R = Path.cwd()
sys.path.insert(0, str(R / "work/us_symmetric_validation_20261125"))
import run_validation as rv

U = Path(
    "/Users/deep1003/Library/Mobile Documents/com~apple~CloudDocs/data3/AI_Graduate_Employment_20261114/us_external_validation_20261118"
)
links = pd.read_csv(U / "derived/census_soc_links.csv")
tasks = pd.read_csv(U / "derived/us_task_scores.csv")
coverage = links.assign(matched=links.soc.isin(tasks.soc)).groupby("occ").matched.mean()
keep = pd.DataFrame({"new": coverage.index[coverage.ge(0.8)]})
original = rv.RAW.copy()
before, _ = rv.prepare("22–25", 47)
rv.RAW = original[original.occupation.isin(keep.new)].copy()
a, support = rv.prepare("22–25", 47)
x, names = rv.design(a)
print(
    "START SOC link coverage >=80% occupations",
    len(keep),
    "supported",
    a.occupation.nunique(),
    "cells",
    len(a),
    flush=True,
)
b, v, v2, info, _, _ = rv.fit(a, "FT", x, names, backend="cg")
row = {
    **support,
    **info,
    **rv.contrast(b, v, names, "DID", info["occupation_clusters"] - 1),
    "age": "22–25",
    "window": 47,
    "outcome": "FT",
    "spec": "SOC_link_coverage_at_least_80pct",
    "eligible_codes": len(keep),
    "FT_share_of_primary_support": a.FT.sum() / before.FT.sum(),
}

O = R / "work/us_expert_audit_20261125"
pd.DataFrame([row]).to_csv(O / "coverage80_sensitivity.csv", index=False)
(O / "coverage80_sensitivity.json").write_text(json.dumps(row, indent=2))
keep.to_csv(O / "coverage80_occupation_codes.csv", index=False)
print(json.dumps(row, indent=2), flush=True)
