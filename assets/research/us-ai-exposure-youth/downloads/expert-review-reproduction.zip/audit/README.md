# Expert audit reproduction

This folder documents an internal three-agent computational audit of the current national monthly CPS occupational THAIE analysis. It does not certify every earlier research branch or replace external peer review.

Use the project Python environment with single-threaded BLAS. Audit scripts write tables and logs; they do not display figures. `report.py` saves and closes figures using Agg.

Before publishing, run these project-relative scripts in order.

1. `work/us_expert_audit_20261125/validate_cache_provenance.py`
2. `work/us_symmetric_validation_20261125/report.py`
3. `work/us_symmetric_validation_20261125/publish.py`
4. `work/us_symmetric_validation_20261125/apply_presentation_audit.py`
5. `work/us_expert_audit_20261125/finalize_review.py`
6. `work/us_symmetric_validation_20261125/check_publication.py`

The helper order matters because the original publisher rebuilds the Methods and Discussion. The presentation and audit helpers apply reviewed corrections afterward. The archive includes project-relative code, not a standalone installation. Original raw archives, embeddings and proprietary local project organization are not bundled. The preserved pre-audit archive remains local as evidence for retrospective cache attestation.

The current primary counts and estimates were not changed. Five additional sensitivity fits, independent source retrievals, expanded sampled regeneration, formula reconstruction and cache invalidation tests are recorded separately. Influence-selected exclusions are post hoc diagnostics, not confirmatory results. An arbitrary 80% score-link coverage rule is sensitivity analysis, not a validated selection threshold.
