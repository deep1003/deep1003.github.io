"""Independent scoped data audit; no plotting."""

from pathlib import Path
import importlib.util, json
import pandas as pd
import numpy as np

R = Path.cwd()
P = R / "outputs/US_THAIE_Regional_Youth_20261122"
T = R / "outputs/US_CPS_Only_Monthly_DID_20261125/tables"
spec = importlib.util.spec_from_file_location(
    "parser", P / "panel_fe3_20261122/scripts/prepare_panel.py"
)
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)
manifest = json.loads(
    (
        R / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json"
    ).read_text()
)
idx = {(x["year"], x["month"]): x for x in manifest if x.get("available", True)}
parser.source = lambda y, m: (Path(idx[y, m]["path"]), Path(idx[y, m]["dictionary"]))
conv = pd.read_csv(P / "extension_2019/derived/occupation_conversion_2010_2018.csv")
score = pd.read_csv(T / "frozen_THAIE_occupation_assignments.csv")
stored = pd.read_parquet(T / "occupation_industry_monthly_counts.parquet")
out = []
for y, m in [(2018, 12), (2019, 10), (2020, 1), (2022, 11), (2026, 10)]:
    d, _ = parser.read(y, m)
    d = d[d.PRTAGE.ge(22) & d.nE.eq(1)].copy()
    d["age"] = pd.cut(
        d.PRTAGE,
        [21, 25, 30, 34, 40, 49, 200],
        labels=["22–25", "26–30", "31–34", "35–40", "41–49", "50+"],
    ).astype(str)
    # Classification checked against a separate official recode.
    mismatch = ((d.PRFTLF.eq(1)) != d.PRWKSTAT.isin([2, 3, 4, 5])).sum()
    if y < 2020:
        d = d.merge(conv, left_on="occ", right_on="old", how="left")
        d["occupation"] = d.new.fillna(-1).astype(int)
        d[["E", "FT", "PT"]] = d[["E", "FT", "PT"]].mul(d.rate.fillna(1), axis=0)
    else:
        d["occupation"] = d.occ
    g = d.groupby(["age", "occupation", "PRMJIND1"])[["E", "FT", "PT"]].sum()
    a = (
        stored[stored.date.eq(f"{y}-{m:02}-01")]
        .rename(columns={"industry": "PRMJIND1"})
        .groupby(["age", "occupation", "PRMJIND1"])[["E", "FT", "PT"]]
        .sum()
    )
    j = g.subtract(a, fill_value=0)
    out.append(
        {
            "month": f"{y}-{m:02}",
            "all_age_cell_max_difference": float(abs(j).max().max()),
            "FT_vs_PRWKSTAT_mismatch": int(mismatch),
            "respondents": len(d),
        }
    )
    assert abs(j).max().max() < 1e-6 and mismatch == 0
# Reconstruct quintile thresholds from stored score and 2019 weights.
s = pd.read_csv(P / "high_exposure_quality/derived/occupation_quintiles.csv")
ordered = s.sort_values(["THAIE", "occ"])
cdf = ordered.emp2019.cumsum() / ordered.emp2019.sum()
cuts = [
    float(ordered.iloc[np.searchsorted(cdf, q)].THAIE) for q in [0.2, 0.4, 0.6, 0.8]
]
assert np.array_equal(np.searchsorted(cuts, s.THAIE, side="right") + 1, s.THAIE_q)
cov = pd.read_csv(T / "exposure_linkage_coverage.csv")
by = (
    cov.groupby(cov.date.str[:4])
    .supported_exposure_share.agg(["min", "mean", "max"])
    .to_dict("index")
)
record = {
    "raw_cell_checks": out,
    "quintile_cutpoints_reproduced": cuts,
    "annual_exposure_coverage": by,
    "crosswalk_split_codes": int((conv.groupby("old").size() > 1).sum()),
    "independent_parser": False,
    "scope": "Parser rerun with separate PRWKSTAT definition and aggregation checks; not independent official source verification",
}
(R / "work/us_expert_audit_20261125/data_checks.json").write_text(
    json.dumps(record, indent=2)
)
print(json.dumps(record, indent=2))
