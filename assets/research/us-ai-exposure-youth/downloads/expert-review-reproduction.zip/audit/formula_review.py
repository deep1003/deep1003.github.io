"""Recompute task-level THAIE and hierarchy from source inputs; no plots."""

from pathlib import Path
import json, zipfile, hashlib
import pandas as pd
import numpy as np
from sklearn.linear_model import RidgeCV
from scipy.special import expit

R = Path.cwd()
B = Path(
    "/Users/deep1003/Library/Mobile Documents/com~apple~CloudDocs/data3/AI_Graduate_Employment_20261114"
)
U = B / "us_external_validation_20261118"
P = R / "outputs/US_THAIE_Regional_Youth_20261122"
O = R / "work/us_expert_audit_20261125"
t = pd.read_csv(U / "derived/us_task_scores.csv")
labels = pd.read_csv(B / "time_horizon_scaleup_20261115/results/onet_labels_v2.csv")
X = np.load(B / "time_horizon_scaleup_20261115/en_bge-m3.npy").astype(float)
assert np.array_equal(t.task_id, labels["Task ID"])
assert not t.duplicated(["onet_soc", "task_id"]).any()
curves = pd.read_csv(
    B / "metr_duration_index_pilot_20261115/derived/metr_model_inputs.csv"
).set_index("model_id")
c = curves.loc["gpt_5_2025_08_07_inspect"]
h50 = float(c.p50_estimate)
h80 = float(c.p80_estimate)
k = np.log(4) / np.log2(h50 / h80)
assert 0 < h80 < h50 and k > 0
f = RidgeCV(alphas=[0.3, 1, 3, 10, 30]).fit(X, labels.y.to_numpy())
e = np.clip(f.predict(X), 0, 1)
ok = labels.lt_obs.notna()
fd = RidgeCV(alphas=[0.3, 1, 3, 10, 30]).fit(X[ok], labels.loc[ok, "lt_obs"])
ld = fd.predict(X)
assert np.isfinite(ld).all()
d = np.exp(ld)
assert (d > 0).all()
p = expit(k * (np.log2(h50) - ld / np.log(2)))
p_error = float(abs(p - t.p).max())
ld_error = float(abs(ld - t.ld_pred).max())
assert p_error < 1e-8 and ld_error < 1e-8
th = e * p
tm = e * np.minimum(1, h50 / d)
assert np.isfinite(e).all() and ((e >= 0) & (e <= 1)).all()
assert ((th >= 0) & (th <= e + 1e-12)).all()
assert np.allclose(th + e * (1 - p), e)
anchors = [float(expit(k * np.log2(h50 / v))) for v in [h50, h80]]
assert np.allclose(anchors, [0.5, 0.8])
grid = np.geomspace(d.min() / 100, d.max() * 100, 1000)
assert np.all(np.diff(expit(k * np.log2(h50 / grid))) <= 0)
hgrid = np.geomspace(h50 / 1000, h50 * 1000, 1000)
assert np.all(np.diff(expit(k * np.log2(hgrid / 100))) >= 0)
t["E"] = e
t["THAIE"] = th
t["TIME"] = tm
t["ld"] = ld
t["ed"] = e * d
t["duration"] = d
q = t.groupby("onet_soc")[["E", "THAIE", "TIME", "ld"]].mean()
q["TIME_SHARE"] = t.groupby("onet_soc").ed.sum() / t.groupby("onet_soc").duration.sum()
q["soc"] = t.groupby("onet_soc").soc.first()
soc = q.groupby("soc")[["E", "THAIE", "TIME", "ld", "TIME_SHARE"]].mean()
links = pd.read_csv(U / "derived/census_soc_links.csv")
assert not links.duplicated(["occ", "soc"]).any()
joined = links.join(soc, on="soc")
unmatched_links = int(joined.THAIE.isna().sum())
census = (
    joined.groupby("occ")[["E", "THAIE", "TIME", "ld", "TIME_SHARE"]].mean().dropna()
)
saved = pd.read_csv(P / "extension_2019/derived/common_census_scores.csv").set_index(
    "occ"
)
diff = {
    v: float(abs(census.loc[saved.index, v] - saved[v]).max())
    for v in ["E", "THAIE", "TIME", "ld", "TIME_SHARE"]
}
assert max(diff.values()) < 1e-8
# Explicit effective task weights under equal tasks, equal O*NET suboccupations,
# then equal matched SOC links. Missing source SOCs are excluded by pandas mean.
validlinks = links[links.soc.isin(soc.index)]
nt = t.groupby("onet_soc").size()
no = q.groupby("soc").size()
nl = validlinks.groupby("occ").size()
w = validlinks.merge(t[["onet_soc", "soc", "task_id"]], on="soc")
w["weight"] = 1 / (w.onet_soc.map(nt) * w.soc.map(no) * w.occ.map(nl))
ws = w.groupby("occ").weight.sum()
assert np.allclose(ws, 1)
zip_path = Path(
    "/Users/deep1003/Library/Mobile Documents/com~apple~CloudDocs/data3/Humanities/26_HSSC_SUBMITTED_8e5cae5c/01_submitted_files/THAIE_manuscript_review.zip"
)
with zipfile.ZipFile(zip_path) as z:
    texes = [n for n in z.namelist() if n.endswith(".tex")]
    manuscript = "\n".join(z.read(n).decode(errors="replace") for n in texes)
formula_found = "\\lambda_s(m)=e_s" in manuscript and "log_2" in manuscript
record = {
    "passed": True,
    "tasks": len(t),
    "onet": len(q),
    "soc": len(soc),
    "census_complete": len(saved),
    "task_label_id_alignment": True,
    "h50_minutes": h50,
    "h80_minutes": h80,
    "kappa_per_log2": k,
    "completion_at_h50_h80": anchors,
    "completion_probability_max_error": p_error,
    "duration_log_prediction_max_error": ld_error,
    "score_reproduction_max_abs_difference": diff,
    "effective_task_weight_sum_max_error": float(abs(ws - 1).max()),
    "unmatched_soc_links_excluded_by_mean": unmatched_links,
    "duration_minutes_range": [float(d.min()), float(d.max())],
    "predicted_content_range": [float(e.min()), float(e.max())],
    "clipped_content_predictions": int(((f.predict(X) < 0) | (f.predict(X) > 1)).sum()),
    "duration_training_labels": int(ok.sum()),
    "formula_in_actual_submitted_tex": formula_found,
    "submitted_zip": str(zip_path),
    "submitted_tex_members": texes,
    "monotonicity": "Verified decreasing in duration and increasing in horizon at fixed positive slope; no claim all distinct model-specific curves are ordered",
    "unverified": [
        "External calibration/transfer of completion curve to workplace domains",
        "Human task durations are model-based estimates, not measured production time",
        "Exposure predictions are fitted on the rating sample, not out-of-sample outcome validation",
        "No bootstrap propagation of content-duration-horizon-linkage uncertainty",
        "Equal task and hierarchical occupation weights are a modeling choice, not measured task-time shares",
        "Current American study estimand/quintile definition differs from Korean submitted empirical design",
    ],
}
link_coverage = (
    links.assign(matched=links.soc.isin(soc.index)).groupby("occ").matched.mean()
)
retained_coverage = link_coverage.reindex(saved.index)
record["SOC_link_coverage"] = {
    "total_links": len(links),
    "census_occupations": len(link_coverage),
    "entirely_unmatched_occupations": int(link_coverage.eq(0).sum()),
    "partially_covered_occupations": int(
        link_coverage.between(0, 1, inclusive="neither").sum()
    ),
    "minimum_fraction_among_retained": float(retained_coverage.min()),
    "retained_below_80pct": int(retained_coverage.lt(0.8).sum()),
}
(O / "formula_review.json").write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
