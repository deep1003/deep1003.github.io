"""Package the specialist audit and apply reviewed public interpretations."""

from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

import pandas as pd
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = ROOT / "outputs/US_Symmetric_Validation_20261125"
SITE = ROOT / "work/homepage-monthly/assets/research/us-ai-exposure-youth"
D = SITE / "downloads"
stable = json.loads((W / "stable_code_sensitivity.json").read_text())
loo = pd.read_csv(W / "leave_one_occupation_out.csv")
variance = json.loads((W / "occupation_variance_summary.json").read_text())
retrieval = json.loads((W / "official_retrieval_check.json").read_text())
assert all(r["matches_local_manifest"] for r in retrieval)
assert json.loads((W / "cache_provenance_validation.json").read_text())["passed"]

report = r"""# Critical specialist audit of the CPS–THAIE employment analysis

## Overall assessment

Share with explicit methodological caveats. Three separate AI specialist agents reviewed statistical design and implementation, data processing, and presentation. The coordinating agent checked evidence, repaired confirmed defects, and commissioned additional refits. This is an internal computational audit, not external peer review. The scope is the current national monthly CPS occupational THAIE analysis and its active web presentation. Earlier SIPP, linked-CPS transitions, state-level panels, productivity and job-posting projects have not been revalidated by this audit.

No demonstrated arithmetic error changed the current primary coefficient. The prior claim of a robust AI-caused youth full-time employment decline is not supported. Pipeline reproducibility and presentation required repairs. Additional robustness tests strengthen the uncertainty rather than rescue significance.

## Confirmed defects and repairs

| Component | Finding | Repair and validation |
|---|---|---|
| Model caches | Reuse depended on filename existence | Require input, prepared sample, design, backend, code and environment fingerprints. Forty historical models were retrospectively attested against the preserved original archive. An intentionally changed signature fails. |
| Preparation caches | Raw or mapping changes could leave stale intermediates | Bind raw files, dictionaries, parser, preparation code, scores, crosswalk and product hashes. Legacy caches rebuild on future preparation. Temporary-file invalidation tests passed. |
| Input audit | Missing-month flag was hardcoded; frozen labels were not reconstructed | Explicit absence/nonnegative/mapping checks, five-month all-age regeneration and reconstructed 2019 weights and cutpoints. |
| Numerical validation | Only harmonized standard errors were disclosed | Publish raw and harmonized errors, exact FE rank446 versus absorbed degrees449. The adjustment factor is1.000892; coefficient agreement is4.72e−15. |
| Detailed Methods | Stale annual normalization, old analysis span and event reference | Align with November2022 baseline, current symmetric windows, support and August–October2022 reference. |
| Chart exports | Missing/suppressed measurements labeled observed | Export unavailable status; interpolation remains separately marked. |
| Accessible graph text | Sex panels described an occupation-fixed comparison | Use a correct sex-within-age/exposure description. |
| Report wording | A36-month post-period called nearly four years | Correct to three years. |

## Source and transformation checks

All94 available raw hashes match the local recorded manifest. Two archives, November2022 and October2026, were retrieved again from official Census URLs and match the stored bytes exactly. This independently checks those two retrievals, not all94 sources. Five selected months, December2018, October2019, January2020, November2022 and October2026, were regenerated for all six ages with the existing parser. Weighted occupational total, full-time and part-time cell differences were exactly zero. An alternative PRWKSTAT recode had zero discrepancies with PRFTLF in inspected employed records. The same-parser exercise does not independently validate every parser field.

The2019 composition weights and four quintile thresholds were rebuilt and reproduced every stored label. Exposure mapping coverage across age/month cells is approximately97.25–98.87%, before additional regression support restrictions. Unmapped workers are excluded, not silently placed in Q1–Q4. Supported chart series/outcome combinations numbered821 and all rebase to100 in November2022. Another439 combinations lack an eligible baseline and are suppressed.

## Statistical estimand and formulas

For age-specific occupational–industry cells, the fitted conditional mean is

$$\mathbb{E}[Y_{oit}\mid X]=\exp\{\alpha_{oi}+\gamma_{o,m(t)}+\delta_{it}+\beta Q5_o Post_t+\sum_q\theta_q Q5_o PandemicQuarter_{qt}\}.$$

Y is a survey-weighted count of usual full-time or part-time employed people, not a job count, employment probability, observed hire, or individual transition. The percentage contrast is100[exp(β)−1]. Transforming both ends of the log-coefficient interval is correct. The result is a conditional multiplicative DID contrast rather than the unadjusted ratio of two aggregate endpoints.

A common monthly age-population exposure offset is algebraically absorbed by industry×date fixed effects, so adding it does not change β. This does not adjust occupation-specific demographics or justify labeling the occupational charts employment rates. Current fixed effects are occupation×industry, occupation×season and industry×date. They are not state×industry×year fixed effects.

Standard errors are occupation-score working sandwich errors, not complete CPS survey-design errors. Repeated households, rotation overlap, occupation-code allocation and exposure measurement uncertainty are not fully propagated. Nominal463 clusters do not ensure diffuse information. The variance-concentration inverse-Herfindahl count is27.93, the largest occupation supplies8.80% of variance and the top ten supply52.42%. These are diagnostics, not substituted degrees of freedom.

## New robustness results

| Youth full-time,47-month window | Relative contrast | Raw p |
|---|---:|---:|
| Current primary | −6.60% | .069 |
| Unchanged, bijective occupation-code links | −4.28% | .292 |
| Exclude influential occupation735 | −7.64% | .030 |
| Exclude influential occupation5000 | −5.71% | .111 |
| Exclude influential occupation4850 | −7.46% | .039 |

The stable-code result has95% CI[−11.77%,+3.85%] and retains74.85% of primary-support weighted FT employment, with329 supported occupations. It changes both mapping exposure and sample composition, so attenuation cannot be attributed uniquely to crosswalk bias. Leave-one-occupation-out exclusions were selected after inspecting influence and are post hoc, uncorrected diagnostics. Their nominally significant estimates must not be promoted as confirmatory evidence. The direction remains negative while nominal significance changes.

A minimum80% matched-SOC coverage restriction, preserving original quintile assignments, gives −6.05% (95% CI[−12.70%,+1.11%],p=.096), retaining94.63% of primary-support FT employment. This arbitrary-threshold eligibility sensitivity does not establish unbiased scores.

## Assumptions and unresolved limitations

1.2019 freezes composition and cutpoints, not the date when the score was measured. THAIE uses retrospective task and capability information. It is neither observed pre-event adoption nor a randomized treatment.
2.Pre2020 national fractional code allocations and directly reported2020+ codes differ in measurement. Fifty-six old codes split. Current intervals do not capture allocation uncertainty.
3.Pandemic-quarter interactions absorb Q5 gaps in2020–2021. Nominal symmetric windows leave only23 or12 nonpandemic premonths. The raw youth FT lead test p=.029 remains a concern. Holm nonrejection is not proof of parallel trends.
4.The pooled pre/post Q5 linear trend can absorb a genuine gradual response as well as pre-existing divergence. It is a sensitivity analysis rather than a definitive correction.
5.Common positive FT/PT support depends on observed outcomes. The FT-only sensitivity is useful but does not eliminate survey sparsity or selection.
6.PRFTLF refers to usual hours across jobs while occupational exposure follows the primary job. Full-time does not mean permanent employment; part-time does not mean temporary, contract or involuntary work. Repeated cross-sections do not trace workers.
7.The12-test Holm family does not adjust for the full historical sequence of investigated outcomes, age boundaries and specifications. This is exploratory work. Joint-zero tests assess fitted coefficients, not AI causality; nonsignificance establishes neither zero effects nor age equivalence.

## Revised interpretation and research priorities

Retain a cautious descriptive signal of relatively weaker youth full-time employment in high-exposure occupations. Do not claim a robust causal AI effect, a demonstrated full-time-to-part-time move, an affected-age boundary, or permanent-to-contract displacement. First harmonize occupation groups over time and assess benchmark-vintage sensitivity. Then obtain suitable survey-design information and longitudinal hours, involuntary part-time, earnings, employer adoption and contract measures. New data access is not a prerequisite for correcting the current analysis.

Official definitions and coding documentation are available from [BLS CPS concepts](https://www.bls.gov/cps/definitions.htm), [BLS CPS technical documentation](https://www.bls.gov/cps/documentation.htm) and [Census occupation classification](https://www.census.gov/programs-surveys/cps/technical-documentation/methodology/industry-and-occupation-classification.html). October2025 CPS data were not collected, as noted in the [BLS full-/part-time table](https://www.bls.gov/cps/cpsaat08.htm). Display interpolation does not create an observed survey month.
"""
# Avoid ambiguous typography without changing the mathematical formula.
formula = json.loads((W / "formula_review.json").read_text())
assert formula["passed"]
report = report.replace(
    "## Statistical estimand and formulas",
    r"""## THAIE formula and score reconstruction

The specialist rebuilt content and log-duration predictions from original embeddings and rating inputs, then checked the actual submitted TeX equation. For task j, the implementation is

$$p_j=\operatorname{logit}^{-1}\{\kappa\log_2(h_{50}/d_j)\},\qquad \mathrm{THAIE}_j=e_jp_j,\qquad \mathrm{TIME}_j=e_j\min(1,h_{50}/d_j).$$

The slope is κ=ln(4)/log₂(h₅₀/h₈₀). The selected curve has h₅₀=203.012577 minutes, h₈₀=38.312431 minutes and κ=0.5762577283. Completion probabilities at those anchors are exactly0.5 and0.8 within floating-point tolerance. Reconstructed probabilities differ by at most2.78e−16. Scores for19,265 tasks through923 O*NET,798 SOC and547 retained Census occupations reproduce stored E,THAIE,TIME and duration quantities within8.89e−16. Effective hierarchical task weights sum to one. Positive durations, bounded content predictions,0≤THAIE≤E and monotonic duration/fixed-slope horizon relationships passed. Content clipping affected2,131 predictions and is an explicit modeling choice, not a newly discovered numerical failure.

The hierarchy gives equal weight to tasks within O*NET suboccupations, suboccupations within SOC, and matched SOC links within Census occupations. These are not measured workplace time shares. Of867 Census–SOC links,69 lack scores. Twenty-one Census occupations are entirely unmatched and excluded;31 retained occupations are only partially covered, including22 below80% link coverage. Means renormalize over matched links. This was previously insufficiently disclosed and is a measurement/selection risk, not an established arithmetic error. Curve calibration transfer to workplaces, prediction validity and uncertainty propagation remain unverified.

## Statistical estimand and formulas""",
)
report = (
    re.sub(
        r"(?<=[A-DF-Za-df-z])(?=[0-9])|(?<=[0-9])(?=[A-DF-Za-df-z])",
        " ",
        report.split("Official definitions")[0],
    )
    + "Official definitions"
    + report.split("Official definitions", 1)[1]
)
for before, after in [
    ("All94", "All 94"),
    ("all94", "all 94"),
    ("numbered821", "numbered 821"),
    ("Another439", "Another 439"),
]:
    report = report.replace(before, after)
report = (
    report.replace("1.2019", "1. 2019")
    .replace("2.Pre2020", "2. Pre-2020")
    .replace("3.Pandemic", "3. Pandemic")
    .replace("4.The", "4. The")
    .replace("5.Common", "5. Common")
    .replace("6.PRFTLF", "6. PRFTLF")
    .replace("7.The12", "7. The 12")
)
for q in range(1, 6):
    report = report.replace(f"Q {q}", f"Q{q}")
report = report.replace(",", ", ")
report = re.sub(r"(?<=\d), (?=\d{3}\b)", ",", report)
report = re.sub(r" {2,}", " ", report)
(O / "EXPERT_CRITICAL_REVIEW_EN.md").write_text(report)
assert not any(ord(c) < 32 and c not in "\n\t\r" for c in report)
shutil.copy2(O / "EXPERT_CRITICAL_REVIEW_EN.md", D / "EXPERT_CRITICAL_REVIEW_EN.md")
for name in ["DATA_REVIEW_EN.md", "METHODS_REVIEW_EN.md", "formula_review.md"]:
    shutil.copy2(W / name, D / name)
shutil.copy2(
    O / "PRESENTATION_EXPERT_AUDIT_EN.md", D / "PRESENTATION_EXPERT_AUDIT_EN.md"
)
for name in [
    "leave_one_occupation_out.csv",
    "stable_code_sensitivity.csv",
    "occupation_variance_summary.json",
    "data_checks.json",
    "official_retrieval_check.json",
    "cache_provenance_validation.json",
    "formula_review.json",
    "coverage80_sensitivity.csv",
]:
    shutil.copy2(W / name, D / ("expert-" + name))

soup = BeautifulSoup((SITE / "index.html").read_text(), "html.parser")
old = soup.find(id="expert-critical-review")
if old:
    old.decompose()
block = """<details class="result" id="expert-critical-review"><summary>Critical specialist audit — corrected pipeline, measurement and interpretation</summary><div class="result-body"><p>Three separate AI specialist agents reviewed data processing, statistical methods, and presentation. This internal computational audit is not external peer review. It covers the current national monthly occupational CPS–THAIE analysis; earlier state, SIPP and posting analyses were not revalidated here.</p><p>No demonstrated coefficient arithmetic error changed the primary result. We repaired stale detailed Methods, missing-value export labels, accessible chart descriptions, hardcoded audit flags and unversioned cache reuse. Five selected months across six ages reproduced counts exactly. Two raw archives were retrieved again from Census and matched local bytes. The 2019 composition weights and quintile cutpoints were reconstructed.</p><div class="table-scroll"><table><caption>Additional youth full-time robustness. These are exploratory diagnostics; raw p-values are uncorrected.</caption><thead><tr><th>Specification</th><th>Relative contrast</th><th>Raw p</th></tr></thead><tbody><tr><td>Primary 47-month window</td><td>−6.60%</td><td>.069</td></tr><tr><td>Unchanged, bijective occupation codes</td><td>−4.28%</td><td>.292</td></tr><tr><td>Exclude influential occupation 735</td><td>−7.64%</td><td>.030</td></tr><tr><td>Exclude influential occupation 5000</td><td>−5.71%</td><td>.111</td></tr><tr><td>Exclude influential occupation 4850</td><td>−7.46%</td><td>.039</td></tr></tbody></table></div><p>The stable-code restriction retains 74.85% of primary-support full-time employment, so differences also reflect sample composition. The occupation exclusions were selected after inspecting influence and do not rescue confirmatory significance. The largest ten occupations supply 52.42% of working variance. Nominal significance is sensitive to occupational coverage.</p><p>Fresh reconstruction of 19,265 task scores reproduced the THAIE formula and hierarchical aggregation within floating-point tolerance. Partial SOC linkage remains a measurement risk. Restricting to at least 80% matched SOC links gives −6.05% (p=.096), retaining 94.63% of primary-support FT employment.</p><p>Standard errors agree with an explicit-dummy reference after harmonizing the finite-sample degrees convention, not through independent validation of that convention. They do not implement the complete CPS survey design. The 2019 baseline fixes composition, not score vintage. Retrospective exposure, occupation-code bridging, selection and imperfect parallel trends remain limitations. Full-time versus part-time does not identify permanent versus contract work or individual transitions. A joint-zero coefficient test is not a test of AI causality.</p><p><a href="downloads/EXPERT_CRITICAL_REVIEW_EN.md">Full critical review</a> · <a href="downloads/expert-stable_code_sensitivity.csv">Stable-code test</a> · <a href="downloads/expert-leave_one_occupation_out.csv">Influential-occupation tests</a> · <a href="downloads/expert-review-reproduction.zip">Audit evidence and code</a></p></div></details>"""
soup.find(id="symmetric-validation").insert_after(BeautifulSoup(block, "html.parser"))
discussion = soup.find(id="discussion")
note = discussion.find(id="expert-discussion-note")
if note:
    note.decompose()
discussion.append(
    BeautifulSoup(
        '<p id="expert-discussion-note">The subsequent specialist audit confirms additional sensitivity. A stable occupation-code restriction gives −4.28% (p=.292), and single influential occupation exclusions give raw p-values from .030 to .111. These post hoc diagnostics reinforce the exploratory interpretation. See the critical review for repaired calculations, documentation and remaining assumptions.</p>',
        "html.parser",
    )
)
for panel in soup.select("#results details"):
    panel.attrs.pop("open", None)
soup.find(id="story-overall")["open"] = ""
script_hash = hashlib.sha256((SITE / "story.js").read_bytes()).hexdigest()[:12]
for script in soup.find_all("script", src=True):
    if script["src"].split("?")[0] == "story.js":
        script["src"] = "story.js?v=expert-audit-" + script_hash
(SITE / "index.html").write_text(str(soup))

with zipfile.ZipFile(
    D / "expert-review-reproduction.zip", "w", zipfile.ZIP_DEFLATED
) as z:
    z.write(O / "EXPERT_CRITICAL_REVIEW_EN.md", "EXPERT_CRITICAL_REVIEW_EN.md")
    z.write(O / "PRESENTATION_EXPERT_AUDIT_EN.md", "PRESENTATION_EXPERT_AUDIT_EN.md")
    for f in W.iterdir():
        if f.is_file() and f.suffix in [".py", ".md", ".csv", ".json", ".log"]:
            z.write(f, "audit/" + f.name)
    for name in [
        "run_validation.py",
        "independent_check.py",
        "audit_inputs.py",
        "attest_legacy_caches.py",
        "apply_presentation_audit.py",
    ]:
        z.write(ROOT / "work/us_symmetric_validation_20261125" / name, "code/" + name)
    z.write(
        ROOT / "work/us_cps_only_monthly_did_20261125/prepare.py", "code/prepare.py"
    )

manifest = dict(
    main_coefficients_unchanged=True,
    assessment="Share with explicit methodological caveats",
    internal_AI_specialist_agents=3,
    new_robustness_models=5,
    official_retrievals_matched=2,
    plots_displayed=False,
    report_sha256=hashlib.sha256(report.encode()).hexdigest(),
)
(W / "review_completion.json").write_text(json.dumps(manifest, indent=2))
print(json.dumps(manifest))
