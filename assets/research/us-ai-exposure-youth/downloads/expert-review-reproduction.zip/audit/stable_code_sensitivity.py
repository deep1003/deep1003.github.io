"""Restrict young-worker DID to bijective unchanged occupation codes."""

from pathlib import Path
import sys, json
import pandas as pd

R = Path.cwd()
sys.path.insert(0, str(R / "work/us_symmetric_validation_20261125"))
import run_validation as rv

conv = pd.read_csv(
    R
    / "outputs/US_THAIE_Regional_Youth_20261122/extension_2019/derived/occupation_conversion_2010_2018.csv"
)
old_n = conv.groupby("old").size()
new_n = conv.groupby("new").size()
keep = conv[
    conv.old.eq(conv.new)
    & conv.old.map(old_n).eq(1)
    & conv.new.map(new_n).eq(1)
    & conv.rate.eq(1)
]
original = rv.RAW.copy()
before, _ = rv.prepare("22–25", 47)
rv.RAW = original[original.occupation.isin(keep.new)].copy()
a, support = rv.prepare("22–25", 47)
x, names = rv.design(a)
print(
    "START stable unchanged bijective occupations",
    len(keep),
    "supported",
    a.occupation.nunique(),
    "cells",
    len(a),
    flush=True,
)
b, v, v2, info, _, _ = rv.fit(a, "FT", x, names, backend="cg")
row = {
    **support,
    **info,
    **rv.contrast(b, v, names, "DID", info["occupation_clusters"] - 1),
    "age": "22–25",
    "window": 47,
    "outcome": "FT",
    "spec": "unchanged_bijective_occupation_codes",
    "eligible_codes": len(keep),
    "FT_share_of_primary_support": a.FT.sum() / before.FT.sum(),
}

O = R / "work/us_expert_audit_20261125"
pd.DataFrame([row]).to_csv(O / "stable_code_sensitivity.csv", index=False)
(O / "stable_code_sensitivity.json").write_text(json.dumps(row, indent=2))
keep.to_csv(O / "stable_occupation_codes.csv", index=False)
print(json.dumps(row, indent=2), flush=True)
