"""Influence concentration and leave-one-occupation-out diagnostic; no plots."""

from pathlib import Path
import sys
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "work/us_symmetric_validation_20261125"))
from run_validation import prepare, design, fit, contrast, W

OUT = Path(__file__).resolve().parent
p = np.load(W / "influence_22–25_47_main_FT.npz")
squared = p["influence"] ** 2
shares = squared / squared.sum()
concentration = pd.DataFrame(
    {
        "occupation": p["occupation"],
        "influence": p["influence"],
        "variance_share": shares,
    }
).sort_values("variance_share", ascending=False)
concentration.to_csv(OUT / "occupation_variance_concentration.csv", index=False)
(OUT / "occupation_variance_summary.json").write_text(
    json.dumps(
        {
            "nominal_clusters": len(shares),
            "inverse_Herfindahl_variance_concentration_count": float(
                1 / (shares @ shares)
            ),
            "maximum_variance_share": float(shares.max()),
            "top10_variance_share": float(concentration.head(10).variance_share.sum()),
            "not_formal_degrees_of_freedom": True,
        },
        indent=2,
    )
)
a, _ = prepare("22–25", 47)
rows = []
for occ in concentration.head(3).occupation:
    cache = OUT / f"leave_out_{occ}.json"
    if cache.exists():
        rows.append(json.loads(cache.read_text()))
        continue
    d = a[a.occupation.ne(occ)].copy()
    for _ in range(30):
        n = len(d)
        for fe in ["occ_industry", "occ_season", "industry_date"]:
            totals = d.groupby(fe).FT.sum()
            d = d[d[fe].isin(totals.index[totals.gt(0)])]
        if len(d) == n:
            break
    x, names = design(d)
    b, v, v2, info, inf, groups = fit(d, "FT", x, names, backend="cg")
    row = {
        "excluded_occupation": int(occ),
        "original_variance_share": float(
            concentration.set_index("occupation").loc[occ, "variance_share"]
        ),
        "N": len(d),
        "occupation_clusters": info["occupation_clusters"],
        **contrast(b, v, names, "DID", info["occupation_clusters"] - 1),
    }
    cache.write_text(json.dumps(row, indent=2))
    rows.append(row)
    pd.DataFrame(rows).to_csv(OUT / "leave_one_occupation_out.csv", index=False)
    print(json.dumps(row), flush=True)
print("LEAVE-ONE-OUT CHECK COMPLETE. No plots displayed.", flush=True)
