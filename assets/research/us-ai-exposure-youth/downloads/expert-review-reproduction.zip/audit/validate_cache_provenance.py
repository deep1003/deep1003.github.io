"""Fail-closed publication prerequisite; no models are refitted and no plots emitted."""

from pathlib import Path
import sys, json

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "work/us_symmetric_validation_20261125"))
from run_validation import validate_all_caches

result = validate_all_caches()
(Path(__file__).resolve().parent / "cache_provenance_validation.json").write_text(
    json.dumps(result, indent=2)
)
print(
    json.dumps(
        {
            "passed": result["passed"],
            "verified_cache_count": result["verified_cache_count"],
            "figures_displayed": False,
        }
    )
)
