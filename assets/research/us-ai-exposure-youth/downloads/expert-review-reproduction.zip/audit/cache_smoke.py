"""Exercise provenance helpers without executing preparation or using real caches."""

import ast, hashlib, json, tempfile
from pathlib import Path

source = Path("work/us_cps_only_monthly_did_20261125/prepare.py")
tree = ast.parse(source.read_text())
defs = [n for n in tree.body if isinstance(n, ast.FunctionDef)]
ns = {"Path": Path, "hashlib": hashlib, "json": json}
exec(compile(ast.Module(body=defs, type_ignores=[]), str(source), "exec"), ns)
with tempfile.TemporaryDirectory() as root:
    p = Path(root)
    raw = p / "raw"
    product = p / "product"
    side = p / "record.json"
    raw.write_text("input")
    product.write_text("output")
    sig = ns["cache_signature"]([raw])
    assert not ns["cache_valid"](side, sig, [product])
    ns["write_cache_record"](side, sig, [product])
    assert ns["cache_valid"](side, sig, [product])
    raw.write_text("changed input")
    sig2 = ns["cache_signature"]([raw])
    assert not ns["cache_valid"](side, sig2, [product])
    assert ns["cache_valid"](side, sig, [product])
    product.write_text("corrupted")
    assert not ns["cache_valid"](side, sig, [product])
    side.write_text("{bad json")
    assert not ns["cache_valid"](side, sig, [product])
print(
    "CACHE PROVENANCE SMOKE PASSED: legacy, unchanged, changed inputs, corrupt output and invalid JSON; no research data mutated"
)
