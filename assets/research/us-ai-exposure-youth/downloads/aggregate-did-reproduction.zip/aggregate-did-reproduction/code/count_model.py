"""Conditional two-group count QMLE with state-cluster CR1 inference."""
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.optimize import minimize
from scipy.special import expit
from scipy.stats import t

def design(data, stage):
    n = len(data)
    names = []
    parts = []
    if stage == "pooled":
        parts.append(sparse.csr_matrix(np.ones((n, 1))))
        names.append("intercept")
    else:
        values = data.GESTFIPS.astype(str) if stage == "state" else data.stratum
        levels = sorted(values.unique())
        lookup = {value: i for i, value in enumerate(levels)}
        parts.append(
            sparse.csr_matrix(
                (np.ones(n), (np.arange(n), values.map(lookup))), shape=(n, len(levels))
            )
        )
        names.extend("FE_" + value for value in levels)
    for year in sorted(data.year.unique()):
        if year == 2022:
            continue
        parts.append(
            sparse.csr_matrix(data.year.eq(year).to_numpy()[:, None].astype(float))
        )
        names.append(f"year_{year}")
    if stage == "state_industry_covid":
        for variable in ["covid", "recovery"]:
            for year in range(2021, 2027):
                parts.append(
                    sparse.csr_matrix(
                        (data[variable] * data.year.eq(year)).to_numpy()[:, None]
                    )
                )
                names.append(f"{variable}_{year}")
    return sparse.hstack(parts, format="csr"), names


def fit(data, stage):
    x, names = design(data, stage)
    scale = 1e5
    trials = data.trials.to_numpy() / scale
    high = data.high.to_numpy() / scale

    def objective(beta):
        eta = x @ beta
        value = np.sum(trials * np.logaddexp(0, eta) - high * eta)
        gradient = np.asarray(x.T @ (trials * expit(eta) - high)).ravel()
        return value, gradient

    initial = np.zeros(x.shape[1])
    if stage == "pooled":
        initial[0] = np.log(high.sum() / (trials.sum() - high.sum()))
    else:
        key = data.GESTFIPS.astype(str) if stage == "state" else data.stratum
        grouped = data.groupby(key)[["high", "other"]].sum()
        levels = sorted(key.unique())
        initial[: len(levels)] = np.log(
            grouped.loc[levels, "high"] / grouped.loc[levels, "other"]
        )
    result = minimize(
        objective,
        initial,
        jac=True,
        method="L-BFGS-B",
        options={"maxiter": 2500, "ftol": 1e-13, "gtol": 1e-8, "maxls": 40},
    )
    beta = result.x
    for _ in range(4):
        value, gradient = objective(beta)
        probability = expit(x @ beta)
        curvature = trials * probability * (1 - probability)
        hessian = (x.T @ x.multiply(curvature[:, None])).toarray()
        delta = np.linalg.solve(hessian, gradient)
        if np.max(abs(delta)) < 1e-9:
            break
        step = 1.0
        while step > 1e-6:
            candidate = beta - step * delta
            if objective(candidate)[0] <= value + 1e-10:
                beta = candidate
                break
            step /= 2
    value, gradient = objective(beta)
    assert np.max(abs(gradient)) < 1e-5, (stage, result.message, np.max(abs(gradient)))
    probability = expit(x @ beta)
    curvature = trials * probability * (1 - probability)
    hessian = (x.T @ x.multiply(curvature[:, None])).toarray()
    assert np.linalg.matrix_rank(hessian) == len(beta)
    bread = np.linalg.inv(hessian)
    scores = []
    for state in sorted(data.GESTFIPS.unique()):
        mask = data.GESTFIPS.eq(state).to_numpy()
        scores.append(
            np.asarray(
                x[mask].T @ (high[mask] - trials[mask] * probability[mask])
            ).ravel()
        )
    scores = np.asarray(scores)
    n = len(data)
    k = len(beta)
    g = len(scores)
    covariance = bread @ (scores.T @ scores) @ bread * g / (g - 1) * (n - 1) / (n - k)
    return (
        beta,
        covariance,
        names,
        {
            "n_cells": n,
            "n_parameters": k,
            "clusters": g,
            "max_scaled_score": float(np.max(abs(gradient))),
            "optimizer_message": str(result.message),
            "objective": float(value),
            "unscaled_survey_employment": float(data.trials.sum()),
        },
    )


def contrast(beta, covariance, names, weights):
    vector = np.zeros(len(beta))
    for name, value in weights.items():
        if name != "year_2022":
            vector[names.index(name)] += value
    estimate = float(vector @ beta)
    variance = float(vector @ covariance @ vector)
    assert variance >= -1e-10
    se = np.sqrt(max(variance, 0))
    critical = t.ppf(0.975, 50)
    return {
        "log_ratio": estimate,
        "se_log": float(se),
        "gap_percent": float(np.expm1(estimate) * 100),
        "ci_low_percent": float(np.expm1(estimate - critical * se) * 100),
        "ci_high_percent": float(np.expm1(estimate + critical * se) * 100),
        "p_unadjusted": float(2 * t.sf(abs(estimate / se), 50)),
    }
