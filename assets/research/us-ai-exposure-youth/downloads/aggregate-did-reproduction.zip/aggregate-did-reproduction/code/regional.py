"""Two-way fixed-effect WLS and state-cluster CR1 inference."""
import numpy as np
import pandas as pd
from scipy.linalg import qr
from scipy.stats import f, t
MEASURES = ['E', 'THAIE', 'TIME']
CONTROLS = [f'ind_{i}' for i in range(1, 13)] + ['covid_drop', 'recovery_gap']
AUDITS = []

def residualize(values, weights, n_states, n_years):
    """Weighted two-way FE absorption on a balanced constant-state-weight panel."""
    z = np.asarray(values).reshape(n_states, n_years, -1)
    state_mean = z.mean(axis=1, keepdims=True)
    state_weights = weights.reshape(n_states, n_years)[:, 0]
    time_mean = np.average(z, axis=0, weights=state_weights)[None, :, :]
    grand = np.average(state_mean[:, 0, :], axis=0, weights=state_weights)[
        None, None, :
    ]
    return (z - state_mean - time_mean + grand).reshape(n_states * n_years, -1)


def make_design(data, measure, adjusted, event=False, continuous=False, post_year=2023):
    years = sorted(data.year.unique())
    base = 2022 if 2022 in years else post_year - 1
    exposure = (
        data[measure + "_z"].to_numpy()
        if continuous
        else data[measure + "_q"].eq(5).astype(float).to_numpy()
    )
    columns = []
    names = []

    def add(name, value):
        columns.append(np.asarray(value, dtype=float))
        names.append(name)

    if event:
        for year in years:
            if year != base:
                add(f"event_{year}", exposure * data.year.eq(year))
    else:
        add("DID", exposure * data.year.ge(post_year))
        if adjusted:
            for year in [2020, 2021]:
                if year in years:
                    add(f"pandemic_{year}", exposure * data.year.eq(year))
    if adjusted:
        for c in CONTROLS:
            for year in years:
                if year != base:
                    add(f"{c}_year_{year}", data[c] * data.year.eq(year))
    return np.column_stack(columns), names, base


def fit(
    data,
    outcome,
    measure,
    adjusted=False,
    event=False,
    continuous=False,
    equal_weights=False,
    post_year=2023,
    label="",
):
    data = data.sort_values(["GESTFIPS", "year"]).reset_index(drop=True)
    g = data.GESTFIPS.nunique()
    nt = data.year.nunique()
    n = len(data)
    assert n == g * nt and data.groupby("GESTFIPS").year.nunique().eq(nt).all()
    wc = "weight_LF" if outcome == "UR" else "weight_P"
    w = np.ones(n) if equal_weights else data[wc].to_numpy()
    assert np.allclose(w.reshape(g, nt), w.reshape(g, nt)[:, [0]])
    w = w / w.mean()
    y = data[outcome].to_numpy() * 100
    x, names, base = make_design(data, measure, adjusted, event, continuous, post_year)
    xa = residualize(x, w, g, nt)
    ya = residualize(y, w, g, nt).ravel()
    sw = np.sqrt(w)
    xw = xa * sw[:, None]
    yw = ya * sw
    _, r, pivot = qr(xw, mode="economic", pivoting=True)
    diag = np.abs(np.diag(r))
    rank = int((diag > diag.max() * 1e-10).sum())
    if rank != xw.shape[1]:
        raise ValueError(f"rank-deficient {label}: {[names[i] for i in pivot[rank:]]}")
    beta = np.linalg.lstsq(xw, yw, rcond=1e-10)[0]
    residual = ya - xa @ beta
    bread = np.linalg.inv(xw.T @ xw)
    score = (xa * (w * residual)[:, None]).reshape(g, nt, -1).sum(axis=1)
    full_k = rank + g + nt - 1
    correction = g / (g - 1) * (n - 1) / (n - full_k)
    covariance = bread @ (score.T @ score) @ bread * correction
    gradient = np.max(abs(xa.T @ (w * residual)))
    audit = {
        "label": label,
        "outcome": outcome,
        "measure": measure,
        "adjusted": adjusted,
        "event": event,
        "n": n,
        "states": g,
        "years": nt,
        "full_parameters": full_k,
        "rank": rank,
        "max_score": float(gradient),
        "condition_number": float(np.linalg.cond(xw)),
        "treated_states": int(data[data[measure + "_q"].eq(5)].GESTFIPS.nunique()),
        "year_min": int(data.year.min()),
        "year_max": int(data.year.max()),
        "base": int(base),
    }
    AUDITS.append(audit)
    return beta, covariance, names, g, audit


def contrast(fit_result, weights):
    beta, cov, names, g, _ = fit_result
    v = np.array([weights.get(name, 0) for name in names])
    estimate = float(v @ beta)
    var = float(v @ cov @ v)
    assert var >= -1e-8
    se = np.sqrt(max(var, 0))
    critical = t.ppf(0.975, g - 1)
    return {
        "estimate_pp": estimate,
        "se": float(se),
        "ci_low_pp": float(estimate - critical * se),
        "ci_high_pp": float(estimate + critical * se),
        "p_value": float(2 * t.sf(abs(estimate / se), g - 1)) if se > 0 else np.nan,
    }


def joint(fit_result, years):
    beta, cov, names, g, _ = fit_result
    idx = [names.index(f"event_{year}") for year in years if f"event_{year}" in names]
    b = beta[idx]
    c = cov[np.ix_(idx, idx)]
    rank = np.linalg.matrix_rank(c)
    statistic = float(b @ np.linalg.pinv(c) @ b / rank)
    return {
        "n_restrictions": len(idx),
        "covariance_rank": int(rank),
        "F": statistic,
        "df_den": g - 1,
        "p_value": float(f.sf(statistic, rank, g - 1)),
    }
