# Aggregate input dictionary

## Regional analysis panel

One row per state/DC and year for ages 22–25. The stored panel covers 2010–2026; the reproduction uses 2017–2026.

- GESTFIPS is the Census state identifier; state is its English label.
- P, E, U and N are sums of nine monthly population, employment, unemployment and non-participation weights.
- EPOP is E/P; UR is U/(E+U). Rates are fractions in the input and percentage points in the model.
- FT and PT are weighted full-time and part-time employment totals; FTPOP and PTPOP divide them by population.
- weight_P and weight_LF are fixed at the selected age group's 2019 population and labour force.
- E_q, THAIE_q and TIME_q are fixed regional quintiles. A value of 5 identifies the high-exposure group.
- E_z, THAIE_z and TIME_z are state-standardised continuous exposure scores.
- ind_1 through ind_12 are standardised 2019 employment shares, with the thirteenth industry omitted. Standardisation was performed across all 51 regions.
- covid_drop and recovery_gap are standardised adult ages 30–54 employment-rate differences for 2019–2020 and 2019–2021. Adults are not assumed to be immune to AI.
- Other employment-quality columns are retained for transparency and are not used in the primary DID.

## Occupational panels

One row per state, major industry, year and exposure measure after outcome-specific common-support selection. Separate files hold E, FT and PT outcomes.

- PRMJIND1 is the CPS major-industry category from 1 through 13.
- measure is E, THAIE or TIME.
- high and other are survey-weighted Q5 and Q1–Q4 employment totals over January–September.
- trials is high + other and is used only as a quasi-likelihood scaling total.
- stratum identifies the state–industry fixed effect.
- covid and recovery are standardised adult changes in the log high/other employment ratio for 2019–2020 and 2019–2021. They differ from the regional rate controls above.

Survey weights and probabilistic occupational conversions can make totals fractional. The input rows are aggregate cells, not individual workers or independent survey respondents.
