"""Reproduce saved DID contrasts from supplied aggregates; no plots or external calls."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
import regional
import count_model


def compare(frame,reference,keys,columns):
    expected=pd.read_csv(ROOT/'reference'/reference)
    merged=frame.merge(expected,on=keys,suffixes=('_new','_reference'),validate='one_to_one')
    assert len(merged)==len(expected)==len(frame)
    error=max(float(abs(merged[c+'_new']-merged[c+'_reference']).max()) for c in columns)
    assert error<1e-6,error
    return error


def main():
    (ROOT/'results').mkdir(exist_ok=True)
    data=pd.read_csv(ROOT/'input/regional_analysis_panel.csv').query('year>=2017')
    rows=[]
    for measure in ['E','THAIE','TIME']:
        for outcome in ['EPOP','UR']:
            for adjusted in [False,True]:
                fit=regional.fit(data,outcome,measure,adjusted,label='reproduction')
                rows.append({'measure':measure,'outcome':outcome,'model':'adjusted' if adjusted else 'basic',
                             **regional.contrast(fit,{'DID':1})})
    results=pd.DataFrame(rows)
    results['p_holm_primary12']=multipletests(results.p_value,method='holm')[1]
    results.to_csv(ROOT/'results/regional_did_primary.csv',index=False)
    regional_error=compare(results,'regional_did_primary.csv',['measure','outcome','model'],
                           ['estimate_pp','se','ci_low_pp','ci_high_pp','p_value','p_holm_primary12'])
    rows=[]
    weights={f'year_{year}':.25 for year in [2023,2024,2025,2026]}
    weights.update({f'year_{year}':-.25 for year in [2017,2018,2019,2022]})
    for outcome in ['E','FT','PT']:
        panel=pd.read_csv(ROOT/'input'/f'occupation_panel_{outcome}.csv')
        for measure in ['E','THAIE','TIME']:
            data=panel.query('measure==@measure').sort_values(['GESTFIPS','PRMJIND1','year']).reset_index(drop=True)
            for stage in ['state_industry','state_industry_covid']:
                beta,covariance,names,audit=count_model.fit(data,stage)
                rows.append({'outcome':outcome,'measure':measure,'stage':stage,
                             **count_model.contrast(beta,covariance,names,weights)})
    results=pd.DataFrame(rows)
    results['p_holm_secondary18']=multipletests(results.p_unadjusted,method='holm')[1]
    results.to_csv(ROOT/'results/occupational_did.csv',index=False)
    occupation_error=compare(results,'occupational_did.csv',['outcome','measure','stage'],
                             ['log_ratio','se_log','gap_percent','ci_low_percent','ci_high_percent','p_unadjusted','p_holm_secondary18'])
    audit={'regional_max_absolute_difference':regional_error,'occupational_max_absolute_difference':occupation_error,
           'tolerance':1e-6,'regional_contrasts':12,'occupational_contrasts':18,'plots_displayed':False}
    (ROOT/'results/reproduction_check.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2))


if __name__=='__main__':main()
