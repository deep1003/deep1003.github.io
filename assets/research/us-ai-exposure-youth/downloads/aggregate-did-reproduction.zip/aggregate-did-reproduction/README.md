# US AI exposure and early-career work

Aggregate-data DID reproduction release, 22 November 2026.

## Scope

This package reproduces 12 primary regional DID contrasts and 18 supplementary occupational contrasts from saved aggregates. It does not re-download CPS microdata, reconstruct occupational crosswalks, or re-fit upstream task predictors. No individual survey records, embeddings, private local paths or submitted manuscript are included. The associated research page documents upstream construction and provides a 153-month source manifest.

The event is ChatGPT's public release on 30 November 2022. Every observation uses January–September, and 2026 is a partial year. Regional exposure uses 2019 composition and fixed quintiles. Regional outcomes concern ages 22–25. The main window is 2017–2026.

## Run

Use Python 3.10 or later. Install the dependencies in your preferred isolated environment.

```sh
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python reproduce.py
```

This writes two result tables and a numerical comparison with the supplied reference results into `results/`. It produces no plots and calls no external API. The recorded software versions describe the original reproduction environment. Library or BLAS differences can change numerical rounding; the comparison tolerance is 1e-6.

## Models

Regional models use fixed 2019 population weights for employment rates and 2019 labour-force weights for unemployment. State and year fixed effects are absorbed. The adjusted model includes baseline industry shares and adult COVID recovery differences interacted with year, plus separate Q5 effects in 2020 and 2021. Regional inference uses 51 state/DC clusters, CR1 covariance and t critical values with 50 degrees of freedom.

Occupational models condition on the total Q5-plus-other employment count in each state–industry–year cell. The likelihood is a binomial quasi-likelihood for the two counts, not an assumption that survey-weighted totals are independent trials. State-cluster covariance handles inference. The reported contrast subtracts the average 2017–2019 and 2022 annual log relative-employment effect from the average 2023–2026 effect, then reports 100 × (exp(contrast) − 1). Full-time and part-time models use outcome-specific common support across the three exposure indices.

See `DATA_DICTIONARY.md`. A significant contrast alone does not establish a causal AI effect. THAIE occupational pre-trends reject and alternative baselines are sensitive. Full-time is not synonymous with permanent employment. Wage DID is not estimated in this package.
