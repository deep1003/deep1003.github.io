Monthly research bundle, November 25, 2026

Aggregate CPS and published Stanford/ADP indices only. No person-level data. Each series uses its own calendar-year 2022 mean. Monthly CPS cells with n<30 or baseline person-month n<120 are not displayed. Missing October2025 is not interpolated.

Scripts retain their original project-relative dependencies and are provided for inspection; this is not a self-contained raw-data parser installation. Aggregate CSV files are sufficient to reproduce the plotted index curves. Source URLs and hashes identify free inputs. The original Stanford downloads normalize to November2022; the long table preserves both scales.

E, THAIE and TIME quintiles are frozen from the existing 2019 mapping, and are distinct from Stanford's source groups. Software developers occupy one quintile per measure.
