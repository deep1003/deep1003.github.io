"""Acquire missing calendar months from official free Census directories."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import requests, zipfile, hashlib, json, io

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
RAW = WORK / "raw"
mon = [
    "jan",
    "feb",
    "mar",
    "apr",
    "may",
    "jun",
    "jul",
    "aug",
    "sep",
    "oct",
    "nov",
    "dec",
]
old = json.loads(
    (
        ROOT
        / "outputs/US_THAIE_Regional_Youth_20261122/robustness_2010_2026/audit/parse.json"
    ).read_text()
)
index = {(a["year"], a["month"]): a for a in old}
jobs = []
for year in range(2020, 2027):
    for month in range(1, 11 if year == 2026 else 13):
        if (year, month) not in index:
            jobs.append((year, month))


def acquire(pair):
    year, month = pair
    name = f"{mon[month-1]}{str(year)[2:]}pub.zip"
    url = f"https://www2.census.gov/programs-surveys/cps/datasets/{year}/basic/{name}"
    dest = RAW / name
    if not dest.exists():
        r = requests.get(url, timeout=120)
        if r.status_code == 404:
            return dict(year=year, month=month, url=url, status=404, available=False)
        r.raise_for_status()
        assert zipfile.is_zipfile(io.BytesIO(r.content))
        dest.write_bytes(r.content)
    rec = index[(year, 1)]
    return dict(
        year=year,
        month=month,
        path=str(dest),
        url=url,
        sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
        dictionary=rec["layout"]["dictionary"],
        reused=False,
    )


records = [
    dict(
        year=y,
        month=m,
        path=index[y, m]["path"],
        dictionary=index[y, m]["layout"]["dictionary"],
        sha256=index[y, m]["sha256"],
        reused=True,
        url=f"https://www2.census.gov/programs-surveys/cps/datasets/{y}/basic/{mon[m-1]}{str(y)[2:]}pub.zip",
    )
    for y, m in index
    if y >= 2020
]
with ThreadPoolExecutor(max_workers=4) as pool:
    for fut in as_completed([pool.submit(acquire, p) for p in jobs]):
        rec = fut.result()
        records.append(rec)
        print("Checked", rec["year"], rec["month"], rec.get("status", 200), flush=True)
records = sorted(records, key=lambda x: (x["year"], x["month"]))
(RAW / "cps_source_manifest.json").write_text(json.dumps(records, indent=2))
print("Months", len(records), "new", len(jobs), flush=True)
url = "https://www2.census.gov/programs-surveys/cps/datasets/2026/basic/cps_dd_record_layout.txt"
r = requests.get(url, timeout=60)
r.raise_for_status()
(RAW / "cps_dictionary_2026_fresh.txt").write_bytes(r.content)
