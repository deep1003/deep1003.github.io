"""Reaggregate official CPS into exact monthly age-sex-occupation cells."""

from pathlib import Path
import importlib.util, json, hashlib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
T = ROOT / "outputs/US_Monthly_Canaries_20261125/tables"
T.mkdir(exist_ok=True, parents=True)
P = ROOT / "outputs/US_THAIE_Regional_Youth_20261122"
spec = importlib.util.spec_from_file_location(
    "parser", P / "panel_fe3_20261122/scripts/prepare_panel.py"
)
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)
records = json.loads((WORK / "raw/cps_source_manifest.json").read_text())
bydate = {(a["year"], a["month"]): a for a in records if a.get("available", True)}
original_source = parser.source
parser.source = lambda y, m: (
    Path(bydate[y, m]["path"]),
    Path(bydate[y, m]["dictionary"]),
)
# Recheck the freshly retrieved 2026 layout against the established parser fields.
fresh = WORK / "raw/cps_dictionary_2026_fresh.txt"
if fresh.exists():
    p, _ = parser.layout(fresh)
    q, _ = parser.layout(Path(bydate[2026, 1]["dictionary"]))
    assert p == q
    for key in bydate:
        if key[0] == 2026:
            bydate[key]["dictionary"] = str(fresh)
ages = ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"]
frames = []
audits = []
for (year, month), rec in sorted(bydate.items()):
    cache = WORK / f"occupation_{year}_{month:02}.parquet"
    auditfile = WORK / f"audit_{year}_{month:02}.json"
    if cache.exists():
        frames.append(pd.read_parquet(cache))
        audits.append(json.loads(auditfile.read_text()))
        continue
    d, audit = parser.read(year, month)
    d = d[d.nE.eq(1)].copy()
    d["age"] = pd.cut(
        d.PRTAGE,
        bins=[15, 21, 25, 30, 34, 40, 49, 200],
        labels=["16–21"] + ages,
        right=True,
    ).astype(str)
    d["sex"] = d.PESEX.map({1: "Men", 2: "Women"})
    assert d.sex.notna().all()
    d["nFT"] = d.PRFTLF.eq(1).astype(int)
    d["nPT"] = d.PRFTLF.eq(2).astype(int)
    d["w2"] = d.E**2
    a = d.groupby(["occ", "age", "sex"], as_index=False)[
        ["E", "FT", "PT", "nE", "nFT", "nPT", "w2"]
    ].sum()
    a["date"] = f"{year}-{month:02}-01"
    a.to_parquet(cache, index=False)
    auditfile.write_text(json.dumps(audit, indent=2))
    frames.append(a)
    audits.append(audit)
    print("Aggregated", year, month, len(d), "employed records", flush=True)
a = pd.concat(frames, ignore_index=True)
a.to_parquet(T / "cps_monthly_occupation_age_sex.parquet", index=False)
scores = pd.read_csv(P / "high_exposure_quality/derived/occupation_quintiles.csv")
assert not scores.occ.duplicated().any()
scores.to_csv(T / "frozen_2019_occupation_quintiles.csv", index=False)
b = a.merge(
    scores[["occ", "E_q", "THAIE_q", "TIME_q"]],
    on="occ",
    how="left",
    validate="many_to_one",
)
coverage = b.groupby("date").E.sum().to_frame("total_E")
coverage["mapped_E"] = b[b.THAIE_q.notna()].groupby("date").E.sum()
coverage["mapped_share"] = coverage.mapped_E / coverage.total_E
coverage.to_csv(T / "monthly_exposure_coverage.csv")
rows = []
for measure in ["E", "THAIE", "TIME"]:
    z = b.copy()
    z["quintile"] = z[measure + "_q"].fillna(0).astype(int)
    z["measure"] = measure
    rows.append(
        z.groupby(["date", "measure", "quintile", "age", "sex"], as_index=False)[
            ["E", "FT", "PT", "nE", "nFT", "nPT", "w2"]
        ].sum()
    )
q = pd.concat(rows, ignore_index=True)
q.to_parquet(T / "cps_monthly_quintile_age_sex.parquet", index=False)
(T / "cps_parse_audit.json").write_text(json.dumps(audits, indent=2))
(T / "cps_month_availability.json").write_text(json.dumps(records, indent=2))
assert np.allclose(a.FT + a.PT, a.E)
assert q.groupby("measure").E.sum().round(3).eq(round(a.E.sum(), 3)).all()
print(
    "Completed",
    a.date.nunique(),
    "months; gap",
    [(r["year"], r["month"]) for r in records if not r.get("available", True)],
    flush=True,
)
