"""Rebuild public chart data exclusively from our CPS aggregate CSV files."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent;O=ROOT/'outputs/US_CPS_Only_Monthly_DID_20261125';SITE=ROOT/'work/homepage-monthly/assets/research/us-ai-exposure-youth';OLD=ROOT/'outputs/US_Monthly_Canaries_20261125/tables'

def compact(d,keys):
 records=[]
 for key,z in d.groupby(keys):
  key=key if isinstance(key,tuple) else (key,);r=dict(zip(keys,key));r['points']=[]
  qualified={out:z[z.date.str.startswith('2022-')]['n'+out].sum()>=120 for out in ['E','FT','PT']}
  for row in z.sort_values('date').itertuples():
   r['points'].append([row.date]+[None if pd.isna(getattr(row,c)) or (c.startswith('index_') and not qualified[c[6:]]) else round(float(getattr(row,c)),3) for c in ['index_E','index_FT','index_PT','nE','nFT','nPT']])
  records.append(r)
 return records
q=pd.read_csv(OLD/'cps_monthly_exposure_indices.csv');q=q[q.measure.eq('THAIE')].copy();o=pd.read_csv(OLD/'cps_monthly_selected_occupation_indices.csv');c=pd.read_csv(OLD/'cps_monthly_computer_math_exposure_indices.csv');c=c[c.measure.eq('THAIE')]
scores=pd.read_csv(O/'tables/frozen_THAIE_occupation_assignments.csv');names={1021:'Software developers',1010:'Computer programmers',1022:'Software quality assurance analysts and testers',1050:'Computer support specialists',5240:'Customer service representatives',9645:'Stockers and order fillers',3601:'Home health aides'};ages=['22–25','26–30','31–34','35–40','41–49','50+']
payload={'metadata':{'source':'Our aggregation of official Basic Monthly CPS only','cps_start':'2020-01','cps_end':'2026-10','missing_cps_months':['2025-10'],'baseline':'Calendar-year 2022 monthly mean=100','ages':ages,'occupations':{str(k):v for k,v in names.items()},'occupation_quintiles':scores[scores.occ.isin(names)][['occ','THAIE_q']].to_dict('records'),'minimum_monthly_records':30,'not_seasonally_adjusted':True},'cps_exposure':compact(q,['measure','age','sex','quintile']),'cps_occupation':compact(o,['scope','age','sex']),'cps_computer':compact(c,['measure','age','sex','quintile'])}
assert 'stanford' not in payload
(O/'data/monthly.json').write_text(json.dumps(payload,separators=(',',':'),ensure_ascii=False));(SITE/'data/monthly.json').write_text((O/'data/monthly.json').read_text())
# Verify overlapping months against independently reconstructed original CPS counts.
new=pd.read_parquet(O/'tables/occupation_industry_monthly_counts.parquet');new=new[new.date.ge('2020-01-01')&new.band.eq('Q5')].groupby(['date','age'])[['FT','PT']].sum().sort_index()
previous=q[q.sex.eq('All')&q.quintile.eq(5)&q.age.isin(ages)].set_index(['date','age'])[['FT','PT']].dropna().sort_index();assert np.allclose(new,previous,rtol=1e-9,atol=1e-5)
fig,ax=plt.subplots(figsize=(11,5));colors=['#a9171c','#527d9e','#f05234','#d89900','#62363a','#aa9a89']
for age,color in zip(ages,colors):
 z=o[o.scope.astype(str).eq('1021')&o.age.eq(age)&o.sex.eq('All')];ax.plot(pd.to_datetime(z.date),z.index_E.where(z.supported_E),color=color,label='Ages '+age,lw=1.5)
ax.axhline(100,color='.6',lw=.7);ax.axvline(pd.Timestamp('2022-11-30'),color='.5',ls=':');ax.set(xlabel='Month',ylabel='Employment index, 2022 monthly mean=100',title='Software developers by age, independently aggregated CPS only');ax.legend(ncol=3,frameon=False);ax.spines[['top','right']].set_visible(False);fig.tight_layout()
for ext in ['png','svg']:fig.savefig(O/'figures'/('monthly_03_software_age.'+ext),bbox_inches='tight',dpi=180);fig.savefig(SITE/'figures'/('monthly_03_software_age.'+ext),bbox_inches='tight',dpi=180)
plt.close(fig)
# Retain only CPS charting code; no source switch or outside benchmark access.
old=(SITE/'monthly.js').read_text();start=old[:old.index('  function exposureRows(')]
start=start.replace('($('+'"source").value === "adp" || p[3 + pos] >= 30)','(p[3 + pos] >= 30)')
start=start.replace('if ($("source").value === "cps") {','{')
script=start+'''
  function exposureRows(age, sex) {
    return data.cps_exposure.filter(r => r.age === age && r.sex === sex);
  }
  function update() {
    latestSeries=[];
    const age=$("age").value, scope=$("occupation").value, measure='THAIE';
    const labelQ=r=>`Q${r.quintile}${r.quintile===5?' (highest)':r.quintile===1?' (lowest)':''}`;
    const colorQ=r=>palette[r.quintile-1];
    chart('chart-overall',series(exposureRows('All ages (16+)','All'),labelQ,colorQ),'All-worker employment by occupational THAIE quintile');
    chart('chart-age',series(exposureRows(age,'All'),labelQ,colorQ),`Ages ${age} by occupational THAIE quintile`);
    const name=scope==='computer_math'?'Computer and mathematical occupations':data.metadata.occupations[scope];
    const rows=data.cps_occupation.filter(r=>r.scope===scope&&r.sex==='All'&&data.metadata.ages.includes(r.age));
    chart('chart-occupation',series(rows,r=>`Ages ${r.age}`,r=>ageColors[data.metadata.ages.indexOf(r.age)]),`${name} by age, CPS only`);
    const q=data.metadata.occupation_quintiles.find(r=>String(r.occ)===scope);
    $('occupation-note').textContent=scope==='computer_math'?'This broad family contains several occupations with different THAIE scores.':`${name} is a single occupation assigned to THAIE Q${q.THAIE_q}. Exposure is fixed within this occupation; five within-occupation strata cannot be identified.`;
    $('computer-wrap').hidden=scope!=='computer_math';
    if(scope==='computer_math')chart('chart-computer',series(data.cps_computer.filter(r=>r.age===age&&r.sex==='All'),labelQ,colorQ),`${name}, ages ${age}, by THAIE`);
    const women=series(exposureRows(age,'Women'),labelQ,colorQ),men=series(exposureRows(age,'Men'),labelQ,colorQ);
    const values=[...women,...men].flatMap(filteredPoints).filter(p=>p.value!==null).map(p=>p.value);
    const limits=values.length?[Math.min(100,...values),Math.max(100,...values)]:undefined;
    chart('chart-women',women,`Women, ages ${age}`,limits);chart('chart-men',men,`Men, ages ${age}`,limits);
    $('chart-status').textContent=`Our CPS aggregation only · January 2020–October 2026 · THAIE · ${$('outcome').selectedOptions[0].textContent} · 2022 monthly mean=100. Not seasonally adjusted. Missing October2025 and low-support cells remain gaps.`;
  }
  function download(){
    const rows=['chart,series,date,index,unweighted_n'];
    latestSeries.forEach(r=>filteredPoints(r).forEach(p=>rows.push([r.chart,r.label,p.date,p.value??'',p.n??''].map(v=>'"'+String(v).replaceAll('"','""')+'"').join(','))));
    const link=document.createElement('a'),url=URL.createObjectURL(new Blob([rows.join('\\n')],{type:'text/csv'}));link.href=url;link.download='CPS-only-selected-monthly-series.csv';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  fetch('data/monthly.json?v=cps-only-20261125').then(r=>{if(!r.ok)throw new Error(`Data response ${r.status}`);return r.json();}).then(d=>{
    data=d;for(const id of ['age','outcome','occupation'])$(id).addEventListener('change',update);$('download-selected').addEventListener('click',download);update();$('explorer-loading').hidden=true;$('explorer-content').hidden=false;
  }).catch(e=>{$('explorer-loading').textContent='The CPS aggregate data could not be loaded. Download the CSV files below. '+e.message;});
})();
'''
assert 'stanford' not in script.lower() and 'adp' not in script.lower() and '$('+'"source")' not in script
(W/'monthly_cps_only.js').write_text(script);(SITE/'monthly.js').write_text(script)
public=[{k:v for k,v in a.items() if k in ['year','month','url','sha256','reused','status','available']} for a in json.loads((W/'raw/cps_only_source_manifest.json').read_text())];(O/'tables/cps_only_public_sources.json').write_text(json.dumps(public,indent=2))
print('Public CPS-only payload rebuilt; independent 2020–2026 overlap counts match exactly. No external benchmark rows read.')
