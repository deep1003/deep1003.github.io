"""Data and file-I/O smoke checks. Deliberately emits no images or graphs."""
from pathlib import Path
from urllib.parse import urljoin,urlparse,unquote
import json,zipfile,hashlib
import numpy as np
import pandas as pd
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[2];O=ROOT/'outputs/US_Monthly_Canaries_20261125';S=ROOT/'work/homepage-monthly/assets/research/us-ai-exposure-youth'
d=json.loads((S/'data/monthly.json').read_text());checks=[]
for key in ['cps_exposure','cps_occupation','cps_computer']:
 for row in d[key]:
  assert len(row['points'])==82
  missing=[p for p in row['points'] if p[0]=='2025-10-01'];assert len(missing)==1 and all(v is None for v in missing[0][1:])
  for idx in range(1,4):
   base=[p[idx] for p in row['points'] if p[0].startswith('2022-') and p[idx] is not None]
   assert len(base) in [0,12]
   if base:assert np.isclose(np.mean(base),100,atol=.001)
 checks.append(key+' baseline and missing-month integrity')
for row in d['stanford']:
 assert len(row['points'])==60
 base=[p[1] for p in row['points'] if p[0].startswith('2022-')];assert np.isclose(np.mean(base),100,atol=.001)
checks.append('Stanford rebasing and 60-month coverage')
page=BeautifulSoup((S/'index.html').read_text(),'html.parser');assert page.html['lang']=='en-US'
assert [x.get('id') for x in page.select('main > section')]==['introduction','methods','results','discussion','materials']
assert len(page.select('#results > details'))==5
broken=[]
for x in page.select('[href],[src]'):
 u=x.get('href',x.get('src',''))
 if not u or urlparse(u).scheme or u.startswith('#'):continue
 path=unquote(urlparse(u).path)
 f=(S/path).resolve()
 if not f.exists():broken.append(str(f))
assert not broken,broken
checks.append('IMRD structure, five Results disclosures, all relative assets and links')
with zipfile.ZipFile(S/'downloads/monthly-research-bundle-20261125.zip') as z:
 assert z.testzip() is None
 assert not any(n.endswith('.parquet') for n in z.namelist())
checks.append('Compressed aggregate-only bundle integrity')
manifest={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for directory in [O,ROOT/'work/us_monthly_canaries_20261125'] for f in directory.rglob('*') if f.is_file() and f.suffix not in ['.pyc','.log','.zip'] and f.name not in ['file_manifest.json','website-validation.json']}
(O/'file_manifest.json').write_text(json.dumps(manifest,indent=2))
result={'passed':True,'checks':checks,'broken_links':broken,'plots_emitted':0,'published_microdata':False}
(O/'website-validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
