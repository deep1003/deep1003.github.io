from pathlib import Path
import requests, zipfile, json, hashlib

p = Path(__file__).resolve().parent / "raw"
records = []
for name in [
    "canaries_by_exposure_results",
    "canaries_age_by_exposure_results",
    "canaries_software_developers_results",
    "canaries_gender_by_exposure_results",
]:
    url = (
        "https://storage.googleapis.com/aviary-del-public/release_memos/latest/downloads/"
        + name
        + ".zip"
    )
    r = requests.get(url, timeout=90)
    r.raise_for_status()
    f = p / (name + ".zip")
    f.write_bytes(r.content)
    with zipfile.ZipFile(f) as z:
        for info in z.infolist():
            if not info.is_dir():
                dest = p / name / Path(info.filename).name
                dest.parent.mkdir(exist_ok=True)
                dest.write_bytes(z.read(info.filename))
        print(name, z.namelist())
    records.append(
        dict(
            url=url,
            status=r.status_code,
            sha256=hashlib.sha256(r.content).hexdigest(),
            bytes=len(r.content),
            headers={
                k: v
                for k, v in r.headers.items()
                if k.lower() in ["last-modified", "etag"]
            },
        )
    )
(p / "stanford_download_manifest.json").write_text(json.dumps(records, indent=2))
