"""Build monthly indices, support diagnostics and scientific figures. Never display plots."""

from pathlib import Path
import json, hashlib, re
import pandas as pd
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = ROOT / "outputs/US_Monthly_Canaries_20261125"
T = O / "tables"
F = O / "figures"
D = O / "data"
D.mkdir(exist_ok=True)
AGES = ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"]
AGESEL = ["All ages (16+)"] + AGES
COLORS = ["#9b171c", "#527d9e", "#f05234", "#d89900", "#401417"]
AC = ["#a9171c", "#527d9e", "#f05234", "#d89900", "#62363a", "#aa9a89"]
SCOPE = {
    1021: "Software developers",
    1010: "Computer programmers",
    1022: "Software quality assurance analysts and testers",
    1050: "Computer support specialists",
    5240: "Customer service representatives",
    9645: "Stockers and order fillers",
    3601: "Home health aides",
}
VALUES = ["E", "FT", "PT", "nE", "nFT", "nPT", "w2"]
N = {"E": "nE", "FT": "nFT", "PT": "nPT"}


def dimensions(a, extra):
    rows = []
    for age in AGESEL:
        z = a if age == AGESEL[0] else a[a.age.eq(age)]
        for sex in ["All", "Women", "Men"]:
            y = z if sex == "All" else z[z.sex.eq(sex)]
            v = y.groupby(["date"] + extra, as_index=False)[VALUES].sum()
            v["age"] = age
            v["sex"] = sex
            rows.append(v)
    return pd.concat(rows, ignore_index=True)


def indices(a, keys):
    rows = []
    months = (
        pd.date_range("2020-01-01", "2026-10-01", freq="MS")
        .strftime("%Y-%m-%d")
        .tolist()
    )
    for key, z in a.groupby(keys, dropna=False):
        key = key if isinstance(key, tuple) else (key,)
        z = z.set_index("date").reindex(months)
        observed_months = {
            f"{r['year']}-{r['month']:02}-01"
            for r in json.loads((W / "raw/cps_source_manifest.json").read_text())
            if r.get("available", True)
        }
        for col in VALUES:
            z.loc[z.index.isin(observed_months), col] = z.loc[
                z.index.isin(observed_months), col
            ].fillna(0)
        z["date"] = z.index
        for name, value in zip(keys, key):
            z[name] = value
        base = z.loc[z.index.str.startswith("2022-"), VALUES].mean()
        assert z.loc[z.index.str.startswith("2022-"), "E"].notna().sum() == 12
        for out in ["E", "FT", "PT"]:
            b = base[out]
            z["index_" + out] = 100 * z[out] / b if b > 0 else np.nan
            nv = N[out]
            baseline_supported = z.loc[z.index.str.startswith("2022-"), nv].sum() >= 120
            z["supported_" + out] = (z[nv] >= 30) & baseline_supported
        z["effective_n_E"] = z.E**2 / z.w2
        rows.append(z.reset_index(drop=True))
    return pd.concat(rows, ignore_index=True)


q = pd.read_parquet(T / "cps_monthly_quintile_age_sex.parquet")
q = q[q.quintile.between(1, 5)]
qi = indices(
    dimensions(q, ["measure", "quintile"]), ["measure", "quintile", "age", "sex"]
)
qi.to_csv(T / "cps_monthly_exposure_indices.csv", index=False)
a = pd.read_parquet(T / "cps_monthly_occupation_age_sex.parquet")
parts = []
for code, name in SCOPE.items():
    z = a[a.occ.eq(code)].copy()
    z["scope"] = str(code)
    parts.append(z)
z = a[a.occ.between(1000, 1299)].copy()
z["scope"] = "computer_math"
parts.append(z)
occ = pd.concat(parts, ignore_index=True)
oi = indices(dimensions(occ, ["scope"]), ["scope", "age", "sex"])
oi.to_csv(T / "cps_monthly_selected_occupation_indices.csv", index=False)
# Exposure variation within the broad computer/mathematical family, not fabricated within one occupation.
scores = pd.read_csv(T / "frozen_2019_occupation_quintiles.csv")
cm = a[a.occ.between(1000, 1299)].merge(
    scores[["occ", "E_q", "THAIE_q", "TIME_q"]],
    on="occ",
    how="left",
    validate="many_to_one",
)
cmq = []
for measure in ["E", "THAIE", "TIME"]:
    z = cm.copy()
    z["quintile"] = z[measure + "_q"]
    z = z[z.quintile.between(1, 5)]
    z["measure"] = measure
    cmq.append(z)
cmq = pd.concat(cmq)
ci = indices(
    dimensions(cmq, ["measure", "quintile"]), ["measure", "quintile", "age", "sex"]
)
ci.to_csv(T / "cps_monthly_computer_math_exposure_indices.csv", index=False)
# Independent direct aggregation check for all mapped employed women ages22–25.
check = (
    a[a.age.eq("22–25") & a.sex.eq("Women")]
    .merge(scores[["occ"]], on="occ", how="inner", validate="many_to_one")
    .groupby("date")
    .E.sum()
)
check2 = (
    qi[qi.age.eq("22–25") & qi.sex.eq("Women") & qi.measure.eq("THAIE")]
    .groupby("date")
    .E.sum(min_count=1)
    .dropna()
)
assert np.allclose(check.sort_index(), check2.sort_index())
for ix in [qi, oi, ci]:
    for out in ["E", "FT", "PT"]:
        groupkeys = [
            c for c in ["measure", "quintile", "scope", "age", "sex"] if c in ix
        ]
        avg = (
            ix[ix.date.str.startswith("2022-")]
            .groupby(groupkeys)["index_" + out]
            .mean()
            .dropna()
        )
        assert np.allclose(avg, 100)

# Stanford downloads retain original Nov2022 indices and add annual-mean rebasing.
std = []
names = ["by_exposure", "age_by_exposure", "software_developers", "gender_by_exposure"]
for name in names:
    d = pd.read_csv(W / f"raw/canaries_{name}_results/canaries_{name}.csv")
    idcols = [
        c
        for c in d
        if c
        in ["observation_date", "exposure_quintile", "Gender", "Age Group", "vintage"]
    ]
    cols = [
        c
        for c in d
        if c.startswith("Quintile")
        or c
        in [
            "Early Career 1 (22-25)",
            "Early Career 2 (26-30)",
            "Developing (31-34)",
            "Mid-Career 1 (35-40)",
            "Mid-Career 2 (41-49)",
            "Senior (50+)",
            "All Occupations",
        ]
    ]
    long = d.melt(
        id_vars=idcols, value_vars=cols, var_name="series", value_name="original_index"
    )
    long["product"] = name

    def age_label(s):
        for age in AGES:
            if age.replace("–", "-") in str(s):
                return age
        return "All ages (source definition)"

    if name == "by_exposure":
        long["age"] = "All ages (source definition)"
        long["quintile"] = long.series.str.extract(r"Quintile (\d)").astype(int)
        long["sex"] = "All"
    elif name == "age_by_exposure":
        long["age"] = long.series.map(age_label)
        long["quintile"] = long.exposure_quintile.str.extract(r"Quintile (\d)").astype(
            int
        )
        long["sex"] = "All"
    elif name == "software_developers":
        long["age"] = long.series.map(age_label)
        long["quintile"] = 5
        long["sex"] = "All"
    else:
        long["age"] = long["Age Group"].map(age_label)
        long["sex"] = long.Gender
        long["quintile"] = (
            long.series.str.extract(r"Quintile (\d)").fillna(0).astype(int)
        )
    long = long.rename(columns={"observation_date": "date"})
    keys = ["age", "sex", "quintile"]
    base = (
        long[long.date.str.startswith("2022-")]
        .groupby(keys)
        .original_index.agg(["mean", "count"])
    )
    assert base["count"].eq(12).all()
    long = long.join(base["mean"].rename("base2022"), on=keys)
    long["index_E"] = 100 * long.original_index / long.base2022
    long["supported_E"] = True
    std.append(long)
stan = pd.concat(std, ignore_index=True)
stan.to_csv(T / "stanford_monthly_rebased_indices.csv", index=False)


# Compact JSON used by the browser, aggregate data only.
# Each record has group keys and a monthly points array [date, E-index, FT-index, PT-index, nE,nFT,nPT].
def compact(ix, keys):
    rows = []
    for key, z in ix.groupby(keys):
        key = key if isinstance(key, tuple) else (key,)
        r = dict(zip(keys, key))
        r["points"] = []
        baseline_ok = {
            out: (
                z[z.date.str.startswith("2022-")][N[out]].sum() >= 120
                if N[out] in z
                else True
            )
            for out in ["E", "FT", "PT"]
        }
        for row in z.sort_values("date").itertuples():
            r["points"].append(
                [row.date]
                + [
                    (
                        None
                        if pd.isna(getattr(row, c, np.nan))
                        or (c.startswith("index_") and not baseline_ok[c[6:]])
                        else round(float(getattr(row, c)), 3)
                    )
                    for c in ["index_E", "index_FT", "index_PT", "nE", "nFT", "nPT"]
                ]
            )
        rows.append(r)
    return rows


payload = {
    "metadata": {
        "cps_start": "2020-01",
        "cps_end": "2026-10",
        "missing_cps_months": ["2025-10"],
        "baseline": "Calendar-year 2022 monthly mean = 100",
        "ages": AGES,
        "occupations": {str(k): v for k, v in SCOPE.items()},
        "occupation_quintiles": scores[scores.occ.isin(SCOPE)][
            ["occ", "E_q", "THAIE_q", "TIME_q"]
        ].to_dict("records"),
        "minimum_monthly_records": 30,
        "source_vintage": sorted(stan.vintage.unique().tolist()),
        "not_seasonally_adjusted": True,
    },
    "cps_exposure": compact(qi, ["measure", "age", "sex", "quintile"]),
    "cps_occupation": compact(oi, ["scope", "age", "sex"]),
    "cps_computer": compact(ci, ["measure", "age", "sex", "quintile"]),
    "stanford": compact(stan, ["product", "age", "sex", "quintile"]),
}
(D / "monthly.json").write_text(
    json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
)
# Table of cell support, not a precision claim based on weighted population counts.
support = (
    oi.groupby(["scope", "age", "sex"])
    .agg(
        months=("E", "count"),
        median_n=("nE", "median"),
        min_n=("nE", "min"),
        supported_months=("supported_E", "sum"),
    )
    .reset_index()
)
support.to_csv(T / "occupation_monthly_support.csv", index=False)
end = qi[qi.date.eq("2026-10-01") & qi.sex.eq("All")][
    ["measure", "age", "quintile", "index_E", "index_FT", "index_PT", "nE"]
]
end.to_csv(T / "latest_exposure_indices.csv", index=False)
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "savefig.dpi": 180,
    }
)


def decorate(ax):
    ax.axhline(100, color=".65", lw=0.7)
    ax.axvline(pd.Timestamp("2022-11-30"), color=".35", ls=":", lw=1)
    ax.grid(axis="y", alpha=0.15)
    ax.set_xlabel("Month")
    ax.set_ylabel("Employment index, 2022 mean = 100")


def line(ax, z, label, color, out="E", support=True):
    y = z["index_" + out].where(z["supported_" + out]) if support else z["index_" + out]
    ax.plot(pd.to_datetime(z.date), y, label=label, color=color, lw=1.5)


def save(fig, name):
    fig.savefig(F / (name + ".png"), bbox_inches="tight")
    fig.savefig(F / (name + ".svg"), bbox_inches="tight")
    plt.close(fig)


fig, ax = plt.subplots(figsize=(10, 4.8))
for quintile in range(1, 6):
    line(
        ax,
        qi[
            (qi.measure == "THAIE")
            & (qi.age == AGESEL[0])
            & (qi.sex == "All")
            & (qi.quintile == quintile)
        ],
        f"Q{quintile}",
        COLORS[quintile - 1],
    )
decorate(ax)
ax.legend(ncol=5, frameon=False)
ax.set_title("U.S. employment by occupational THAIE quintile, ages 16+")
fig.tight_layout()
save(fig, "monthly_01_all_exposure")
fig, axs = plt.subplots(2, 3, figsize=(14, 8), sharex=True, sharey=True)
for ax, age in zip(axs.flat, AGES):
    for quintile in range(1, 6):
        line(
            ax,
            qi[
                (qi.measure == "THAIE")
                & (qi.age == age)
                & (qi.sex == "All")
                & (qi.quintile == quintile)
            ],
            f"Q{quintile}",
            COLORS[quintile - 1],
        )
    decorate(ax)
    ax.set_title("Ages " + age)
axs.flat[0].legend(ncol=5, fontsize=8, frameon=False)
fig.suptitle(
    "Monthly employment by age and frozen occupational THAIE quintile", fontsize=14
)
fig.tight_layout()
save(fig, "monthly_02_age_exposure")
fig, axs = plt.subplots(1, 2, figsize=(13, 4.8), sharey=False)
for ax, source in zip(axs, ["CPS", "Stanford / ADP"]):
    for j, age in enumerate(AGES):
        z = (
            oi[(oi.scope == "1021") & (oi.age == age) & (oi.sex == "All")]
            if source == "CPS"
            else stan[(stan["product"] == "software_developers") & (stan.age == age)]
        )
        line(ax, z, "Ages " + age, AC[j], support=source == "CPS")
    decorate(ax)
    ax.set_title(source + " software developers")
    ax.legend(fontsize=8, ncol=2, frameon=False)
fig.suptitle(
    "Software developer employment by age, with distinct survey and payroll samples",
    fontsize=13,
)
fig.tight_layout()
save(fig, "monthly_03_software_age")
fig, axs = plt.subplots(2, 3, figsize=(14, 8), sharex=True, sharey=True)
for ax, age in zip(axs.flat, AGES):
    for quintile in range(1, 6):
        for sex, ls in [("Women", "-"), ("Men", "--")]:
            z = qi[
                (qi.measure == "THAIE")
                & (qi.age == age)
                & (qi.sex == sex)
                & (qi.quintile == quintile)
            ]
            ax.plot(
                pd.to_datetime(z.date),
                z.index_E.where(z.supported_E),
                color=COLORS[quintile - 1],
                ls=ls,
                lw=1.2,
                label=f"Q{quintile}, {sex}",
            )
    decorate(ax)
    ax.set_title("Ages " + age)
fig.suptitle("Monthly THAIE quintile trends by age and recorded sex", fontsize=14)
fig.text(
    0.5,
    0.005,
    "Colors identify Q1–Q5. Solid lines show women; dashed lines show men. All series use their own 2022 monthly mean.",
    ha="center",
    fontsize=9,
)
fig.tight_layout(rect=[0, 0.03, 1, 1])
save(fig, "monthly_04_gender_age_exposure")
validation = {
    "months_cps_available": int(a.date.nunique()),
    "calendar_months_requested": 82,
    "missing_months": ["2025-10"],
    "base2022_months": 12,
    "monthly_mean_index2022_check": True,
    "FT_PT_additivity_check": True,
    "direct_age_sex_aggregation_check": True,
    "stanford_months": int(stan.date.nunique()),
    "stanford_first": stan.date.min(),
    "stanford_last": stan.date.max(),
    "software_Census_code": 1021,
    "software_E_quintile": int(scores.set_index("occ").loc[1021, "E_q"]),
    "software_THAIE_quintile": int(scores.set_index("occ").loc[1021, "THAIE_q"]),
    "no_interpolation": True,
    "not_seasonally_adjusted": True,
}
(O / "validation.json").write_text(json.dumps(validation, indent=2))
print(json.dumps(validation, indent=2))
print(
    support[(support.scope == "1021") & (support.sex == "Women")].to_string(index=False)
)
print("Browser payload MB", round((D / "monthly.json").stat().st_size / 1e6, 2))
