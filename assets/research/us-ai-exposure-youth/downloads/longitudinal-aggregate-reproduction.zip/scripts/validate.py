"""Independent numerical, survey-weight and panel-integrity checks; no plots."""

from pathlib import Path
import importlib.util, json
import numpy as np, pandas as pd, statsmodels.api as sm

R = Path(__file__).resolve().parents[1]
P = R.parent
W = R.parents[2] / "work/us_longitudinal"
D = R / "derived"
checks = {}
audit = json.loads((R / "audit/cps_weights.json").read_text())
assert len(audit) == 17
assert max(max(x["fold_iterations"]) for x in audit) < 100
assert max(x["max_relative_margin_error"] for x in audit) < 1e-6
assert all(x["structural_zeros"] == 0 and x["clipped"] <= 2 for x in audit)
checks["CPS_response_fits_and_calibration"] = {
    "years": 17,
    "max_Newton_iterations": max(max(x["fold_iterations"]) for x in audit),
    "max_relative_margin_error": max(x["max_relative_margin_error"] for x in audit),
    "structural_zeros": 0,
    "probability_clipping_needed": sum(x["clipped"] for x in audit),
}
old = pd.read_parquet(P / "adaptation_20261122/derived/matched_flows.parquet")
new = pd.read_parquet(D / "cps_corrected_transitions.parquet")
raw = new[new.method.eq("origin") & new.measure.eq("regional")]
keys = ["GESTFIPS", "age", "subgroup", "year"]
j = raw.merge(old, on=keys, suffixes=("_new", "_old"), validate="one_to_one")
cols = [
    "FT_den",
    "PT_den",
    "FT_to_FT",
    "FT_to_PT",
    "FT_to_PTecon",
    "FT_to_U",
    "FT_to_N",
]
diff = {c: float(abs(j[c + "_new"] - j[c + "_old"]).max()) for c in cols}
assert max(diff.values()) < 1e-5, diff
checks["uncorrected_CPS_reproduces_prior_linked_counts"] = diff
for origin in ["FT", "PT"]:
    assert np.allclose(
        new[origin + "_den"],
        sum(new[origin + "_to_" + c] for c in ["FT", "PT", "U", "N"]),
    )
checks["weighted_transition_accounting_all_methods"] = True
b = (
    pd.read_parquet(W / "sipp_worker_baseline.parquet")
    .sort_values("pid")
    .reset_index(drop=True)
)
panel = pd.read_parquet(W / "sipp_worker_panel.parquet")
assert not panel.duplicated(["pid", "time"]).any()
assert panel.groupby("pid").size().eq(48).all()
assert len(panel) == len(b) * 48
assert np.allclose(
    panel.employed, panel.full_intensity + panel.part_intensity, equal_nan=True
)
checks["SIPP_worker_cohort"] = {
    "persons": len(b),
    "person_months": len(panel),
    "months_per_person": 48,
    "hours_identity": True,
}
rep = pd.read_parquet(W / "sipp_replicate_weights.parquet")
rw = ["REPWGT" + str(i) for i in range(241)]
bw = b.merge(
    rep[["SSUID", "PNUM", "SPANEL"] + rw],
    on=["SSUID", "PNUM", "SPANEL"],
    validate="one_to_one",
)
assert np.allclose(bw.FINYR4, bw.REPWGT0)
assert (bw[rw].to_numpy() > 0).all()
checks["official_longitudinal_weight_equals_replicate0"] = True
# Independently refit adjusted all-adult THAIE hours differences in statsmodels.
s = importlib.util.spec_from_file_location("model", R / "scripts/sipp_models.py")
a = importlib.util.module_from_spec(s)
s.loader.exec_module(a)
year = panel[panel.MONTHCODE.le(9)].groupby(["pid", "year"])[a.OUT].mean()
yy = {
    y: year.xs(y, level="year").reindex(b.pid)[a.OUT].to_numpy(float)
    for y in range(2021, 2025)
}
Yall = np.column_stack(
    [
        (yy[2023] + yy[2024] - yy[2021] - yy[2022]) / 2,
        yy[2021] - yy[2022],
        yy[2023] - yy[2022],
        yy[2024] - yy[2022],
    ]
)
valid = np.isfinite(Yall).all(axis=1)
g = b[valid]
weights = bw.loc[valid, rw].to_numpy()
delta = Yall[valid, 0]
state = pd.get_dummies(
    g.TEHC_ST.astype(int), prefix="state", drop_first=True, dtype=float
)
age = (g.age_at_event.to_numpy() - 40) / 20
X = np.column_stack(
    [np.ones(len(g)), g.THAIE_q.eq(5).to_numpy(float), state.to_numpy(), age, age**2]
    + [
        g[c].to_numpy()
        for c in [
            "female",
            "no_BA",
            "black",
            "hispanic",
            "foreign",
            "disabled",
            "low_income",
        ]
    ]
)
names = (
    ["intercept", "high"]
    + list(state.columns)
    + [
        "age",
        "age_squared",
        "female",
        "no_BA",
        "black",
        "hispanic",
        "foreign",
        "disabled",
        "low_income",
    ]
)
X, names = a.independent(X, names, weights[:, 0])
ix = names.index("high")
bs = []
for k in range(241):
    bs.append(float(sm.WLS(delta, X, weights=weights[:, k]).fit().params[ix]))
bs = np.array(bs)
se = np.sqrt(4 / 240 * np.sum((bs[1:] - bs[0]) ** 2))
saved = (
    pd.read_csv(D / "sipp_within_person_results.csv")
    .query(
        "age=='all16plus' and subgroup=='all' and measure=='THAIE' and model=='adjusted' and contrast=='pooled_DID' and outcome=='hours'"
    )
    .iloc[0]
)
assert abs(bs[0] - saved.estimate) < 1e-7 and abs(se - saved.se) < 1e-7
checks["independent_statsmodels_point_and_240_Fay_replicates"] = {
    "coefficient_error": abs(bs[0] - saved.estimate),
    "SE_error": abs(se - saved.se),
    "replicates": 240,
    "Fay": 0.5,
}
# Main SIPP models should have no unsupported estimates encoded as zeros.
r = pd.read_csv(D / "sipp_within_person_results.csv")
assert r.loc[r.status.ne("estimated"), "estimate"].isna().all()
assert len(r) == 5760
checks["all_planned_SIPP_comparisons_retained"] = len(r)
checks["graphs_emitted"] = False
(R / "audit/validation.json").write_text(json.dumps(checks, indent=2))
print(json.dumps(checks, indent=2))
