"""Construct baseline-exposure SIPP worker cohort and auditable outcomes."""

from pathlib import Path
import importlib.util, json, re
import numpy as np, pandas as pd

R = Path(__file__).resolve().parents[1]
P = R.parent
W = R.parents[2] / "work/us_longitudinal"
s = importlib.util.spec_from_file_location(
    "prior", P / "panel_fe3_20261122/scripts/prepare_panel.py"
)
p = importlib.util.module_from_spec(s)
s.loader.exec_module(p)
KEY = ["SSUID", "PNUM", "SPANEL"]
METRICS = ["E", "THAIE", "TIME"]
if __name__ == "__main__":
    d = pd.read_parquet(W / "sipp_cohort_person_months.parquet")
    d = d[d.RIN_UNIV.eq(1)].copy()
    d["time"] = d.year * 12 + d.MONTHCODE
    hours = np.column_stack(
        [
            d.get(f"TJB{i}_MWKHRS", pd.Series(np.nan, index=d.index)).to_numpy()
            for i in range(1, 8)
        ]
    )
    hours = np.where(hours >= 0, hours, np.nan)
    d["hours"] = np.nansum(hours, axis=1)
    d["employed"] = d.RMESR.between(1, 5).astype(float)
    d.loc[~d.RMESR.between(1, 8), "employed"] = np.nan
    d["nonemployed"] = 1 - d.employed
    d["hours"] = d.hours.where(d.employed.notna())
    d.loc[d.employed.eq(0), "hours"] = 0
    # This is a month-averaged work-intensity measure, not the CPS usual FT recode.
    d["full_intensity"] = ((d.hours >= 35) & d.employed.eq(1)).astype(float)
    d["part_intensity"] = ((d.hours < 35) & d.employed.eq(1)).astype(float)
    for c in ["full_intensity", "part_intensity"]:
        d.loc[d.employed.isna(), c] = np.nan
    active = np.column_stack(
        [
            d.get(f"EJB{i}_JBORSE", pd.Series(np.nan, index=d.index)).to_numpy()
            for i in range(1, 8)
        ]
    )
    d["any_employee"] = (active == 1).any(axis=1).astype(float)
    d["any_self"] = (active == 2).any(axis=1).astype(float)
    d["any_other"] = (active == 3).any(axis=1).astype(float)
    for c in ["any_employee", "any_self", "any_other"]:
        d.loc[d.employed.isna(), c] = np.nan
    # Main current arrangement uses the job with the highest monthly average hours; ties use earlier slot.
    best = np.argmax(np.nan_to_num(hours, nan=-1), axis=1)
    besthours = np.nanmax(np.where(np.isnan(hours), -1, hours), axis=1)
    d["main_arrangement"] = active[np.arange(len(d)), best]
    d.loc[d.employed.eq(0) | (besthours < 0), "main_arrangement"] = 0
    jobids = np.column_stack(
        [
            d.get(f"EJB{i}_JOBID", pd.Series(np.nan, index=d.index)).to_numpy()
            for i in range(1, 8)
        ]
    )
    d["main_job_id"] = jobids[np.arange(len(d)), best]
    d.loc[d.employed.eq(0), "main_job_id"] = np.nan
    d["no_ongoing_other"] = 0.0
    for i in range(1, 8):
        if f"EJB{i}_CONCHK" in d:
            d["no_ongoing_other"] = np.maximum(
                d.no_ongoing_other,
                ((d[f"EJB{i}_JBORSE"] == 3) & (d[f"EJB{i}_CONCHK"] == 2)).astype(float),
            )
    d["earnings"] = d.TPEARN.where(d.TPEARN.notna() | d.employed.ne(0), 0)
    d.loc[d.employed.eq(0) & d.TPEARN.isna(), "earnings"] = 0
    d["income"] = d.TPTOTINC
    cpi = p.cpi_values()
    # Prior CPI cache has all 2021–2024 months, including Oct–Dec.
    factors = np.array(
        [cpi[2026, 9] / cpi[int(y), int(m)] for y, m in zip(d.year, d.MONTHCODE)]
    )
    d["real_earnings"] = d.earnings * factors
    d["real_income"] = d.income * factors
    d["asinh_earnings"] = np.arcsinh(d.real_earnings / 1000)
    d["asinh_income"] = np.arcsinh(d.real_income / 1000)
    baseline = d[d.year.eq(2021)].copy()
    parts = []
    for i in range(1, 8):
        cols = ["pid", f"TJB{i}_OCC", f"TJB{i}_MWKHRS"]
        v = baseline[cols].rename(columns={cols[1]: "occ", cols[2]: "h"})
        v = v[v.h.gt(0) & v.occ.notna()]
        parts.append(v)
    jobs = pd.concat(parts)
    jobs.occ = jobs.occ.astype(int)
    scores = pd.read_csv(P / "high_exposure_quality/derived/occupation_quintiles.csv")
    matched = jobs.merge(
        scores[["occ"] + METRICS + [m + "_q" for m in METRICS]],
        on="occ",
        how="left",
        validate="many_to_one",
    )
    valid = matched[METRICS].notna().all(axis=1)
    coverage = matched.groupby("pid").h.sum().to_frame("hours_base")
    coverage["matched_hours"] = matched[valid].groupby("pid").h.sum()
    coverage["coverage"] = (coverage.matched_hours / coverage.hours_base).fillna(0)
    totals = matched[valid].groupby(["pid", "occ"], as_index=False).h.sum()
    dom = (
        totals.sort_values(["pid", "h", "occ"], ascending=[True, False, True])
        .drop_duplicates("pid")
        .merge(scores[["occ"] + METRICS + [m + "_q" for m in METRICS]], on="occ")
    )
    # Eligibility/characteristics from Dec 2021, age at the pre-release October 2022 snapshot.
    dec = d[d.year.eq(2021) & d.MONTHCODE.eq(12)].copy()
    age = d[d.year.eq(2022) & d.MONTHCODE.eq(10)][["pid", "TAGE_EHC"]].rename(
        columns={"TAGE_EHC": "age_at_event"}
    )
    fields = (
        ["pid"]
        + KEY
        + [
            "TAGE_EHC",
            "ESEX",
            "ERACE",
            "EORIGIN",
            "EEDUC",
            "EBORNUS",
            "EDISABL",
            "THCYINCPOV",
            "TEHC_ST",
            "FINYR4",
            "GVARSTR",
            "GHLFSAM",
        ]
    )
    base = (
        dec[fields]
        .merge(age, on="pid", validate="one_to_one")
        .merge(dom, on="pid", validate="one_to_one")
        .merge(coverage.reset_index(), on="pid", validate="one_to_one")
    )
    base = base[
        base.TAGE_EHC.ge(16) & base.age_at_event.ge(16) & base.coverage.ge(0.9)
    ].copy()
    nmonths = d.groupby("pid").size()
    base["nmonths"] = base.pid.map(nmonths)
    # The baseline adult worker cohort happens to be fully observed; assert rather than silently drop attriters.
    pre_balanced = len(base)
    base_all = base.copy()
    base_all.to_parquet(
        W / "sipp_worker_baseline_with_out_of_universe.parquet", index=False
    )
    base = base[base.nmonths.eq(48)].copy()
    for name, mask in {
        "female": base.ESEX.eq(2),
        "no_BA": base.EEDUC.lt(43),
        "black": base.ERACE.eq(2),
        "hispanic": base.EORIGIN.eq(1),
        "foreign": base.EBORNUS.eq(2),
        "disabled": base.EDISABL.eq(1),
        "low_income": base.THCYINCPOV.between(0, 2, inclusive="left"),
    }.items():
        base[name] = mask.astype(int)
    base.to_parquet(W / "sipp_worker_baseline.parquet", index=False)
    keep = [
        "pid",
        "year",
        "MONTHCODE",
        "time",
        "hours",
        "employed",
        "nonemployed",
        "full_intensity",
        "part_intensity",
        "any_employee",
        "any_self",
        "any_other",
        "no_ongoing_other",
        "real_earnings",
        "real_income",
        "asinh_earnings",
        "asinh_income",
        "main_arrangement",
        "main_job_id",
        "EINTTYPE",
    ]
    person = d[keep].merge(base, on="pid", validate="many_to_one")
    person.to_parquet(W / "sipp_worker_panel.parquet", index=False)
    profile = []
    for y, g in person.groupby("year"):
        profile.append(
            dict(
                year=int(y),
                persons=g.pid.nunique(),
                rows=len(g),
                missing_earnings=float(g.real_earnings.isna().mean()),
                missing_income=float(g.real_income.isna().mean()),
                missing_hours=float(g.hours.isna().mean()),
                mean_hours=float(np.average(g.hours, weights=g.FINYR4)),
                negative_earnings=int(g.real_earnings.lt(0).sum()),
            )
        )
    pd.DataFrame(profile).to_csv(R / "derived/sipp_outcome_coverage.csv", index=False)
    summary = dict(
        official_four_year_people=int(d.pid.nunique()),
        baseline_workers_positive_hours=int(jobs.pid.nunique()),
        worker_cohort=int(len(base)),
        baseline_workers_before_continuous_frame_restriction=int(pre_balanced),
        excluded_noncontinuous_frame=int(pre_balanced - len(base)),
        person_months=int(len(person)),
        baseline_hours_matched_fraction=float(
            matched.loc[valid, "h"].sum() / matched.h.sum()
        ),
        cohort_min_occupation_coverage=float(base.coverage.min()),
        all_worker_cohort_months=48,
        states=int(base.TEHC_ST.nunique()),
        pre_event_age_bands=base.age_at_event.value_counts().sort_index().to_dict(),
        ages_at_event="October 2022",
        baseline_exposure="2021 dominant occupation by cumulative monthly-average hours",
        income_zero_rule="TPEARN missing is set to zero only for RMESR 6–8 no-job months; employed missing remains missing",
        hours_definition="Sum of all available job monthly-average weekly hours; includes non-work weeks as zero; not usual FT/PT",
    )
    (R / "audit/sipp_worker_cohort.json").write_text(json.dumps(summary, indent=2))
    print("Worker cohort", len(base), "person months", len(person), flush=True)
