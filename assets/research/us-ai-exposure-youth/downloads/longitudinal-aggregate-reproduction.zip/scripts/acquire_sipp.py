"""Acquire official SIPP microdata and longitudinal-weight documentation."""

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests, json, hashlib, time

R = Path(__file__).resolve().parents[1]
W = R.parents[2] / "work/us_longitudinal/raw"
W.mkdir(parents=True, exist_ok=True)
jobs = []
for y in range(2022, 2026):
    root = f"https://www2.census.gov/programs-surveys/sipp/data/datasets/{y}/"
    for f in [f"pu{y}_csv.zip", f"pu{y}_schema.json"]:
        jobs.append((root + f, f))
root = "https://www2.census.gov/programs-surveys/sipp/data/datasets/2025/"
for f in [
    "lgtwgt2025yr4_csv.zip",
    "lgtwgt2025yr4_schema.json",
    "lgtrw2025yr4_csv.zip",
    "lgtrw2025yr4_schema.json",
]:
    jobs.append((root + f, f))
for f in [
    "2025_SIPP_Data_Dictionary.pdf",
    "lgtwgt2025_dictionary.txt",
    "lgtrw2025_dictionary.txt",
]:
    jobs.append(
        (
            "https://www2.census.gov/programs-surveys/sipp/tech-documentation/data-dictionaries/2025/"
            + f,
            f,
        )
    )
for y in [2022, 2023, 2024]:
    jobs.append(
        (
            f"https://www2.census.gov/programs-surveys/sipp/tech-documentation/data-dictionaries/{y}/{y}_SIPP_Data_Dictionary.pdf",
            f"{y}_SIPP_Data_Dictionary.pdf",
        )
    )


def get(job):
    url, name = job
    p = W / name
    if not p.exists():
        with requests.get(url, stream=True, timeout=90) as r:
            r.raise_for_status()
            with p.with_suffix(p.suffix + ".partial").open("wb") as out:
                for b in r.iter_content(1024 * 1024):
                    out.write(b)
        p.with_suffix(p.suffix + ".partial").rename(p)
    h = hashlib.sha256(p.read_bytes()).hexdigest()
    print(name, p.stat().st_size, flush=True)
    return dict(url=url, file=name, bytes=p.stat().st_size, sha256=h)


if __name__ == "__main__":
    rows = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        fut = {pool.submit(get, j): j for j in jobs}
        for f in as_completed(fut):
            try:
                rows.append(f.result())
            except Exception as e:
                rows.append(dict(url=fut[f][0], file=fut[f][1], error=str(e)))
                print("Acquisition error", fut[f][1], str(e), flush=True)
    (R / "audit/sipp_sources.json").write_text(json.dumps(rows, indent=2))
