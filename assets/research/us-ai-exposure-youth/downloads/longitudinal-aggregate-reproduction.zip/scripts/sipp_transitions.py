"""Observed SIPP person paths, with official longitudinal replicate inference."""

from pathlib import Path
import importlib.util, json
import numpy as np, pandas as pd
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests

R = Path(__file__).resolve().parents[1]
W = R.parents[2] / "work/us_longitudinal"
D = R / "derived"
s = importlib.util.spec_from_file_location("sm", R / "scripts/sipp_models.py")
a = importlib.util.module_from_spec(s)
s.loader.exec_module(a)
if __name__ == "__main__":
    b = (
        pd.read_parquet(W / "sipp_worker_baseline.parquet")
        .sort_values("pid")
        .reset_index(drop=True)
    )
    d = pd.read_parquet(W / "sipp_worker_panel.parquet").sort_values(["pid", "time"])
    rep = pd.read_parquet(W / "sipp_replicate_weights.parquet")
    bw = b.merge(
        rep[a.KEY + ["REPWGT" + str(i) for i in range(241)]],
        on=a.KEY,
        validate="one_to_one",
    )
    ww = bw[["REPWGT" + str(i) for i in range(241)]].to_numpy()
    prev = d.groupby("pid")[
        ["time", "full_intensity", "main_arrangement", "employed"]
    ].shift(1)
    valid = d.time.eq(prev.time + 1) & d.MONTHCODE.between(2, 9)
    flows = {
        "full_to_part": (prev.full_intensity.eq(1), d.part_intensity.eq(1)),
        "full_to_nonemployment": (prev.full_intensity.eq(1), d.nonemployed.eq(1)),
        "employee_to_self": (prev.main_arrangement.eq(1), d.main_arrangement.eq(2)),
        "employee_to_other": (prev.main_arrangement.eq(1), d.main_arrangement.eq(3)),
        "employee_to_no_ongoing_other": (
            prev.main_arrangement.eq(1),
            d.no_ongoing_other.eq(1) & d.main_arrangement.eq(3),
        ),
        "employee_to_nonemployment": (prev.main_arrangement.eq(1), d.nonemployed.eq(1)),
    }
    d["period"] = np.where(d.year.ge(2023), "post", "pre")
    counts = {}
    for name, (origin, dest) in flows.items():
        for period in ["pre", "post"]:
            mask = valid & d.period.eq(period)
            tmp = (
                pd.DataFrame(
                    {
                        "pid": d.pid,
                        "den": (mask & origin).astype(int),
                        "num": (mask & origin & dest).astype(int),
                    }
                )
                .groupby("pid")[["den", "num"]]
                .sum()
                .reindex(b.pid)
                .fillna(0)
            )
            counts[name, period] = tmp.to_numpy(float)
    results = []
    descriptive = []
    for age, sub, mask in a.groups(b):
        for metric in a.M:
            hi = b[metric + "_q"].eq(5).to_numpy()
            for name in flows:
                rates = {}
                ok = True
                meta = dict(age=age, subgroup=sub, measure=metric, transition=name)
                for band, bandmask in [("Q5", hi), ("Q1_Q4", ~hi)]:
                    im = mask & bandmask
                    w = ww[im]
                    for period in ["pre", "post"]:
                        values = counts[name, period][im]
                        origins = int((values[:, 0] > 0).sum())
                        events = int(values[:, 1].sum())
                        num = values[:, 1] @ w
                        den = values[:, 0] @ w
                        rr = (
                            np.divide(num, den, out=np.full(241, np.nan), where=den > 0)
                            * 100
                        )
                        rates[band, period] = rr
                        descriptive.append(
                            meta
                            | dict(
                                band=band,
                                period=period,
                                origin_persons=origins,
                                observed_events=events,
                                estimate=float(rr[0]),
                                rare_events=events < 5,
                            )
                        )
                        ok = ok and origins >= 20
                if ok:
                    effect = (
                        rates["Q5", "post"]
                        - rates["Q5", "pre"]
                        - rates["Q1_Q4", "post"]
                        + rates["Q1_Q4", "pre"]
                    )
                    est = effect[0]
                    se = np.sqrt(4 / 240 * np.sum((effect[1:] - est) ** 2))
                    results.append(
                        meta
                        | dict(
                            status="estimated",
                            estimate=est,
                            se=se,
                            ci_low=est - 1.96 * se,
                            ci_high=est + 1.96 * se,
                            p_value=2 * norm.sf(abs(est / se)) if se else np.nan,
                        )
                    )
                else:
                    results.append(meta | dict(status="unsupported_origin_domain"))
        print("SIPP paths", age, sub, flush=True)
    r = pd.DataFrame(results)
    r["p_holm_all"] = multipletests(r.p_value.fillna(1), method="holm")[1]
    r.to_csv(D / "sipp_observed_transition_DID.csv", index=False)
    pd.DataFrame(descriptive).to_csv(
        D / "sipp_observed_transition_rates.csv", index=False
    )
    # Within-person endpoints retain later nonemployment; percentage earnings loss only conditions on baseline positive earnings.
    by = d.groupby(["pid", "year"])[
        [
            "hours",
            "real_earnings",
            "real_income",
            "employed",
            "any_employee",
            "any_self",
            "any_other",
        ]
    ].mean()
    base = by.xs(2021, level="year").reindex(b.pid)
    end = by.xs(2024, level="year").reindex(b.pid)
    outcomes = {
        "hours_change_2021_2024": end.hours - base.hours,
        "real_monthly_earnings_change_2021_2024": end.real_earnings
        - base.real_earnings,
        "real_monthly_income_change_2021_2024": end.real_income - base.real_income,
        "earnings_loss_20pct": (end.real_earnings <= 0.8 * base.real_earnings)
        .astype(float)
        .where(base.real_earnings > 0),
        "hours_loss_20pct": (end.hours <= 0.8 * base.hours)
        .astype(float)
        .where(base.hours > 0),
    }
    rows = []
    for age, sub, mask in a.groups(b):
        for metric in a.M:
            for band, hm in [
                ("Q5", b[metric + "_q"].eq(5).to_numpy()),
                ("Q1_Q4", b[metric + "_q"].ne(5).to_numpy()),
            ]:
                for outcome, values in outcomes.items():
                    vals = values.to_numpy()
                    im = mask & hm & np.isfinite(vals)
                    n = int(im.sum())
                    if n < 20:
                        continue
                    weights = ww[im]
                    means = vals[im] @ weights / weights.sum(axis=0)
                    se = np.sqrt(4 / 240 * np.sum((means[1:] - means[0]) ** 2))
                    scale = 100 if "loss_20pct" in outcome else 1
                    rows.append(
                        dict(
                            age=age,
                            subgroup=sub,
                            measure=metric,
                            band=band,
                            outcome=outcome,
                            persons=n,
                            estimate=means[0] * scale,
                            ci_low=(means[0] - 1.96 * se) * scale,
                            ci_high=(means[0] + 1.96 * se) * scale,
                        )
                    )
    pd.DataFrame(rows).to_csv(D / "sipp_person_endpoint_changes.csv", index=False)
    print("SIPP paths complete", len(r), flush=True)
