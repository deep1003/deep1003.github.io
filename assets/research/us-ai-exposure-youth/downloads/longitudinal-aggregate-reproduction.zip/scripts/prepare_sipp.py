"""Stream selected SIPP columns and keep person records only in work."""

from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import json, zipfile, re, hashlib
import numpy as np, pandas as pd

R = Path(__file__).resolve().parents[1]
W = R.parents[2] / "work/us_longitudinal"
RAW = W / "raw"
KEY = ["SSUID", "PNUM", "SPANEL"]
BASE = [
    "SSUID",
    "PNUM",
    "SPANEL",
    "SWAVE",
    "MONTHCODE",
    "TAGE",
    "TAGE_EHC",
    "ESEX",
    "ERACE",
    "EORIGIN",
    "EEDUC",
    "EBORNUS",
    "ECITIZEN",
    "EDISABL",
    "TEHC_ST",
    "THHLDSTATUS",
    "RIN_UNIV",
    "EINTTYPE",
    "WPFINWGT",
    "RMESR",
    "RMWKWJB",
    "RMWKLKG",
    "RMWKSAB",
    "TPEARN",
    "TPEARNALT",
    "TPTOTINC",
    "THINCPOV",
    "THCYINCPOV",
    "GVARSTR",
    "GHLFSAM",
]
JOB = ["OCC", "MWKHRS", "MSUM", "MSUMALT", "JOBHRS1", "JOBHRS2", "JOBHRS3"]
EMP = [
    "JOBID",
    "JBORSE",
    "CONCHK",
    "CLWRK",
    "CNTRC",
    "RSEND",
    "BMONTH",
    "EMONTH",
    "CHHOMN1",
    "CHHOMN2",
    "PTRESN1",
    "PTRESN2",
    "PTRESN3",
]
COLUMNS = (
    BASE
    + [f"TJB{i}_{x}" for i in range(1, 8) for x in JOB]
    + [f"EJB{i}_{x}" for i in range(1, 8) for x in EMP]
    + [f"TWKHRS{i}" for i in range(1, 6)]
)


def read_weights():
    with zipfile.ZipFile(RAW / "lgtwgt2025yr4_csv.zip") as z:
        d = pd.read_csv(z.open(z.namelist()[0]), sep="|", dtype={"ssuid": "string"})
    d.columns = d.columns.str.upper()
    assert not d.duplicated(KEY).any()
    assert (d.FINYR4 > 0).all()
    d["SSUID"] = d.SSUID.str.zfill(14)
    d.to_parquet(W / "sipp_longitudinal_weights.parquet", index=False)
    with zipfile.ZipFile(RAW / "lgtrw2025yr4_csv.zip") as z:
        rep = pd.read_csv(z.open(z.namelist()[0]), sep="|", dtype={"SSUID": "string"})
    rep.columns = rep.columns.str.upper()
    rep["SSUID"] = rep.SSUID.str.zfill(14)
    assert not rep.duplicated(KEY).any()
    rep.to_parquet(W / "sipp_replicate_weights.parquet", index=False)
    print(
        "Longitudinal weight persons",
        len(d),
        "panels",
        d.SPANEL.value_counts().to_dict(),
        "replicate columns",
        len([c for c in rep if c.startswith("REPWGT")]),
        flush=True,
    )
    return d


def year(release):
    schema = json.loads((RAW / f"pu{release}_schema.json").read_text())
    present = {s["name"] for s in schema}
    cols = [c for c in COLUMNS if c in present]
    chunks = []
    with zipfile.ZipFile(RAW / f"pu{release}_csv.zip") as z:
        assert len(z.namelist()) == 1
        with z.open(z.namelist()[0]) as stream:
            for d in pd.read_csv(
                stream,
                sep="|",
                usecols=cols,
                dtype={"SSUID": "string"},
                na_values=[".", ""],
                chunksize=12000,
                low_memory=False,
            ):
                d["SSUID"] = d.SSUID.str.zfill(14)
                d["year"] = release - 1
                chunks.append(d)
    d = pd.concat(chunks, ignore_index=True)
    assert not d.duplicated(KEY + ["MONTHCODE"]).any()
    d.to_parquet(W / f"sipp_{release}.parquet", index=False)
    summary = dict(
        release=release,
        reference_year=release - 1,
        rows=len(d),
        persons=len(d[KEY].drop_duplicates()),
        fields=len(cols),
        missing_requested=sorted(set(COLUMNS) - present),
        panels=d.SPANEL.value_counts().to_dict(),
        month_counts=d.MONTHCODE.value_counts().sort_index().to_dict(),
    )
    (R / "audit" / f"sipp_parse_{release}.json").write_text(
        json.dumps(summary, indent=2)
    )
    print("Read SIPP", release, len(d), len(cols), flush=True)
    return summary


if __name__ == "__main__":
    w = read_weights()
    with ProcessPoolExecutor(max_workers=2) as pool:
        futures = [
            pool.submit(year, y)
            for y in range(2022, 2026)
            if not (W / f"sipp_{y}.parquet").exists()
        ]
        for f in as_completed(futures):
            f.result()
    # Restrict to the official four-year cohort before storing a compact panel.
    pieces = []
    for y in range(2022, 2026):
        d = pd.read_parquet(W / f"sipp_{y}.parquet")
        d = d.merge(w, on=KEY, validate="many_to_one", how="inner")
        pieces.append(d)
    d = pd.concat(pieces, ignore_index=True)
    assert not d.duplicated(KEY + ["year", "MONTHCODE"]).any()
    d["pid"] = pd.factorize(pd.MultiIndex.from_frame(d[KEY]), sort=True)[0]
    # Person records stay in work; no individual identifier appears in outputs.
    d.to_parquet(W / "sipp_cohort_person_months.parquet", index=False)
    summary = dict(
        rows=len(d),
        persons=d.pid.nunique(),
        reference_years=sorted(d.year.unique().tolist()),
        months_per_person=d.groupby("pid").size().value_counts().sort_index().to_dict(),
        weight_matched_persons=len(w),
        panels=d.SPANEL.value_counts().to_dict(),
    )
    (R / "audit/sipp_panel_integrity.json").write_text(json.dumps(summary, indent=2))
    print("SIPP cohort", summary, flush=True)
