from pathlib import Path
import json, hashlib
import pandas as pd, numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

R = Path("outputs/US_THAIE_Regional_Youth_20261122/longitudinal_20261122")
D = R / "derived"
F = R / "figures"
r = pd.read_csv(D / "sipp_within_person_results.csv")
c = pd.read_csv(D / "cps_corrected_DID.csv")
t = pd.read_csv(D / "sipp_observed_transition_DID.csv")
ages = ["all16plus", "age22_25", "age26_29", "age30_34"]
labels = ["All baseline workers", "22–25", "26–29", "30–34"]
colors = {"E": "#286090", "THAIE": "#b54532", "TIME": "#5f8347"}
plt.rcParams.update(
    {
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "savefig.dpi": 180,
    }
)
figs = []


def save(fig, name):
    fig.savefig(F / (name + ".png"), bbox_inches="tight")
    fig.savefig(F / (name + ".pdf"), bbox_inches="tight")
    figs.append(fig)


def forest(ax, dat, outcome, title):
    for k, m in enumerate(colors):
        q = (
            dat[dat.measure.eq(m) & dat.outcome.eq(outcome)]
            .set_index("age")
            .reindex(ages)
        )
        y = np.arange(4) + (k - 1) * 0.19
        ax.errorbar(
            q.estimate,
            y,
            xerr=[q.estimate - q.ci_low, q.ci_high - q.estimate],
            fmt="o",
            ms=4,
            color=colors[m],
            label=m,
            capsize=2,
        )
    ax.axvline(0, color=".6", lw=0.8)
    ax.set_yticks(range(4), labels)
    ax.invert_yaxis()
    ax.set_title(title)
    ax.grid(axis="x", alpha=0.15)


fig, axs = plt.subplots(1, 3, figsize=(13, 4))
sel = r.query("subgroup=='all' and model=='adjusted' and contrast=='pooled_DID'")
for ax, o, ti in zip(
    axs,
    ["hours", "part_intensity", "real_earnings"],
    [
        "Weekly hours change",
        "Lower monthly hours intensity (pp)",
        "Monthly real earnings change ($)",
    ],
):
    forest(ax, sel, o, ti)
axs[0].legend()
fig.suptitle("SIPP within-person change, 2023–24 versus 2021–22, Q5 relative to Q1–Q4")
fig.text(
    0.5,
    -0.05,
    "January–September means · 95% Fay BRR intervals · Age fixed October 2022 · Baseline 2021 workers\nAdjusted for baseline state and demographics · Monthly intensity is not usual full-time/part-time status",
    ha="center",
    fontsize=9,
)
fig.tight_layout()
save(fig, "sipp_within_person_DID")
fig, axs = plt.subplots(2, 2, figsize=(11, 7))
tr = pd.read_csv(D / "sipp_monthly_trajectories.csv")
for ax, age, lab in zip(axs.flat, ages, labels):
    for band, color in [("Q5", "#b54532"), ("Q1_Q4", "#286090")]:
        q = tr.query(
            "measure=='THAIE' and subgroup=='all' and outcome=='hours' and age==@age and band==@band"
        ).sort_values(["year", "month"])
        x = q.year + (q.month - 0.5) / 12
        ax.plot(x, q.estimate, label=band, color=color)
        ax.fill_between(x, q.ci_low, q.ci_high, color=color, alpha=0.1)
    ax.axvline(2022 + 11 / 12, color=".4", ls=":")
    ax.set_title(lab)
    ax.set_ylabel("Monthly-average weekly hours")
    ax.grid(alpha=0.15)
axs[0, 0].legend()
fig.suptitle("SIPP observed hours trajectories, THAIE baseline exposure")
fig.text(
    0.5,
    0.01,
    "Same 2021 workers, including later nonemployment · 95% Fay BRR intervals · Descriptive, not causal",
    ha="center",
    fontsize=9,
)
fig.tight_layout(rect=[0, 0.035, 1, 0.95])
save(fig, "sipp_monthly_hours")
fig, axs = plt.subplots(1, 3, figsize=(12, 4))
for ax, age, lab in zip(axs, ages[1:], labels[1:]):
    for model, col in [("basic", "#777777"), ("adjusted", "#b54532")]:
        q = r.query(
            "age==@age and subgroup=='all' and measure=='THAIE' and outcome=='part_intensity' and model==@model and contrast!='pooled_DID'"
        ).copy()
        q["year"] = q.contrast.str[-4:].astype(int)
        q = q.sort_values("year")
        ax.errorbar(
            q.year,
            q.estimate,
            yerr=[q.estimate - q.ci_low, q.ci_high - q.estimate],
            fmt="o-",
            color=col,
            label=model,
            capsize=3,
        )
    ax.axhline(0, color=".6", lw=0.8)
    ax.axvline(2022.92, ls=":", color=".5")
    ax.set_title(lab)
    ax.set_xticks([2021, 2022, 2023, 2024])
    ax.set_ylabel("Q5 relative change, pp")
    ax.grid(alpha=0.15)
axs[0].legend()
fig.suptitle("SIPP annual event contrasts for lower monthly hours intensity")
fig.text(
    0.5,
    -0.035,
    "2022 reference · January–September means · Only one pre-period contrast · 95% Fay BRR intervals\n22–25 has 28 THAIE Q5 people; model sensitivity and pre-trends prevent a causal interpretation",
    ha="center",
    fontsize=9,
)
fig.tight_layout()
save(fig, "sipp_event_sensitivity")
fig, axs = plt.subplots(1, 2, figsize=(10, 4))
for ax, o, ti in zip(
    axs,
    ["FT_to_PT_rate", "FT_to_PTecon_rate"],
    ["Usual full-time to usual part-time", "Full-time to economic short hours"],
):
    for k, method in enumerate(["origin", "calibrated"]):
        q = (
            c.query(
                "level=='occupation' and subgroup=='all' and measure=='THAIE' and model=='adjusted' and outcome==@o and method==@method"
            )
            .set_index("age")
            .reindex(ages[1:])
        )
        y = np.arange(3) + (k - 0.5) * 0.16
        ax.errorbar(
            q.estimate,
            y,
            xerr=[q.estimate - q.ci_low, q.ci_high - q.estimate],
            fmt="o",
            label=method,
            capsize=3,
        )
    ax.axvline(0, color=".5")
    ax.set_yticks(range(3), labels[1:])
    ax.invert_yaxis()
    ax.set_title(ti)
    ax.set_xlabel("Post-2022 differential, percentage points")
axs[0].legend()
fig.suptitle("Linked CPS attrition sensitivity, THAIE Q5 versus Q1–Q4")
fig.text(
    0.5,
    -0.04,
    "2017–2026 models · Adjusted specification · State-cluster intervals condition on estimated response weights",
    ha="center",
    fontsize=9,
)
fig.tight_layout()
save(fig, "cps_attrition_sensitivity")
with PdfPages(F / "LONGITUDINAL_FIGURES.pdf") as pdf:
    for fig in figs:
        pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
# Machine-readable variable audit. Each row distinguishes question universe from interpretation.
rows = [
    (
        "EJB*_JBORSE",
        "All reported job arrangements",
        "1 employer; 2 own business/self-employment; 3 other arrangement",
        "Employee, self-employment and other work",
        "No permanent versus fixed-term distinction",
        "Used",
    ),
    (
        "EJB*_CONCHK",
        "Only JBORSE=3",
        "1 ongoing employer arrangement; 2 no ongoing arrangement",
        "Loose attachment among other arrangements",
        "Not a contract-duration or fixed-term variable",
        "Used as narrowly labelled proxy",
    ),
    (
        "EJB*_CNTRC",
        "Union coverage universe",
        "Union contract coverage",
        "Collective bargaining coverage",
        "Does not mean fixed-term employment contract",
        "Not used for contract status",
    ),
    (
        "EJB*_RSEND",
        "Ended job spells",
        "4 temporary/seasonal job completed",
        "Reason for a job ending",
        "Cannot classify continuing jobs as permanent or temporary",
        "Available, not main outcome",
    ),
    (
        "EJB*_PTRESN1",
        "Job-spell beginning part-time universe",
        "Includes unable to find full-time and slack business",
        "Reason for initial part-time hours",
        "Not an automatically monthly updated involuntary-part-time measure; later reason stages need spell alignment",
        "Available, not main outcome",
    ),
    (
        "EJB*_JOBID",
        "Job spells within person",
        "Persistent job identifier",
        "Observe job changes across waves",
        "A job change is not necessarily a contract-type change",
        "Used internally only",
    ),
    (
        "TJB*_MWKHRS",
        "Job monthly records",
        "Average weekly hours over month",
        "Hours intensity, including nonwork weeks",
        "Below 35 can reflect a partial job month, not usual part-time status",
        "Used",
    ),
    (
        "TPEARN / TPTOTINC",
        "Person-month",
        "Earnings/profits / total personal income",
        "Real monthly earnings and total income",
        "Not hourly wages; business losses retained; total income includes nonlabour sources",
        "Used",
    ),
    (
        "EJB*_CLWRK",
        "Job class-of-worker field",
        "Schema field, no contract-duration coding established",
        "Requires questionnaire-specific interpretation",
        "Not used to infer permanent or fixed-term status",
        "Not used",
    ),
]
v = pd.DataFrame(
    rows,
    columns=[
        "variable",
        "universe",
        "coding_or_definition",
        "identifies",
        "does_not_identify",
        "analysis_use",
    ],
)
v["source"] = "2022–2025 SIPP dictionaries and 2025 instrument"
v.to_csv(D / "sipp_contract_variable_audit.csv", index=False)


def table(df):
    return df.to_markdown(index=False, floatfmt=".2f")


main = sel[
    sel.outcome.isin(["hours", "part_intensity", "real_earnings"]) & sel.age.isin(ages)
][
    [
        "age",
        "measure",
        "outcome",
        "estimate",
        "ci_low",
        "ci_high",
        "persons",
        "high_persons",
    ]
]
main.to_csv(D / "sipp_primary_summary.csv", index=False)
flow = t.query(
    "measure=='THAIE' and subgroup=='all' and age in ['all16plus','age22_34']"
)[["age", "transition", "estimate", "ci_low", "ci_high", "status"]]
report = (
    """# Following workers after the generative AI shock

How have employment opportunities and job quality changed for young people entering the labour market in highly AI-exposed fields, and how far up the age distribution do these changes extend?

This extension follows observed worker adaptation. It adds attrition-corrected linked CPS transitions and a newly acquired SIPP person-month panel. The estimates describe differential changes by baseline exposure. They do not identify individual AI adoption or establish that AI caused those changes.

## Findings

Custom response correction changes the linked CPS estimates little. For THAIE Q5 workers aged 22–25, the adjusted occupational full-time-to-part-time differential is approximately +0.21 percentage points after calibration, with a 95% interval of about −1.34 to +1.76. The corresponding economic-short-hours estimate is about +0.52 pp, with an interval of −0.42 to +1.45. Neither establishes increased downgrading. The intervals condition on the fitted correction weights.

The SIPP main cohort contains 2,850 baseline workers observed for 48 months in 2021–2024, or 136,800 person-months. Of these, 2,843 have the complete outcome periods required by the common-sample models. For all baseline workers, adjusted THAIE Q5 relative changes are +0.70 weekly hours [−0.94, +2.35], +1.72 pp in lower monthly hours intensity [−1.88, +5.32], and −$479 in monthly real earnings [−$1,145, +$187]. These intervals allow meaningful adverse and favourable changes.

The 22–25 THAIE group contains only 28 high-exposure people. Its lower-intensity estimate changes from +9.12 pp in the basic specification to +32.33 pp in the adjusted specification. The adjusted annual pre-period contrast is already −15.00 pp [−29.51, −0.49]. The post estimate does not survive the predeclared primary-family Holm correction. This combination is not convincing evidence of an AI-induced transition out of full-time work. Employment entry among this baseline-worker cohort can also increase the lower-intensity employment share.

Directly observed monthly transitions do not support a clear increase in movement from full-time intensity to lower intensity, or from employee work to other arrangements. No SIPP DID survives correction over the broad planned family. This does not demonstrate that effects are absent. Small high-exposure and subgroup samples leave wide uncertainty.

## Sources and observation windows

Basic CPS records cover January–September of 2010–2026, with adjacent-month links restricted to origin rotation groups eligible for the following month. Main corrected transition models use 2017–2026 and a 2023–2026 post period. The new SIPP analysis uses the 2022, 2023, 2024 and 2025 survey files, which refer to calendar years 2021, 2022, 2023 and 2024. The 2025 file being released in 2026 does not create 2026 outcomes. SIPP and CPS are analysed separately and are not linked to one another.

Official four-year SIPP longitudinal weights identify 6,122 people. The main analytical cohort restricts to adults with positive baseline job hours, a covered 2021 occupation, and continuous US survey-frame membership across all 48 months. Eleven otherwise eligible people are excluded by that final frame restriction. This defines a selected baseline-worker cohort. It does not represent all later labour-market entrants or all US residents. Never-employed baseline entrants cannot be assigned baseline occupational exposure in this design.

Age is frozen in October 2022. Baseline vulnerability characteristics are frozen in 2021. The analysis covers ages 16 and above, with separate 22–25, 26–29 and 30–34 bands, older groups, and comparisons within female, no-BA, Black, Hispanic, foreign-born, work-limiting disability and household-income-below-200%-of-poverty groups. These characteristics mark distinct dimensions of potential disadvantage, rather than a uniform vulnerable category. Many youth-by-vulnerability cells fail minimum support and remain explicitly unsupported.

## CPS response correction

Next-month linkage is modelled from origin state, age, sex, race, Hispanic origin, education, citizenship, marital status, labour-force status, major occupation and industry, rotation, calendar month and hours categories. A household-separated two-fold cross-fit logistic model produces inverse-response weights. We compare origin weights, inverse-probability weights, 99th-percentile-trimmed response factors, and calibrated weights. Calibration targets the eligible origin sample's weighted demographic, state, labour-status and month-by-rotation margins.

All yearly models converge. Maximum relative calibration error is below 0.000001, with no structural-zero target cells. Two fitted probabilities in 2021 require the predeclared probability safeguard; the remaining years require none. The safeguard, trimming and calibration are documented in the weight audit. The correction assumes response is ignorable conditional on observed origin variables. It cannot recover destinations of unobserved movers or solve nonignorable attrition. These custom weights are not official CPS gross-flow weights or IPUMS linkage weights.

Adjusted state-panel transition contrasts retain common support across the three exposure measures and the same fixed 2019 origin denominator weights across correction methods. They include baseline industry composition and pandemic-recovery controls. State-cluster uncertainty conditions on the estimated response and calibration weights and therefore omits weight-estimation uncertainty. Matched pairs are repeated observations, not unique independent workers.

## SIPP identification and estimation

Occupational exposure is assigned once using the 2021 occupation contributing the largest cumulative monthly-average hours. At least 90% of baseline job hours must map to the shared occupation universe. Baseline matched-hour coverage is 97.64%. Existing exposure, THAIE and simple time weighting use the same people, outcomes, cutoffs and periods. Q5 membership uses the existing frozen 2019 occupational quintile cutoffs. Exposure never updates in response to later job changes.

For each person, the pooled contrast is average January–September outcomes in 2023–2024 minus the corresponding average in 2021–2022. A weighted regression compares Q5 with Q1–Q4. It is a within-person change design, equivalent to the two-period person fixed-effect contrast. The adjusted specification adds baseline state effects on changes, age and age squared, and the baseline demographic flags. Annual event contrasts use 2022 as reference. There is only one annual pre-event contrast, so this panel cannot establish a long parallel trend.

Point estimates use FINYR4. All 240 official replicate weights refit each regression; Fay BRR with factor 0.5 supplies variance, using 4/240 times the sum of squared replicate deviations. Unsupported comparisons remain missing, rather than becoming zeros. The planned broad DID family has 1,440 comparisons, and the primary three-age family has 180. Holm-adjusted probabilities are retained alongside unadjusted values. The interpretation is exploratory and conditional on baseline exposure, not causal adoption DID.

Monthly observed transitions use the same people but changing origin risk sets. They compare February–September transitions in 2023–2024 against 2021–2022. These pooled flow contrasts are descriptive and do not use the adjusted change-regression covariates. They distinguish actual individual moves from a changing cross-sectional share.

## Outcome interpretation

SIPP hours sum monthly-average weekly hours over all jobs. Nonworking weeks within a month contribute zero. The 35-hour split measures monthly employment intensity; a partial job month can fall below 35 even when usual weekly work is full-time. It must not be labelled the CPS usual full-time/part-time classification. SIPP lower-intensity employment is not itself involuntary part-time work.

TPEARN measures earnings and business profits, including negative losses. TPTOTINC includes other personal income. Both are deflated with monthly CPI-U to September 2026 dollars. Missing earnings are set to zero only for recorded nonemployment months. Employed missing earnings remain missing. Later nonemployed people remain in the cohort, avoiding a comparison limited to employment survivors. Neither series is an hourly wage measure.

CPS economic short hours can occur among usually full-time workers and overlaps that usual-status category. It is not a subset of usual part-time work. Employee-to-self-employment is not permanent-to-contract employment.

## Can permanent-to-contract transitions be identified?

Not cleanly from these SIPP fields. JBORSE identifies employer, own-business/self-employment, or other arrangements. CONCHK asks only people reporting other arrangements whether an ongoing employer arrangement exists. CNTRC concerns union contract coverage. It does not identify fixed-term employment. RSEND can flag a temporary or seasonal job ending, but is observed only for ended spells. Job IDs allow tracking job changes but do not supply contract duration.

Accordingly, the outputs report employee-to-self-employment, employee-to-other-arrangement and a narrowly labelled no-ongoing-arrangement proxy. None is renamed permanent-to-contract. A validated contract-duration or contingent-work measure, with its restricted universe and timing, is needed for that stronger research claim. The separate variable audit records which fields are available and which have actually been used.

## Results tables

### Common-sample SIPP changes

"""
    + table(main)
    + """\n\n### Observed THAIE monthly transition contrasts\n\n"""
    + table(flow)
    + """\n\n## Reproducibility and verification

The scripts retain raw-source lineage and separate public aggregate outputs from internal person-level public-use records. No person or household identifiers are exported in the deliverables. Independent checks reproduce uncorrected CPS counts, verify transition accounting and panel keys, confirm longitudinal weight equality to replicate zero, and independently refit the all-adult THAIE hours regression and all 240 replicate regressions using statsmodels. Point and standard-error differences are below 0.0000001. Smoke checks emit no figures. Plot files are generated separately.

## Primary documentation

- [Census SIPP datasets](https://www.census.gov/programs-surveys/sipp/data/datasets.html)
- [2025 SIPP data and longitudinal files](https://www.census.gov/programs-surveys/sipp/data/datasets/2025-data/2025.html)
- [Census SIPP weighting](https://www.census.gov/programs-surveys/sipp/methodology/weighting.html)
- [2025 source and accuracy statement](https://www2.census.gov/programs-surveys/sipp/tech-documentation/source-accuracy-statements/2025/SIPP-2025-SA.pdf)
- [2025 SIPP dictionary](https://www2.census.gov/programs-surveys/sipp/tech-documentation/data-dictionaries/2025/2025_SIPP_Data_Dictionary.pdf)
- [2025 SIPP instrument](https://www2.census.gov/programs-surveys/sipp/tech-documentation/2025/2025_SIPP_PU_Instrument_Specifications.pdf)
- [IPUMS CPS linking documentation](https://cps.ipums.org/cps/cps_linking_documentation.shtml)
"""
)
vulnerable = r.query(
    "measure=='THAIE' and model=='adjusted' and contrast=='pooled_DID' and subgroup!='all' and outcome in ['hours','real_earnings','part_intensity']"
)[
    [
        "age",
        "subgroup",
        "outcome",
        "persons",
        "high_persons",
        "status",
        "estimate",
        "ci_low",
        "ci_high",
        "p_holm_all_DID",
    ]
]
vulnerable.to_csv(D / "sipp_vulnerability_summary.csv", index=False)
report += (
    "\n## Baseline vulnerability domains\n\nThese are within-domain exposure contrasts, not formal tests of differences between demographic groups. The foreign-born earnings interval excludes zero before multiplicity correction, but does not survive the planned correction. Small youth cells are marked unsupported; no zero effect is imputed.\n\n"
    + table(vulnerable)
    + "\n"
)
(R / "RESEARCH_REPORT_EN.md").write_text(report)
(R / "REPORT_KO.md").write_text(
    """# AI 충격 이후 노동자 적응 추적

연결 CPS의 표본 이탈 보정과 SIPP 개인 패널 분석을 완료했다. 이번 결과는 고노출 노동자가 AI 때문에 시간제나 계약직으로 밀려났다는 결론을 뒷받침하지 않는다. 효과가 없다고 확정할 만큼 정밀하지도 않다.

CPS는 연결 확률의 역수 가중과 모집단 주변분포 보정을 적용했다. 보정 전후 결과가 대체로 유사하다. THAIE 최고 노출 직업군 22–25세의 전일제→시간제 전환 차이는 보정 후 약 +0.21%p이고 95% 구간은 약 −1.34~+1.76%p다. 경제적 이유의 근로시간 축소는 약 +0.52%p로 구간에 0을 포함한다. 이는 관측 가능한 출발 시점 특성에 조건부인 보정이며, 관측하지 못한 이동자의 목적지나 비무작위 이탈까지 복원하지 않는다. 추론은 추정 가중치를 고정한 조건부 추론이다.

SIPP 공식 4년 종단 가중치 대상 6,122명 중 2021년 직업 노출도를 연결하고 48개월 내내 조사 범위 안에 있는 성인 노동자는 2,850명이다. 이들을 2021–2024년 136,800개 개인·월로 추적했다. 2026년에 공개된 자료에도 2026년 노동시장 결과가 들어 있는 것은 아니다. 이번 SIPP 관측은 2024년까지이며 CPS의 2026년 결과와 구분한다. 이후 미취업자가 된 사람도 유지하고, 사업 손실과 무소득 기간을 제외하지 않았다.

전체 연령의 THAIE 고노출 집단은 비교집단 대비 주당 근로시간 변화 +0.70시간, 낮은 월간 근로강도 취업 비중 +1.72%p, 월 실질 근로소득 변화 −479달러로 추정됐다. 각각의 95% 구간은 −0.94~+2.35시간, −1.88~+5.32%p, −1,145~+187달러다. 모든 금액은 2026년 9월 가격이다. 월평균 주당 시간의 35시간 구분은 통상적인 전일제·시간제 구분과 다르며, 월 중간 입·퇴직도 낮은 근로강도로 나타날 수 있다.

22–25세 THAIE 고노출자는 28명뿐이다. 낮은 근로강도 취업의 추정치는 기본 모형 +9.12%p에서 통제 모형 +32.33%p로 달라진다. 충격 전 2021년 대 2022년 차이도 이미 나타나며, 다중검정 보정 후 유의하지 않다. 따라서 청년층의 시간제 밀려남으로 해석하면 안 된다. 실제 개인의 월별 전환을 별도로 추적한 결과에서도 전일제 강도→낮은 강도 또는 피고용→기타 고용형태 증가가 명확하지 않다.

22–25세, 26–29세, 30–34세와 고령층, 여성, 비대졸, 흑인, 히스패닉, 해외출생, 근로제약 장애, 저소득 가구를 구분했다. 청년층과 취약성 특성이 겹치는 다수 표본은 최소 지지 조건을 충족하지 못한다. 기존 노출도·THAIE·단순 시간가중을 같은 표본과 기간에서 비교했으며, 광범위한 DID 다중검정에서 유지되는 결과는 없다. SIPP는 사전 연도가 두 개뿐이라 긴 사전 추세 검증을 대체하지 못한다. 개인별 AI 사용을 측정하지 않아 인과적 채택 효과로 해석하지 않는다.

정규직→계약직 전환은 현재 변수로 명확하게 식별할 수 없다. JBORSE는 피고용·자영업·기타 형태를 구분한다. CONCHK는 기타 형태 응답자에게만 지속적인 고용주 관계가 있는지 묻는다. CNTRC는 노조 단체협약 적용 여부이며 기간제 계약 변수가 아니다. RSEND는 끝난 일자리의 임시·계절 일 종료 사유를 알 수 있지만 계속되는 일자리의 계약기간을 제공하지 않는다. 따라서 피고용→자영업, 피고용→기타 형태와 지속적 관계 없는 기타 형태를 별도 대리지표로만 보고했다.

공식 240개 반복가중치와 Fay 계수 0.5를 사용했다. 별도 statsmodels 구현으로 전체 연령 근로시간 회귀와 240개 반복 추정을 대조했고, 원래 CPS 집계의 재현과 개인·월 중복 및 가중치 검증도 통과했다. 스모크 검증은 이미지나 그래프를 출력하지 않았다. 상세 모형, 결과표, 변수 사전과 원자료 출처는 영문 보고서 및 derived·audit·scripts 폴더에 보존했다.
"""
)
(R / "README.md").write_text(
    """# Longitudinal worker adaptation extension

Start with REPORT_KO.md or RESEARCH_REPORT_EN.md. figures/LONGITUDINAL_FIGURES.pdf contains four saved figures. derived contains public aggregate results only. scripts contains acquisition, panel construction, correction, models and independent validation. audit contains source and numerical checks. Raw downloads and individual public-use records remain in work/us_longitudinal and are not public deliverables.

Execution order is acquire_sipp.py, prepare_sipp.py, sipp_panel.py, sipp_models.py, sipp_transitions.py; CPS uses cps_attrition.py then cps_models.py. validate.py performs numerical smoke checks without plotting. Data inputs also require the prior adaptation release and existing CPS/exposure/CPI caches. This is a reproducible workspace pipeline, not a standalone raw-data archive.
"""
)
print(
    "Saved reports, aggregate variable audit and four figures without displaying images."
)
