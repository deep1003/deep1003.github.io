"""Weighted within-person SIPP changes with official 240 Fay replicates."""

from pathlib import Path
import json
import numpy as np, pandas as pd
from scipy.linalg import qr
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests

R = Path(__file__).resolve().parents[1]
W = R.parents[2] / "work/us_longitudinal"
D = R / "derived"
KEY = ["SSUID", "PNUM", "SPANEL"]
M = ["E", "THAIE", "TIME"]
OUT = [
    "hours",
    "employed",
    "full_intensity",
    "part_intensity",
    "real_earnings",
    "real_income",
    "any_employee",
    "any_self",
    "any_other",
    "no_ongoing_other",
]
BINARY = [
    "employed",
    "full_intensity",
    "part_intensity",
    "any_employee",
    "any_self",
    "any_other",
    "no_ongoing_other",
]


def groups(b):
    for lo, hi in [
        (16, 21),
        (22, 25),
        (26, 29),
        (30, 34),
        (35, 44),
        (45, 54),
        (55, 64),
        (65, 99),
    ]:
        yield f"age{lo}_{hi}", "all", b.age_at_event.between(lo, hi).to_numpy()
    yield "all16plus", "all", np.ones(len(b), bool)
    yield "age22_34", "all", b.age_at_event.between(22, 34).to_numpy()
    for age, mask in [
        ("all16plus", np.ones(len(b), bool)),
        ("age22_34", b.age_at_event.between(22, 34).to_numpy()),
    ]:
        for sub in [
            "female",
            "no_BA",
            "black",
            "hispanic",
            "foreign",
            "disabled",
            "low_income",
        ]:
            yield age, sub, mask & b[sub].eq(1).to_numpy()


def independent(X, names, w):
    _, r, piv = qr(X * np.sqrt(w)[:, None], mode="economic", pivoting=True)
    diag = abs(np.diag(r))
    rank = int((diag > diag.max() * 1e-10).sum())
    keep = np.sort(piv[:rank])
    return X[:, keep], [names[i] for i in keep]


def estimate(X, Y, weights, names):
    beta = []
    for col in range(weights.shape[1]):
        w = weights[:, col]
        w = w / w.mean()
        g = X.T @ (X * w[:, None])
        rhs = X.T @ (Y * w[:, None])
        beta.append(np.linalg.solve(g, rhs))
    beta = np.stack(beta)
    return beta


if __name__ == "__main__":
    b = (
        pd.read_parquet(W / "sipp_worker_baseline.parquet")
        .sort_values("pid")
        .reset_index(drop=True)
    )
    data = pd.read_parquet(W / "sipp_worker_panel.parquet")
    rep = pd.read_parquet(W / "sipp_replicate_weights.parquet")
    rw = ["REPWGT" + str(k) for k in range(241)]
    bw = b.merge(rep[KEY + rw], on=KEY, validate="one_to_one")
    assert np.allclose(bw.FINYR4, bw.REPWGT0)
    weight = bw[rw].to_numpy(float)
    byyear = data[data.MONTHCODE.le(9)].groupby(["pid", "year"])[OUT].mean()
    wide = {
        y: byyear.xs(y, level="year").reindex(b.pid)[OUT].to_numpy(float)
        for y in range(2021, 2025)
    }
    pre = (wide[2021] + wide[2022]) / 2
    post = (wide[2023] + wide[2024]) / 2
    YY = np.column_stack(
        [
            post - pre,
            wide[2021] - wide[2022],
            wide[2023] - wide[2022],
            wide[2024] - wide[2022],
        ]
    )
    complete = np.isfinite(YY).all(axis=1)
    b["complete_outcomes"] = complete
    # All outcomes share a person domain; income missingness is not replaced for workers.
    years = ["pooled_DID", "event_2021", "event_2023", "event_2024"]
    rows = []
    support = []
    coeff_audit = []
    for age, sub, mask in groups(b):
        mask = mask & complete
        g = b.loc[mask].copy()
        Y = YY[mask]
        weights = weight[mask]
        n = len(g)
        nh = {m: int(g[m + "_q"].eq(5).sum()) for m in M}
        supported = (
            n >= 50
            and min(nh.values(), default=0) >= 20
            and min(n - nh[m] for m in M) >= 20
        )
        support.append(
            dict(
                age=age,
                subgroup=sub,
                persons=n,
                high_E=nh["E"],
                high_THAIE=nh["THAIE"],
                high_TIME=nh["TIME"],
                supported=supported,
                ESS=(
                    float(weights[:, 0].sum() ** 2 / (weights[:, 0] ** 2).sum())
                    if n
                    else 0
                ),
            )
        )
        for metric in M:
            h = g[metric + "_q"].eq(5).to_numpy(float)
            for model in ["basic", "adjusted"]:
                names = ["intercept", "high"]
                X = np.column_stack([np.ones(n), h])
                if model == "adjusted" and n:
                    state = pd.get_dummies(
                        g.TEHC_ST.astype(int),
                        prefix="state",
                        drop_first=True,
                        dtype=float,
                    )
                    age0 = (g.age_at_event.to_numpy() - 40) / 20
                    extra = np.column_stack(
                        [state.to_numpy(), age0, age0**2]
                        + [
                            g[c].to_numpy()
                            for c in [
                                "female",
                                "no_BA",
                                "black",
                                "hispanic",
                                "foreign",
                                "disabled",
                                "low_income",
                            ]
                        ]
                    )
                    X = np.column_stack([X, extra])
                    names += list(state.columns) + [
                        "age",
                        "age_squared",
                        "female",
                        "no_BA",
                        "black",
                        "hispanic",
                        "foreign",
                        "disabled",
                        "low_income",
                    ]
                status = "estimated" if supported else "unsupported_small_domain"
                if supported:
                    X, names = independent(X, names, weights[:, 0])
                    status = (
                        "estimated"
                        if "high" in names and n > X.shape[1] + 10
                        else "unsupported_rank"
                    )
                if status == "estimated":
                    beta = estimate(X, Y, weights, names)
                    ix = names.index("high")
                    effects = beta[:, ix, :]
                    point = effects[0]
                    se = np.sqrt(4 / 240 * np.sum((effects[1:] - point) ** 2, axis=0))
                    coeff_audit.append(
                        dict(
                            age=age,
                            subgroup=sub,
                            measure=metric,
                            model=model,
                            N=n,
                            rank=X.shape[1],
                            min_high=nh[metric],
                            replicates=240,
                        )
                    )
                for yi, year in enumerate(years):
                    for j, outcome in enumerate(OUT):
                        meta = dict(
                            age=age,
                            subgroup=sub,
                            measure=metric,
                            model=model,
                            contrast=year,
                            outcome=outcome,
                            persons=n,
                            high_persons=nh[metric],
                            status=status,
                            unit=(
                                "percentage_points"
                                if outcome in BINARY
                                else (
                                    "hours_per_week"
                                    if outcome == "hours"
                                    else "September_2026_dollars_per_month"
                                )
                            ),
                        )
                        if status == "estimated":
                            k = yi * len(OUT) + j
                            scale = 100 if outcome in BINARY else 1
                            val = point[k] * scale
                            s = se[k] * scale
                            meta.update(
                                estimate=float(val),
                                se=float(s),
                                ci_low=float(val - 1.96 * s),
                                ci_high=float(val + 1.96 * s),
                                p_value=(
                                    float(2 * norm.sf(abs(val / s))) if s else np.nan
                                ),
                            )
                        rows.append(meta)
        print("SIPP models", age, sub, n, nh, status, flush=True)
    r = pd.DataFrame(rows)
    main = r.contrast.eq("pooled_DID")
    r.loc[main, "p_holm_all_DID"] = multipletests(
        r.loc[main, "p_value"].fillna(1), method="holm"
    )[1]
    # Primary early-career family is explicitly separate from all-age/domain exploration.
    prim = (
        main & r.age.isin(["age22_25", "age26_29", "age30_34"]) & r.subgroup.eq("all")
    )
    r.loc[prim, "p_holm_primary180"] = multipletests(
        r.loc[prim, "p_value"].fillna(1), method="holm"
    )[1]
    r.to_csv(D / "sipp_within_person_results.csv", index=False)
    pd.DataFrame(support).to_csv(D / "sipp_domain_support.csv", index=False)
    (R / "audit/sipp_regressions.json").write_text(json.dumps(coeff_audit, indent=2))
    # Aggregate monthly trajectories with point/replicate inference and no individual records.
    monthly = []
    for age, sub, mask in groups(b):
        pids = b.loc[mask, "pid"]
        g = data[data.pid.isin(pids)]
        n = len(pids)
        if n < 50:
            continue
        for metric in M:
            high = b[metric + "_q"].eq(5).to_numpy()
            for band, hm in [("Q5", high), ("Q1_Q4", ~high)]:
                im = mask & hm
                nn = int(im.sum())
                if nn < 20:
                    continue
                ids = b.loc[im, "pid"]
                w = weight[im]
                for (year, month), f in g[g.pid.isin(ids)].groupby(
                    ["year", "MONTHCODE"]
                ):
                    values = f.set_index("pid").reindex(ids)[OUT].to_numpy(float)
                    num = np.nan_to_num(values, nan=0).T @ w
                    den = np.isfinite(values).astype(float).T @ w
                    means = num / den
                    se = np.sqrt(
                        4 / 240 * ((means[:, 1:] - means[:, [0]]) ** 2).sum(axis=1)
                    )
                    for j, o in enumerate(OUT):
                        scale = 100 if o in BINARY else 1
                        monthly.append(
                            dict(
                                age=age,
                                subgroup=sub,
                                measure=metric,
                                band=band,
                                year=int(year),
                                month=int(month),
                                outcome=o,
                                persons=nn,
                                estimate=float(means[j, 0] * scale),
                                ci_low=float((means[j, 0] - 1.96 * se[j]) * scale),
                                ci_high=float((means[j, 0] + 1.96 * se[j]) * scale),
                            )
                        )
    pd.DataFrame(monthly).to_csv(D / "sipp_monthly_trajectories.csv", index=False)
    print("SIPP inference complete", len(r), len(monthly), flush=True)
