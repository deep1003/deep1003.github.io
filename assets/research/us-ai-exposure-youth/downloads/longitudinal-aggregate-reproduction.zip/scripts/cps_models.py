"""Compare uncorrected and attrition-corrected CPS transition estimates."""

from pathlib import Path
import importlib.util, json
import numpy as np, pandas as pd
from statsmodels.stats.multitest import multipletests

R = Path(__file__).resolve().parents[1]
P = R.parent
D = R / "derived"
s = importlib.util.spec_from_file_location(
    "models", P / "adaptation_20261122/scripts/models.py"
)
a = importlib.util.module_from_spec(s)
s.loader.exec_module(a)
METHODS = ["origin", "ipw", "ipw_trim99", "calibrated"]
OUT = ["FT_to_PT_rate", "FT_to_PTecon_rate", "FT_to_U_rate", "employee_to_self_rate"]
if __name__ == "__main__":
    f = pd.read_parquet(D / "cps_corrected_transitions.parquet")
    scores = pd.read_csv(P / "high_exposure_quality/derived/region_quintiles.csv")
    f = f.merge(a.context(), on="GESTFIPS").merge(
        scores[["GESTFIPS"] + [m + "_q" for m in a.METRICS]], on="GESTFIPS"
    )
    for outcome, den in [
        ("FT_to_PT", "FT_den"),
        ("FT_to_PTecon", "FT_den"),
        ("FT_to_U", "FT_den"),
        ("employee_to_self", "employee_den"),
    ]:
        f[outcome + "_rate"] = (100 * f[outcome] / f[den]).where(f["n" + den] >= 30)
    base = f[f.year.eq(2019) & f.method.eq("origin")][
        ["GESTFIPS", "age", "subgroup", "measure", "high", "FT_den"]
    ].rename(columns={"FT_den": "weight"})
    f = f.merge(
        base,
        on=["GESTFIPS", "age", "subgroup", "measure", "high"],
        validate="many_to_one",
    )
    rows = []
    events = []
    tests = []
    failed = []
    for (age, sub), group in f.groupby(["age", "subgroup"]):
        primary = age in a.AGES and sub == "all"
        for level in ["regional", "occupation"]:
            frame = (
                group[group.measure.eq("regional")]
                if level == "regional"
                else group[group.measure.ne("regional")]
            )
            for outcome in OUT:
                for method in METHODS:
                    if not primary and method not in ["origin", "calibrated"]:
                        continue
                    dd = frame[frame.method.eq(method) & frame.year.ge(2017)].copy()
                    if level == "occupation":
                        good = (
                            dd.pivot(
                                index=["GESTFIPS", "year", "high"],
                                columns="measure",
                                values=outcome,
                            )
                            .reindex(columns=a.METRICS)
                            .notna()
                            .all(axis=1)
                            .unstack("high")
                            .reindex(columns=[0, 1])
                            .fillna(False)
                            .all(axis=1)
                        )
                        dd = dd.merge(
                            good.index[good].to_frame(index=False),
                            on=["GESTFIPS", "year"],
                        )
                    else:
                        dd = dd[dd[outcome].notna()]
                    good = dd.groupby("GESTFIPS").year.agg(
                        lambda x: 2022 in set(x) and any(x >= 2023) and any(x <= 2019)
                    )
                    dd = dd[dd.GESTFIPS.isin(good.index[good]) & dd.weight.gt(0)]
                    for metric in a.METRICS:
                        dm = dd if level == "regional" else dd[dd.measure.eq(metric)]
                        for adj in [False, True] if primary else [True]:
                            meta = dict(
                                level=level,
                                age=age,
                                subgroup=sub,
                                method=method,
                                outcome=outcome,
                                measure=metric,
                                model="adjusted" if adj else "basic",
                                primary=primary,
                            )
                            try:
                                z = a.fit(dm, outcome, metric, level, adj, False)
                                if "DID" not in z[2]:
                                    raise ValueError("DID absorbed")
                                rows.append(
                                    meta
                                    | a.result(z, {"DID": 1})
                                    | dict(N=z[4]["N"], states=z[3])
                                )
                                if (
                                    primary
                                    and adj
                                    and method in ["origin", "calibrated"]
                                    and outcome
                                    in ["FT_to_PT_rate", "FT_to_PTecon_rate"]
                                ):
                                    zz = a.fit(dm, outcome, metric, level, True, True)
                                    for y in sorted(dm.year.unique()):
                                        events.append(
                                            meta
                                            | dict(year=int(y))
                                            | (
                                                a.result(zz, {"event_" + str(y): 1})
                                                if y != 2022
                                                else dict(
                                                    estimate=0,
                                                    ci_low=0,
                                                    ci_high=0,
                                                    p_value=np.nan,
                                                    unit="percentage_points",
                                                )
                                            )
                                        )
                                    tests.append(
                                        meta | a.pretest(zz, range(2017, 2020))
                                    )
                            except (
                                ValueError,
                                AssertionError,
                                np.linalg.LinAlgError,
                            ) as e:
                                failed.append(meta | dict(reason=str(e)))
        print("CPS models", age, sub, flush=True)
    rr = pd.DataFrame(rows)
    rr["status"] = "estimated"
    keys = ["level", "age", "subgroup", "method", "outcome", "measure", "model"]
    seen = set(rr[keys].itertuples(index=False, name=None))
    missing = []
    for x in failed:
        key = tuple(x[k] for k in keys)
        if key not in seen:
            missing.append(x | dict(status="not_estimable"))
            seen.add(key)
    rr = pd.concat([rr, pd.DataFrame(missing)], ignore_index=True)
    rr["p_holm_all"] = multipletests(rr.p_value.fillna(1), method="holm")[1]
    rr.to_csv(D / "cps_corrected_DID.csv", index=False)
    pd.DataFrame(events).to_csv(D / "cps_corrected_events.csv", index=False)
    pd.DataFrame(tests).to_csv(D / "cps_corrected_pretrends.csv", index=False)
    (R / "audit/cps_model_failures.json").write_text(json.dumps(failed, indent=2))
    (R / "audit/cps_model_diagnostics.json").write_text(json.dumps(a.AUD, indent=2))
    # National transition means do not average state rates.
    group = ["year", "age", "subgroup", "method", "measure", "high"]
    cols = [
        c
        for c in f
        if c.endswith("_den")
        or "_to_" in c
        and not c.endswith("_rate")
        or c in ["hours_pair_den", "hours_change_sum"]
    ]
    nat = f.groupby(group, as_index=False)[cols].sum()
    for out, den in [
        ("FT_to_PT", "FT_den"),
        ("FT_to_PTecon", "FT_den"),
        ("FT_to_U", "FT_den"),
        ("employee_to_self", "employee_den"),
    ]:
        nat[out + "_rate"] = 100 * nat[out] / nat[den]
    nat["paired_employed_hours_change"] = nat.hours_change_sum / nat.hours_pair_den
    nat.to_csv(D / "cps_national_corrected_transitions.csv", index=False)
    print("CPS model comparisons complete", len(rr), flush=True)
