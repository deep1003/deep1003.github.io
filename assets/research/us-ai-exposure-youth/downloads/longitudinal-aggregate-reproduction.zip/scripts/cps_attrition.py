"""Cross-fitted response IPW and calibrated origin margins for linked CPS."""

from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import importlib.util, json, hashlib
import numpy as np, pandas as pd
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, brier_score_loss

R = Path(__file__).resolve().parents[1]
P = R.parent
W = R.parents[2] / "work/us_longitudinal"
W.mkdir(exist_ok=True)
s = importlib.util.spec_from_file_location(
    "a", P / "adaptation_20261122/scripts/prepare.py"
)
a = importlib.util.module_from_spec(s)
s.loader.exec_module(a)
a.p.FIELDS += ["HRHHID", "HRHHID2", "PULINENO"]
KEY = ["HRHHID", "HRHHID2", "PULINENO"]
CATS = [
    "GESTFIPS",
    "ageband",
    "PESEX",
    "racecat",
    "PEHSPNON",
    "edu",
    "PRCITSHP",
    "PEMARITL",
    "PEMLR",
    "PRMJIND1",
    "PRMJOCC1",
    "HRMIS",
    "HRMONTH",
    "hourscat",
]


def categories(d):
    d = d.copy()
    age = d.PRTAGE.to_numpy()
    d["ageband"] = np.select(
        [age < 22, age < 26, age < 30, age < 35, age < 45, age < 55, age < 65],
        range(7),
        default=7,
    )
    d["racecat"] = np.select(
        [d.PTDTRACE.eq(1), d.PTDTRACE.eq(2), d.PTDTRACE.eq(4)], [1, 2, 3], default=4
    )
    d["edu"] = np.select(
        [d.PEEDUCA.le(38), d.PEEDUCA.le(39), d.PEEDUCA.le(42), d.PEEDUCA.le(43)],
        [0, 1, 2, 3],
        default=4,
    )
    d["hourscat"] = (
        pd.cut(d.PEHRUSLT, [-10, 0, 20, 34, 40, 60, 200], labels=False)
        .fillna(0)
        .astype(int)
    )
    return d


MARGINS = [
    ["GESTFIPS", "ageband", "PESEX"],
    ["racecat", "ageband", "PESEX"],
    ["PEHSPNON", "ageband", "PESEX"],
    ["edu", "ageband", "PESEX"],
    ["PEMLR", "ageband", "PESEX"],
    ["HRMONTH", "HRMIS"],
]


def rake(d, base, linked, ipw):
    weights = ipw.copy()
    lookup = []
    zero = 0
    for cols in MARGINS:
        key = pd.MultiIndex.from_frame(d[cols])
        code, _ = pd.factorize(key, sort=True)
        target = np.bincount(code, weights=base)
        observed = np.bincount(code[linked], minlength=len(target))
        zero += int(((target > 0) & (observed == 0)).sum())
        lookup.append((code[linked], target))
    if zero:
        raise ValueError(f"{zero} structural zero calibration cells")
    for it in range(1000):
        for codes, target in lookup:
            got = np.bincount(codes, weights=weights, minlength=len(target))
            ratio = np.divide(target, got, out=np.ones_like(target), where=got > 0)
            weights *= ratio[codes]
        err = max(
            np.max(
                abs(np.bincount(c, weights=weights, minlength=len(t)) - t)
                / np.maximum(t, 1)
            )
            for c, t in lookup
        )
        if err < 1e-7:
            break
    assert err < 1e-5, (it, err)
    return weights, dict(
        iterations=it + 1, max_relative_margin_error=float(err), structural_zeros=zero
    )


def one_year(year):
    records = []
    prev, _ = a.p.read(year, 1)
    for month in range(2, 10):
        cur, _ = a.p.read(year, month)
        left = prev[prev.HRMIS.isin([1, 2, 3, 5, 6, 7])].copy()
        nxt = cur[
            KEY
            + [
                "HRMIS",
                "PESEX",
                "PTDTRACE",
                "PRTAGE",
                "GESTFIPS",
                "PEMLR",
                "PRFTLF",
                "PRWKSTAT",
                "PEHRUSLT",
                "PEIO1COW",
            ]
        ]
        assert not left.duplicated(KEY).any() and not nxt.duplicated(KEY).any()
        d = left.merge(
            nxt, on=KEY, how="left", suffixes=("", "_next"), validate="one_to_one"
        )
        d["linked"] = (
            d.PEMLR_next.notna()
            & d.HRMIS_next.eq(d.HRMIS + 1)
            & d.PESEX_next.eq(d.PESEX)
            & d.PTDTRACE_next.eq(d.PTDTRACE)
            & (d.PRTAGE_next - d.PRTAGE).between(0, 1)
            & d.GESTFIPS_next.eq(d.GESTFIPS)
        )
        d["fold"] = (
            (d.HRHHID.astype(np.int64) ^ d.HRHHID2.astype(np.int64)) % 2
        ).astype(int)
        # Keep only variables needed for response modelling and aggregate transitions.
        keep = list(set(CATS) - {"ageband", "racecat", "edu", "hourscat"}) + [
            "PRTAGE",
            "PTDTRACE",
            "PEEDUCA",
            "PEHRUSLT",
            "P",
            "occ",
            "FT",
            "PT",
            "PEIO1COW",
            "linked",
            "fold",
            "PEMLR_next",
            "PRFTLF_next",
            "PRWKSTAT_next",
            "PEHRUSLT_next",
            "PEIO1COW_next",
        ]
        records.append(d[list(dict.fromkeys(keep))])
        prev = cur
    d = categories(pd.concat(records, ignore_index=True))
    base = d.P.to_numpy()
    linked = d.linked.to_numpy()
    y = linked.astype(int)
    enc = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
    X = enc.fit_transform(d[CATS].astype(str))
    prob = np.empty(len(d))
    fits = []
    for fold in [0, 1]:
        train = d.fold.ne(fold).to_numpy()
        test = ~train
        model = LogisticRegression(
            C=10, max_iter=100, solver="newton-cholesky", tol=1e-7
        )
        model.fit(X[train], y[train], sample_weight=base[train] / base[train].mean())
        prob[test] = model.predict_proba(X[test])[:, 1]
        fits.append(int(model.n_iter_[0]))
    rawprob = prob.copy()
    prob = np.clip(prob, 0.05, 0.995)
    inv = 1 / prob[linked]
    ipw = base[linked] * inv
    trim_cut = float(np.quantile(inv, 0.99))
    trim = base[linked] * np.minimum(inv, trim_cut)
    calibrated, diag = rake(d, base, linked, ipw)
    weights = {
        "origin": base[linked],
        "ipw": ipw,
        "ipw_trim99": trim,
        "calibrated": calibrated,
    }
    diag.update(
        year=year,
        eligible=len(d),
        linked=int(linked.sum()),
        weighted_match_rate=float(np.average(y, weights=base)),
        crossfit_auc=float(roc_auc_score(y, rawprob, sample_weight=base)),
        crossfit_brier=float(brier_score_loss(y, rawprob, sample_weight=base)),
        p_quantiles=np.quantile(rawprob, [0, 0.01, 0.05, 0.5, 0.95, 0.99, 1]).tolist(),
        clipped=int(np.sum(rawprob != prob)),
        inverse_response_trim_cut=trim_cut,
        fold_iterations=fits,
    )
    # Balance diagnostics compare response covariate margins with eligible origin targets.
    balance = []
    for method, w in weights.items():
        diag[method + "_ESS"] = float(w.sum() ** 2 / np.sum(w * w))
        diag[method + "_max_weight_share"] = float(w.max() / w.sum())
        for cols in MARGINS:
            code, _ = pd.factorize(pd.MultiIndex.from_frame(d[cols]), sort=True)
            target = np.bincount(code, weights=base)
            got = np.bincount(code[linked], weights=w, minlength=len(target))
            balance.append(
                dict(
                    year=year,
                    method=method,
                    margin=" × ".join(cols),
                    L1_share_distance=float(
                        abs(target / target.sum() - got / got.sum()).sum()
                    ),
                    max_absolute_share_gap=float(
                        abs(target / target.sum() - got / got.sum()).max()
                    ),
                )
            )
    g = d[linked].copy()
    g["FT_next"] = g.PEMLR_next.isin([1, 2]) & g.PRFTLF_next.eq(1)
    g["PT_next"] = g.PEMLR_next.isin([1, 2]) & g.PRFTLF_next.eq(2)
    g["PTecon_next"] = g.PEMLR_next.isin([1, 2]) & g.PRWKSTAT_next.isin([3, 6])
    g["U_next"] = g.PEMLR_next.isin([3, 4])
    g["N_next"] = g.PEMLR_next.isin([5, 6, 7])
    g["employee_next"] = g.PEMLR_next.isin([1, 2]) & g.PEIO1COW_next.between(1, 5)
    g["self_next"] = g.PEMLR_next.isin([1, 2]) & g.PEIO1COW_next.isin([6, 7])
    rows = []
    era = "2002" if year == 2010 else "2010" if year < 2020 else "2018"
    probs = {}
    for m in a.METRICS:
        mp = a.MAP[era, m]
        for high in [0, 1]:
            probs[m, high] = (
                g.occ.map(
                    mp[mp.quintile.eq(5) if high else mp.quintile.between(1, 4)]
                    .groupby("occ")
                    .probability.sum()
                )
                .fillna(0)
                .to_numpy()
            )
    for age, sub, mask in a.masks(g):
        f = g.loc[mask]
        for method, w in weights.items():
            for metric, high in [("regional", -1)] + [
                (m, h) for m in a.METRICS for h in [0, 1]
            ]:
                frac = np.ones(len(f)) if high < 0 else probs[metric, high][mask]
                z = f.copy()
                z["w"] = w[mask] * frac
                z["support"] = frac
                out = pd.DataFrame(index=sorted(g.GESTFIPS.unique()))
                out.index.name = "GESTFIPS"
                for origin in ["FT", "PT", "employee"]:
                    orig = (
                        z[origin].gt(0)
                        if origin in ["FT", "PT"]
                        else z.PEMLR.isin([1, 2]) & z.PEIO1COW.between(1, 5)
                    )
                    v = z.loc[orig]
                    out[origin + "_den"] = v.groupby("GESTFIPS").w.sum()
                    out["n" + origin + "_den"] = v.groupby("GESTFIPS").support.sum()
                    for dest in ["FT", "PT", "PTecon", "U", "N", "employee", "self"]:
                        out[origin + "_to_" + dest] = (
                            v[v[dest + "_next"]].groupby("GESTFIPS").w.sum()
                        )
                h0 = z.PEHRUSLT.between(1, 198) & z.PEMLR.isin([1, 2])
                h1 = z.PEHRUSLT_next.between(1, 198) & z.PEMLR_next.isin([1, 2])
                v = z[h0 & h1].copy()
                v["wdiff"] = v.w * (v.PEHRUSLT_next - v.PEHRUSLT)
                out["hours_pair_den"] = v.groupby("GESTFIPS").w.sum()
                out["hours_change_sum"] = v.groupby("GESTFIPS").wdiff.sum()
                out = out.fillna(0).reset_index()
                out["year"] = year
                out["age"] = age
                out["subgroup"] = sub
                out["method"] = method
                out["measure"] = metric
                out["high"] = high
                rows.append(out)
    pd.concat(rows, ignore_index=True).to_parquet(
        W / f"cps_corrected_{year}.parquet", index=False
    )
    pd.DataFrame(balance).to_csv(W / f"cps_balance_{year}.csv", index=False)
    (W / f"cps_weight_audit_{year}.json").write_text(json.dumps(diag, indent=2))
    return year


if __name__ == "__main__":
    with ProcessPoolExecutor(max_workers=2) as pool:
        fut = [
            pool.submit(one_year, y)
            for y in range(2010, 2027)
            if not (W / f"cps_corrected_{y}.parquet").exists()
        ]
        for f in as_completed(fut):
            print("Corrected CPS", f.result(), flush=True)
    pd.concat(
        [pd.read_parquet(W / f"cps_corrected_{y}.parquet") for y in range(2010, 2027)],
        ignore_index=True,
    ).to_parquet(R / "derived/cps_corrected_transitions.parquet", index=False)
    pd.concat(
        [pd.read_csv(W / f"cps_balance_{y}.csv") for y in range(2010, 2027)],
        ignore_index=True,
    ).to_csv(R / "derived/cps_balance.csv", index=False)
    (R / "audit/cps_weights.json").write_text(
        json.dumps(
            [
                json.loads((W / f"cps_weight_audit_{y}.json").read_text())
                for y in range(2010, 2027)
            ],
            indent=2,
        )
    )
    print("CPS correction complete", flush=True)
