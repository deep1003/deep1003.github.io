# Longitudinal worker adaptation extension

Start with REPORT_KO.md or RESEARCH_REPORT_EN.md. figures/LONGITUDINAL_FIGURES.pdf contains four saved figures. derived contains public aggregate results only. scripts contains acquisition, panel construction, correction, models and independent validation. audit contains source and numerical checks. Raw downloads and individual public-use records remain in work/us_longitudinal and are not public deliverables.

Execution order is acquire_sipp.py, prepare_sipp.py, sipp_panel.py, sipp_models.py, sipp_transitions.py; CPS uses cps_attrition.py then cps_models.py. validate.py performs numerical smoke checks without plotting. Data inputs also require the prior adaptation release and existing CPS/exposure/CPI caches. This is a reproducible workspace pipeline, not a standalone raw-data archive.
