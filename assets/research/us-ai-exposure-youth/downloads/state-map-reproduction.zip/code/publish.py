"""Place the observed CPS state map first in Results without changing models."""

from pathlib import Path
import hashlib
import json
import shutil
import zipfile

from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
O = ROOT / "outputs/US_State_Map_20261126"
S = ROOT / "work/homepage-expert-review/assets/research/us-ai-exposure-youth"
assert json.loads((O / "VALIDATION.json").read_text())["passed"]
shutil.copy2(O / "state_map.json", S / "data/state-youth-map.json")
shutil.copy2(W / "state-map.js", S / "state-map.js")
for filename in [
    "state_youth_Q5_fulltime_rates.csv",
    "state_youth_monthly_aggregates.csv",
    "VALIDATION.json",
]:
    shutil.copy2(O / filename, S / "downloads" / ("state-map-" + filename))
methods = """# State map of full-time employment in highly AI-exposed occupations

The target group is residents aged 22–25 in the 50 states and District of Columbia. The rate is 100 times full-time employed residents in THAIE Q5 primary occupations divided by all civilian noninstitutional residents aged 22–25 in that state. It is a contribution to the age-group employment–population ratio, not a conditional employment probability for everyone exposed to AI. Unemployed and nonparticipating residents remain in the denominator, regardless of occupational history. Q5 membership uses the existing fixed occupational classification.

For each year 2022–2026, January–September observed Basic Monthly CPS files are pooled. The published ratio is the sum of nine weighted numerators divided by the sum of nine weighted population denominators. Average counts divide those sums by nine. This is a ratio of sums, not a simple average of monthly percentages. Equal observed months make comparisons comparable across years and avoid the missing October 2025 month. There is no interpolation, seasonally adjusted estimate, or DID in this map.

The universe, composite weight PWCMPWGT/10,000, employment recode and usual full-time recode are identical to the audited national reconstruction. All 45 raw archives were verified against recorded hashes and reparsed. Each state numerator was checked against the existing state-industry aggregate. Each national denominator was checked against existing age-population totals. All checks passed within floating-point tolerance. Original raw files, source manifest, parser and fixed scores remain unchanged. The map covers state of residence, not workplace location. Exposure follows the primary occupation; usual full-time status refers to hours across jobs.

States require at least 200 total population person-month records and 50 Q5 full-time person-month records for color display. Both endpoints must qualify to show changes from 2022. This explicit display rule is a research choice, not an official CPS precision standard. Rotation overlap means pooled counts are not independent or unique people. Sampling uncertainty, population controls and changes in occupational composition remain relevant. No design-based confidence intervals, significance rankings or AI causal claims are attached to map colors. Hatched states are insufficient-support estimates, not zero employment. The national ratio includes all observed states, including those whose individual colors are suppressed. The downloadable table retains raw estimates and support flags for audit.

Rates are displayed on one fixed sequential scale across years. Changes use one fixed symmetric diverging scale across years. The change is an unadjusted percentage-point difference from the same nine months of 2022, not a Q5-versus-Q1–Q4 DID. A higher level reflects more residents in Q5 full-time employment, not greater harm from AI. The main DID estimates are unchanged.

Boundaries are the [Census 2025 state cartographic boundary KML](https://www2.census.gov/geo/tiger/GENZ2025/kml/cb_2025_us_state_20m.zip), documented in [Census cartographic boundary files](https://www.census.gov/geographies/mapping-files/time-series/geo/cartographic-boundary.2025.html). The contiguous states use a spherical Albers equal-area thematic projection. Alaska and Hawaii are repositioned and rescaled insets. Territories are excluded because this CPS reconstruction covers the states and DC. State shapes are schematic thematic boundaries, not for navigation or precise spatial measurement.

Reproduction requires the original project-relative CPS archives, dictionaries and parser. Run build.py, then publish.py. Only aggregate counts, geometry, validation and code are published. No individual records are included. Updated November 26, 2026.
"""
(O / "STATE_MAP_METHODS_EN.md").write_text(methods)
shutil.copy2(O / "STATE_MAP_METHODS_EN.md", S / "downloads/STATE_MAP_METHODS_EN.md")

html = """<details class="result" id="state-youth-map" open><summary>Where do young adults hold full-time jobs in highly exposed occupations?</summary><div class="result-body"><p class="state-map-kicker">STATE PICTURE · AGES 22–25 · THAIE Q5</p><h3 class="state-map-title">Full-time employment in THAIE Q5 · ages 22–25 · 2026</h3><p><strong>Employment rate = Q5 full-time workers ÷ all residents aged 22–25 in each state.</strong> This is not the full-time share among employed Q5 workers. Compare the same January–September months across years.</p><div class="state-map-controls"><div role="group" aria-label="Map year"><button type="button" data-year="2022" aria-pressed="false">2022</button><button type="button" data-year="2023" aria-pressed="false">2023</button><button type="button" data-year="2024" aria-pressed="false">2024</button><button type="button" data-year="2025" aria-pressed="false">2025</button><button type="button" data-year="2026" aria-pressed="true">2026</button></div><div role="group" aria-label="Map measure"><button type="button" data-mode="rate" aria-pressed="true">Employment rate</button><button type="button" data-mode="change" aria-pressed="false">Change since 2022</button></div></div><p class="state-map-stats" aria-live="polite">Loading weighted CPS state estimates…</p><svg viewBox="0 0 1000 700" role="group" aria-label="State map loading" class="state-map-svg"></svg><div class="state-map-legend"></div><p class="state-map-info" aria-live="polite">Loading state details…</p><p class="state-map-note">Descriptive estimates, not AI effects. Hatched states have insufficient sample support, not zero employment. Display requires ≥50 Q5 full-time and ≥200 population person-month records; pooled observations can include the same respondent repeatedly. Changes require support in both years. Colors do not indicate statistical significance. The national rate includes all states.</p><p><a href="downloads/state-map-state_youth_Q5_fulltime_rates.csv">Download state rates</a> · <a href="downloads/STATE_MAP_METHODS_EN.md">Definitions and methods</a> · <a href="downloads/state-map-VALIDATION.json">Validation</a> · <button type="button" class="state-map-save">Save map SVG</button></p></div></details>"""
css = """#state-youth-map .state-map-kicker{font-size:.75rem;letter-spacing:.13em;font-weight:700;color:#82909a}#state-youth-map .state-map-controls{display:flex;flex-wrap:wrap;gap:1rem;margin:1rem 0}#state-youth-map button{background:#fff;border:1px solid #d5dce1;border-radius:5px;color:#4d606c;padding:.55rem .85rem;cursor:pointer;font:inherit}#state-youth-map button[aria-pressed=true]{background:#c64f5a;color:white;border-color:#c64f5a}#state-youth-map .state-map-svg{width:100%;height:auto;display:block}#state-youth-map .state-map-abbr{font:600 14px Arial,sans-serif;fill:#39434b;paint-order:stroke;stroke:white;stroke-width:2px;stroke-linejoin:round}#state-youth-map .state-map-inset{font:13px Arial,sans-serif;fill:#66727b}#state-youth-map path[data-state]{cursor:pointer}#state-youth-map path[data-state]:hover,#state-youth-map path[data-state]:focus{stroke:#39434b;stroke-width:2;outline:none}#state-youth-map .state-map-stats{background:#faf0f1;padding:.85rem 1rem;border-left:3px solid #c64f5a;font-size:.96rem}#state-youth-map .state-map-info{min-height:5rem;background:#f4f6f7;padding:1rem;font-size:.93rem}#state-youth-map .state-map-note{font-size:.84rem;color:#687780}#state-youth-map .state-map-legend{display:flex;gap:.8rem;align-items:center;flex-wrap:wrap;font-size:.85rem;color:#687780}#state-youth-map .state-map-ramp{display:inline-block;width:150px;height:13px;border:1px solid #eee}@media(max-width:600px){#state-youth-map .state-map-controls{gap:.6rem}#state-youth-map button{padding:.4rem .6rem;font-size:.85rem}#state-youth-map .state-map-abbr{font-size:17px}#state-youth-map .state-map-info{min-height:7rem}}"""
(S / "state-map.css").write_text(css)
soup = BeautifulSoup((S / "index.html").read_text(), "html.parser")
for node in soup.find_all(
    string=lambda text: text and "Updated November 25, 2026" in text
):
    node.replace_with(
        node.replace("Updated November 25, 2026", "Updated November 26, 2026")
    )
old_note = soup.find(id="state-map-method-note")
if old_note:
    old_note.decompose()
soup.find(id="methods").append(
    BeautifulSoup(
        '<p id="state-map-method-note">The opening state map reports actual employment–population ratios, rather than normalized indices. Its numerator is THAIE Q5 full-time employment at ages 22–25; its denominator is all residents of the same age in each state. Each year pools the same nine observed months, January–September. Percentage-point changes are descriptive comparisons, separate from the DID models.</p>',
        "html.parser",
    )
)
old = soup.find(id="state-youth-map")
if old:
    old.decompose()
results = soup.find(id="results")
results.h2.insert_after(BeautifulSoup(html, "html.parser"))
for detail in results.find_all("details"):
    detail.attrs.pop("open", None)
soup.find(id="state-youth-map")["open"] = ""
soup.find(id="state-youth-map").find(class_="state-map-save").parent.append(
    BeautifulSoup(
        ' · <a href="downloads/state-map-reproduction.zip">Reproduction bundle</a>',
        "html.parser",
    )
)
for old in soup.select('link[href^="state-map.css"],script[src^="state-map.js"]'):
    old.decompose()
style = soup.new_tag("link", rel="stylesheet", href="state-map.css?v=20261126")
soup.head.append(style)
digest = hashlib.sha256((S / "state-map.js").read_bytes()).hexdigest()[:12]
script = soup.new_tag("script", src="state-map.js?v=" + digest, defer="")
soup.body.append(script)
(S / "index.html").write_text(str(soup))
with zipfile.ZipFile(
    S / "downloads/state-map-reproduction.zip", "w", zipfile.ZIP_DEFLATED
) as z:
    for p in W.glob("*.py"):
        z.write(p, "code/" + p.name)
    z.write(W / "state-map.js", "code/state-map.js")
    z.write(W / "cb_2025_us_state_20m.zip", "geometry/cb_2025_us_state_20m.zip")
    for p in O.iterdir():
        if p.is_file():
            z.write(p, "outputs/" + p.name)
assert soup.select_one("#results details").get("id") == "state-youth-map"
assert [p.get("id") for p in soup.select("#results details[open]")] == [
    "state-youth-map"
]
print("Published state map first in Results; only that result opens by default.")
