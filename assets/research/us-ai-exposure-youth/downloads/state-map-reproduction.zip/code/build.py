"""Rebuild comparable state youth employment rates from observed CPS months."""

from pathlib import Path
import hashlib
import importlib.util
import json
import math
import zipfile
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
OUT = ROOT / "outputs/US_State_Map_20261126"
OUT.mkdir(exist_ok=True)
SOURCE = ROOT / "outputs/US_CPS_Only_Monthly_DID_20261125/tables"
MANIFEST = (
    ROOT / "work/us_cps_only_monthly_did_20261125/raw/cps_only_source_manifest.json"
)
PARSER = (
    ROOT
    / "outputs/US_THAIE_Regional_Youth_20261122/panel_fe3_20261122/scripts/prepare_panel.py"
)
scores = pd.read_csv(SOURCE / "frozen_THAIE_occupation_assignments.csv")
assert not scores.occ.duplicated().any()
q5 = set(scores.loc[scores.THAIE_q.eq(5), "occ"])
records = json.loads(MANIFEST.read_text())
records = [r for r in records if 2022 <= r["year"] <= 2026 and r["month"] <= 9]
assert len(records) == 45 and all(r.get("available", True) for r in records)
lookup = {(r["year"], r["month"]): r for r in records}
spec = importlib.util.spec_from_file_location("state_map_parser", PARSER)
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)
parser.source = lambda y, m: (
    Path(lookup[y, m]["path"]),
    Path(lookup[y, m]["dictionary"]),
)
monthly = []
checks = []
for rec in records:
    y, m = rec["year"], rec["month"]
    d, audit = parser.read(y, m)
    assert audit["sha256"] == rec["sha256"]
    d = d[d.PRTAGE.between(22, 25)].copy()
    d["Q5_E"] = d.E.where(d.occ.isin(q5), 0)
    d["Q5_FT"] = d.FT.where(d.occ.isin(q5), 0)
    d["mapped_E"] = d.E.where(d.occ.isin(scores.occ), 0)
    d["nP"] = 1
    d["nQ5_E"] = (d.Q5_E > 0).astype(int)
    d["nQ5_FT"] = (d.Q5_FT > 0).astype(int)
    cols = ["P", "E", "FT", "Q5_E", "Q5_FT", "mapped_E", "nP", "nQ5_E", "nQ5_FT"]
    a = d.groupby("GESTFIPS", as_index=False)[cols].sum()
    a["year"], a["month"] = y, m
    # Compare the rebuilt numerator with the previously audited state aggregation.
    previous = pd.read_parquet(
        ROOT / f"work/us_cps_only_monthly_did_20261125/states_{y}_{m:02}.parquet"
    )
    prev = (
        previous[previous.age.eq("22–25") & previous.band.eq("Q5")]
        .groupby("GESTFIPS")
        .FT.sum()
    )
    err = float(
        (
            a.set_index("GESTFIPS").Q5_FT
            - prev.reindex(a.GESTFIPS, fill_value=0).to_numpy()
        )
        .abs()
        .max()
    )
    assert err < 1e-6
    national = pd.read_parquet(
        ROOT / f"work/us_cps_only_monthly_did_20261125/population_{y}_{m:02}.parquet"
    )
    assert abs(a.P.sum() - national.loc[national.age.eq("22–25"), "P"].iloc[0]) < 1e-5
    assert len(a) == 51
    monthly.append(a)
    checks.append(
        dict(year=y, month=m, raw_sha256=audit["sha256"], max_numerator_difference=err)
    )
    print(f"Verified {y}-{m:02}", flush=True)
monthly = pd.concat(monthly, ignore_index=True)
monthly.to_csv(OUT / "state_youth_monthly_aggregates.csv", index=False)
annual = monthly.groupby(["year", "GESTFIPS"], as_index=False)[cols].sum()
annual["months"] = 9
annual["population_average"] = annual.P / 9
annual["Q5_FT_average"] = annual.Q5_FT / 9
annual["Q5_E_average"] = annual.Q5_E / 9
annual["rate_pct"] = 100 * annual.Q5_FT / annual.P
annual["FT_share_of_Q5_employed_pct"] = 100 * annual.Q5_FT / annual.Q5_E
annual["exposure_coverage_pct"] = 100 * annual.mapped_E / annual.E
# This transparent display rule is not an official CPS precision criterion.
annual["supported"] = annual.nP.ge(200) & annual.nQ5_FT.ge(50)
base = annual[annual.year.eq(2022)].set_index("GESTFIPS")
annual["baseline_rate_pct"] = annual.GESTFIPS.map(base.rate_pct)
annual["change_pp"] = annual.rate_pct - annual.baseline_rate_pct
annual["change_supported"] = annual.supported & annual.GESTFIPS.map(base.supported)
assert annual.rate_pct.between(0, 100).all()
assert annual.Q5_FT.le(annual.Q5_E + 1e-6).all()
assert annual[annual.year.eq(2022)].change_pp.abs().max() == 0

ns = {"k": "http://www.opengis.net/kml/2.2"}
geometry_file = W / "cb_2025_us_state_20m.zip"
with zipfile.ZipFile(geometry_file) as z:
    tree = ET.fromstring(z.read("cb_2025_us_state_20m.kml"))
features = []
for placemark in tree.findall(".//k:Placemark", ns):
    prop = {n.attrib["name"]: n.text for n in placemark.findall(".//k:SimpleData", ns)}
    fips = int(prop["STATEFP"])
    if fips not in set(annual.GESTFIPS):
        continue
    rings = []
    for ring in placemark.findall(".//k:LinearRing/k:coordinates", ns):
        pairs = [list(map(float, token.split(",")[:2])) for token in ring.text.split()]
        rings.append(pairs)
    features.append(
        dict(fips=fips, name=prop["NAME"], abbr=prop["STUSPS"], rings=rings)
    )
assert len(features) == 51 and len({f["fips"] for f in features}) == 51


def albers(lon, lat, center=-96, origin=37.5, parallel1=29.5, parallel2=45.5):
    """Spherical Albers equal-area conic, used only for thematic display."""
    p1, p2, p0, phi = map(math.radians, [parallel1, parallel2, origin, lat])
    n = (math.sin(p1) + math.sin(p2)) / 2
    c = math.cos(p1) ** 2 + 2 * n * math.sin(p1)
    rho = math.sqrt(c - 2 * n * math.sin(phi)) / n
    rho0 = math.sqrt(c - 2 * n * math.sin(p0)) / n
    theta = n * math.radians(lon - center)
    return rho * math.sin(theta), -(rho0 - rho * math.cos(theta))


def project(f, pair):
    lon, lat = pair
    if f["abbr"] == "AK":
        if lon > 0:
            lon -= 360
        return albers(lon, lat, -154, 58.5, 55, 65)
    if f["abbr"] == "HI":
        return lon * math.cos(math.radians(20)), -lat
    return albers(lon, lat)


for f in features:
    f["xy"] = [[project(f, point) for point in ring] for ring in f.pop("rings")]
for group, box in [
    ("main", (35, 15, 850, 520)),
    ("AK", (40, 490, 175, 145)),
    ("HI", (245, 555, 160, 85)),
]:
    subset = [
        f
        for f in features
        if (f["abbr"] == group if group != "main" else f["abbr"] not in ["AK", "HI"])
    ]
    points = np.array([p for f in subset for ring in f["xy"] for p in ring])
    lo, hi = points.min(axis=0), points.max(axis=0)
    x, y, width, height = box
    scale = min(width / (hi[0] - lo[0]), height / (hi[1] - lo[1]))
    for f in subset:
        f["xy"] = [
            [[(p[0] - lo[0]) * scale + x, (p[1] - lo[1]) * scale + y] for p in ring]
            for ring in f["xy"]
        ]
        f["path"] = " ".join(
            "M" + " L".join(f"{px:.2f},{py:.2f}" for px, py in ring) + " Z"
            for ring in f["xy"]
        )
        # Area-weighted centroid of the largest ring gives sensible label anchors.
        ring = max(
            f["xy"],
            key=lambda r: abs(
                sum(
                    r[i][0] * r[(i + 1) % len(r)][1] - r[(i + 1) % len(r)][0] * r[i][1]
                    for i in range(len(r))
                )
            ),
        )
        arr = np.array(ring)
        cross = arr[:-1, 0] * arr[1:, 1] - arr[1:, 0] * arr[:-1, 1]
        area6 = 3 * cross.sum()
        f["label"] = [
            float(((arr[:-1, j] + arr[1:, j]) * cross).sum() / area6) for j in [0, 1]
        ]
        f.pop("xy")
name_map = {f["fips"]: f["name"] for f in features}
abbr_map = {f["fips"]: f["abbr"] for f in features}
annual["state"] = annual.GESTFIPS.map(name_map)
annual["abbr"] = annual.GESTFIPS.map(abbr_map)
annual.to_csv(OUT / "state_youth_Q5_fulltime_rates.csv", index=False)
national = []
for year, g in annual.groupby("year"):
    national.append(
        dict(
            year=int(year),
            rate_pct=float(100 * g.Q5_FT.sum() / g.P.sum()),
            Q5_FT_average=float(g.Q5_FT.sum() / 9),
            population_average=float(g.P.sum() / 9),
            supported_states=int(g.supported.sum()),
            supported_changes=int(g.change_supported.sum()),
        )
    )
payload = dict(
    states=features,
    rates=json.loads(annual.to_json(orient="records")),
    national=national,
    metadata=dict(
        age="22–25",
        measure="THAIE Q5",
        months="January–September",
        denominator="All civilian noninstitutional residents aged 22–25 in each state",
        numerator="Residents aged 22–25 employed full time in a THAIE Q5 primary occupation",
        rate="100 × sum of weighted Q5 FT employment / sum of weighted age-group population across nine observed months",
        quality_flag_rule="At least 200 population person-month records and 50 Q5 full-time person-month records; both years must pass to avoid a smaller-sample change flag. All finite estimates are shown by default.",
        uncertainty="Repeated CPS respondents are included across months. These are descriptive weighted ratios; the display threshold does not ensure precision and no design-based significance is claimed.",
        geometry_url="https://www2.census.gov/geo/tiger/GENZ2025/kml/cb_2025_us_state_20m.zip",
        updated="2026-11-26",
    ),
)
(OUT / "state_map.json").write_text(json.dumps(payload, separators=(",", ":")))
validation = dict(
    passed=True,
    raw_months=45,
    state_years=len(annual),
    states=51,
    national=national,
    all_numerators_match_existing=True,
    all_denominators_match_existing=True,
    support_flags_do_not_suppress_finite_estimates=True,
    no_interpolation=True,
    sources=checks,
    score_sha256=hashlib.sha256(
        (SOURCE / "frozen_THAIE_occupation_assignments.csv").read_bytes()
    ).hexdigest(),
    geometry_sha256=hashlib.sha256(geometry_file.read_bytes()).hexdigest(),
    parser_sha256=hashlib.sha256(PARSER.read_bytes()).hexdigest(),
)
(OUT / "VALIDATION.json").write_text(json.dumps(validation, indent=2))
print(json.dumps(national, indent=2))
