from pathlib import Path
import json,shutil,hashlib
import pandas as pd
P=Path(__file__).resolve().parent;H=P.parent;S=H/'37_korea_monthly_panels_20261125/publish/assets/research/korea-ai-exposure-employment'
B=P/'site_backup_before_84months'
if not B.exists():shutil.copytree(S,B)
d=pd.read_csv(P/'occupation_age_sex_extended_checked.csv');d['sex']=d.sex.map({'남':'Male','여':'Female'})
a=d.groupby(['occupation','age','time']).agg(stock=('stock','sum'),n_sexes=('sex','nunique')).reset_index();a.loc[a.n_sexes.ne(2),'stock']=float('nan');a['sex']='All';d=pd.concat([d,a],ignore_index=True)
manifest=json.loads((S/'data/monthly-occupations/manifest.json').read_text())
for item in manifest:
 label='2025직종_'+item['label']
 g=d[d.occupation.eq(label)]
 if g.empty:continue
 old=json.loads((B/f'data/monthly-occupations/{item["id"]}.json').read_text())
 # Existing official all-age totals and fully reconciled software series are retained.
 if item['label']=='소프트웨어 개발자':
  keys={(r[0],r[1],r[2]) for r in old}
  g=g[[ (r.time,r.age,r.sex) not in keys for r in g.itertuples()]]
  keep=old
 else:keep=[r for r in old if r[1]=='All']
 bases={(r[1],r[2]):r[4] for r in old if r[0]=='2022-11' and r[4] is not None and r[4]>0}
 rows=keep+[[r.time,r.age,r.sex,100*r.stock/bases[(r.age,r.sex)] if (r.age,r.sex) in bases and pd.notna(r.stock) else None,int(r.stock) if pd.notna(r.stock) else None] for r in g.itertuples()]
 keys=[tuple(r[:3]) for r in rows];assert len(keys)==len(set(keys))
 (S/f'data/monthly-occupations/{item["id"]}.json').write_text(json.dumps(rows,ensure_ascii=False,separators=(',',':'),allow_nan=False))
 cross=[r[0] for r in rows if r[1]!='All'];item.update(cross_start=min(cross),cross_end=max(cross))
(S/'data/monthly-occupations/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,separators=(',',':')))
# Preserve verified official linkage; rebuild only the longer displayed-window cohorts.
s=(H/'41_korea_monthly_quintile_sex_20261125/build.py').read_text()
s=s.replace("'2024-11'","'2026-10'").replace('35 months','58 months').replace('35 real months','58 real months')
s=s.replace("raw=pd.read_csv(H/'37_korea_monthly_panels_20261125/occupation_age_sex_202001_202411_checked.csv')","raw=pd.read_csv(R/'occupation_age_sex_extended_checked.csv')")
(P/'rebuild_extended_quintiles.py').write_text(s)
print('Updated occupation JSON and saved extended quintile builder')
