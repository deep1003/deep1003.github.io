from pathlib import Path
import hashlib,json,re,warnings
import pandas as pd
warnings.filterwarnings('ignore',message='Workbook contains no default style')
P=Path(__file__).resolve().parent
records=[]; audits=[]
for f in sorted((P/'raw').glob('occ_age5_sex_*.xlsx')):
 d=pd.read_excel(f,header=None); h=d.index[d[0].eq('직종_소분류(현행화)')][0]
 months={c:re.sub(r'(\d{4})년(\d{2})월',r'\1-\2',str(d.iloc[h-1,c])) for c in range(3,d.shape[1],3)}
 occ=None;age=None; totals={};leaf=[];ot=[]
 for row in d.iloc[h+1:].itertuples(index=False,name=None):
  a,b,s=row[:3]
  if pd.notna(a):
   if str(a)=='총계':
    totals={m:row[c] for c,m in months.items()};continue
   if str(a).endswith(' 전체') and pd.isna(b):
    occ=str(a)[:-3];age=None
    for c,m in months.items(): ot.append({'occupation':occ,'time':m,'stock':row[c]})
    continue
   occ=str(a)
  if pd.notna(b): age=re.sub(r' 전체$','',str(b))
  if s not in ('남','여'): continue
  assert occ and age,(f,row[:3])
  for c,m in months.items():
   r={'occupation':occ,'age':age,'sex':s,'time':m,'stock':row[c],'acquisitions':row[c+1],'separations':row[c+2]};records.append(r);leaf.append(r)
 z=pd.DataFrame(leaf); t=pd.DataFrame(ot)
 stocksum=z.groupby('time').stock.sum(min_count=1);ots=t.groupby('time').stock.sum(min_count=1)
 audit={'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'rows':len(z),'months':list(months.values()),'occupations':z.occupation.nunique(),'duplicates':int(z.duplicated(['occupation','age','sex','time']).sum()),'null_measures':z[['stock','acquisitions','separations']].isna().sum().to_dict(),'leaf_minus_grand':{m:float(stocksum[m]-v) for m,v in totals.items()},'occupation_totals_minus_grand':{m:float(ots[m]-v) for m,v in totals.items()}}
 metric_delta=d.iloc[h+1:][d.iloc[h+1:,2].isin(['남','여'])].iloc[:,3:].apply(pd.to_numeric).sum().values-d.iloc[h+1,3:].astype(float).values
 audit['all_metrics_max_absolute_sum_difference']=float(abs(metric_delta).max())
 audits.append(audit)
new=pd.DataFrame(records);new.to_csv(P/'new_observations_occupation_age_sex.csv',index=False,encoding='utf-8-sig')
old=pd.read_csv(P.parent/'37_korea_monthly_panels_20261125/occupation_age_sex_202001_202411_checked.csv');merged=pd.concat([old,new],ignore_index=True)
assert not merged.duplicated(['occupation','age','sex','time']).any()
# Accept only monthly leaf stocks reconciled to the official grand total.
valid=[m for a in audits for m,v in a['leaf_minus_grand'].items() if v==0 and a['duplicates']==0]
accepted=pd.concat([old,new[new.time.isin(valid)]],ignore_index=True)
accepted.to_csv(P/'occupation_age_sex_extended_checked.csv',index=False,encoding='utf-8-sig')
accepted.groupby('time').agg(rows=('stock','size'),occupations=('occupation','nunique'),stock=('stock','sum')).to_csv(P/'coverage_by_month.csv')
(P/'VALIDATION.json').write_text(json.dumps({'sources':audits,'accepted_new_months':valid,'combined_rows':len(accepted),'combined_months':accepted.time.nunique(),'first':accepted.time.min(),'last':accepted.time.max(),'source_url':'https://eis.work24.go.kr/eisps/rpt/reptDtl.do?menuId=020020020','download_date':'2026-11-26'},ensure_ascii=False,indent=2))
print(json.dumps({'audits':audits,'accepted_new_months':valid},ensure_ascii=False))
