"""Strict, allocation-free KECO-to-THAIE quintile linkage and fixed cohorts."""
from pathlib import Path
import hashlib,json,re,subprocess
import numpy as np,pandas as pd,fitz
R=Path(__file__).resolve().parent;H=R.parent;ROOT=H.parent
S=H/'37_korea_monthly_panels_20261125/publish/assets/research/korea-ai-exposure-employment'
C=ROOT/'AI_Graduate_Employment_20261114/prerequisite_audit_20261114/occupation'
classification=H/'35_korea_monthly_acquisition_20261125/classification/KECO_2025_official_classification.pdf'
text=subprocess.check_output(['pdftotext','-raw',str(classification),'-'],text=True).split('\f')[1]
lines=text.splitlines();names={}
for i,line in enumerate(lines):
    m=re.match(r'^(\d{3})\s+(.+)',line)
    if not m:continue
    name=re.split(r'\s+\d{4}\s',m[2])[0];j=i+1
    while j<len(lines) and not re.match(r'^\d',lines[j]):name+=lines[j];j+=1
    names[m[1]]=name
norm=lambda s:re.sub(r'[^가-힣a-zA-Z0-9]','',s)
lookup={norm(v):k for k,v in names.items()};assert len(lookup)==140
edges=pd.read_csv(C/'KECO2025_KSCO8_official_edges.csv',dtype=str)
assert set(re.findall(r'(?<!\d)(\d{4})(?=\s)',text))==set(edges.keco_code)
source_pdf=fitz.open(C/'KEIS2025.pdf')
for row in edges.itertuples():
    page=source_pdf[int(row.pdf_page)-1].get_text()
    assert row.keco_code in page and row.ksco_code in page
assignment=pd.read_csv(H/'29_youth_employment_quintiles_20261124/quintile_assignment.csv')
qs=assignment[assignment.method.eq('THAIE')].set_index('occ').quintile.to_dict()
manifest=json.loads((S/'data/monthly-occupations/manifest.json').read_text())
mapping=[];data=[]
for item in manifest:
    code=lookup.get(norm(item['label']));targets=set();status='not_classified';quintile=None
    if code:
        for raw in edges.loc[edges.keco_code.str.startswith(code),'ksco_code']:
            if re.fullmatch(r'\d{4}',str(raw)):targets.add(int(raw[:3]))
        values={qs.get(t) for t in targets}
        if targets and None not in values and len(values)==1:quintile=int(next(iter(values)));status='all_targets_same_quintile'
        elif not targets or None in values:status='unscored_target'
        else:status='multiple_quintiles'
    mapping.append(dict(id=item['id'],label=item['label'],keco2025=code,ksco8_targets=';'.join(map(str,sorted(targets))),quintile=quintile,status=status))
    if code and item['cross_end']:
        for time,age,sex,index,stock in json.loads((S/f"data/monthly-occupations/{item['id']}.json").read_text()):
            if '2022-01'<=time<='2026-10' and sex in ['Male','Female']:
                data.append(dict(id=item['id'],time=time,age=age,sex=sex,employment=stock,quintile=quintile))
mapping=pd.DataFrame(mapping);assert mapping.quintile.notna().sum()==110
mapping.to_csv(R/'strict_quintile_linkage.csv',index=False)
d=pd.DataFrame(data);assert not d.duplicated(['id','time','age','sex']).any()
months=pd.period_range('2022-01','2026-10',freq='M').astype(str).tolist()
ages=['20~24세 이하','25~29세 이하','30~34세 이하','35~39세 이하','40~44세 이하','45~49세 이하','50~54세 이하','55~59세 이하','60~64세 이하','65~69세 이하','70세 이상']
raw=pd.read_csv(R/'occupation_age_sex_extended_checked.csv')
assert not raw.duplicated(['occupation','age','sex','time']).any()
raw['sex']=raw.sex.map({'남':'Male','여':'Female'})
rows=[];metadata=[];cohorts=[]
for age in ages:
    a=d[d.age.eq(age)&d.quintile.notna()].copy();eligible=[]
    for occ,g in a.groupby('id'):
        if len(g)!=len(months)*2 or g.employment.isna().any():continue
        if not g.time.nunique()==len(months):continue
        base=g[g.time.eq('2022-11')]
        if len(base)!=2 or not base.employment.gt(0).all():continue
        eligible.append(occ)
    a=a[a.id.isin(eligible)];counts=a[['id','quintile']].drop_duplicates().groupby('quintile').size().to_dict()
    age_meta=dict(id=age,label=age.replace('세 이하','세'),cohort_counts={f'Q{int(q)}':int(n) for q,n in counts.items()},occupations=len(eligible),coverage={},coverage_named_only={},coverage_full_source={},coverage_denominator={},coverage_numerator={},coverage_denominator_full_source={},coverage_denominator_named_only={})
    for occ in eligible:cohorts.append(dict(age=age,id=occ,quintile=int(a[a.id.eq(occ)].quintile.iloc[0])))
    for sex in ['Male','Female']:
        named_ref=d[d.age.eq(age)&d.sex.eq(sex)&d.time.eq('2022-11')].employment.sum(min_count=1)
        baseline=raw[raw.age.eq(age)&raw.sex.eq(sex)&raw.time.eq('2022-11')]
        ref=baseline[baseline.occupation.str.startswith('2025직종_')].stock.sum(min_count=1)
        full_ref=baseline.stock.sum(min_count=1)
        retained=a[a.sex.eq(sex)&a.time.eq('2022-11')].employment.sum(min_count=1)
        age_meta['coverage'][sex]=round(100*retained/ref,2) if ref and pd.notna(retained) else None
        age_meta['coverage_named_only'][sex]=round(100*retained/named_ref,2)
        age_meta['coverage_full_source'][sex]=round(100*retained/full_ref,2)
        age_meta['coverage_denominator'][sex]=float(ref)
        age_meta['coverage_numerator'][sex]=float(retained)
        age_meta['coverage_denominator_full_source'][sex]=float(full_ref)
        age_meta['coverage_denominator_named_only'][sex]=float(named_ref)
    for group in ['Q1','Q2','Q3','Q4','Q5','All']:
        subset=a if group=='All' else a[a.quintile.eq(int(group[1:]))]
        if subset.empty:continue
        grouped=subset.groupby(['time','sex']).employment.sum(min_count=1)
        base=grouped.loc['2022-11']
        occ_base=subset[subset.time.eq('2022-11')].pivot(index='id',columns='sex',values='employment')
        common_weights=occ_base.sum(axis=1)/occ_base.to_numpy().sum()
        for (time,sex),value in grouped.items():
            cell=subset[subset.time.eq(time)&subset.sex.eq(sex)].set_index('id').employment
            standard=100*(common_weights*cell/occ_base[sex]).sum()
            rows.append(dict(age=age,group=group,time=time,sex=sex,employment=float(value),index=100*value/base.loc[sex],standardized_index=float(standard)))
    metadata.append(age_meta)
output=dict(baseline='2022-11',start='2022-01',end='2026-10',ages=metadata,rows=rows,
            definition='Fixed 2019–2021 national RES employment-weighted THAIE quintiles, not re-ranked within sex or age',
            score_benchmark='GPT-5 2025, existing corrected KSCO8 manuscript scores',
            membership='KECO2025 exact normalized official label; all KSCO8 targets must have the same original quintile; no allocation weights',
            cohort='Within each age, identical occupation cohort for both sexes, observed in every one of 58 months, positive November2022 counts',
            selection='Eligibility uses full displayed-window completeness; descriptive selected cohort, not national causal inference',
            missing='No zero imputation, no time interpolation; explicit observed zero counts retained',
            total='Observed counts sum across included Q1–Q5; standardized All is independently weighted over all included occupations',
            coverage_denominator='Observed ordinary 2025 occupation source rows including unclassified; separate artist/provider occupation tables excluded',
            standardized_formula='100*sum_o(w_o*N_sex,o,t/N_sex,o,Nov2022), w_o=pooled male+female baseline employment share within age and panel',
            source='Employment administration official occupation-age-sex aggregates; KEIS KECO2025–KSCO8 official appendix pp659–682 (PDF pages663–686)')
# Verify algebra, baseline, dimensions and exact subgroup additivity.
f=pd.DataFrame(rows);assert not f.duplicated(['age','group','sex','time']).any()
assert np.allclose(f[f.time.eq('2022-11')]['index'],100)
assert np.allclose(f[f.time.eq('2022-11')]['standardized_index'],100)
assert f.time.min()=='2022-01' and f.time.max()=='2026-10'
for (age,sex,time),g in f.groupby(['age','sex','time']):
    assert np.isclose(g[g.group.ne('All')].employment.sum(),g[g.group.eq('All')].employment.iloc[0])
for age in metadata:
    assert set(age['cohort_counts'])=={'Q1','Q2','Q3','Q4','Q5'}
(S/'data/monthly-quintile-sex.json').write_text(json.dumps(output,ensure_ascii=False,separators=(',',':'),allow_nan=False))
f.to_csv(S/'downloads/monthly-quintile-sex.csv',index=False)
shas={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [classification,C/'KEIS2025.pdf',C/'KECO2025_KSCO8_official_edges.csv',H/'29_youth_employment_quintiles_20261124/quintile_assignment.csv']}
(R/'VALIDATION.json').write_text(json.dumps(dict(passed=True,source_hashes=shas,matched_native_labels=140,native_labels=142,unambiguous_quintile_occupations=110,ages=metadata,rows=len(rows),checks=['495 source codes complete','495 edge endpoints present on source PDF pages','unique source grain','fixed joint-sex cohorts','58 real months','November2022 equals100','Q1–Q5 sum equals included total']),ensure_ascii=False,indent=2))
pd.DataFrame(cohorts).to_csv(R/'fixed_cohorts.csv',index=False)
print(pd.DataFrame(metadata)[['label','occupations','coverage']].to_string(index=False));print('PASS',len(rows),'plot rows')
