from pathlib import Path
import os,ast
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,pandas as pd
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
P=Path(__file__).resolve().parent;H=P.parent
src=ast.parse((H/'49_korea_stock_flows_20261126/analyze.py').read_text());func=next(x for x in src.body if isinstance(x,ast.FunctionDef) and x.name=='fit');exec(compile(ast.Module(body=[func],type_ignores=[]),'audit_fit','exec'))
rows=[]
for age in ['age20_24','age25_29']:
 a=pd.read_csv(H/'47_korea_age_split_did_20261126'/age/'balanced_occupation_sex_month.csv')
 for sex in ['Male','Female']:
  g=a[a.sex.eq(sex)].copy();base=g[g.rel.eq(0)].set_index('occupation').n;g['base']=g.occupation.map(base);g['treated']=g.q5;g=g[g.rel.ne(0)].copy()
  for outcome in ['acquisitions','separations']:
   g['y']=100*g[outcome]/g.base
   for spec,weighted,extra in [('base',False,None),('weighted',True,None),('trend',False,'trend'),('covid',False,'covid')]:
    rows.append(dict(age_group=age,sex=sex,outcome=outcome,specification=spec,**fit(g,'y',weighted,extra)))
r=pd.DataFrame(rows);mask=r.specification.eq('base');r.loc[mask,'p_holm_eight_age_sex_flow_tests']=multipletests(r.loc[mask,'p'],method='holm')[1];r.to_csv(P/'ALL_FOUR_GROUP_FLOW_AUDIT.csv',index=False)
print(r[mask][['age_group','sex','outcome','coefficient','p','p_holm_eight_age_sex_flow_tests']].to_string(index=False))
