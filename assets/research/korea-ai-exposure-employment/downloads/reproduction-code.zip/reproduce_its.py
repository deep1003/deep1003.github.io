"""Independent model-shape audit. Does not edit original source, estimates or site."""
from pathlib import Path
import hashlib,json
import numpy as np,pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.diagnostic import acorr_ljungbox
R=Path(__file__).resolve().parent;H=R.parent
source=R/'site/assets/research/korea-ai-exposure-employment/data/administrative.json'
(R/'outputs').mkdir(exist_ok=True)
d=pd.DataFrame(json.loads(source.read_text()));d=d[d.kind.eq('software')&d.frequency.eq('monthly')]
young=['20~24세 이하','25~29세 이하'];older=['40~44세 이하','45~49세 이하','50~54세 이하','55~59세 이하','60~64세 이하','65~69세 이하','70세 이상']
rows=[]
for (sex,month),g in d.groupby(['sex','time']):
    a=g.set_index('age_group').employment
    if not set(young+older)<=set(a.index):continue
    if a.loc[young+older].isna().any():continue
    y,o=a.loc[young].sum(),a.loc[older].sum()
    if min(y,o)<=0:continue
    rel=pd.Period(month,'M').ordinal-pd.Period('2022-11','M').ordinal
    rows.append(dict(sex=sex,time=month,rel=rel,month=int(month[-2:]),gap=np.log(y/o)))
panel=pd.DataFrame(rows)
original=pd.read_csv(R/'inputs/monthly_age_gap_reference.csv')
check=panel.merge(original[['sex','time','gap']],on=['sex','time'],suffixes=('_independent','_original'),validate='one_to_one')
assert len(check)==len(panel)==len(original) and np.allclose(check.gap_independent,check.gap_original,atol=1e-14)
models=[('linear','gap~rel+post+after+pulse+C(month)'),('common_quadratic','gap~rel+I(rel**2)+post+after+pulse+C(month)'),('segmented_quadratic','gap~rel+I(rel**2)+post+after+I(after**2)+pulse+C(month)')]
results=[];pre=[]
for sex in ['All','Male','Female']:
    g=panel[panel.sex.eq(sex)&panel.rel.between(-34,34)].copy();assert len(g)==69
    g['post']=g.rel.gt(0).astype(int);g['after']=g.rel.clip(lower=0);g['pulse']=g.rel.eq(0).astype(int)
    assert np.diff(np.sort(g.rel)).tolist()==[1]*68
    for spec,formula in models:
        m=smf.ols(formula,g).fit(cov_type='HAC',cov_kwds={'maxlags':12,'use_correction':True},use_t=True)
        c=np.zeros(len(m.params));c[m.params.index.get_loc('post')]=1;c[m.params.index.get_loc('after')]=24
        if 'I(after ** 2)' in m.params.index:c[m.params.index.get_loc('I(after ** 2)')]=24**2
        test=m.t_test(c);b=float(np.asarray(test.effect).item());ci=test.conf_int()[0]
        # Equivalent to predicted value minus extrapolated pre-shape at t=24.
        assert np.isclose(b,sum(m.params[name]*value for name,value in zip(m.params.index,c)))
        results.append(dict(sex=sex,spec=spec,n=int(m.nobs),pre=34,post=34,transition_pulse=1,horizon=24,
                            parameters=len(m.params),design_rank=np.linalg.matrix_rank(m.model.exog),df_resid=m.df_resid,
                            estimate_logpoints=100*b,percent=100*np.expm1(b),ci_low_percent=100*np.expm1(ci[0]),
                            ci_high_percent=100*np.expm1(ci[1]),p_two_sided=float(test.pvalue),bic=m.bic,
                            ljung_box12_p=acorr_ljungbox(m.resid,lags=[12]).lb_pvalue.iloc[0]))
    for spec,formula in [('pre_linear','gap~rel+C(month)'),('pre_quadratic','gap~rel+I(rel**2)+C(month)')]:
        m=smf.ols(formula,g[g.rel.lt(0)]).fit(cov_type='HAC',cov_kwds={'maxlags':6,'use_correction':True},use_t=True)
        pre.append(dict(sex=sex,spec=spec,n=int(m.nobs),parameters=len(m.params),df_resid=m.df_resid,bic=m.bic,
                        quadratic_coefficient=m.params.get('I(rel ** 2)',np.nan),
                        quadratic_p_two_sided=m.pvalues.get('I(rel ** 2)',np.nan)))
pd.DataFrame(results).to_csv(R/'outputs/independent_its_functional_form.csv',index=False)
pd.DataFrame(pre).to_csv(R/'outputs/independent_its_preperiod_curvature.csv',index=False)
audit=dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),raw_gap_reconstruction_max_error=float(np.max(abs(check.gap_independent-check.gap_original))),
           selection='Exploratory model-shape sensitivity. BIC is not a causal validation or a rule to select the true specification.',
           comparison='Same 69 consecutive months, month fixed effects, November2022 pulse, HAC12 finite-sample correction and t intervals; only polynomial shape changes.',
           pre_only='Preperiod quadratic diagnosis uses only Jan2020–Oct2022, 34 months, HAC6. Small sample and COVID still limit inference.',
           caution='Segmented quadratic is a diagnostic alternative, not a preferred causal model. Its wider uncertainty demonstrates lack of functional-form robustness.')
(R/'outputs/independent_its_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(pd.DataFrame(results).to_string(index=False));print(pd.DataFrame(pre).to_string(index=False))
