from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
x=pd.read_csv(P/"res-employment-indices.csv",dtype={"scope":str,"time":str})
x=x[(x.kind=="occupation")&(x.scope=="222")&(x.sex=="All")&(x.frequency=="annual")&(x.agegroup!="All")]
f,ax=plt.subplots(figsize=(10,5))
for a,z in x.groupby("agegroup"):
 z=z.sort_values("time");ax.plot(z.time.astype(int),z["index"],marker="o",label=a)
ax.axhline(100,color="grey",linestyle=":");ax.set_ylabel("Employment index (2022=100)");ax.legend(ncol=3);f.tight_layout();f.savefig(P/"software-age.pdf");f.savefig(P/"software-age.png",dpi=200)
