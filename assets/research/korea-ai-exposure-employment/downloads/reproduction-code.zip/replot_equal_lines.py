from pathlib import Path
import matplotlib.patheffects as pe
S=Path(__file__).resolve().parent
# Use existing published points only for static figures.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
D=pd.read_json(S/'data/res.json');D['time']=D.time.astype(str)
A=['22–25','26–30','31–34','35–40','41–49','50+']
GREY=['#6F62A3','#3C929D','#7F9C73','#B19264','#6685AF','#89939A'];RED='#C34E58';QCOL={'Q1':'#B7BABE','Q2':'#D9DBDE','Q3':'#F2D9DC','Q4':'#DF9DA4','Q5':'#C34E58'};DASH=['solid','dashed','dotted','dashdot']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'pdf.fonttype':42,'ps.fonttype':42,'legend.frameon':False})
def lines(ax,g,col,order,focus=False):
 for i,c in enumerate(order):
  z=g[g[col].eq(c)].sort_values('time');hi=c=='Q5' or focus
  ax.plot(z.time.astype(float),z['index'],marker='o',ms=3,color=RED if hi else QCOL.get(c,GREY[i%len(GREY)]),label=c,lw=2.4,ls=DASH[i%len(DASH)] if focus else 'solid',zorder=5 if hi else 2,path_effects=[pe.Stroke(linewidth=4.0,foreground='white'),pe.Normal()])
 ax.axhline(100,color='#a7afb5',lw=.65,ls=':',zorder=0);ax.axvline(2022,color='#c0c5c9',lw=.65,ls='--',zorder=0);ax.set_xticks(range(2020,2026));ax.grid(axis='y',color='#e8ebed',lw=.5);ax.set_ylabel('Employment index (2022 = 100)')
def save(f,n):
 for ax in f.axes:
  ax.get_legend().remove() if ax.get_legend() is not None else None
  labels=[]
  for line in ax.lines:
   label=line.get_label()
   if label.startswith('_'):continue
   xs,ys=line.get_data();valid=[(float(x),float(y)) for x,y in zip(xs,ys) if pd.notna(y)]
   if valid:labels.append([valid[-1][1],valid[-1][1],label,line.get_color(),valid[-1][0]])
  lo,hi=ax.get_ylim();gap=(hi-lo)*.065;labels.sort(key=lambda r:r[0])
  for i,r in enumerate(labels):r[0]=max(r[0],lo+gap,labels[i-1][0]+gap if i else lo+gap)
  for i in range(len(labels)-1,-1,-1):labels[i][0]=min(labels[i][0],labels[i+1][0]-gap if i<len(labels)-1 else hi-gap*.4)
  ax.set_xlim(2019.8,2026.8)
  for y,original,label,color,x in labels:
   text={'Q1':'Q1 (lowest)','Q5':'Q5 (highest)'}.get(label,label)
   ax.annotate(text,xy=(x,original),xytext=(2025.13,y),color=color,fontweight='bold',fontsize=10,va='center',arrowprops={'arrowstyle':'-','lw':.6,'color':color} if abs(y-original)>gap*.3 else None)
 f.savefig(S/'figures'/f'{n}.png',dpi=300,bbox_inches='tight');f.savefig(S/'figures'/f'{n}.pdf',bbox_inches='tight');plt.close(f)
g=D[(D.frequency=='annual')&(D.sex=='All')]
f,ax=plt.subplots(figsize=(10,5));lines(ax,g[(g.kind=='occupation')&(g.scope=='222')&g.agegroup.isin(A)],'agegroup',A);ax.set_title('Korea: computer systems and software professionals (KSCO 222)');ax.legend(ncol=3);f.tight_layout();save(f,'01-software-age')
f,axs=plt.subplots(2,3,figsize=(14,8),sharex=True,sharey=True)
for ax,a in zip(axs.flat,A):lines(ax,g[(g.kind=='exposure')&(g.scope=='All')&(g.agegroup==a)],'line',[f'Q{i}' for i in range(1,6)]);ax.set_title(f'Ages {a}')
axs.flat[0].legend(ncol=3);f.suptitle('Korea: fixed occupational THAIE quintiles within age groups');f.tight_layout();save(f,'02-age-exposure')
f,axs=plt.subplots(2,3,figsize=(14,8),sharex=True,sharey=True)
for ax,a in zip(axs.flat,A):
 z=D[(D.frequency=='annual')&(D.kind=='exposure')&(D.scope=='All')&(D.agegroup==a)&D.line.eq('Q5')&D.sex.isin(['Male','Female'])];lines(ax,z,'sex',['Male','Female'],focus=True);ax.set_title(f'Ages {a}, THAIE Q5')
axs.flat[0].legend();f.suptitle('Korea: sex-specific employment in the highest THAIE quintile');f.tight_layout();save(f,'03-gender-q5')
f,ax=plt.subplots(figsize=(10,5));lines(ax,g[(g.kind=='exposure')&(g.scope=='All')&(g.agegroup=='All')],'line',[f'Q{i}' for i in range(1,6)]);ax.set_title('Korea: all ages 15+, fixed occupational THAIE quintiles');ax.legend(ncol=5);f.tight_layout();save(f,'04-overall-exposure')
print('Restyled four static figures and interactive charts. Data JSON unchanged.')
