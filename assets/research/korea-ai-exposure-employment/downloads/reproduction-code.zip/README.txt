Korean THAIE employment trends, 25 November 2026

No Stanford data or exposure scores are used.

To reproduce the software-age graphic from the public aggregates, run python replot.py. Requires pandas and matplotlib. Other charts use app.js and the supplied aggregate CSVs. Exact original figure formatting is in build.py.

Full microdata reconstruction requires your own authorized MDIS access. Restricted raw records are deliberately absent. The raw-reading script prepare.py expects 2020–2025 B-type Regional Employment Survey files in the existing project directory. build.py additionally expects the two EAPS public annual2 extracts downloaded in this session, official seven-column CSV layouts with raw weights divided by 1000, plus existing verified occupational scores and quintile assignments. See the Korean methods report and source layout comments.

Annual RES results average April and October. EAPS annual results average twelve monthly estimates. Never interpolate RES into monthly occupational exposure series. Small RES cells with fewer than 30 observations in either the current wave or either 2022 baseline wave are not published. Missing values do not mean zero population employment.

No inference, causal effect, or design-based confidence interval is claimed by these indexed descriptive figures. Sampling uncertainty, population composition and classification differences matter.

Visual update 2026-11-25: Q5 dark red and thicker; other quintiles grey. Missing values remain missing.
