"""Rebuild current monthly graph aggregates using only the bundled public inputs."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parent
S=R/'site/assets/research/korea-ai-exposure-employment'
link=pd.read_csv(R/'inputs/strict_quintile_linkage.csv')
den=pd.read_csv(R/'inputs/baseline_denominators.csv').set_index(['age','sex'])
manifest=json.loads((S/'data/monthly-occupations/manifest.json').read_text())
byid={r['id']:r for r in manifest};months=pd.period_range('2022-01','2026-10',freq='M').astype(str).tolist()
rows=[]
for row in link[link.quintile.notna()].itertuples():
    if not byid[row.id]['cross_end']:continue
    for time,age,sex,old_index,n in json.loads((S/f'data/monthly-occupations/{row.id}.json').read_text()):
        if time in months and sex in ['Male','Female']:
            rows.append(dict(occupation=row.id,age=age,sex=sex,time=time,n=n,q=int(row.quintile)))
d=pd.DataFrame(rows);assert not d.duplicated(['occupation','age','sex','time']).any()
reference=json.loads((S/'data/monthly-quintile-sex.json').read_text())
rebuilt=[];coverage=[]
for age in [x['id'] for x in reference['ages']]:
    a=d[d.age.eq(age)].copy();eligible=[]
    for code,g in a.groupby('occupation'):
        base=g[g.time.eq('2022-11')]
        if len(g)==116 and g.time.nunique()==58 and g.n.notna().all() and len(base)==2 and base.n.gt(0).all():eligible.append(code)
    a=a[a.occupation.isin(eligible)]
    for sex in ['Male','Female']:
        base=a[a.sex.eq(sex)&a.time.eq('2022-11')].n.sum()
        coverage.append(dict(age=age,sex=sex,occupations=len(eligible),coverage=100*base/den.loc[(age,sex),'ordinary_source']))
    for group in ['Q1','Q2','Q3','Q4','Q5','All']:
        g=a if group=='All' else a[a.q.eq(int(group[-1]))]
        if g.empty:continue
        base=g[g.time.eq('2022-11')].pivot(index='occupation',columns='sex',values='n')
        weights=base.sum(axis=1)/base.to_numpy().sum()
        for (time,sex),part in g.groupby(['time','sex']):
            n=part.set_index('occupation').n
            rebuilt.append(dict(age=age,group=group,time=time,sex=sex,employment=float(n.sum()),
                                index=100*n.sum()/base[sex].sum(),standardized_index=100*(weights*n/base[sex]).sum()))
a=pd.DataFrame(rebuilt);b=pd.DataFrame(reference['rows']);keys=['age','group','sex','time']
a=a.sort_values(keys).reset_index(drop=True);b=b.sort_values(keys).reset_index(drop=True)
assert a[keys].equals(b[keys])
errors={c:float(abs(a[c]-b[c]).max()) for c in ['employment','index','standardized_index']}
assert all(v<1e-9 for v in errors.values())
assert np.allclose(a[a.time.eq('2022-11')][['index','standardized_index']],100)
for row in coverage:
    published=next(x for x in reference['ages'] if x['id']==row['age'])
    assert round(row['coverage'],2)==published['coverage'][row['sex']]
O=R/'outputs';O.mkdir(exist_ok=True)
a.to_csv(O/'rebuilt_monthly_quintile_sex.csv',index=False)
(O/'REBUILD_VALIDATION.json').write_text(json.dumps(dict(passed=True,rows=len(a),maximum_errors=errors,no_raw_person_records=True),indent=2))
print('PASS. Rebuilt',len(a),'observed and standardized graph rows from public occupation counts.')
