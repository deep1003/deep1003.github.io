"""Build Korean-only aggregate trend evidence and accessible static figure assets."""
from pathlib import Path
import pandas as pd
import numpy as np
import json,zipfile,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent;R=O.parents[1];SITE=R/'deep1003.github.io/assets/research/korea-ai-exposure-employment'
for p in [SITE,SITE/'data',SITE/'figures',SITE/'downloads']:p.mkdir(parents=True,exist_ok=True)
A=['22–25','26–30','31–34','35–40','41–49','50+'];COL=['#0072B2','#E69F00','#009E73','#CC79A7','#D55E00','#6b7280']
d=pd.read_csv(O/'employment_cells.csv');assert d.ym.nunique()==12
labels=pd.read_csv(R/'AI_Graduate_Employment_20261114/appendix_web_release_20261116/audit/occupation_labels.csv').set_index('occ')
indnames=pd.read_csv(R/'AI_Graduate_Employment_20261114/industry_unit_analysis_20261117/youth_industry_contributions_named.csv').set_index('industry2').industry_name.dropna().to_dict()
indnames.update({64:'금융업',62:'컴퓨터 프로그래밍, 시스템 통합 및 관리업',63:'정보서비스업'})
scores=pd.read_csv(O.parent/'29_youth_employment_quintiles_20261124/occupation_scores.csv').set_index('occ')
b=d[d.year.eq(2022)].copy();b['score_mass']=b.employment*b.occ.map(scores.THAIE)
ir=b[b.q_THAIE.notna()].groupby('industry2').agg(emp=('employment','sum'),mass=('score_mass','sum'));ir.emp/=2;ir['THAIE']=ir.mass/(ir.emp*2)
ir=ir[ir.emp.ge(150000)].sort_values('THAIE',ascending=False);ir['name']=ir.index.map(lambda x:indnames.get(x,f'KSIC {x:02d}'));ir.to_csv(O/'industry_baseline_ranking.csv')
industries=ir.head(6).index.astype(int).tolist()
if 62 not in industries:industries.append(62)
# Software services is a prespecified sector of substantive interest, not selected by outcomes.
if 62 not in ir.index:
 t=b[b.industry2.eq(62)&b.q_THAIE.notna()];ir.loc[62,['emp','mass','THAIE','name']]=[t.employment.sum()/2,t.score_mass.sum(),t.score_mass.sum()/t.employment.sum(),indnames[62]]
# Representative occupations selected by fixed 2022 national employment and THAIE, plus broader software group.
ob=b.groupby('occ').employment.sum()/2;eligible=ob[ob.ge(100000)].index.intersection(scores.index)
occs=[222]+[int(x) for x in scores.loc[eligible].sort_values('THAIE',ascending=False).head(6).index if x!=222];occs=occs[:7]
rows=[]
def expanded(x):
 y=x.copy();y['sex']=y.sex.map({1:'Male',2:'Female'});z=pd.concat([y,y.assign(sex='All')]);return pd.concat([z,z.assign(agegroup='All')])
def agg(x,kind,scope):
 x=expanded(x)
 keys=['ym','year','agegroup','sex']+(['q_THAIE'] if kind=='exposure' else [])
 a=x.groupby(keys,dropna=False,as_index=False)[['employment','records']].sum()
 if kind=='exposure':a=a[a.q_THAIE.notna()];a['line']='Q'+a.q_THAIE.astype(int).astype(str)
 else:a['line']=a.agegroup
 a['kind']=kind;a['scope']=str(scope);rows.append(a.drop(columns='q_THAIE',errors='ignore'))
agg(d,'exposure','All')
for i in industries:agg(d[d.industry2.eq(i)],'exposure',f'industry_{i}');agg(d[d.industry2.eq(i)],'industry',i)
for o in occs:agg(d[d.occ.eq(o)],'occupation',o)
w=pd.concat(rows,ignore_index=True)
keys=['kind','scope','agegroup','sex','line']
# Complete time grids. Zero sample observations remain unsupported rather than a population zero.
frames=[]
for k,g in w.groupby(keys,dropna=False):
 z=g.set_index('ym').reindex(sorted(d.ym.unique()));z['year']=z.index//100;z[['employment','records']]=z[['employment','records']].fillna(0)
 for col,val in zip(keys,k):z[col]=val
 z.index.name='ym';frames.append(z.reset_index())
w=pd.concat(frames,ignore_index=True);w['frequency']='wave';w['time']=w.ym.astype(int).astype(str).str[:4]+'-'+w.ym.astype(int).astype(str).str[4:]
w['min_records']=w.records
annual=w.groupby(keys+['year'],as_index=False).agg(employment=('employment','mean'),records=('records','sum'),min_records=('records','min'),waves=('ym','nunique'))
assert annual.waves.eq(2).all();annual['frequency']='annual';annual['time']=annual.year.astype(str)
allres=pd.concat([w,annual],ignore_index=True)
base=annual[annual.year.eq(2022)][keys+['employment','min_records']].rename(columns={'employment':'base2022','min_records':'base_min_records'})
allres=allres.merge(base,on=keys,how='left',validate='many_to_one');allres['supported']=allres.min_records.ge(30)&allres.base_min_records.ge(30)&allres.base2022.gt(0)
allres['index']=np.where(allres.supported,allres.employment/allres.base2022*100,np.nan)
allres.to_csv(O/'indices_local.csv',index=False)
# Publish aggregate series only; no unsupported estimates or small-cell counts are exported.
pub=allres[keys+['frequency','time','index','supported']].copy();pub['employment']=allres.employment.where(allres.supported);pub['records']=allres.records.where(allres.supported);pub['min_records']=allres.min_records.where(allres.supported)
pub.to_csv(SITE/'downloads/res-employment-indices.csv',index=False)
coverage=d.assign(matched=d.employment.where(d.q_THAIE.notna(),0)).groupby('ym').agg(total=('employment','sum'),matched=('matched','sum'));coverage['coverage_pct']=coverage.matched/coverage.total*100;coverage.to_csv(SITE/'downloads/score-coverage.csv')
# Independent monthly survey, no THAIE imputation from broad occupation codes.
monthly=[];audit=[]
for archive in sorted((O/'raw').glob('*데이터.zip')):
 with zipfile.ZipFile(archive) as z:
  for n in z.namelist():
   if not n.endswith('.csv'):continue
   x=pd.read_csv(z.open(n),encoding='cp949');year=int(str(n)[:4]);assert len(x.columns)==7
   x=x.rename(columns={'성별코드':'sex','조사연월':'ym','만연령':'age','가중값':'weight','경제활동상태코드':'lfs'})
   assert x.ym.nunique()==12
   x['weight']=x.weight/1000;x=x[x.age.ge(15)&x.sex.isin([1,2])&x.lfs.isin([1,2,3])&x.weight.gt(0)].copy()
   x['agegroup']=np.select([x.age.between(22,25),x.age.between(26,30),x.age.between(31,34),x.age.between(35,40),x.age.between(41,49),x.age.ge(50)],A,default='15–21')
   x['employment']=x.weight*x.lfs.eq(1);x['unemployment']=x.weight*x.lfs.eq(2);x['nonparticipation']=x.weight*x.lfs.eq(3);x['records']=1
   x=expanded(x)
   a=x.groupby(['ym','agegroup','sex'],as_index=False).agg(employment=('employment','sum'),population=('weight','sum'),unemployment=('unemployment','sum'),nonparticipation=('nonparticipation','sum'),records=('records','sum'))
   monthly.append(a);audit.append({'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'member_year':year,'rows':len(x)//4,'months':12})
m=pd.concat(monthly,ignore_index=True);assert m.ym.nunique()==72;assert np.allclose(m.population,m.employment+m.unemployment+m.nonparticipation)
m['year']=m.ym//100;m['frequency']='monthly';m['time']=m.ym.astype(str).str[:4]+'-'+m.ym.astype(str).str[4:]
ma=m.groupby(['agegroup','sex','year'],as_index=False)[['employment','population','records']].mean();ma['frequency']='annual';ma['time']=ma.year.astype(str)
mb=ma[ma.year.eq(2022)][['agegroup','sex','employment']].rename(columns={'employment':'base2022'})
m=pd.concat([m,ma],ignore_index=True).merge(mb,on=['agegroup','sex'],validate='many_to_one');m['index']=100*m.employment/m.base2022;m['employment_rate']=100*m.employment/m.population
m.to_csv(SITE/'downloads/monthly-age-sex-context.csv',index=False);(O/'MONTHLY_SOURCE_AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
meta={'ages':A,'industries':[{'id':str(i),'name':indnames.get(i,f'KSIC {i:02d}'),'score':float(ir.loc[i,'THAIE'])} for i in industries],'occupations':[{'id':str(o),'name':labels.loc[o,'source_name_ko'],'en':labels.loc[o,'name_en'],'score':float(scores.loc[o,'THAIE']),'quintile':int(d.loc[d.occ.eq(o),'q_THAIE'].iloc[0])} for o in occs],'coverage_min':float(coverage.coverage_pct.min()),'coverage_max':float(coverage.coverage_pct.max()),'monthly_source':'MDIS EAPS annual2 DOI 10.23333/PN.50149167.V3.9','baseline':'2022 mean, April and October for RES; twelve months for EAPS','quintiles':'Existing 2019–2021 national employment-weighted occupational quintiles, fixed GPT-5 2025 THAIE','stanford_data_used':False}
(SITE/'data/meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
pub.round({'index':6,'employment':3}).to_json(SITE/'data/res.json',orient='records',force_ascii=False)
m[['agegroup','sex','frequency','time','index','employment','employment_rate']].round(6).to_json(SITE/'data/monthly.json',orient='records',force_ascii=False)
# Paper figures, in English for consistent typography; native vectors for export.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
def save(fig,name):
 fig.savefig(SITE/'figures'/f'{name}.png',dpi=200,bbox_inches='tight');fig.savefig(SITE/'figures'/f'{name}.pdf',bbox_inches='tight');plt.close(fig)
def lines(ax,g,col,order,colors=COL):
 for c,clr in zip(order,colors):
  z=g[g[col].eq(c)].sort_values('time');ax.plot(z.time.astype(float),z['index'],marker='o',color=clr,label=c,lw=1.8)
 ax.axhline(100,color='#888',lw=.8,ls=':');ax.axvline(2022,color='#aaa',lw=.8,ls='--');ax.set_xticks(range(2020,2026));ax.grid(axis='y',alpha=.2);ax.set_ylabel('Employment index (2022 = 100)')
g=pub[(pub.frequency=='annual')&(pub.sex=='All')]
f,ax=plt.subplots(figsize=(10,5));lines(ax,g[(g.kind=='occupation')&(g.scope=='222')&(g.agegroup.isin(A))],'agegroup',A);ax.set_title('Korea: computer systems and software professionals (KSCO 222)');ax.legend(ncol=3,frameon=False);f.tight_layout();save(f,'01-software-age')
f,axs=plt.subplots(2,3,figsize=(14,8),sharex=True,sharey=True)
for ax,a in zip(axs.flat,A):
 lines(ax,g[(g.kind=='exposure')&(g.scope=='All')&(g.agegroup==a)],'line',[f'Q{i}' for i in range(1,6)]);ax.set_title(f'Ages {a}')
axs.flat[0].legend(frameon=False,ncol=3);f.suptitle('Korea: fixed occupational THAIE quintiles within age groups');f.tight_layout();save(f,'02-age-exposure')
f,axs=plt.subplots(2,3,figsize=(14,8),sharex=True,sharey=True)
for ax,a in zip(axs.flat,A):
 z=pub[(pub.frequency=='annual')&(pub.kind=='exposure')&(pub.scope=='All')&(pub.agegroup==a)&pub.line.eq('Q5')&pub.sex.isin(['Male','Female'])];lines(ax,z,'sex',['Male','Female']);ax.set_title(f'Ages {a}, THAIE Q5')
axs.flat[0].legend(frameon=False);f.suptitle('Korea: sex-specific employment in the highest THAIE quintile');f.tight_layout();save(f,'03-gender-q5')
f,ax=plt.subplots(figsize=(10,5));lines(ax,g[(g.kind=='exposure')&(g.scope=='All')&(g.agegroup=='All')],'line',[f'Q{i}' for i in range(1,6)]);ax.set_title('Korea: all ages 15+, fixed occupational THAIE quintiles');ax.legend(frameon=False,ncol=5);f.tight_layout();save(f,'04-overall-exposure')
sw=g[(g.kind=='occupation')&(g.scope=='222')&(g.time=='2025')&(g.agegroup.isin(A))];sw.to_csv(SITE/'downloads/software-age-2025.csv',index=False)
validation={'res_waves':12,'res_years':6,'monthly_months':72,'monthly_years':6,'stanford_inputs':0,'small_cell_min_records_each_RES_wave':30,'baseline_2022_supported_indices_max_deviation':float(abs(pub[(pub.frequency=='annual')&pub.time.eq('2022')&pub.supported]['index']-100).max()),'monthly_2022_average_index_max_deviation':float(abs(m[(m.frequency=='monthly')&m.year.eq(2022)].groupby(['agegroup','sex'])['index'].mean()-100).max()),'population_identity':'PASS','protected_existing_files':'No manuscript or existing numerical result edited','software_scope':'KSCO222 broader than software developers','monthly_exposure':'Not identifiable from public broad occupational codes; not imputed','survey_design_CI':'Not estimated, design variables not available; no nominal significance assigned'}
(O/'VALIDATION.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2));(SITE/'downloads/validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2))
print(json.dumps(meta,ensure_ascii=False,indent=2));print(sw[['agegroup','index','min_records']].to_string(index=False));print(validation)
