"""Aggregate exact requested ages from RES. No microdata exported."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
import numpy as np
import json,hashlib
O=Path(__file__).resolve().parent;R=O.parents[1]
files=sorted((R/'AI_Graduate_Employment_20261114').glob('mdis_regional_B_H*_2013_2025/[0-9]*/*raw.csv'))
files=[p for p in files if int(p.parent.name)>=2020]
q=pd.read_csv(O.parent/'29_youth_employment_quintiles_20261124/quintile_assignment.csv')
q=q.pivot(index='occ',columns='method',values='quintile').rename(columns={'E':'q_E','THAIE':'q_THAIE','inverse60':'q_TIME'})
def read(p):
 h=pd.read_csv(p,encoding='cp949',nrows=0).columns
 def one(words):
  v=[c for c in h if all(w in c for w in words)];assert len(v)==1,v;return v[0]
 cols={'ym':'조사연월','age':'만연령','sex':one(['성별']),'lfs':next(c for c in h if '경제활동인구상태' in c or '경제활동구분' in c),'weight':next(c for c in h if c in ['시도전국가중값','시도가중값']),'occ':one(['8차','직업소분류']),'industry':one(['산업소분류'])}
 d=pd.read_csv(p,encoding='cp949',usecols=list(cols.values())).rename(columns={v:k for k,v in cols.items()}).apply(pd.to_numeric,errors='coerce')
 d=d[d.age.ge(15)&d.sex.isin([1,2])&d.lfs.eq(1)&d.weight.gt(0)].copy()
 d['agegroup']=np.select([d.age.between(22,25),d.age.between(26,30),d.age.between(31,34),d.age.between(35,40),d.age.between(41,49),d.age.ge(50)],['22–25','26–30','31–34','35–40','41–49','50+'],default='15–21')
 d['industry2']=(d.industry//10).fillna(-1).astype(int)
 a=d.groupby(['ym','agegroup','sex','occ','industry2'],dropna=False).agg(employment=('weight','sum'),records=('weight','size')).reset_index()
 print(p.parent.name,int(d.ym.iloc[0]),len(d),flush=True)
 return a,{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'columns':cols,'employed':float(d.weight.sum())}
with ThreadPoolExecutor(max_workers=3) as pool:r=list(pool.map(read,files))
a=pd.concat([x[0] for x in r],ignore_index=True).merge(q,on='occ',how='left');a['year']=a.ym.astype(int)//100
assert len(files)==12
# Keep original cells locally; publish only supported aggregated series later.
a.to_csv(O/'employment_cells.csv',index=False)
(O/'SOURCE_AUDIT.json').write_text(json.dumps([x[1] for x in r],ensure_ascii=False,indent=2))
print('PASS',len(a))
