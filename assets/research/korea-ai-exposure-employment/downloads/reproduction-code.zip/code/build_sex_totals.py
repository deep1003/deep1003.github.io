from pathlib import Path
import pandas as pd,json
R=Path(__file__).resolve().parent;H=R.parent;S=R/'publish/assets/research/korea-ai-exposure-employment';d=pd.read_csv(H/'34_korea_canaries_20261125/employment_cells.csv');d=d[d.q_THAIE.notna()].copy();d['sex']=d.sex.map({1:'Male',2:'Female'});d=pd.concat([d,d.assign(agegroup='All')]);meta=json.load(open(S/'data/meta.json'));rows=[]
for scope,subset in [('All',d)]+[('industry_'+x['id'],d[d.industry2.eq(int(x['id']))]) for x in meta['industries']]:
 for (age,sex),g in subset.groupby(['agegroup','sex']):
  wave=g.groupby('ym').agg(employment=('employment','sum'),records=('records','sum')).reindex(sorted(d.ym.unique()));wave['year']=wave.index//100
  annual=wave.groupby('year').agg(employment=('employment','mean'),min_records=('records','min'),waves=('records','count'));annual.loc[annual.waves.ne(2),'min_records']=0
  base=annual.loc[2022];validbase=base.min_records>=30 and base.employment>0
  for ym,r in wave.iterrows():
   okay=validbase and pd.notna(r.records) and r.records>=30;rows.append({'scope':scope,'agegroup':age,'sex':sex,'frequency':'wave','time':str(ym)[:4]+'-'+str(ym)[4:],'index':round(100*r.employment/base.employment,6) if okay else None,'employment':float(r.employment) if okay else None})
  for yr,r in annual.iterrows():
   okay=validbase and r.min_records>=30;rows.append({'scope':scope,'agegroup':age,'sex':sex,'frequency':'annual','time':str(yr),'index':round(100*r.employment/base.employment,6) if okay else None,'employment':float(r.employment) if okay else None})
(S/'data/gender-totals.json').write_text(json.dumps(rows,ensure_ascii=False,separators=(',',':')))
print('All scored occupation aggregates built',len(rows))
