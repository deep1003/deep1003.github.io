from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt,matplotlib.patheffects as pe
from matplotlib.backends.backend_pdf import PdfPages
R=Path(__file__).resolve().parent;S=R.parent/'37_korea_monthly_panels_20261125/publish/assets/research/korea-ai-exposure-employment';O=S/'figures';O.mkdir(exist_ok=True)
d=pd.read_json(S/'data/res.json');d=d[(d.kind=='exposure')&d.scope.eq('All')&d.frequency.eq('wave')&d.sex.isin(['Male','Female'])];t=pd.read_json(S/'data/gender-totals.json');t=t[t.scope.eq('All')&t.frequency.eq('wave')&t.sex.isin(['Male','Female'])];t['line']='ALL';d=pd.concat([d,t],ignore_index=True);d['x']=d.time.str[:4].astype(int)+(d.time.str[5:7].astype(int)-1)/12
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6,'pdf.fonttype':42,'savefig.facecolor':'white'})
col={'Male':'#C64F5A','Female':'#577C96'};titles=['Quintile 1 (least exposed)','Quintile 2','Quintile 3','Quintile 4','Quintile 5 (most exposed)','All scored occupations'];ages=['22–25','26–30','31–34','35–40','41–49','50+','All']
with PdfPages(O/'sex-by-quintile-all-ages.pdf') as bundle:
 for age in ages:
  z=d[d.agegroup.eq(age)].copy();valid=z['index'].dropna();lo=np.floor((min(100,valid.min())-4)/5)*5;hi=np.ceil((max(100,valid.max())+4)/5)*5
  f,axs=plt.subplots(2,3,figsize=(13.4,8.3),sharex=True,sharey=True);f.subplots_adjust(left=.065,right=.98,top=.81,bottom=.16,wspace=.23,hspace=.27)
  for j,(ax,q,title) in enumerate(zip(axs.flat,['Q1','Q2','Q3','Q4','Q5','ALL'],titles)):
   g=z[z.line.eq(q)].sort_values('x');ax.set_title(title,fontsize=12,fontweight='bold',pad=12);last=[]
   m=g[g.sex.eq('Male')].set_index('time');w=g[g.sex.eq('Female')].set_index('time');ix=m.index.union(w.index).sort_values();paired=pd.DataFrame({'x':pd.to_datetime(ix).year+(pd.to_datetime(ix).month-1)/12,'m':m['index'].reindex(ix),'w':w['index'].reindex(ix)});ax.fill_between(paired.x.to_numpy(float),paired.m.to_numpy(float),paired.w.to_numpy(float),color='#71818b',alpha=.12,linewidth=0)
   for sex,label in [('Male','Men'),('Female','Women')]:
    a=g[g.sex.eq(sex)];ax.plot(a.x,a['index'],color=col[sex],lw=2.0,marker='o',ms=2.3,path_effects=[pe.Stroke(linewidth=3.0,foreground='white'),pe.Normal()],zorder=3);a=a[a['index'].notna()]
    if len(a):r=a.iloc[-1];last.append({'y':r['index'],'real':r['index'],'x':r.x,'label':label,'color':col[sex]})
   gap=(hi-lo)*.055;last.sort(key=lambda r:r['y'])
   if len(last)==2 and last[1]['y']-last[0]['y']<gap:
    mid=sum(x['y'] for x in last)/2;last[0]['y']=mid-gap/2;last[1]['y']=mid+gap/2
   for a in last:ax.annotate(a['label'],xy=(a['x'],a['real']),xytext=(2025.93,a['y']),color=a['color'],fontsize=10,fontweight='bold',va='center',arrowprops={'arrowstyle':'-','color':a['color'],'lw':.6} if abs(a['y']-a['real'])>.01 else None)
   event=2022+10/12;ax.axvline(event,color='#8a9296',ls=(0,(2,2)),lw=.75,zorder=0);ax.axhline(100,color='#abb4b9',ls=(0,(3,3)),lw=.7,zorder=0);ax.text(event-.045,hi-(hi-lo)*.025,'Nov 2022',rotation=90,va='top',ha='right',fontsize=7.5,color='#65727a');ax.grid(axis='y',color='#e7ebed',lw=.6);ax.set_ylim(lo,hi);ax.set_xlim(2020,2026.8);months=sorted(d.time.unique());ticks=[int(a[:4])+(int(a[5:])-1)/12 for a in months];ax.set_xticks(ticks);ax.set_xticklabels([a.replace('-','.') for a in months],rotation=55,ha='right',fontsize=7);ax.tick_params(length=0,labelsize=7,pad=6);ax.spines['left'].set_color('#d8dfe3');ax.spines['bottom'].set_color('#d8dfe3')
   if j%3==0:ax.set_ylabel('Employment index (2022 mean = 100)',fontsize=9)
  age_text='All ages 15+' if age=='All' else 'Ages '+age;f.text(.065,.965,'KOREA  |  THAIE AND EMPLOYMENT',fontsize=10,color='#6b7c87',weight='bold');f.text(.065,.92,'Women and men within each exposure quintile',fontsize=19,weight='bold',color='#263c49');f.text(.065,.885,age_text+' · Actual April / October observations · Separate 2022 baselines',fontsize=11,color='#526875');f.text(.065,.057,'Source: Regional Employment Survey, 2020–2025, own THAIE linkage. Grey shading shows the index gap, not uncertainty.',fontsize=8.5,color='#61727d');f.text(.065,.032,'The total covers scored occupations. Missing or small-sample cells remain unplotted. Monthly observations are not inferred.',fontsize=8.5,color='#61727d')
  slug=age.replace('–','-').replace('+','plus').lower();f.savefig(O/f'sex-by-quintile-{slug}.png',dpi=200);f.savefig(O/f'sex-by-quintile-{slug}.pdf');bundle.savefig(f);plt.close(f)
print('Built seven age-specific PNG/PDF figures and combined PDF; original indices unchanged.')
