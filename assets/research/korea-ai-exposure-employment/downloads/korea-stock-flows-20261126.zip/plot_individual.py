from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;d=pd.read_csv(P/'MONTHLY_PATHS.csv');labels={'age20_24':['Computer systems specialists','Accounting clerks','Legal professionals'],'age25_29':['Business and HR specialists','Accounting clerks','Finance and insurance sales']}
for age in labels:
 fig,axs=plt.subplots(3,2,figsize=(12,9),sharex=True)
 for i,group in enumerate(['top1','top2','top3']):
  for j,(outcome,label) in enumerate([('acquisition_rate','Acquisitions'),('separation_rate','Separations')]):
   ax=axs[i,j]
   for tr,col,name in [(1,'#C64F5A' if age=='age20_24' else '#577C96','Selected occupation'),(0,'#B6BCC1','Q1–Q4')]:
    v=d[(d.age_group==age)&(d.group==group)&d.treated.eq(tr)&d.time.ge('2022-01')];ax.plot(pd.to_datetime(v.time),v[outcome],color=col,lw=1.8,label=name)
   ax.axvline(pd.Timestamp('2022-11-01'),color='.6',ls=':',lw=1);ax.set_title(labels[age][i]+' · '+label);ax.set_ylabel('Monthly count / Nov2022 stock (%)');ax.grid(axis='y',alpha=.15);ax.spines[['top','right']].set_visible(False)
 axs[0,0].legend(fontsize=8);fig.suptitle(('Women, ages 20–24' if age=='age20_24' else 'Men, ages 25–29')+' · Individual occupations');fig.autofmt_xdate();fig.tight_layout()
 for ext in ['png','pdf']:fig.savefig(P/f'individual_flows_{age}.{ext}',dpi=200)
 plt.close(fig)
p=P/'REPORT_KO.md';s=p.read_text();s+='\n\n월별 출처와 정의는 https://eis.work24.go.kr/eisps/rpt/reptDtl.do?menuId=020020020 및 https://ei.work24.go.kr/ei/eih/st/retrieveAdOfferList.do 에서 확인했다. 연령은 해당월 말일 기준이며 직종은 취득 사업장과 상실 사업장의 취득 시 근무직종 기준으로 설명된다. 따라서 실제 과업 이동을 직접 측정한 자료로 해석하지 않는다.\n\n개별 상위 직종에서도 흐름은 동일하지 않다. 여성 컴퓨터시스템과 남성 경영인사는 기본 순취득 DID가 양수로, 이들 직종의 재고 상대변화를 단순한 취득 감소로 설명할 수 없다. 다른 상위 직종 및 잔차와 기간 기준을 함께 확인해야 한다.\n';p.write_text(s)
print('Individual paths saved; no rendered chart output')
