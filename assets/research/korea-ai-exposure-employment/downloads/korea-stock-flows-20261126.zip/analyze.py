from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,pandas as pd,json
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;H=P.parent
# Exact balanced TWFE with occupation-constant weights and full-dummy df correction.
def fit(g,ycol,weighted=False,extra=None):
 occ=sorted(g.occupation.unique());times=sorted(g.time.unique());G=len(occ);T=len(times)
 def mat(col):return g.pivot(index='occupation',columns='time',values=col).loc[occ,times].to_numpy()
 y=mat(ycol);w=g.groupby('occupation').base.first().loc[occ].to_numpy() if weighted else np.ones(G);q=g.groupby('occupation').treated.first().loc[occ].to_numpy();rel=g.groupby('time').rel.first().loc[times].to_numpy();xs=[q[:,None]*(rel>0)]
 if extra=='trend':xs.append(q[:,None]*rel)
 if extra=='covid':xs.append(q[:,None]*np.array([int('2020-03'<=x<='2021-12') for x in times]))
 if extra=='season':
  for mon in range(2,13):xs.append(q[:,None]*np.array([int(int(x[-2:])==mon) for x in times]))
 def within(v):return v-v.mean(axis=1,keepdims=True)-np.average(v,axis=0,weights=w)[None,:]+np.average(v.mean(axis=1),weights=w)
 X=np.stack([within(x) for x in xs],axis=2);Y=within(y);sw=np.sqrt(w)[:,None];X=(X*sw[:,:,None]).reshape(-1,len(xs));Y=(Y*sw).reshape(-1);bread=np.linalg.pinv(X.T@X);b=bread@X.T@Y;u=Y-X@b;scores=np.einsum('gtk,gt->gk',X.reshape(G,T,-1),u.reshape(G,T));N=G*T;K=G+T-1+np.linalg.matrix_rank(X);cov=bread@scores.T@scores@bread*(G/(G-1))*((N-1)/(N-K));se=np.sqrt(cov[0,0]);crit=t.ppf(.975,G-1)
 return dict(coefficient=b[0],se=se,ci_low=b[0]-crit*se,ci_high=b[0]+crit*se,p=2*t.sf(abs(b[0]/se),G-1),G=G,N=N,treated_occupations=int(q.sum()),treated_clusters=int(q.sum()))
results=[];decomp=[];paths=[];checks=[]
con=pd.read_csv(H/'48_korea_occupation_contributions_20261126/OCCUPATION_CONTRIBUTIONS.csv')
for age,sex in [('age20_24','Female'),('age25_29','Male')]:
 a=pd.read_csv(H/'47_korea_age_split_did_20261126'/age/'balanced_occupation_sex_month.csv');a=a[a.sex.eq(sex)].copy().sort_values(['occupation','time']);assert not a.duplicated(['occupation','time']).any();assert a[['acquisitions','separations']].notna().all().all()
 base=a[a.rel.eq(0)].set_index('occupation').n;a['base']=a.occupation.map(base)
 for col in ['acquisitions','separations']:a[col+'_rate']=100*a[col]/a.base
 a['net_rate']=a.acquisitions_rate-a.separations_rate;a['stock_change']=a.groupby('occupation').n.diff();a['residual']=a.stock_change-a.acquisitions+a.separations
 for col in ['stock_change','residual']:a[col+'_rate']=100*a[col]/a.base
 a['logn']=np.log(a.n);ranks=con[con.age_group.eq(age)].sort_values('beta_contribution').occupation.tolist();software='2025직종_소프트웨어 개발자';groups={'Q5':a[a.q5.eq(1)].occupation.unique().tolist(),'major_top3':ranks[:3],'software':[software]}
 for j,occ in enumerate(ranks[:3]):groups['top'+str(j+1)]=[occ]
 for group,treat in groups.items():
  g=a[a.q5.eq(0)|a.occupation.isin(treat)].copy();g['treated']=g.occupation.isin(treat).astype(int);b=g[g.rel.ne(0)].copy()
  for spec,weighted,extra in [('base',False,None),('weighted',True,None),('trend',False,'trend'),('covid',False,'covid'),('season',False,'season')]:
   for outcome in ['acquisitions_rate','separations_rate','net_rate','logn']:
    res=fit(b,outcome,weighted,extra);results.append(dict(age_group=age,sex=sex,group=group,specification=spec,outcome=outcome,**res))
  # Accounting on common months. First month lacks previous stock; omit from both sides for identity only.
  accounting=g[g.rel.ne(0)&g.stock_change.notna()].copy();months=sorted(accounting.time.unique());accounting=accounting[accounting.time.isin(months)]
  for outcome in ['stock_change_rate','acquisitions_rate','separations_rate','net_rate','residual_rate']:
   res=fit(accounting,outcome);decomp.append(dict(age_group=age,group=group,outcome=outcome,**res))
  sums=g.groupby(['time','rel','treated']).agg(n=('n','sum'),acquisitions=('acquisitions','sum'),separations=('separations','sum'),base=('base','sum'),residual=('residual','sum')).reset_index();sums['stock_index']=100*sums.n/sums.base;sums['acquisition_rate']=100*sums.acquisitions/sums.base;sums['separation_rate']=100*sums.separations/sums.base;sums['net_rate']=sums.acquisition_rate-sums.separation_rate;sums['age_group']=age;sums['group']=group;paths.append(sums)
 checks.append(dict(age_group=age,flow_missing=0,zero_acquisitions=int(a.acquisitions.eq(0).sum()),zero_separations=int(a.separations.eq(0).sum()),accounting_residual_abs_sum=float(a.residual.abs().sum()),stock_change_abs_sum=float(a.stock_change.abs().sum())))
r=pd.DataFrame(results);mask=r.group.eq('Q5')&r.specification.eq('base')&r.outcome.isin(['acquisitions_rate','separations_rate']);r.loc[mask,'p_holm_four_flow_tests']=multipletests(r.loc[mask,'p'],method='holm')[1];r.to_csv(P/'FLOW_DID.csv',index=False);d=pd.DataFrame(decomp);d.to_csv(P/'ACCOUNTING_DID.csv',index=False);pd.concat(paths).to_csv(P/'MONTHLY_PATHS.csv',index=False)
for keys,v in d.groupby(['age_group','group']):
 x=v.set_index('outcome').coefficient;assert abs(x.stock_change_rate-(x.net_rate+x.residual_rate))<1e-9
(P/'CHECKS.json').write_text(json.dumps(checks,indent=2));print(r[(r.specification=='base')&r.group.isin(['Q5','major_top3','software'])][['age_group','group','outcome','coefficient','ci_low','ci_high','p','p_holm_four_flow_tests']].to_string(index=False));print(checks)
# Raw monthly paths, no interpolation, rates relative to fixed November2022 stock.
paths=pd.concat(paths)
for age,title in [('age20_24','Women, ages 20–24'),('age25_29','Men, ages 25–29')]:
 fig,axs=plt.subplots(3,2,figsize=(12,9),sharex=True)
 for i,group in enumerate(['Q5','major_top3','software']):
  for j,(outcome,label) in enumerate([('acquisition_rate','Acquisitions'),('separation_rate','Separations')]):
   ax=axs[i,j]
   for tr,col,ls,name in [(1,'#C64F5A' if age=='age20_24' else '#577C96','-','Selected occupations'),(0,'#B6BCC1','--','Q1–Q4')]:
    v=paths[(paths.age_group==age)&(paths.group==group)&paths.treated.eq(tr)&paths.time.ge('2022-01')];ax.plot(pd.to_datetime(v.time),v[outcome],color=col,lw=1.8,ls=ls,label=name)
   ax.axvline(pd.Timestamp('2022-11-01'),color='.6',ls=':',lw=1);ax.set_title({'Q5':'All Q5','major_top3':'Three main contributing occupations','software':'Software developers'}[group]+' · '+label);ax.set_ylabel('Monthly count / Nov2022 stock (%)');ax.grid(axis='y',alpha=.15);ax.spines[['top','right']].set_visible(False)
 axs[0,0].legend(fontsize=8);fig.suptitle(title+' · Actual observed monthly flows');fig.autofmt_xdate();fig.tight_layout();fig.savefig(P/f'flows_{age}.png',dpi=200);fig.savefig(P/f'flows_{age}.pdf');plt.close(fig)
