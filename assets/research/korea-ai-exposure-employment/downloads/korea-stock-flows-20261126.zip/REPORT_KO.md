# 취득·상실 흐름과 Q5 청년 고용의 상대적 변화

2026년 11월 26일. 홈페이지·원고 변경 없음.

## 설계

고정 105개 직종, 사전 2019년 11월–2022년 10월과 사후 2022년 12월–2025년 11월 각 36개월, 전환월 제외를 유지했다. 취득·상실에는 실제 0이 있어 로그를 취하거나 결측으로 바꾸지 않았다. 월별 흐름을 각 직종·집단의 고정 2022년 11월 피보험자 수 100명당 건수로 정규화했다. 당월 고용을 분모로 쓰지 않아 감소에 따른 분모 효과를 피했다. 기본 명세는 직종·월 고정효과, 직종 동일가중, 직종 군집 표준오차와 G−1 자유도 양측 검정이다. 단위는 월별 기준인원 100명당 건수의 차이이며 로그 고용 DID의 감소율과 다르다.

## Q5 기본 결과

| age_group   | outcome           |   coefficient |   ci_low |   ci_high |      p |   p_holm_four_flow_tests |
|:------------|:------------------|--------------:|---------:|----------:|-------:|-------------------------:|
| age20_24    | acquisitions_rate |       -1.8434 |  -3.1271 |   -0.5596 | 0.0053 |                   0.0170 |
| age20_24    | separations_rate  |       -0.6163 |  -1.7126 |    0.4800 | 0.2675 |                   0.2675 |
| age20_24    | net_rate          |       -1.2270 |  -1.9578 |   -0.4962 | 0.0012 |                 nan      |
| age25_29    | acquisitions_rate |       -1.0669 |  -1.7904 |   -0.3433 | 0.0042 |                   0.0170 |
| age25_29    | separations_rate  |       -0.4581 |  -0.9734 |    0.0572 | 0.0809 |                   0.1617 |
| age25_29    | net_rate          |       -0.6088 |  -1.0263 |   -0.1912 | 0.0047 |                 nan      |

두 집단 모두 취득 감소가 관측되고, 상실 증가는 관측되지 않았다. 상실 역시 감소 방향이어서 순취득 감소를 일부 상쇄한다. 네 기본 취득·상실 검정을 Holm 보정한 후에도 취득 감소는 유의하다. 순취득은 취득−상실로 정확히 가산적이다.

## 사전 추세

| age_group   | outcome      |   pre_F |   pre_p |
|:------------|:-------------|--------:|--------:|
| age20_24    | acquisitions |  0.4510 |  0.8117 |
| age20_24    | separations  |  0.9017 |  0.4830 |
| age25_29    | acquisitions |  0.4466 |  0.8149 |
| age25_29    | separations  |  1.1983 |  0.3152 |

사전 계수 검정의 유의성은 아래 결론의 중요한 제약이다. 비유의도 평행추세 증명은 아니다.

## 명세 민감도

| age_group   | specification   | outcome           |   coefficient |      p |
|:------------|:----------------|:------------------|--------------:|-------:|
| age20_24    | base            | acquisitions_rate |       -1.8434 | 0.0053 |
| age20_24    | base            | separations_rate  |       -0.6163 | 0.2675 |
| age20_24    | base            | net_rate          |       -1.2270 | 0.0012 |
| age20_24    | weighted        | acquisitions_rate |       -2.9671 | 0.0009 |
| age20_24    | weighted        | separations_rate  |       -1.9712 | 0.0220 |
| age20_24    | weighted        | net_rate          |       -0.9959 | 0.0002 |
| age20_24    | trend           | acquisitions_rate |       -1.8087 | 0.0201 |
| age20_24    | trend           | separations_rate  |       -0.5289 | 0.3489 |
| age20_24    | trend           | net_rate          |       -1.2797 | 0.0441 |
| age20_24    | covid           | acquisitions_rate |       -2.0243 | 0.0027 |
| age20_24    | covid           | separations_rate  |       -0.6669 | 0.1995 |
| age20_24    | covid           | net_rate          |       -1.3574 | 0.0027 |
| age20_24    | season          | acquisitions_rate |       -1.8434 | 0.0053 |
| age20_24    | season          | separations_rate  |       -0.6163 | 0.2678 |
| age20_24    | season          | net_rate          |       -1.2270 | 0.0012 |
| age25_29    | base            | acquisitions_rate |       -1.0669 | 0.0042 |
| age25_29    | base            | separations_rate  |       -0.4581 | 0.0809 |
| age25_29    | base            | net_rate          |       -0.6088 | 0.0047 |
| age25_29    | weighted        | acquisitions_rate |       -1.1297 | 0.0005 |
| age25_29    | weighted        | separations_rate  |       -0.4510 | 0.1866 |
| age25_29    | weighted        | net_rate          |       -0.6787 | 0.0020 |
| age25_29    | trend           | acquisitions_rate |       -1.5475 | 0.0016 |
| age25_29    | trend           | separations_rate  |       -0.8029 | 0.0002 |
| age25_29    | trend           | net_rate          |       -0.7447 | 0.0569 |
| age25_29    | covid           | acquisitions_rate |       -1.0930 | 0.0046 |
| age25_29    | covid           | separations_rate  |       -0.3799 | 0.1618 |
| age25_29    | covid           | net_rate          |       -0.7132 | 0.0091 |
| age25_29    | season          | acquisitions_rate |       -1.0669 | 0.0043 |
| age25_29    | season          | separations_rate  |       -0.4581 | 0.0811 |
| age25_29    | season          | net_rate          |       -0.6088 | 0.0047 |

두 집단의 취득 감소는 고용규모 가중, 차등 선형추세, 코로나기간, 차등 월별 계절성 명세에서 원 p<0.05로 유지됐다. 그러나 추세는 사후 자료도 사용하며 각 민감도 검정 전체의 다중검정은 보정하지 않았다.

## 주요 직종과 소프트웨어 개발자

| age_group   | group      | outcome           |   coefficient | inference_note                                                                |
|:------------|:-----------|:------------------|--------------:|:------------------------------------------------------------------------------|
| age20_24    | major_top3 | acquisitions_rate |       -2.5356 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | major_top3 | separations_rate  |       -2.1439 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | major_top3 | net_rate          |       -0.3917 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | software   | acquisitions_rate |       -1.2932 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | software   | separations_rate  |        0.9636 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | software   | net_rate          |       -2.2568 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | top1       | acquisitions_rate |       -3.1158 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | top1       | separations_rate  |       -3.4187 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | top1       | net_rate          |        0.3029 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | top2       | acquisitions_rate |       -1.9934 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | top2       | separations_rate  |       -0.8740 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | top2       | net_rate          |       -1.1194 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | top3       | acquisitions_rate |       -2.4977 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | top3       | separations_rate  |       -2.1390 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age20_24    | top3       | net_rate          |       -0.3587 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | major_top3 | acquisitions_rate |       -1.5636 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | major_top3 | separations_rate  |       -1.0298 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | major_top3 | net_rate          |       -0.5338 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | software   | acquisitions_rate |       -1.0083 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | software   | separations_rate  |        0.2393 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | software   | net_rate          |       -1.2476 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | top1       | acquisitions_rate |        0.3674 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | top1       | separations_rate  |       -0.1877 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | top1       | net_rate          |        0.5551 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | top2       | acquisitions_rate |       -1.5955 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | top2       | separations_rate  |       -1.1542 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | top2       | net_rate          |       -0.4413 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | top3       | acquisitions_rate |       -3.4628 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | top3       | separations_rate  |       -1.7476 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |
| age25_29    | top3       | net_rate          |       -1.7152 | Descriptive contrast only; 1–3 treated clusters, cluster inference suppressed |

major_top3는 이전 분석의 DID 기여 상위 3개 직종이다. 여성은 컴퓨터시스템·회계경리·법률 전문가, 남성은 경영인사·회계경리·금융보험 영업원이다. top1–3는 이 순서의 개별 직종이다. 소프트웨어와 각 개별 직종은 처리 직종이 하나뿐이며 major_top3도 3개뿐이므로 표준 군집 p값과 신뢰구간을 제시하지 않는다. 이 비교는 기술적 상대변화이며 통계적 인과효과를 주장하지 않는다.

## 재고·흐름 정합성

| age_group   | outcome           |   coefficient |      p |
|:------------|:------------------|--------------:|-------:|
| age20_24    | stock_change_rate |       -1.0081 | 0.0107 |
| age20_24    | acquisitions_rate |       -1.7987 | 0.0088 |
| age20_24    | separations_rate  |       -0.6133 | 0.2748 |
| age20_24    | net_rate          |       -1.1854 | 0.0021 |
| age20_24    | residual_rate     |        0.1773 | 0.3201 |
| age25_29    | stock_change_rate |       -0.7287 | 0.0177 |
| age25_29    | acquisitions_rate |       -1.0718 | 0.0046 |
| age25_29    | separations_rate  |       -0.4753 | 0.0719 |
| age25_29    | net_rate          |       -0.5965 | 0.0069 |
| age25_29    | residual_rate     |       -0.1322 | 0.4550 |

월말 피보험자 변화 = 취득−상실+잔차로 점검했다. 전월 재고가 없는 첫 사전월을 제외해 이 표만 사전 35개월·사후 36개월이다. 잔차를 포함한 항등식은 수치 오차 1e−9 이내다. 월별 잔차는 크며 CHECKS.json에 보존했다. 연령집단 이동·직종 이동·정정·보고시점 차이 등의 가능성이 있으나 항목별로 식별하지 못했다. 잔차를 모두 연령 이동으로 간주하지 않는다. 고용 변화가 취득·상실만으로 완전히 설명된다고 주장하지 않는다.

## 결론과 해석 제한

기술적으로 Q5의 상대적 순유입 약화는 상실 증가보다 취득 감소와 일치한다. 소프트웨어는 두 집단 모두 취득 감소와 상실 증가 방향의 조합이지만 개별 직종 인과효과는 검정하지 않는다. 기존 고용 DID 기여와 흐름 DID는 측정대상이 다르고, 기준월 이후 재고 감소와 전체 사전·사후 평균 비교도 구분한다.

취득은 고용보험 자격 취득이며 첫 취업·순신규채용과 같지 않다. 재취업·직장이동·가입범위 변화가 포함될 수 있다. 상실은 해고와 같지 않다. 자발적 퇴사·계약 종료·다른 일자리 이동 등이 구분되지 않는다. 실제 AI 도입, 산업 수요, 인구 변화, 코로나 회복을 분리하지 못했으므로 AI가 채용을 줄였다는 인과결론은 불가하다. 상위 직종은 이전 결과로 선택했으므로 추가 탐색 편향이 있다.

## 재현과 그래프

FLOW_DID.csv, FLOW_PRETRENDS.csv, ACCOUNTING_DID.csv, MONTHLY_PATHS.csv, CHECKS.json, analyze.py, finalize.py를 보존했다. 월별 그래프는 보간·연간평균·마커 없이 실제 관측월을 표시한다. 흐름의 기준월 값이 다르고 0이 있을 수 있어 취득·상실 각각을 100으로 만들지 않고 고정 기준월 고용 100명당 흐름을 그렸다.

월별 출처와 정의는 https://eis.work24.go.kr/eisps/rpt/reptDtl.do?menuId=020020020 및 https://ei.work24.go.kr/ei/eih/st/retrieveAdOfferList.do 에서 확인했다. 연령은 해당월 말일 기준이며 직종은 취득 사업장과 상실 사업장의 취득 시 근무직종 기준으로 설명된다. 따라서 실제 과업 이동을 직접 측정한 자료로 해석하지 않는다.

개별 상위 직종에서도 흐름은 동일하지 않다. 여성 컴퓨터시스템과 남성 경영인사는 기본 순취득 DID가 양수로, 이들 직종의 재고 상대변화를 단순한 취득 감소로 설명할 수 없다. 다른 상위 직종 및 잔차와 기간 기준을 함께 확인해야 한다.


월별 경로 그림은 각 직종군의 취득·상실 합계를 기준월 고용 합계로 나눈 규모 가중 기술통계다. 기본 DID는 직종 동일가중이므로 그림과 기본 계수의 가중 방식이 다르다. 규모 가중 DID를 FLOW_DID.csv에 함께 제공한다.
