from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import pandas as pd,numpy as np,json
import statsmodels.formula.api as smf
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
P=Path(__file__).resolve().parent
frames=[]
for age in ['age20_24','age25_29']:
 a=pd.read_csv(P/age/'balanced_occupation_sex_month.csv');a['age_group']=age;frames.append(a)
 meta=json.loads((P/age/'DESIGN_AND_CHECKS.json').read_text());meta['youth']=age;meta['missing']='Same 105 occupations as pooled analysis; both sexes and both age cells observed and strictly positive for all 73 months';(P/age/'DESIGN_AND_CHECKS.json').write_text(json.dumps(meta,indent=2))
a=pd.concat(frames);a=a[a.rel.ne(0)].copy();out=[]
# Difference of age-specific outcomes within same occupation, month, sex.
z=a.pivot(index=['occupation','time','rel','q5','post','covid','sex'],columns='age_group',values='logn').reset_index();z['gap']=z.age20_24-z.age25_29
for sex,g in z.groupby('sex'):
 for spec,extra in [('base',''),('linear_trend','+q5:rel'),('covid','+q5:covid')]:
  m=smf.ols('gap~C(occupation)+C(time)+q5:post'+extra,data=g).fit(cov_type='cluster',cov_kwds={'groups':g.occupation},use_t=True);b=m.params['q5:post'];se=m.bse['q5:post'];crit=t.ppf(.975,104)
  out.append(dict(sex=sex,specification=spec,comparison='20–24 minus 25–29',coefficient=b,relative_percent=100*np.expm1(b),percent_low=100*np.expm1(b-crit*se),percent_high=100*np.expm1(b+crit*se),p=2*t.sf(abs(b/se),104)))
r=pd.DataFrame(out);r.to_csv(P/'DIRECT_AGE_DIFFERENCES.csv',index=False)
allr=[];alle=[];allpt=[];allsex=[]
for age in ['age20_24','age25_29']:
 for name,arr in [('DID_RESULTS.csv',allr),('EVENT_STUDY.csv',alle),('PRETREND_TESTS.csv',allpt),('SEX_DIFFERENCE_SENSITIVITY.csv',allsex)]:
  x=pd.read_csv(P/age/name);x['age_group']=age;arr.append(x)
r=pd.concat(allr);mask=r.specification.eq('TWFE');r.loc[mask,'p_holm_four_age_sex_tests']=multipletests(r.loc[mask,'p'],method='holm')[1];mask=r.specification.eq('direct_sex_difference');r.loc[mask,'p_holm_two_age_sex_contrasts']=multipletests(r.loc[mask,'p'],method='holm')[1];r.to_csv(P/'DID_ALL.csv',index=False)
e=pd.concat(alle);mask=e.event_start.gt(0);e.loc[mask,'p_holm_24_post_bins']=multipletests(e.loc[mask,'p'],method='holm')[1];e.to_csv(P/'EVENT_ALL.csv',index=False)
pd.concat(allpt).to_csv(P/'PRETREND_ALL.csv',index=False);pd.concat(allsex).to_csv(P/'SEX_SENSITIVITY_ALL.csv',index=False)
print(r[['age_group','sex','specification','relative_percent','p','percent_low','percent_high']].to_string(index=False));print(pd.concat(allpt).to_string(index=False));print(pd.DataFrame(out).to_string(index=False))
