from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,pandas as pd,json
import statsmodels.formula.api as smf
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent
r=pd.read_csv(P/'DID_ALL.csv');e=pd.read_csv(P/'EVENT_ALL.csv');pt=pd.read_csv(P/'PRETREND_ALL.csv');ss=pd.read_csv(P/'SEX_SENSITIVITY_ALL.csv');ad=pd.read_csv(P/'DIRECT_AGE_DIFFERENCES.csv')
frames=[]
for age in ['age20_24','age25_29']:
 a=pd.read_csv(P/age/'balanced_occupation_sex_month.csv');a['age_group']=age;frames.append(a)
a=pd.concat(frames);assert not a.duplicated(['occupation','time','sex','age_group']).any();checks=[]
for (age,sex),g in a[a.rel.ne(0)].groupby(['age_group','sex']):
 assert len(g)==7560 and g.n.gt(0).all() and g.time.nunique()==72
 v=g.groupby(['occupation','q5','post']).logn.mean().unstack();delta=(v[1]-v[0]).groupby(level='q5').mean();beta=delta[1]-delta[0];target=r[(r.age_group==age)&(r.sex==sex)&(r.specification=='TWFE')].coefficient.iloc[0];assert abs(beta-target)<1e-10;checks.append(dict(age=age,sex=sex,twfe_identity_error=abs(beta-target)))
z=a[a.rel.ne(0)].pivot(index=['occupation','time','rel','q5','post','covid','age_group'],columns='sex',values='logn').reset_index();z['sexgap']=z.Female-z.Male
z=z.pivot(index=['occupation','time','rel','q5','post','covid'],columns='age_group',values='sexgap').reset_index();z['gap']=z.age25_29-z.age20_24
triple=[]
for spec,extra in [('base',''),('linear_trend','+q5:rel'),('covid','+q5:covid')]:
 m=smf.ols('gap~C(occupation)+C(time)+q5:post'+extra,data=z).fit(cov_type='cluster',cov_kwds={'groups':z.occupation},use_t=True);b=m.params['q5:post'];se=m.bse['q5:post'];c=t.ppf(.975,104);triple.append(dict(specification=spec,comparison='Female-minus-Male DID, age25_29 minus age20_24',coefficient=b,relative_percent=100*np.expm1(b),percent_low=100*np.expm1(b-c*se),percent_high=100*np.expm1(b+c*se),p=2*t.sf(abs(b/se),104)))
tr=pd.DataFrame(triple);tr.to_csv(P/'AGE_BY_SEX_DIFFERENCE.csv',index=False)
fig,axs=plt.subplots(2,2,figsize=(12,8),sharex=True,sharey=True)
for i,age in enumerate(['age20_24','age25_29']):
 for j,(sex,col) in enumerate([('Male','#577C96'),('Female','#C64F5A')]):
  ax=axs[i,j];d=e[(e.age_group==age)&(e.sex==sex)];ax.errorbar(d.event_mid,d.relative_percent,yerr=[d.relative_percent-d.percent_low,d.percent_high-d.relative_percent],fmt='-',capsize=3,lw=2,color=col);ax.axhline(0,color='.5',lw=.8);ax.axvline(0,color='.6',ls=':',lw=1);ax.set_title(f'{"20–24" if i==0 else "25–29"} years · {sex}');ax.grid(axis='y',alpha=.15);ax.spines[['top','right']].set_visible(False)
  if j==0:ax.set_ylabel('Q5 relative to Q1–Q4 (%)')
  if i==1:ax.set_xlabel('Months relative to November 2022')
fig.suptitle('Reference: May–October 2022 · Pointwise 95% confidence intervals');fig.tight_layout()
for ext in ['png','pdf']:fig.savefig(P/f'event_study_age_sex.{ext}',dpi=220)
plt.close(fig)
primary=r[r.specification.eq('TWFE')].copy();primary['age_group']=primary.age_group.map({'age20_24':'20–24','age25_29':'25–29'})
lines=['# 年齢別 DID・イベントスタディ'.replace('年齢別 DID・イベントスタディ','연령별 DID와 이벤트 스터디'),'','2026년 11월 26일. 홈페이지와 원고는 수정하지 않았다.','','같은 105개 직종(Q5 20개, Q1–Q4 85개)을 고정했다. 20–24세와 25–29세, 남성과 여성 각각 7,560개 관측이다. 사전 2019년 11월–2022년 10월, 사후 2022년 12월–2025년 11월 각 36개월이며 전환월은 제외했다. 84개월 중 대칭 창 72개월을 사용한다. 결측을 0으로 채우지 않았다.','','## 기본 DID','',primary[['age_group','sex','relative_percent','percent_low','percent_high','p','p_holm_four_age_sex_tests']].to_markdown(index=False,floatfmt='.4f'),'','로그 피보험자 수, 직종·월 고정효과, 직종 동일가중, 직종 군집 표준오차와 104 자유도 양측 검정이다. 변화율은 exp(β)−1이며 Q1–Q4 대비 상대적 변화다. 네 연령·성별 기본 검정을 Holm 보정하면 모두 5% 수준에서 유의하지 않다.','','## 사전 추세','',pt.to_markdown(index=False,floatfmt='.4f'),'','각 연령·성별의 사전 5개 6개월 계수 공동검정과 사전만 사용한 차등 선형추세 검정 모두 5% 수준에서 유의하지 않다. 평행추세의 증명은 아니다.','','## 이벤트 스터디','',e[e.event_start.eq(31)][['age_group','sex','relative_percent','percent_low','percent_high','p','p_holm_24_post_bins']].to_markdown(index=False,floatfmt='.4f'),'','위 표는 2025년 6–11월 구간이다. 기준은 2022년 5–10월이다. 평균 DID의 전체 사전 36개월 기준과 다르다. 그림의 신뢰구간은 구간별이며 동시신뢰구간이 아니다. EVENT_ALL.csv에 사후 24개 검정의 Holm 보정도 제공한다.','','## 명세별 강건성','',r[~r.specification.isin(['direct_sex_difference'])][['age_group','sex','specification','relative_percent','p']].to_markdown(index=False,floatfmt='.4f'),'','20–24세 여성의 감소는 선형추세 조정에서 유의하지 않다. 20–24세 남성은 고용규모 가중에서만 유의하다. 25–29세 남성은 기본·선형추세·코로나 조정에서 유의하지만 규모 가중에서 유의하지 않다. 유의한 명세만 선택하지 않는다. 사후 자료를 사용하는 차등 선형추세는 결정적 보정이 아니며 규모 가중은 추정대상을 바꾼다.','','## 남녀 차이의 직접 검정','',r[r.specification.eq('direct_sex_difference')][['age_group','relative_percent','percent_low','percent_high','p','p_holm_two_age_sex_contrasts']].to_markdown(index=False,floatfmt='.4f'),'',ss.to_markdown(index=False,floatfmt='.4f'),'','직종 내 여성/남성 고용비에 동일 DID를 적용했다. 25–29세의 여성 상대변화가 남성보다 높지만 20–24세에서는 남녀 차이가 유의하지 않다. 이는 상대변화의 비율이며 퍼센트포인트 차이가 아니다.','','## 연령 차이를 직접 검정','',ad.to_markdown(index=False,floatfmt='.4f'),'','한 연령에서 유의하고 다른 연령에서 비유의하다고 해서 연령 간 차이가 유의한 것은 아니다. 여성의 기본 20–24세 대비 25–29세 차이는 유의하지만 차등 선형추세 조정 시 유의하지 않다. 남성의 연령 차이는 비유의다.','','남녀 격차 자체의 연령 차이에 대한 직접 검정은 아래와 같다. 양수는 25–29세에서 여성의 상대적 우위가 더 크다는 뜻이다.','',''+tr.to_markdown(index=False,floatfmt='.4f'),'','추가 대조와 민감도는 탐색적이며 전체 탐색을 포괄하는 다중검정 보정을 의미하지 않는다.','','## 한계','', '고용보험 피보험자 수이며 인구 조정 고용률·채용·전일제 고용이 아니다. 산업별 수요, 코로나 회복과 연령집단 인구 변화를 완전히 통제하지 못했다. 같은 사람을 추적하지 않으며 연령집단 유입·유출도 반영한다. 2025년 고정 THAIE와 역사적 직종 재분류, 완전관측·양수 선택표본의 제약이 있다. AI 도입 자체를 관측하지 않았고 Q1–Q4도 미처리군이라고 보장할 수 없다. 인과효과로 단정하지 않는다.','','원 추정과 별개로 네 기본 계수를 직종별 사전·사후 평균차의 집단 차이로 재계산했고 오차 1e−10 미만을 확인했다.']
(P/'REPORT_KO.md').write_text('\n'.join(lines));(P/'VALIDATION.json').write_text(json.dumps(checks,indent=2));print(primary[['age_group','sex','relative_percent','p','p_holm_four_age_sex_tests']].to_string(index=False));print(ss.to_string(index=False));print(tr.to_string(index=False));print(e[e.event_start.eq(31)][['age_group','sex','relative_percent','p','p_holm_24_post_bins']].to_string(index=False))
