# 연령별 DID와 이벤트 스터디

2026년 11월 26일. 홈페이지와 원고는 수정하지 않았다.

같은 105개 직종(Q5 20개, Q1–Q4 85개)을 고정했다. 20–24세와 25–29세, 남성과 여성 각각 7,560개 관측이다. 사전 2019년 11월–2022년 10월, 사후 2022년 12월–2025년 11월 각 36개월이며 전환월은 제외했다. 84개월 중 대칭 창 72개월을 사용한다. 결측을 0으로 채우지 않았다.

## 기본 DID

| age_group   | sex    |   relative_percent |   percent_low |   percent_high |      p |   p_holm_four_age_sex_tests |
|:------------|:-------|-------------------:|--------------:|---------------:|-------:|----------------------------:|
| 20–24       | Male   |            -4.1390 |      -19.8143 |        14.6006 | 0.6397 |                      1.0000 |
| 20–24       | Female |            -9.8958 |      -18.4814 |        -0.4059 | 0.0415 |                      0.1662 |
| 25–29       | Male   |            -9.0962 |      -17.2847 |        -0.0971 | 0.0477 |                      0.1662 |
| 25–29       | Female |             2.7650 |       -8.1759 |        15.0095 | 0.6319 |                      1.0000 |

로그 피보험자 수, 직종·월 고정효과, 직종 동일가중, 직종 군집 표준오차와 104 자유도 양측 검정이다. 변화율은 exp(β)−1이며 Q1–Q4 대비 상대적 변화다. 네 연령·성별 기본 검정을 Holm 보정하면 모두 5% 수준에서 유의하지 않다.

## 사전 추세

| sex    | test                                          |        F |   df_num |   df_den |      p |   coefficient |       se | age_group   |
|:-------|:----------------------------------------------|---------:|---------:|---------:|-------:|--------------:|---------:|:------------|
| Male   | six_month_pre_event_coefficients_jointly_zero |   1.0277 |   5.0000 | 104.0000 | 0.4053 |      nan      | nan      | age20_24    |
| Male   | preperiod_linear_differential_trend           | nan      | nan      | nan      | 0.5679 |        0.0020 |   0.0034 | age20_24    |
| Female | six_month_pre_event_coefficients_jointly_zero |   1.6580 |   5.0000 | 104.0000 | 0.1514 |      nan      | nan      | age20_24    |
| Female | preperiod_linear_differential_trend           | nan      | nan      | nan      | 0.3334 |        0.0032 |   0.0033 | age20_24    |
| Male   | six_month_pre_event_coefficients_jointly_zero |   0.6929 |   5.0000 | 104.0000 | 0.6300 |      nan      | nan      | age25_29    |
| Male   | preperiod_linear_differential_trend           | nan      | nan      | nan      | 0.4879 |        0.0019 |   0.0027 | age25_29    |
| Female | six_month_pre_event_coefficients_jointly_zero |   0.7452 |   5.0000 | 104.0000 | 0.5914 |      nan      | nan      | age25_29    |
| Female | preperiod_linear_differential_trend           | nan      | nan      | nan      | 0.1658 |        0.0043 |   0.0031 | age25_29    |

각 연령·성별의 사전 5개 6개월 계수 공동검정과 사전만 사용한 차등 선형추세 검정 모두 5% 수준에서 유의하지 않다. 평행추세의 증명은 아니다.

## 이벤트 스터디

| age_group   | sex    |   relative_percent |   percent_low |   percent_high |      p |   p_holm_24_post_bins |
|:------------|:-------|-------------------:|--------------:|---------------:|-------:|----------------------:|
| age20_24    | Male   |            -9.2051 |      -25.0216 |         9.9479 | 0.3194 |                1.0000 |
| age20_24    | Female |           -19.4898 |      -30.1782 |        -7.1652 | 0.0032 |                0.0544 |
| age25_29    | Male   |           -14.8633 |      -22.4828 |        -6.4947 | 0.0009 |                0.0208 |
| age25_29    | Female |            -5.9912 |      -13.7684 |         2.4873 | 0.1589 |                1.0000 |

위 표는 2025년 6–11월 구간이다. 기준은 2022년 5–10월이다. 평균 DID의 전체 사전 36개월 기준과 다르다. 그림의 신뢰구간은 구간별이며 동시신뢰구간이 아니다. EVENT_ALL.csv에 사후 24개 검정의 Holm 보정도 제공한다.

## 명세별 강건성

| age_group   | sex    | specification                |   relative_percent |      p |
|:------------|:-------|:-----------------------------|-------------------:|-------:|
| age20_24    | Male   | TWFE                         |            -4.1390 | 0.6397 |
| age20_24    | Male   | TWFE_two_way_cluster         |            -4.1390 | 0.6368 |
| age20_24    | Male   | baseline_employment_weighted |           -19.5964 | 0.0022 |
| age20_24    | Male   | differential_linear_trend    |            -4.4260 | 0.1794 |
| age20_24    | Male   | differential_covid           |            -6.0876 | 0.4637 |
| age20_24    | Female | TWFE                         |            -9.8958 | 0.0415 |
| age20_24    | Female | TWFE_two_way_cluster         |            -9.8958 | 0.0460 |
| age20_24    | Female | baseline_employment_weighted |           -18.8896 | 0.0020 |
| age20_24    | Female | differential_linear_trend    |            -4.8707 | 0.2041 |
| age20_24    | Female | differential_covid           |           -10.3468 | 0.0210 |
| age25_29    | Male   | TWFE                         |            -9.0962 | 0.0477 |
| age25_29    | Male   | TWFE_two_way_cluster         |            -9.0962 | 0.0489 |
| age25_29    | Male   | baseline_employment_weighted |            -6.5962 | 0.3647 |
| age25_29    | Male   | differential_linear_trend    |            -5.6714 | 0.0198 |
| age25_29    | Male   | differential_covid           |            -8.9358 | 0.0284 |
| age25_29    | Female | TWFE                         |             2.7650 | 0.6319 |
| age25_29    | Female | TWFE_two_way_cluster         |             2.7650 | 0.6323 |
| age25_29    | Female | baseline_employment_weighted |             1.4745 | 0.8302 |
| age25_29    | Female | differential_linear_trend    |            -0.4673 | 0.8369 |
| age25_29    | Female | differential_covid           |             1.8030 | 0.7214 |

20–24세 여성의 감소는 선형추세 조정에서 유의하지 않다. 20–24세 남성은 고용규모 가중에서만 유의하다. 25–29세 남성은 기본·선형추세·코로나 조정에서 유의하지만 규모 가중에서 유의하지 않다. 유의한 명세만 선택하지 않는다. 사후 자료를 사용하는 차등 선형추세는 결정적 보정이 아니며 규모 가중은 추정대상을 바꾼다.

## 남녀 차이의 직접 검정

| age_group   |   relative_percent |   percent_low |   percent_high |      p |   p_holm_two_age_sex_contrasts |
|:------------|-------------------:|--------------:|---------------:|-------:|-------------------------------:|
| age20_24    |            -6.0053 |      -20.4900 |        11.1180 | 0.4647 |                         0.4647 |
| age25_29    |            13.0480 |        3.6305 |        23.3215 | 0.0062 |                         0.0123 |

| specification            |   female_minus_male_log_difference |   relative_percent |      p | age_group   |
|:-------------------------|-----------------------------------:|-------------------:|-------:|:------------|
| unweighted               |                            -0.0619 |            -6.0053 | 0.4647 | age20_24    |
| pooled_baseline_weighted |                             0.1397 |            14.9949 | 0.0137 | age20_24    |
| linear_trend             |                            -0.0047 |            -0.4653 | 0.9092 | age20_24    |
| covid                    |                            -0.0464 |            -4.5353 | 0.5616 | age20_24    |
| unweighted               |                             0.1226 |            13.0480 | 0.0062 | age25_29    |
| pooled_baseline_weighted |                             0.1702 |            18.5568 | 0.0261 | age25_29    |
| linear_trend             |                             0.0537 |             5.5170 | 0.0053 | age25_29    |
| covid                    |                             0.1115 |            11.7925 | 0.0052 | age25_29    |

직종 내 여성/남성 고용비에 동일 DID를 적용했다. 25–29세의 여성 상대변화가 남성보다 높지만 20–24세에서는 남녀 차이가 유의하지 않다. 이는 상대변화의 비율이며 퍼센트포인트 차이가 아니다.

## 연령 차이를 직접 검정

| sex    | specification   | comparison        |   coefficient |   relative_percent |   percent_low |   percent_high |      p |
|:-------|:----------------|:------------------|--------------:|-------------------:|--------------:|---------------:|-------:|
| Female | base            | 20–24 minus 25–29 |       -0.1315 |           -12.3201 |      -21.0656 |        -2.6057 | 0.0147 |
| Female | linear_trend    | 20–24 minus 25–29 |       -0.0452 |            -4.4240 |       -9.8387 |         1.3159 | 0.1270 |
| Female | covid           | 20–24 minus 25–29 |       -0.1271 |           -11.9346 |      -19.8864 |        -3.1935 | 0.0090 |
| Male   | base            | 20–24 minus 25–29 |        0.0531 |             5.4532 |       -9.4693 |        22.8356 | 0.4917 |
| Male   | linear_trend    | 20–24 minus 25–29 |        0.0131 |             1.3203 |       -4.6303 |         7.6422 | 0.6683 |
| Male   | covid           | 20–24 minus 25–29 |        0.0308 |             3.1276 |      -10.8080 |        19.2406 | 0.6749 |

한 연령에서 유의하고 다른 연령에서 비유의하다고 해서 연령 간 차이가 유의한 것은 아니다. 여성의 기본 20–24세 대비 25–29세 차이는 유의하지만 차등 선형추세 조정 시 유의하지 않다. 남성의 연령 차이는 비유의다.

남녀 격차 자체의 연령 차이에 대한 직접 검정은 아래와 같다. 양수는 25–29세에서 여성의 상대적 우위가 더 크다는 뜻이다.

| specification   | comparison                                     |   coefficient |   relative_percent |   percent_low |   percent_high |      p |
|:----------------|:-----------------------------------------------|--------------:|-------------------:|--------------:|---------------:|-------:|
| base            | Female-minus-Male DID, age25_29 minus age20_24 |        0.1846 |            20.2707 |        0.6529 |        43.7121 | 0.0423 |
| linear_trend    | Female-minus-Male DID, age25_29 minus age20_24 |        0.0584 |             6.0102 |       -2.5200 |        15.2869 | 0.1706 |
| covid           | Female-minus-Male DID, age25_29 minus age20_24 |        0.1579 |            17.1034 |       -0.9946 |        38.5096 | 0.0650 |

추가 대조와 민감도는 탐색적이며 전체 탐색을 포괄하는 다중검정 보정을 의미하지 않는다.

## 한계

고용보험 피보험자 수이며 인구 조정 고용률·채용·전일제 고용이 아니다. 산업별 수요, 코로나 회복과 연령집단 인구 변화를 완전히 통제하지 못했다. 같은 사람을 추적하지 않으며 연령집단 유입·유출도 반영한다. 2025년 고정 THAIE와 역사적 직종 재분류, 완전관측·양수 선택표본의 제약이 있다. AI 도입 자체를 관측하지 않았고 Q1–Q4도 미처리군이라고 보장할 수 없다. 인과효과로 단정하지 않는다.

원 추정과 별개로 네 기본 계수를 직종별 사전·사후 평균차의 집단 차이로 재계산했고 오차 1e−10 미만을 확인했다.