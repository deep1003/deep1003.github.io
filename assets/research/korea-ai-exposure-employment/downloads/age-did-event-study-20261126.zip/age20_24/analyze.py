"""Balanced-window, occupation-clustered exploratory monthly DID. No imputation."""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import json,hashlib
import numpy as np,pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.sandwich_covariance import cov_cluster_2groups
from scipy.stats import t as td,f as fd
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;H=P.parent.parent
source=H/'45_korea_public_monthly_backfill_20261126/occupation_age_sex_extended_checked.csv'
d=pd.read_csv(source);link=pd.read_csv(H/'45_korea_public_monthly_backfill_20261126/strict_quintile_linkage.csv')
link['occupation']='2025직종_'+link.label;link=link[link.quintile.notna()]
d=d.merge(link[['occupation','quintile']],on='occupation',how='inner',validate='many_to_one')
age_label=os.environ['SOURCE_AGE']
d=d[d.age.eq(age_label)].copy()
d['rel']=pd.PeriodIndex(d.time,freq='M').asi8-pd.Period('2022-11','M').ordinal
d=d[d.rel.between(-36,36)]
assert not d.duplicated(['occupation','sex','time']).any()
a=d.rename(columns={'stock':'n'}).copy()
reference=pd.read_csv(H/'46_korea_monthly_did_20261126/balanced_occupation_sex_month.csv')
eligible=reference.occupation.unique().tolist()
assert len(eligible)==105
a=a[a.occupation.isin(eligible)].copy();a['q5']=(a.quintile==5).astype(int);a['post']=(a.rel>0).astype(int);a['logn']=np.log(a.n);a['sex']=a.sex.map({'남':'Male','여':'Female'});a['covid']=(a.time.between('2020-03','2021-12')).astype(int)
a.to_csv(P/'balanced_occupation_sex_month.csv',index=False)
# Event month omitted. Pre -36..-1, post +1..+36, exactly 72 months.
b=a[a.rel.ne(0)].copy();b['eventbin']=np.where(b.rel<0,(b.rel+36)//6,(b.rel-1)//6+6).astype(int)
for i in list(range(5))+list(range(6,12)):b[f'ev{i}']=((b.eventbin==i)&b.q5.eq(1)).astype(int)
results=[];events=[];pretests=[]
def coefficient(m,term,sex,spec,g):
 beta=float(m.params[term]);se=float(m.bse[term]);df=g.occupation.nunique()-1;crit=td.ppf(.975,df);p=2*td.sf(abs(beta/se),df)
 return dict(sex=sex,specification=spec,coefficient=beta,se=se,p=p,ci_low=beta-crit*se,ci_high=beta+crit*se,relative_percent=100*np.expm1(beta),percent_low=100*np.expm1(beta-crit*se),percent_high=100*np.expm1(beta+crit*se),observations=len(g),occupations=g.occupation.nunique(),months=g.time.nunique(),q5_occupations=g[g.q5.eq(1)].occupation.nunique(),control_occupations=g[g.q5.eq(0)].occupation.nunique())
for sex in ['Male','Female']:
 g=b[b.sex.eq(sex)].copy();weights=a[(a.sex.eq(sex))&a.time.eq('2022-10')].set_index('occupation').n;g['weight']=g.occupation.map(weights)
 for spec,extra,w in [('TWFE','',False),('baseline_employment_weighted','',True),('differential_linear_trend',' + q5:rel',False),('differential_covid',' + q5:covid',False)]:
  model=(smf.wls('logn ~ C(occupation)+C(time)+q5:post'+extra,data=g,weights=g.weight) if w else smf.ols('logn ~ C(occupation)+C(time)+q5:post'+extra,data=g))
  m=model.fit(cov_type='cluster',cov_kwds={'groups':g.occupation},use_t=True)
  r=coefficient(m,'q5:post',sex,spec,g);results.append(r)
  if spec=='TWFE':
   c,_,_=cov_cluster_2groups(m,pd.Categorical(g.occupation).codes,pd.Categorical(g.time).codes);j=m.params.index.get_loc('q5:post');se=np.sqrt(c[j,j]);df=min(g.occupation.nunique()-1,g.time.nunique()-1);crit=td.ppf(.975,df)
   results.append(dict(r,specification='TWFE_two_way_cluster',se=float(se),p=float(2*td.sf(abs(r['coefficient']/se),df)),ci_low=r['coefficient']-crit*se,ci_high=r['coefficient']+crit*se,percent_low=100*np.expm1(r['coefficient']-crit*se),percent_high=100*np.expm1(r['coefficient']+crit*se)))
 terms=[f'ev{i}' for i in list(range(5))+list(range(6,12))]
 m=smf.ols('logn ~ C(occupation)+C(time)+'+'+'.join(terms),data=g).fit(cov_type='cluster',cov_kwds={'groups':g.occupation},use_t=True)
 for i in list(range(5))+list(range(6,12)):
  r=coefficient(m,f'ev{i}',sex,'event_study',g);lo=-36+6*i if i<6 else 1+6*(i-6);events.append(dict(r,bin=i,event_start=lo,event_end=lo+5,event_mid=lo+2.5))
 pre=[f'ev{i}' for i in range(5)];j=[m.params.index.get_loc(x) for x in pre];bet=m.params.iloc[j].values;cov=m.cov_params().iloc[j,j].values;stat=float(bet@np.linalg.pinv(cov)@bet/5);pretests.append(dict(sex=sex,test='six_month_pre_event_coefficients_jointly_zero',F=stat,df_num=5,df_den=g.occupation.nunique()-1,p=float(fd.sf(stat,5,g.occupation.nunique()-1))))
 # Pre-only differential trend, no post-treatment observations.
 predata=g[g.rel.lt(0)];pm=smf.ols('logn ~ C(occupation)+C(time)+q5:rel',data=predata).fit(cov_type='cluster',cov_kwds={'groups':predata.occupation},use_t=True)
 rr=coefficient(pm,'q5:rel',sex,'preperiod_differential_trend_per_month',predata);pretests.append(dict(sex=sex,test='preperiod_linear_differential_trend',p=rr['p'],coefficient=rr['coefficient'],se=rr['se']))
# Direct test whether the Q5-relative post shift differs by sex.
sexgap=b.pivot(index=['occupation','quintile','time','rel','q5','post'],columns='sex',values='logn').reset_index()
sexgap['loggap']=sexgap.Female-sexgap.Male
m=smf.ols('loggap ~ C(occupation)+C(time)+q5:post',data=sexgap).fit(cov_type='cluster',cov_kwds={'groups':sexgap.occupation},use_t=True)
results.append(coefficient(m,'q5:post','Female_minus_Male','direct_sex_difference',sexgap))
r=pd.DataFrame(results);primary=r.specification.eq('TWFE');r.loc[primary,'p_holm_two_sexes']=multipletests(r.loc[primary,'p'],method='holm')[1];r.to_csv(P/'DID_RESULTS.csv',index=False)
e=pd.DataFrame(events);e.to_csv(P/'EVENT_STUDY.csv',index=False);pd.DataFrame(pretests).to_csv(P/'PRETREND_TESTS.csv',index=False)
# Group-size-weighted descriptive aggregates, separately indexed to observed November2022.
c=a.groupby(['sex','q5','time','rel']).n.sum().reset_index();base=c[c.rel.eq(0)].set_index(['sex','q5']).n;c['index']=[100*x.n/base.loc[x.sex,x.q5] for x in c.itertuples()];c.to_csv(P/'GROUP_INDICES.csv',index=False)
fig,axs=plt.subplots(1,2,figsize=(11,4),sharey=True)
for ax,sex,col in zip(axs,['Male','Female'],['#577C96','#C64F5A']):
 s=e[e.sex.eq(sex)];ax.errorbar(s.event_mid,s.relative_percent,yerr=[s.relative_percent-s.percent_low,s.percent_high-s.relative_percent],fmt='-',color=col,capsize=3,lw=1.7);ax.axhline(0,color='.5',lw=.8);ax.axvline(0,color='.6',ls=':',lw=1);ax.set_title(sex);ax.set_xlabel('Months relative to November 2022');ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.16)
axs[0].set_ylabel('Q5 relative to Q1–Q4 (%)\nReference: months -6 to -1');fig.tight_layout();fig.savefig(P/'event_study.png',dpi=240);fig.savefig(P/'event_study.pdf');plt.close(fig)
meta={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'pre':'2019-11 through 2022-10','post':'2022-12 through 2025-11','transition':'2022-11 omitted','youth':'20–29, both 20–24 and 25–29 source cells required','eligible_occupations':len(eligible),'balanced_records_with_transition':len(a),'DID_records_per_sex':len(b)//2,'missing':'No imputation; both sexes and ages required for all 73 months; strictly positive outcome','primary':'Unweighted log occupation counts, occupation/month FE, occupation-clustered SE, t with G-1 df','event':'Six-month bins, reference -6..-1; pre-bin joint F test','causal':'Descriptive differential change; AI causal effect not identified','publication':'No website or manuscript changes'}
(P/'DESIGN_AND_CHECKS.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));print(r[['sex','specification','relative_percent','p']].to_string(index=False));print(pd.DataFrame(pretests).to_string(index=False));print(meta)
