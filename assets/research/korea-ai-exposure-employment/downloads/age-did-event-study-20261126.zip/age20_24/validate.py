from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import pandas as pd,numpy as np,json
import statsmodels.formula.api as smf
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
P=Path(__file__).resolve().parent;a=pd.read_csv(P/'balanced_occupation_sex_month.csv');b=a[a.rel.ne(0)].copy();r=pd.read_csv(P/'DID_RESULTS.csv');e=pd.read_csv(P/'EVENT_STUDY.csv');pt=pd.read_csv(P/'PRETREND_TESTS.csv')
# Independent balanced TWFE identity: difference between group means of occupation changes.
checks=[]
for sex in ['Male','Female']:
 g=b[b.sex.eq(sex)];v=g.groupby(['occupation','q5','post']).logn.mean().unstack();change=v[1]-v[0];simple=change.groupby(level='q5').mean().diff().iloc[-1];est=r[(r.sex==sex)&(r.specification=='TWFE')].coefficient.iloc[0];assert abs(simple-est)<1e-10;checks.append({'sex':sex,'independent_TWFE_error':abs(simple-est)})
z=b.pivot(index=['occupation','quintile','time','rel','q5','post','covid'],columns='sex',values='logn').reset_index();z['gap']=z.Female-z.Male
w=a[a.rel.eq(-1)].groupby('occupation').n.sum();z['w']=z.occupation.map(w);out=[]
for spec,extra,weight in [('unweighted','',False),('pooled_baseline_weighted','',True),('linear_trend','+q5:rel',False),('covid','+q5:covid',False)]:
 model=smf.wls('gap~C(occupation)+C(time)+q5:post'+extra,data=z,weights=z.w) if weight else smf.ols('gap~C(occupation)+C(time)+q5:post'+extra,data=z)
 m=model.fit(cov_type='cluster',cov_kwds={'groups':z.occupation},use_t=True);beta=m.params['q5:post'];se=m.bse['q5:post'];df=z.occupation.nunique()-1;out.append({'specification':spec,'female_minus_male_log_difference':beta,'relative_percent':100*np.expm1(beta),'p':2*t.sf(abs(beta/se),df)})
pd.DataFrame(out).to_csv(P/'SEX_DIFFERENCE_SENSITIVITY.csv',index=False)
post=e.event_start.gt(0);e.loc[post,'p_holm_12_post_bins']=multipletests(e.loc[post,'p'],method='holm')[1];e.to_csv(P/'EVENT_STUDY.csv',index=False)
(P/'INDEPENDENT_CHECKS.json').write_text(json.dumps({'balanced_months_each_side':36,'checks':checks,'event_intervals':'pointwise 95%, not simultaneous','post_tests':'Holm correction over 12 sex-by-post-bin tests','sex_sensitivity':out},indent=2))
