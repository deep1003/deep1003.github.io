from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import pandas as pd,numpy as np,json
from scipy.stats import t,f
from statsmodels.stats.multitest import multipletests
P=Path(__file__).resolve().parent;H=P.parent
prev=H/'47_korea_age_split_did_20261126'
# Balanced two-way FE; constant occupation weights. Exact full-dummy residual df correction.
def fit(g,spec='base',event=False):
 occ=sorted(g.occupation.unique());times=sorted(g.time.unique());G=len(occ);T=len(times)
 def matrix(col):return g.pivot(index='occupation',columns='time',values=col).loc[occ,times].to_numpy()
 y=matrix('logn');q=g.groupby('occupation').q5.first().loc[occ].to_numpy();rel=g.groupby('time').rel.first().loc[times].to_numpy();post=(rel>0).astype(int)
 weights=g.groupby('occupation').weight.first().loc[occ].to_numpy() if spec=='weighted' else np.ones(G)
 xs=[q[:,None]*post]
 if event:
  eb=np.where(rel<0,(rel+36)//6,(rel-1)//6+6).astype(int);ids=list(range(5))+list(range(6,12));xs=[q[:,None]*(eb==i) for i in ids]
 elif spec=='trend':xs.append(q[:,None]*rel)
 elif spec=='covid':xs.append(q[:,None]*np.array([int('2020-03'<=x<='2021-12') for x in times]))
 def within(v):return v-v.mean(axis=1,keepdims=True)-np.average(v,axis=0,weights=weights)[None,:]+np.average(v.mean(axis=1),weights=weights)
 X=np.stack([within(x) for x in xs],axis=2);Y=within(y);sw=np.sqrt(weights)[:,None];xx=(X*sw[:,:,None]).reshape(-1,len(xs));yy=(Y*sw).reshape(-1);bread=np.linalg.inv(xx.T@xx);beta=bread@xx.T@yy;u=yy-xx@beta;scores=np.einsum('gtk,gt->gk',xx.reshape(G,T,-1),u.reshape(G,T));N=G*T;K=G+T-1+len(xs);cov=bread@(scores.T@scores)@bread*(G/(G-1))*((N-1)/(N-K));se=np.sqrt(np.diag(cov));df=G-1;crit=t.ppf(.975,df)
 result=dict(coefficient=beta[0],relative_percent=100*np.expm1(beta[0]),percent_low=100*np.expm1(beta[0]-crit*se[0]),percent_high=100*np.expm1(beta[0]+crit*se[0]),p=2*t.sf(abs(beta[0]/se[0]),df),G=G,N=N)
 if event:
  result['pre_p']=f.sf(beta[:5]@np.linalg.pinv(cov[:5,:5])@beta[:5]/5,5,df);result['last_percent']=100*np.expm1(beta[-1]);result['last_p']=2*t.sf(abs(beta[-1]/se[-1]),df)
 return result
contrib=[];loos=[];exclusions=[];checks=[]
for age,sex in [('age20_24','Female'),('age25_29','Male')]:
 a=pd.read_csv(prev/age/'balanced_occupation_sex_month.csv');a=a[a.sex.eq(sex)].copy();w=a[a.rel.eq(-1)].set_index('occupation').n;a['weight']=a.occupation.map(w);g=a[a.rel.ne(0)].copy();old=pd.read_csv(prev/age/'DID_RESULTS.csv');reference=old[(old.sex==sex)&(old.specification=='TWFE')].iloc[0];b=fit(g);assert abs(b['coefficient']-reference.coefficient)<1e-10;assert abs(b['p']-reference.p)<1e-10
 v=g.groupby(['occupation','q5','post']).agg(logn=('logn','mean'),n=('n','mean')).unstack('post');delta=v['logn'][1]-v['logn'][0];control=delta[delta.index.get_level_values('q5')==0].mean();q=v[v.index.get_level_values('q5')==1].copy();q['delta_log']=delta.loc[q.index];q['relative_log']=q.delta_log-control;q['beta_contribution']=q.relative_log/len(q);q['mean_pre_n']=q['n'][0];q['mean_post_n']=q['n'][1];q['count_change']=q.mean_post_n-q.mean_pre_n
 flat=pd.DataFrame({col:q[col] for col in ['delta_log','relative_log','beta_contribution','mean_pre_n','mean_post_n','count_change']}).reset_index();flat['age_group']=age;flat['sex']=sex;flat['did_log_share_percent']=100*flat.beta_contribution/b['coefficient'];assert abs(flat.beta_contribution.sum()-b['coefficient'])<1e-10;contrib.append(flat)
 checks.append(dict(age=age,sex=sex,coefficient_error=b['coefficient']-reference.coefficient,p_error=b['p']-reference.p,decomposition_error=flat.beta_contribution.sum()-b['coefficient']))
 for occ in sorted(g.occupation.unique()):
  z=fit(g[g.occupation.ne(occ)]);loos.append(dict(age_group=age,sex=sex,excluded=occ,is_q5=int(g[g.occupation.eq(occ)].q5.iloc[0]),**z))
 software='2025직종_ソフトウェア'.replace('ソフトウェア','소프트웨어 개발자');it=[x for x in flat.occupation if any(term in x for term in ['소프트웨어 개발자','컴퓨터시스템 전문가','네트워크 시스템 개발자','컴퓨터하드웨어'])]
 ranks=flat.sort_values('beta_contribution').occupation.tolist()
 count_ranks=flat.sort_values('count_change').occupation.tolist()
 sets={'none':[], 'software':[software],'IT_four':it,'top1_DID':ranks[:1],'top3_DID':ranks[:3],'top5_DID':ranks[:5],'top3_count':count_ranks[:3]}
 for name,drop in sets.items():
  z=g[~g.occupation.isin(drop)]
  for spec in ['base','weighted','trend','covid']:
   res=fit(z,spec);exclusions.append(dict(age_group=age,sex=sex,exclusion=name,excluded=';'.join(drop),specification=spec,**res))
  res=fit(z,event=True);exclusions.append(dict(age_group=age,sex=sex,exclusion=name,excluded=';'.join(drop),specification='event',**res))
pd.concat(contrib).to_csv(P/'OCCUPATION_CONTRIBUTIONS.csv',index=False);pd.DataFrame(loos).to_csv(P/'LEAVE_ONE_OUT.csv',index=False);pd.DataFrame(exclusions).to_csv(P/'EXCLUSION_SENSITIVITY.csv',index=False);(P/'VALIDATION.json').write_text(json.dumps(checks,indent=2));print(pd.DataFrame(exclusions).query("specification=='base'")[['age_group','exclusion','relative_percent','p']].to_string(index=False))
for df in contrib:
 print(df.sort_values('beta_contribution')[['age_group','occupation','beta_contribution','did_log_share_percent','count_change']].head(6).to_string(index=False))
