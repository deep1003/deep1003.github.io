"""Exploratory inference on observed Korean employment counts, no imputation."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy.stats import t as student_t, f as f_dist
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.diagnostic import acorr_ljungbox

OUT = Path(__file__).resolve().parent
H = OUT.parent
SITE = H / '37_korea_monthly_panels_20261125/publish/assets/research/korea-ai-exposure-employment'
SOURCE = SITE / 'data/administrative.json'
d = pd.DataFrame(json.loads(SOURCE.read_text()))
d = d[(d.kind == 'software') & (d.frequency == 'monthly')].copy()
young = ['20~24세 이하', '25~29세 이하']
older = ['40~44세 이하', '45~49세 이하', '50~54세 이하', '55~59세 이하',
         '60~64세 이하', '65~69세 이하', '70세 이상']
# Explicitly compare 20–29 with 40+, without treating omitted younger cells as zero.
rows = []
for sex in ['All', 'Male', 'Female']:
    for month, g in d[d.sex == sex].groupby('time'):
        y = g[g.age_group.isin(young)]
        a = g[g.age_group.isin(older)]
        if len(y) != len(young) or len(a) != len(older):
            continue
        if y.employment.isna().any() or a.employment.isna().any():
            continue
        if min(y.employment.sum(), a.employment.sum()) <= 0:
            continue
        stamp = pd.Period(month, 'M')
        relative = stamp.ordinal - pd.Period('2022-11', 'M').ordinal
        rows.append(dict(sex=sex, time=month, rel=relative, month=stamp.month,
                         youth=y.employment.sum(), older=a.employment.sum(),
                         gap=np.log(y.employment.sum()/a.employment.sum())))
panel = pd.DataFrame(rows)
panel.to_csv(OUT / 'monthly_age_gap.csv', index=False)
results, events = [], []
for sex in ['All', 'Male', 'Female']:
    for window in [24, 34]:
        g = panel[(panel.sex == sex) & panel.rel.between(-window, window) & (panel.rel != 0)].copy()
        assert len(g) == 2*window and g.time.nunique() == len(g)
        g['post'] = (g.rel > 0).astype(int)
        g['after'] = g.rel.clip(lower=0)
        # HAC requires consecutive equally spaced months. Include the transition
        # month as an unrestricted pulse, so exclusion from the contrast does not
        # collapse the November/December spacing in covariance estimation.
        transition = panel[(panel.sex == sex) & (panel.rel == 0)].copy()
        transition['post'] = 0
        transition['after'] = 0
        g = pd.concat([g, transition]).sort_values('rel')
        g['pulse'] = (g.rel == 0).astype(int)
        assert np.diff(g.rel).tolist() == [1]*(len(g)-1)
        for spec in ['level_DID', 'trend_adjusted_ITS', 'trend_COVID_ITS', 'trend_HAC6_ITS', 'trend_HAC18_ITS', 'common_quadratic_ITS', 'segmented_quadratic_ITS']:
            formula = 'gap ~ post + pulse + C(month)'
            if spec != 'level_DID':
                formula += ' + rel + after'
            if spec == 'trend_COVID_ITS':
                g['covid2020']=g.time.str.startswith('2020').astype(int)
                g['covid2021']=g.time.str.startswith('2021').astype(int)
                formula += ' + covid2020 + covid2021'
            if spec in ['common_quadratic_ITS','segmented_quadratic_ITS']:
                g['rel2']=g.rel**2
                formula += ' + rel2'
            if spec=='segmented_quadratic_ITS':
                g['after2']=g.after**2
                formula += ' + after2'
            lags=6 if spec=='trend_HAC6_ITS' else 18 if spec=='trend_HAC18_ITS' else 12
            model = smf.ols(formula, g).fit(cov_type='HAC', cov_kwds={'maxlags':lags, 'use_correction':True}, use_t=True)
            for horizon in ([None] if spec == 'level_DID' else sorted(set([12, 24, window]))):
                contrast = np.zeros(len(model.params))
                contrast[model.params.index.get_loc('post')] = 1
                if horizon is not None:
                    contrast[model.params.index.get_loc('after')] = horizon
                    if spec=='segmented_quadratic_ITS':
                        contrast[model.params.index.get_loc('after2')] = horizon**2
                test = model.t_test(contrast)
                b = float(np.asarray(test.effect).item())
                ci = np.asarray(test.conf_int()).ravel()
                results.append(dict(family='monthly', sex=sex, window=window, spec=spec,
                                    horizon=horizon, estimate_logpoints=100*b,
                                    percent=100*np.expm1(b), ci_low_percent=100*np.expm1(ci[0]),
                                    ci_high_percent=100*np.expm1(ci[1]), p_two_sided=float(test.pvalue),
                                    observations=len(g), pre_months=window, post_months=window,
                                    covariance=f'HAC Bartlett {lags} lags, finite-sample correction',
                                    start=g.time.min(), end=g.time.max(),parameters=len(model.params),design_rank=int(np.linalg.matrix_rank(model.model.exog)),bic=model.bic,ljung_box12_p=float(acorr_ljungbox(model.resid,lags=[12],return_df=True).lb_pvalue.iloc[0])))
        # Pre-period differential trend, not a proof of equivalence when nonsignificant.
        pre = g[g.rel < 0]
        fit = smf.ols('gap ~ rel + C(month)', pre).fit(cov_type='HAC', cov_kwds={'maxlags':6,'use_correction':True}, use_t=True)
        results.append(dict(family='monthly_pretrend',sex=sex,window=window,spec='linear_slope',
                            estimate_logpoints=100*fit.params['rel'],p_two_sided=fit.pvalues['rel'],
                            observations=len(pre),start=pre.time.min(),end=pre.time.max()))
        # Six-month event windows, relative to the last six pre-event months.
        g['event_bin'] = np.where(g.rel < 0, np.floor(g.rel/6), np.floor((g.rel-1)/6)+1).astype(int)
        g.loc[g.rel == 0, 'event_bin'] = 0
        ev = smf.ols('gap ~ C(event_bin, Treatment(reference=-1)) + C(month)',g).fit(
            cov_type='HAC',cov_kwds={'maxlags':12,'use_correction':True},use_t=True)
        pre_terms=[]
        for name in ev.params.index:
            if not name.startswith('C(event_bin'):
                continue
            bin_id=int(name.rsplit('[T.',1)[1].rstrip(']'))
            if bin_id < -1:
                pre_terms.append(name)
            ci=ev.conf_int().loc[name]
            events.append(dict(sex=sex,window=window,event_bin=bin_id,estimate_logpoints=100*ev.params[name],
                               ci_low_logpoints=100*ci.iloc[0],ci_high_logpoints=100*ci.iloc[1],p_two_sided=ev.pvalues[name]))
        R=np.zeros((len(pre_terms),len(ev.params)))
        for j,name in enumerate(pre_terms): R[j,ev.params.index.get_loc(name)]=1
        test=ev.wald_test(R,use_f=True,scalar=True)
        results.append(dict(family='monthly_pretrend',sex=sex,window=window,spec='event_joint_pretest',
                            p_two_sided=float(test.pvalue),observations=len(g),start=g.time.min(),end=g.time.max()))

# Independent annual THAIE comparison, preserving source inputs and population adjustment.
# This is an occupational youth/adult contrast, not a monthly software effect.
annual=[]
annual_pre=[]
annual_events=[]
for mode in ['occupation','industry']:
    source=H/'33_productivity_youth_vs40plus_20261124'/f'{mode}_panel.csv'
    raw=pd.read_csv(source)
    cols=['pair','occ','year','q5','w']+(['industry2'] if mode=='industry' else [])
    gap=raw.pivot(index=cols,columns='agegroup',values=['employment','expected']).reset_index()
    gap.columns=['_'.join(x).rstrip('_') if isinstance(x,tuple) else x for x in gap.columns]
    gap=gap[(gap.employment_Youth>0)&(gap.employment_Age40plus>0)].copy()
    gap['gap']=np.log(gap.employment_Youth/gap.expected_Youth)-np.log(gap.employment_Age40plus/gap.expected_Age40plus)
    gap['post']=gap.year.ge(2023).astype(int)*gap.q5
    gap['trend']=(gap.year-2013)*gap.q5
    for yr in [2020,2021,2022]:gap[f'covid{yr}']=gap.year.eq(yr).astype(int)*gap.q5
    for yr in range(2013,2026):
        if yr!=2022:gap[f'event{yr}']=gap.year.eq(yr).astype(int)*gap.q5
    for name,start,trend in [('balanced_3y',2020,False),('long_no_trend',2013,False),('long_trend_COVID',2013,True),('event_study',2013,False)]:
        g=gap[gap.year.ge(start)].copy()
        predictors=[f'event{yr}' for yr in range(2013,2026) if yr!=2022] if name=='event_study' else ['post']+(['trend','covid2020','covid2021','covid2022'] if trend else [])
        M=np.column_stack([g.gap,*[g[c] for c in predictors]]).astype(float)
        w=g.w.to_numpy();w=w/w.mean()
        g['time_effect']=g.industry2.astype(str)+'_'+g.year.astype(str) if mode=='industry' else g.year.astype(str)
        codes=[pd.factorize(g[c])[0] for c in ['pair','time_effect']]
        for it in range(10000):
            old=M.copy()
            for code in codes:
                den=np.bincount(code,weights=w)
                for j in range(M.shape[1]):M[:,j]-=(np.bincount(code,weights=w*M[:,j])/den)[code]
            if np.max(np.abs(M-old))<1e-10:break
        else:raise RuntimeError('Within transformation failed')
        y,X=M[:,0],M[:,1:];bread=np.linalg.inv((X.T*w)@X);b=bread@(X.T@(w*y));resid=y-X@b
        cluster=pd.factorize(g.occ)[0];G=cluster.max()+1
        scores=np.zeros((G,len(b)));np.add.at(scores,cluster,X*(w*resid)[:,None])
        V=bread@scores.T@scores@bread*G/(G-1)
        critical=student_t.ppf(.975,G-1)
        if name=='event_study':
            ix=[j for j,c in enumerate(predictors) if int(c[5:])<2022]
            rank=np.linalg.matrix_rank(V[np.ix_(ix,ix)])
            F=b[ix]@np.linalg.pinv(V[np.ix_(ix,ix)])@b[ix]/rank
            annual_pre.append(dict(mode=mode,F=F,df1=rank,df2=G-1,p_two_sided=f_dist.sf(F,rank,G-1),occupations=G))
            for j,c in enumerate(predictors):
                se=np.sqrt(V[j,j]);annual_events.append(dict(mode=mode,year=int(c[5:]),estimate_logpoints=100*b[j],ci_low_logpoints=100*(b[j]-critical*se),ci_high_logpoints=100*(b[j]+critical*se)))
            continue
        se=np.sqrt(V[0,0])
        annual.append(dict(mode=mode,spec=name,start=start,end=2025,occupations=G,pairs=g.pair.nunique(),
                           observations=len(g)*2,paired_differences=len(g),estimate_logpoints=100*b[0],
                           percent=100*np.expm1(b[0]),ci_low_percent=100*np.expm1(b[0]-critical*se),
                           ci_high_percent=100*np.expm1(b[0]+critical*se),p_two_sided=2*student_t.sf(abs(b[0]/se),G-1)))
monthly=pd.DataFrame(results)
primary=(monthly.family=='monthly')&(monthly.window==34)&(monthly.spec=='trend_adjusted_ITS')&(monthly.horizon==24)
monthly.loc[primary,'holm_three_sexes']=multipletests(monthly.loc[primary,'p_two_sided'],method='holm')[1]
monthly.to_csv(OUT/'monthly_tests.csv',index=False)
pd.DataFrame(events).to_csv(OUT/'monthly_event_study.csv',index=False)
pd.DataFrame(annual).to_csv(OUT/'annual_thaie_tests.csv',index=False)
pd.DataFrame(annual_pre).to_csv(OUT/'annual_pretrend_tests.csv',index=False)
pd.DataFrame(annual_events).to_csv(OUT/'annual_event_study.csv',index=False)
audit=dict(exploratory=True,transition='2022-11 separately absorbed by a pulse in monthly fits',
           baseline_not_used_in_regressions='Raw log count ratios; reindexing does not determine inference',
           monthly_source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
           monthly_available=[panel.time.min(),panel.time.max()],
           missing_pre36='2019-11 and 2019-12 unavailable; balanced 34 months plus 24-month sensitivity',
           monthly_population='Software-developer employment insurance, youth20-29 and comparator40+',
           annual_population='RES youth15-29 and comparator40+, occupation THAIE fixed from original analysis',
           functional_form='Linear, common quadratic, and segmented quadratic sensitivities reported together. Do not select a model as truth from post-period fit. Linear significance is not robust across functional forms.',
           no_causal_identification='Monthly age groups are not randomized AI exposure groups; no untreated counterfactual. Annual estimates require parallel trends and no differential shocks.',
           p_values='two-sided; 95 percent confidence intervals; no plots emitted')
(OUT/'AUDIT.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(monthly.loc[primary].to_string(index=False))
print(pd.DataFrame(annual).to_string(index=False))
