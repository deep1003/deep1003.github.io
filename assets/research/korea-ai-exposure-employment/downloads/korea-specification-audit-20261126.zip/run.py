"""Finite prespecified robustness grid. Not a causal identification exercise."""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import itertools,json,hashlib
import numpy as np,pandas as pd
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
P=Path(__file__).resolve().parent;H=P.parent
plan={'age':'20–29 vs40+, sex pooled; same observed ages in both sources','datasets':['EIS','RegionalSurvey'],'samples':['common76','min30','no_multi_contributor'],'quintiles':[1,2,3,4,5],'weights':['equal_occupation','aggregate_counts'],'windows':['2years2021_2024','3years2020_2025'],'outcomes':['log_young','log_older','log_young_older_ratio','population_adjusted_logratio'],'trends':['none','linear'],'HAC_lags':[1,2,3],'family_size':5,'primary':'common76, equal occupation,3years,logratio,no trend,HAC2','limitations':'No observed AI adoption. Grid significance is not causal proof. Specification counts are correlated; rejection fractions are not posterior probabilities. National population adjustment is accounting, not demographic causal identification.'}
(P/'DESIGN_BEFORE_RESULTS.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))
d=pd.read_csv(H/'58_korea_two_source_validation_20261126/COMMON_KSCO_PANEL.csv',dtype={'ksco':str});d['year']=d.time.str[:4].astype(int)
cave=pd.read_csv(H/'58_korea_two_source_validation_20261126/COMMON_CODE_LINKAGE_CAVEATS.csv',dtype={'ksco':str});clean=set(cave.loc[~cave.has_omitted_multi_target_contributors,'ksco'])
s=pd.read_csv(H/'57_korea_two_dataset_core_20261126/B_REGIONAL_SURVEY.csv');s=s[s.year.between(2020,2025)];s['ksco']=s.occ.astype(int).astype(str);s['ag']=np.where(s.band.between(20,25),'young',np.where(s.band.ge(40),'older','other'));s=s[s.ag!='other'];n=s.groupby(['ksco','time','ag']).sample_records.sum().unstack();good={k for k,g in n.groupby(level=0) if len(g)==12 and g[['young','older']].ge(30).all().all()}
pop=pd.read_csv(H/'57_korea_two_dataset_core_20261126/B_POPULATION_DENOMINATORS.csv');pop['ag']=np.where(pop.band.between(20,25),'young',np.where(pop.band.ge(40),'older','other'));pop=pop[pop.ag!='other'];pn=pop.groupby(['time','ag']).population.sum().unstack();pr=np.log(pn.young/pn.older)
rows=[];skips=[]
for ds,sample,q,weight,window,outcome,trend in itertools.product(plan['datasets'],plan['samples'],plan['quintiles'],plan['weights'],plan['windows'],plan['outcomes'],plan['trends']):
 g=d[(d.dataset==ds)&(d.THAIE_quintile==q)].copy()
 if sample=='min30':g=g[g.ksco.isin(good)]
 if sample=='no_multi_contributor':g=g[g.ksco.isin(clean)]
 if window.startswith('2'):g=g[g.year.between(2021,2024)]
 if g.empty or g.ksco.nunique()<2:skips.append([ds,sample,q,weight,window,outcome,trend]);continue
 if weight=='equal_occupation':
  t=g.assign(log_young=np.log(g.young),log_older=np.log(g.older)).groupby('time')[['log_young','log_older']].mean()
 else:
  t=np.log(g.groupby('time')[['young','older']].sum()).rename(columns={'young':'log_young','older':'log_older'})
 t['log_young_older_ratio']=t.log_young-t.log_older;t['population_adjusted_logratio']=t.log_young_older_ratio-t.index.map(pr)
 tm=t.index;X=pd.DataFrame({'constant':1.,'post':(tm>'2022-11').astype(float),'october':(tm.str[5:]=='10').astype(float)},index=tm)
 if trend=='linear':X['trend']=(pd.PeriodIndex(tm,freq='M').asi8-pd.Period('2022-11').ordinal).astype(float)
 for lag in plan['HAC_lags']:
  m=sm.OLS(t[outcome],X).fit(cov_type='HAC',cov_kwds={'maxlags':lag,'use_correction':True},use_t=True);b=m.params['post'];ci=m.conf_int().loc['post'];rows.append(dict(dataset=ds,sample=sample,quintile=q,weight=weight,window=window,outcome=outcome,trend=trend,HAC_lag=lag,beta=b,percent=100*np.expm1(b),p=m.pvalues['post'],low=100*np.expm1(ci.iloc[0]),high=100*np.expm1(ci.iloc[1]),occupations=g.ksco.nunique(),waves=len(t)))
r=pd.DataFrame(rows)
family=['dataset','sample','weight','window','outcome','trend','HAC_lag']
for _,ix in r.groupby(family).groups.items():r.loc[ix,'p_holm_Q1_Q5']=multipletests(r.loc[ix,'p'],method='holm')[1]
r.to_csv(P/'ALL_SPECIFICATIONS.csv',index=False)
summary=r.groupby(['dataset','outcome','trend']).agg(specifications=('p','size'),median_percent=('percent','median'),min_percent=('percent','min'),max_percent=('percent','max'),negative_share=('beta',lambda x:(x<0).mean()),raw_sig_share=('p',lambda x:(x<.05).mean()),holm_sig_share=('p_holm_Q1_Q5',lambda x:(x<.05).mean())).reset_index();summary.to_csv(P/'SUMMARY_ALL_QUINTILES.csv',index=False)
z=r[r.quintile.eq(5)].groupby(['dataset','outcome','trend']).agg(specifications=('p','size'),median_percent=('percent','median'),min_percent=('percent','min'),max_percent=('percent','max'),negative_share=('beta',lambda x:(x<0).mean()),holm_negative_sig_share=('p_holm_Q1_Q5',lambda p:((p<.05)&(r.loc[p.index,'beta']<0)).mean())).reset_index();z.to_csv(P/'Q5_SUMMARY.csv',index=False)
# Placebo in strictly pre-Nov2022 data: 2020 calendar year vs2021..2022 not true adoption.
place=[]
for (ds,q),g in d.groupby(['dataset','THAIE_quintile']):
 g=g[g.year.le(2022)];t=g.groupby('time').gap.mean();X=pd.DataFrame({'constant':1.,'post':(t.index>'2020-11').astype(float),'october':(t.index.str[5:]=='10').astype(float)},index=t.index)
 for trend in ['none','linear']:
  xx=X.copy()
  if trend=='linear':xx['trend']=np.arange(len(t))
  m=sm.OLS(t,xx).fit(cov_type='HAC',cov_kwds={'maxlags':1,'use_correction':True},use_t=True);place.append(dict(dataset=ds,quintile=q,fake_cutoff='2020-11',trend=trend,percent=100*np.expm1(m.params['post']),p=m.pvalues['post'],waves=len(t),warning='Only6 preperiod waves; highly underpowered.'))
pd.DataFrame(place).to_csv(P/'PREPERIOD_PLACEBO.csv',index=False)
assert not r.duplicated(family+['quintile']).any();assert r.p.between(0,1).all();(P/'VALIDATION.json').write_text(json.dumps({'models':len(r),'skipped_combinations':len(skips),'grid_unique':True,'p_values_valid':True,'skip_details':skips,'inputs_sha256':hashlib.sha256((H/'58_korea_two_source_validation_20261126/COMMON_KSCO_PANEL.csv').read_bytes()).hexdigest()},indent=2));print('Models',len(r),'Skipped',len(skips));print(z[z.outcome.isin(['log_young_older_ratio','population_adjusted_logratio'])].to_string(index=False))
