from pathlib import Path
import numpy as np,pandas as pd,json
from scipy.stats import spearmanr
P=Path(__file__).resolve().parent;H=P.parent;CORE=H/'57_korea_two_dataset_core_20261126'
d=pd.read_csv(P/'COMMON_KSCO_PANEL.csv',dtype={'ksco':str});s=pd.read_csv(CORE/'B_REGIONAL_SURVEY.csv');s=s[s.year.between(2020,2025)].copy();s['ksco']=s.occ.astype(int).astype(str);s['ag']=np.where(s.band.between(20,25),'young',np.where(s.band.ge(40),'older','other'));s=s[s.ag!='other'];n=s.groupby(['ksco','time','ag']).sample_records.sum().unstack();good=[k for k,g in n.groupby(level=0) if len(g)==12 and g[['young','older']].ge(30).all().all()];rows=[]
for subset,codes in [('all_common',d.ksco.unique()),('survey_min30_each_age_each_wave',good)]:
 z=d[d.ksco.isin(codes)]
 for (ds,q),g in z.groupby(['dataset','THAIE_quintile']):
  m=g.groupby('post').gap.mean();rows.append(dict(sample=subset,dataset=ds,quintile=q,occupations=g.ksco.nunique(),basic_change_percent=100*np.expm1(m[1]-m[0])))
pd.DataFrame(rows).to_csv(P/'SPARSE_CELL_SENSITIVITY.csv',index=False)
# Stronger coverage audit: distinguish exact concordance from complete occupation coverage.
links=pd.read_csv(H/'45_korea_public_monthly_backfill_20261126/strict_quintile_linkage.csv',dtype={'ksco8_targets':str});links=links[links.ksco8_targets.notna()];coverage=[]
for code in sorted(d.ksco.unique()):
 related=links[links.ksco8_targets.map(lambda x:code in [str(int(v)) for v in x.split(';')])];single=related[~related.ksco8_targets.str.contains(';')];coverage.append(dict(ksco=code,all_linkage_contributors=len(related),single_target_contributors=len(single),has_omitted_multi_target_contributors=len(related)>len(single)))
pd.DataFrame(coverage).to_csv(P/'COMMON_CODE_LINKAGE_CAVEATS.csv',index=False)
# Accounting identity for Q employment-to-age-population contributions, not occupation-specific population rates.
pop=pd.read_csv(P/'POPULATION_DECOMPOSITION.csv').iloc[0];z=d[d.time.str[:4].isin(['2022','2025'])].copy();z['year']=z.time.str[:4].astype(int);v=z.groupby(['dataset','THAIE_quintile','year','time'])[['young','older']].sum().groupby(['dataset','THAIE_quintile','year']).mean().reset_index();out=[]
for (ds,q),g in v.groupby(['dataset','THAIE_quintile']):
 g=g.set_index('year');change=np.log((g.loc[2025,'young']/g.loc[2025,'older'])/(g.loc[2022,'young']/g.loc[2022,'older']));out.append(dict(dataset=ds,quintile=q,ratio_change_percent=100*np.expm1(change),log_change_points=100*change,population_component_logpoints=pop.population_component_logpoints,residual_relative_employment_share_logpoints=100*change-pop.population_component_logpoints,note='Uses national survey age population; EIS residual also includes insurance coverage changes. Not causal attribution.'))
pd.DataFrame(out).to_csv(P/'QUINTILE_POPULATION_ACCOUNTING.csv',index=False)
print(pd.DataFrame(rows).query('quintile==5').to_string(index=False));print('Codes with omitted contributors',sum(x['has_omitted_multi_target_contributors'] for x in coverage));print(pd.DataFrame(out).query('quintile==5').to_string(index=False))
