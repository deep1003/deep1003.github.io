"""Two-source descriptive triangulation. No causal claims or missing-zero imputation."""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,pandas as pd,json,hashlib
import statsmodels.formula.api as smf
from scipy.stats import spearmanr
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent;H=P.parent;CORE=H/'57_korea_two_dataset_core_20261126'
a=pd.read_csv(CORE/'COMMON_AGE_OCCUPATION_SEX.csv',dtype={'occupation_id':str},low_memory=False);l=pd.read_csv(H/'45_korea_public_monthly_backfill_20261126/strict_quintile_linkage.csv',dtype={'keco2025':str,'ksco8_targets':str});l['occupation_id']='2025직종_'+l.label
# Restrict to one verified classification target; do not split a count across targets.
l=l[l.ksco8_targets.notna()&~l.ksco8_targets.str.contains(';',na=False)&l.quintile.notna()].copy();l['ksco']=l.ksco8_targets.astype(int).astype(str)
e=a[(a.dataset=='EIS')&a.calendar_matched_2020_2025&a.age_group.isin(['20_29','40plus'])].merge(l[['occupation_id','ksco']],on='occupation_id',validate='many_to_one');e['valid_value']=e.count_validated_age
# Sum only when all observed KECO component cells are valid; full-period group presence checked below.
e=e.groupby(['ksco','THAIE_quintile','age_group','time']).agg(count=('valid_value',lambda x:x.sum(min_count=len(x))),source_occ=('occupation_id','nunique'),components=('valid_value','size')).reset_index();e['dataset']='EIS';e['records']=np.nan
s=pd.read_csv(CORE/'B_REGIONAL_SURVEY.csv');s=s[s.year.between(2020,2025)];s['age_group']=np.select([s.band.between(20,25),s.band.ge(40)],['20_29','40plus'],default='other');s=s[s.age_group.ne('other')];s['ksco']=s.occ.astype(int).astype(str);s=s.groupby(['ksco','THAIE_quintile','age_group','time']).agg(count=('employed_estimate','sum'),records=('sample_records','sum')).reset_index();s['dataset']='RegionalSurvey'
d=pd.concat([e,s],ignore_index=True);d=d.pivot(index=['dataset','ksco','THAIE_quintile','time'],columns='age_group',values='count').reset_index();d=d.rename(columns={'20_29':'young','40plus':'older'})
valid=[]
for code,g in d.groupby('ksco'):
 if all(len(g[g.dataset.eq(ds)])==12 and g[g.dataset.eq(ds)][['young','older']].notna().all().all() and g[g.dataset.eq(ds)][['young','older']].gt(0).all().all() for ds in ['EIS','RegionalSurvey']):
  if g.THAIE_quintile.nunique()==1:valid.append(code)
d=d[d.ksco.isin(valid)].copy();d['gap']=np.log(d.young/d.older);d['post']=(d.time>'2022-11').astype(int);d['rel']=pd.PeriodIndex(d.time,freq='M').asi8-pd.Period('2022-11').ordinal;d['month']=d.time.str[5:];d.to_csv(P/'COMMON_KSCO_PANEL.csv',index=False)
# Common single-target code panel improves comparability, not necessarily total-market coverage.
rows=[];paths=[]
for (ds,q),g in d.groupby(['dataset','THAIE_quintile']):
 for aggregation in ['equal_occupation_logratio','aggregate_count_ratio']:
  t=g.groupby(['time','post','rel','month']).agg(gap=('gap','mean'),young=('young','sum'),older=('older','sum')).reset_index()
  if aggregation=='aggregate_count_ratio':t['gap']=np.log(t.young/t.older)
  for spec,extra in [('basic',''),('linear_trend','+rel')]:
   m=smf.ols('gap~post+C(month)'+extra,t).fit(cov_type='HAC',cov_kwds={'maxlags':2,'use_correction':True},use_t=True);ci=m.conf_int().loc['post'];rows.append(dict(dataset=ds,quintile=q,aggregation=aggregation,spec=spec,percent=100*np.expm1(m.params['post']),p=m.pvalues['post'],low=100*np.expm1(ci.iloc[0]),high=100*np.expm1(ci.iloc[1]),occupations=g.ksco.nunique(),waves=len(t)))
  if aggregation=='aggregate_count_ratio':
   t['dataset']=ds;t['quintile']=q;t['ratio_index_2022']=100*np.exp(t.gap-t.loc[t.time.str.startswith('2022'),'gap'].mean());paths.append(t)
r=pd.DataFrame(rows)
for _,ix in r.groupby(['dataset','aggregation','spec']).groups.items():r.loc[ix,'p_holm5']=multipletests(r.loc[ix,'p'],method='holm')[1]
r.to_csv(P/'COMMON_CODE_RESULTS.csv',index=False);path=pd.concat(paths);path.to_csv(P/'COMMON_CODE_PATHS.csv',index=False)
# Cross-source concordance of occupation changes, same calendar months.
d['year']=d.time.str[:4].astype(int);yr=d[d.year.isin([2022,2025])].groupby(['dataset','ksco','THAIE_quintile','year'])[['young','older']].mean().reset_index();yr['gap']=np.log(yr.young/yr.older);chg=yr.pivot(index=['dataset','ksco','THAIE_quintile'],columns='year',values='gap').reset_index();chg['change']=chg[2025]-chg[2022];chg.to_csv(P/'OCCUPATION_CHANGES.csv',index=False)
w=chg.pivot(index='ksco',columns='dataset',values='change').dropna();rho,pv=spearmanr(w.EIS,w.RegionalSurvey);agreement=(np.sign(w.EIS)==np.sign(w.RegionalSurvey)).mean()
# Population decomposition from ALL survey occupations, not just linked or common jobs.
pop=pd.read_csv(CORE/'B_POPULATION_DENOMINATORS.csv');pop['group']=np.select([pop.band.between(20,25),pop.band.ge(40)],['20_29','40plus'],default='other');pop=pop[pop.group.ne('other')];tot=pop.groupby(['year','wave','group'])[['population','employment']].sum().reset_index();annual=tot.groupby(['year','group'])[['population','employment']].mean();vals={}
for y in [2022,2025]:
 z=annual.loc[y];vals[y]={'population_ratio':z.loc['20_29','population']/z.loc['40plus','population'],'employment_ratio':z.loc['20_29','employment']/z.loc['40plus','employment'],'young_rate':100*z.loc['20_29','employment']/z.loc['20_29','population'],'older_rate':100*z.loc['40plus','employment']/z.loc['40plus','population']}
logn=np.log(vals[2025]['employment_ratio']/vals[2022]['employment_ratio']);logpop=np.log(vals[2025]['population_ratio']/vals[2022]['population_ratio']);lograte=logn-logpop
assert abs(logn-logpop-lograte)<1e-12
pd.DataFrame([dict(start=2022,end=2025,age='20_29_vs40plus',employment_ratio_change_percent=100*np.expm1(logn),log_change_points=100*logn,population_component_logpoints=100*logpop,relative_employment_rate_component_logpoints=100*lograte,population_share=logpop/logn,young_rate2022=vals[2022]['young_rate'],young_rate2025=vals[2025]['young_rate'],older_rate2022=vals[2022]['older_rate'],older_rate2025=vals[2025]['older_rate'])]).to_csv(P/'POPULATION_DECOMPOSITION.csv',index=False)
# Co-moving indexed levels can be spurious; compare changes as well.
correlations=[]
for q,g in path.groupby('quintile'):
 z=g.pivot(index='time',columns='dataset',values='gap');v=spearmanr(z.EIS,z.RegionalSurvey);diff=z.diff().dropna();vv=spearmanr(diff.EIS,diff.RegionalSurvey);correlations.append(dict(quintile=q,levels_rho=v.statistic,changes_rho=vv.statistic,periods=len(z),changes=len(diff),note='descriptive only; no independence-based p-values reported'))
pd.DataFrame(correlations).to_csv(P/'PATH_CONCORDANCE.csv',index=False)
meta={'common_single_target_KSCO_codes':len(valid),'per_quintile':d.groupby('THAIE_quintile').ksco.nunique().to_dict(),'occupation_change_spearman':float(rho),'occupation_change_direction_agreement':float(agreement),'comparison_period':'2020..2025 April/October; pre2020..2022, post2023..2025','occupation_change_period':'2022 two-wave mean to2025 two-wave mean','no_population_imputation':True,'no_count_splitting':True,'caveat':'Single-target KECO contributors may not exhaust a KSCO occupation. Industry, insurance coverage and survey sampling differences remain.'};(P/'VALIDATION.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));print(meta);print(pd.read_csv(P/'POPULATION_DECOMPOSITION.csv').to_string(index=False));print(r[(r.quintile==5)&(r.aggregation=='equal_occupation_logratio')].to_string(index=False))
fig,axs=plt.subplots(3,2,figsize=(11,10),sharex=True)
for ax,q in zip(axs.flat,range(1,6)):
 for ds,col in [('EIS','#C64F5A'),('RegionalSurvey','#577C96')]:
  z=path[(path.quintile==q)&(path.dataset==ds)].sort_values('time');ax.plot(pd.to_datetime(z.time),z.ratio_index_2022,color=col,lw=2,label=ds)
 ax.set_title(f'Q{q}');ax.axhline(100,color='.7',ls=':',lw=.8);ax.spines[['top','right']].set_visible(False);ax.set_ylabel('Youth / age40+ ratio, 2022=100');ax.legend(frameon=False,fontsize=8)
axs.flat[-1].axis('off');fig.tight_layout();fig.savefig(P/'common_code_paths.pdf');fig.savefig(P/'common_code_paths.png',dpi=180);plt.close(fig)
