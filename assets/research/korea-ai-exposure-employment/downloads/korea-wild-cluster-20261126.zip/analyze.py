"""Null-imposed WCR11, exact balanced two-way FE reprojection. No website edits."""
from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np,pandas as pd,json,hashlib
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
import statsmodels.api as sm
import statsmodels.formula.api as smf
P=Path(__file__).resolve().parent;H=P.parent;B=99999;SEED=20261126
site=H/'37_korea_monthly_panels_20261125/publish/assets/research/korea-ai-exposure-employment/index.html';site_before=hashlib.sha256(site.read_bytes()).hexdigest()
link=pd.read_csv(H/'45_korea_public_monthly_backfill_20261126/strict_quintile_linkage.csv',dtype={'keco2025':str});link['occupation']='2025직종_'+link.label;mapping=link.set_index('occupation').keco2025

def within(a):return a-a.mean(axis=1,keepdims=True)-a.mean(axis=0,keepdims=True)+a.mean()
def groupsum(a,codes):
 out=np.zeros((codes.max()+1,)+a.shape[1:]);np.add.at(out,codes,a);return out

def wcr(y,x,codes,weights_name,seed):
 # Input y and x already absorbed on all occupation and time FE.
 G,T=y.shape;N=G*T;K=G+T-1+1;C=int(codes.max())+1;D=np.sum(x*x);beta=np.sum(x*y)/D
 z=groupsum((x*y).sum(axis=1),codes);d=groupsum((x*x).sum(axis=1),codes)
 Xg=groupsum(x,codes);Ug=groupsum(y,codes)
 # Multiplying null residuals by cluster signs destroys time-FE orthogonality.
 # Reproject them in every draw via H rather than treating absorbed data as fixed.
 A=np.diag(z)-Xg@Ug.T/G-np.outer(d,z)/D
 corr=(C/(C-1))*((N-1)/(N-K));u=y-beta*x;score=groupsum((x*u).sum(axis=1),codes);se=np.sqrt(corr*np.sum(score**2))/D;observed=beta/se
 rng=np.random.default_rng(seed);extreme=0;valid=0;sum_t=0
 for start in range(0,B,4000):
  n=min(4000,B-start)
  if weights_name=='rademacher':W=rng.choice([-1.,1.],size=(C,n))
  else:W=rng.choice(np.array([-np.sqrt(1.5),-1.,-np.sqrt(.5),np.sqrt(.5),1.,np.sqrt(1.5)]),size=(C,n))
  numer=z@W;S=A@W;denom=np.sqrt(corr*np.sum(S*S,axis=0));ok=denom>1e-14;ts=numer[ok]/denom[ok];extreme+=int(np.sum(np.abs(ts)>=abs(observed)));valid+=len(ts)
 p=(extreme+1)/(valid+1)
 return dict(coefficient=beta,se=se,t=observed,asymptotic_p=2*t.sf(abs(observed),C-1),bootstrap_p=p,mc_se=np.sqrt(p*(1-p)/(valid+1)),extreme=extreme,valid_draws=valid,requested_draws=B,seed=seed,clusters=C,weights=weights_name)

rows=[];corrs=[];two=[];hac=[];familyfe=[];validation=[];targets=[]
for name,age,sex in [('female20_24_acquisitions','age20_24','Female'),('male25_29_acquisitions','age25_29','Male'),('age25_29_female_minus_male_employment','age25_29','gap')]:
 a=pd.read_csv(H/'47_korea_age_split_did_20261126'/age/'balanced_occupation_sex_month.csv')
 if sex=='gap':
  g=a.pivot(index=['occupation','time','rel','q5','post'],columns='sex',values='logn').reset_index();g['y']=g.Female-g.Male
 else:
  g=a[a.sex.eq(sex)].copy();base=g[g.rel.eq(0)].set_index('occupation').n;g['y']=100*g.acquisitions/g.occupation.map(base)
 full=g.copy();g=g[g.rel.ne(0)].copy();occ=sorted(g.occupation.unique());times=sorted(g.time.unique());Y=g.pivot(index='occupation',columns='time',values='y').loc[occ,times].to_numpy();q=g.groupby('occupation').q5.first().loc[occ].to_numpy();post=g.groupby('time').post.first().loc[times].to_numpy();x=within(q[:,None]*post);y=within(Y);beta=np.sum(x*y)/np.sum(x*x);u=y-beta*x;G,T=y.shape;N=G*T;K=G+T;D=np.sum(x*x)
 group=pd.Categorical([mapping.loc[o][:2] for o in occ]);codes=group.codes
 targets.append(dict(target=name,coefficient=beta,units='baseline stock 100-person monthly acquisitions' if sex!='gap' else 'log female/male employment contrast',q5=20,controls=85,months=72,N=N))
 # Verify full-dummy cluster t and explicit bootstrap refits for two deterministic draws.
 m=smf.ols('y~C(occupation)+C(time)+q5:post',data=g,eval_env=-1).fit(cov_type='cluster',cov_kwds={'groups':g.occupation},use_t=True)
 for level,c in [('occupation',np.arange(G)),('KECO_two_digit',codes)]:
  C=int(c.max())+1;correction=C/(C-1)*(N-1)/(N-K);zs=groupsum((x*y).sum(axis=1),c);ds=groupsum((x*x).sum(axis=1),c);A=np.diag(zs)-groupsum(x,c)@groupsum(y,c).T/G-np.outer(ds,zs)/D
  for rep in range(2):
   w=np.random.default_rng(132+rep).choice([-1.,1.],size=C);ystar=within(y*w[c,None]);bstar=np.sum(x*ystar)/D;ustar=ystar-bstar*x;sstar=groupsum((x*ustar).sum(axis=1),c);fast_beta=zs@w/D;fast_s=A@w
   assert abs(bstar-fast_beta)<1e-10;assert np.max(abs(sstar-fast_s))<1e-9
   validation.append(dict(target=name,cluster=level,draw=rep,beta_error=float(abs(bstar-fast_beta)),score_error=float(np.max(abs(sstar-fast_s)))))
  for j,wt in enumerate(['rademacher','webb']):
   r=wcr(y,x,c,wt,SEED+j);r.update(target=name,cluster=level,treated_clusters=int(len(set(c[q==1]))),mixed_clusters=int(sum((q[c==k].min()!=q[c==k].max()) for k in range(C))));rows.append(r)
   if level=='occupation':assert abs(r['se']-m.bse['q5:post'])<1e-10
   print(name,level,wt,'p',round(r['bootstrap_p'],5),flush=True)
 # Two-way CGM sandwich: arbitrary contemporaneous cross-occupation dependence.
 for level,c in [('occupation',np.arange(G)),('KECO_two_digit',codes)]:
  C=int(c.max())+1;sc=groupsum((x*u).sum(axis=1),c);st=(x*u).sum(axis=0);sct=groupsum(x*u,c);CT=C*T
  v=((C/(C-1))*np.sum(sc**2)+(T/(T-1))*np.sum(st**2)-(CT/(CT-1))*np.sum(sct**2))*(N-1)/(N-K)/D**2
  se=np.sqrt(v) if v>0 else np.nan;df=min(C-1,T-1);two.append(dict(target=name,cluster=level+' + month',coefficient=beta,se=se,p=2*t.sf(abs(beta/se),df),df=df,variance=v))
 # Monthly treated-control gap, retain November as a transition dummy for HAC calendar spacing.
 gap=full.groupby(['time','q5']).y.mean().unstack();gap['difference']=gap[1]-gap[0];gap['post']=(gap.index>'2022-11').astype(int);gap['transition']=(gap.index=='2022-11').astype(int);X=sm.add_constant(gap[['post','transition']])
 for lag in [6,12,18]:
  hm=sm.OLS(gap.difference,X).fit(cov_type='HAC',cov_kwds={'maxlags':lag,'use_correction':True},use_t=True);assert abs(hm.params['post']-beta)<1e-10;hac.append(dict(target=name,lag=lag,coefficient=beta,se=hm.bse['post'],p=hm.pvalues['post'],months=len(gap),df=hm.df_resid))
 # Diagnostic residual correlation, not a formal significance test.
 Cmat=np.corrcoef(u);upper=np.triu(np.ones((G,G),dtype=bool),1);same=codes[:,None]==codes[None,:]
 for key,mask in [('within_KECO_two_digit',upper&same),('between_KECO_two_digit',upper&~same)]:
  z=Cmat[mask];corrs.append(dict(target=name,pairs=len(z),type=key,mean_correlation=np.mean(z),median_correlation=np.median(z),positive_share=np.mean(z>0)))
 # Family-by-month FE sensitivity. Pure treatment groups do not identify this coefficient.
 def family_within(Z):
  z=Z-Z.mean(axis=1,keepdims=True)
  for k in range(codes.max()+1):z[codes==k]-=z[codes==k].mean(axis=0,keepdims=True)
  return z
 xf=family_within(q[:,None]*post);yf=family_within(Y);active=(np.sum(xf**2,axis=1)>1e-12);familyfe.append(dict(target=name,coefficient=np.sum(xf*yf)/np.sum(xf**2),active_occupations=int(active.sum()),active_q5=int(q[active].sum()),active_families=int(len(set(codes[active]))),note='Changed estimand; only mixed-treatment families identify it. No confirmatory p-value.'))
 # Store all raw monthly gaps for replication without microdata.
 gap.to_csv(P/(name+'_monthly_gap.csv'))
r=pd.DataFrame(rows)
for level in ['occupation','KECO_two_digit']:
 for wt in ['rademacher','webb']:
  ix=r.cluster.eq(level)&r.weights.eq(wt);r.loc[ix,'p_holm_three_requested_tests']=multipletests(r.loc[ix,'bootstrap_p'],method='holm')[1]
r.to_csv(P/'WILD_BOOTSTRAP_RESULTS.csv',index=False);pd.DataFrame(two).to_csv(P/'TWO_WAY_CLUSTER_RESULTS.csv',index=False);pd.DataFrame(hac).to_csv(P/'MONTHLY_GAP_HAC.csv',index=False);pd.DataFrame(corrs).to_csv(P/'RESIDUAL_CORRELATIONS.csv',index=False);pd.DataFrame(familyfe).to_csv(P/'FAMILY_MONTH_FE_DIAGNOSTIC.csv',index=False)
meta={'B':B,'seed':SEED,'method':'Null-imposed wild cluster restricted bootstrap WCR11, studentized CRV1. Full FE reprojection in every draw.','weights':['Rademacher','Webb six-point'],'unit':'105 occupations or 31 KECO two-digit families','pre':'2019-11 through 2022-10','post':'2022-12 through 2025-11','excluded':'2022-11 transition in panel DID; retained with a separate dummy in monthly-gap HAC','targets':targets,'validation':validation,'website_hash_before':site_before,'website_hash_after':hashlib.sha256(site.read_bytes()).hexdigest(),'original_analysis_overwritten':False,'multiple_testing':'Holm within three user-requested contrasts for each bootstrap variant; does not adjust prior selection/research-wide exploration','limitations':'Coarse occupational families are not industry controls. Seven treatment-containing families. Two-way month clustering handles contemporaneous dependence, not arbitrary cross-occupation serial dependence. Monthly HAC treats fixed occupation set as given.'};assert meta['website_hash_before']==meta['website_hash_after'];(P/'DESIGN_AND_VALIDATION.json').write_text(json.dumps(meta,indent=2));print(r[['target','cluster','weights','bootstrap_p','p_holm_three_requested_tests']].to_string(index=False))
