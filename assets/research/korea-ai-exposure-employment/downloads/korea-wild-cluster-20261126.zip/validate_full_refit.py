from pathlib import Path
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import numpy as np,pandas as pd,json
import statsmodels.formula.api as smf
from statsmodels.stats.sandwich_covariance import cov_cluster_2groups
P=Path(__file__).resolve().parent;H=P.parent
link=pd.read_csv(H/'45_korea_public_monthly_backfill_20261126/strict_quintile_linkage.csv',dtype={'keco2025':str});link['occupation']='2025직종_'+link.label;mapping=link.set_index('occupation').keco2025
rows=[]
two=pd.read_csv(P/'TWO_WAY_CLUSTER_RESULTS.csv')
cluster_checks=[]
for age,sex,target in [('age20_24','Female','female20_24_acquisitions'),('age25_29','Male','male25_29_acquisitions'),('age25_29','gap','age25_29_female_minus_male_employment')]:
 a=pd.read_csv(H/'47_korea_age_split_did_20261126'/age/'balanced_occupation_sex_month.csv')
 if sex=='gap':g=a.pivot(index=['occupation','time','rel','q5','post'],columns='sex',values='logn').reset_index();g['y']=g.Female-g.Male
 else:g=a[a.sex.eq(sex)].copy();base=g[g.rel.eq(0)].set_index('occupation').n;g['y']=100*g.acquisitions/g.occupation.map(base)
 g=g[g.rel.ne(0)].sort_values(['occupation','time']).copy();G=g.occupation.nunique();T=g.time.nunique();N=G*T;K=G+T
 null=smf.ols('y~C(occupation)+C(time)',data=g,eval_env=-1).fit();Y=null.resid.to_numpy().reshape(G,T);X=g.q5.to_numpy().reshape(G,T)*g.post.to_numpy().reshape(G,T);X=X-X.mean(axis=1,keepdims=True)-X.mean(axis=0,keepdims=True)+X.mean();occ=sorted(g.occupation.unique())
 mobs=smf.ols('y~C(occupation)+C(time)+q5:post',data=g,eval_env=-1).fit()
 for level,c in [('occupation',np.arange(G)),('KECO_two_digit',pd.Categorical([mapping.loc[o][:2] for o in occ]).codes)]:
  vc,_,_=cov_cluster_2groups(mobs,np.repeat(c,T),np.tile(np.arange(T),G));j=mobs.params.index.get_loc('q5:post');target_v=two[(two.target==target)&two.cluster.eq(level+' + month')].variance.iloc[0];assert abs(vc[j,j]-target_v)<1e-10;cluster_checks.append(dict(target=target,cluster=level,variance_error=abs(vc[j,j]-target_v)))
  C=int(c.max())+1;w=np.random.default_rng(7491).choice([-1.,1.],C);g['ystar']=null.fittedvalues.to_numpy()+null.resid.to_numpy()*np.repeat(w[c],T);g['cluster']=np.repeat(c,T)
  m=smf.ols('ystar~C(occupation)+C(time)+q5:post',data=g,eval_env=-1).fit(cov_type='cluster',cov_kwds={'groups':g.cluster},use_t=True)
  us=Y*w[c,None];us=us-us.mean(axis=1,keepdims=True)-us.mean(axis=0,keepdims=True)+us.mean();D=np.sum(X*X);b=np.sum(X*us)/D;u=us-b*X;score=np.zeros(C);np.add.at(score,c,(X*u).sum(axis=1));se=np.sqrt(C/(C-1)*(N-1)/(N-K)*np.sum(score*score))/D
  assert abs(b-m.params['q5:post'])<1e-10;assert abs(se-m.bse['q5:post'])<1e-10
  rows.append(dict(target=target,cluster=level,beta_error=abs(b-m.params['q5:post']),se_error=abs(se-m.bse['q5:post'])))
(P/'FULL_DUMMY_BOOTSTRAP_REFIT_CHECKS.json').write_text(json.dumps({'bootstrap_refits':rows,'two_way_CGM_checks':cluster_checks},indent=2));print('Six null-imposed full-dummy bootstrap refits matched coefficients and clustered SE')
