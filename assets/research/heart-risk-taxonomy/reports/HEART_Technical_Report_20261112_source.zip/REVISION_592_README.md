# HEART Technical Report

The final taxonomy contains 592 active bilingual risk cards in 55 L3 categories. Domain counts are General 481, Agentic 58, and Physical 53. The evidence flow is 3,610,449 AI documents, 82,971 risk documents, and 592 final risk cards.

Compile the main.tex at the project root with XeLaTeX and BibTeX. Appendix A and the released CSV and JSON use the same L0 to L3 definitions. Section 5.4 reports the measured structural consistency checks of the final taxonomy. The report does not present automatic assignment performance for the current inventory.

All seven active figures have been audited, including text inside raster and vector assets. The service-mapping figure is generated from its original SVG and included as vector PDF. The architecture figure is regenerated from its authored Python code with Responsible AI Governance at L0.

Earlier experiment records and prior source versions are preserved separately from this final report. The nested older result and appendix files are inactive archival copies. Appendix C remains excluded.
