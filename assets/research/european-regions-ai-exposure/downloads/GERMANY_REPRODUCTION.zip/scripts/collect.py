from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import requests,json,hashlib,shutil,time
R=Path(__file__).resolve().parents[1]
def go(date):
 p=R/'raw'/f'BA_d_{date}.xlsx';u=f'https://statistik.arbeitsagentur.de/Statistikdaten/Detail/{date}/iiia6/beschaeftigung-sozbe-bo-heft/bo-heft-d-0-{date}-xlsx.xlsx'
 old=R.parents[1]/'01_data/software_age_gap_collection_20261125/raw'/f'DE_BA_BO_HEFT_d_{date}.xlsx'
 try:
  if not p.exists():
   if old.exists():shutil.copy2(old,p)
   else:
    r=requests.get(u,timeout=(10,30));r.raise_for_status();assert r.content.startswith(b'PK');p.write_bytes(r.content)
  return dict(date=date,url=u,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 except Exception as e:return dict(date=date,url=u,error=str(e))
dates=[f'{y}{m:02d}' for y in range(2013,2027) for m in [3,6,9,12] if f'{y}{m:02d}'<='202603']
rows=[]
for dt in dates:
 a=go(dt);rows.append(a);print(a['date'],a.get('bytes',a.get('error')),flush=True)
 if '429' in a.get('error',''):break
 time.sleep(1)
(R/'metadata/DOWNLOADS.json').write_text(json.dumps(rows,indent=2))
