"""Observed BA snapshots, deterministic crosswalk, conditional Poisson age DDD.
No interpolation or moving average is fabricated from missing quarters.
"""
from pathlib import Path
import re,json
import numpy as np,pandas as pd,openpyxl
from scipy import sparse,linalg,stats
from scipy.special import expit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1]; C=R.parents[1]
P=R/'metadata'
S=pd.read_csv(R/'metadata/THAIE_ISCO3_OUR_SCORES.csv',dtype={'isco3':str})
maps=[]
for v in ['F1','F2020']:
 d=pd.read_csv(P/f'PAIRS_DE_KLDB2010_{v}_4d.csv',dtype=str)
 d=d[d.n_isco3_for_source=='1'][['source_code','isco08_3digit']].drop_duplicates();maps.append(d)
m=maps[0].merge(maps[1],on=['source_code','isco08_3digit']).rename(columns={'source_code':'code','isco08_3digit':'isco3'}).merge(S,on='isco3')
assert not m.code.duplicated().any()
rows=[];totals=[]
for p in sorted((R/'raw').glob('*.xlsx')):
 date=p.stem[-6:];w=openpyxl.load_workbook(p,read_only=True,data_only=True);sh=w['SVB - Tabelle I']
 allr=list(sh.values)
 for j,r in enumerate(allr):
  if str(r[0]).strip()=='Insgesamt':totals.append(dict(date=date,total=r[1],under25=r[6],age25_54=r[7],age55_64=r[8],age65plus=r[9],apprentices=r[11]));break
 for j,r in enumerate(allr):
  ma=re.match(r'^\s*(\d{4})(?:\s|$)',str(r[0]))
  if ma:
   def val(x): return float(x) if isinstance(x,(int,float)) and x>=0 else np.nan
   rows.append(dict(date=date,code=ma.group(1),label=r[0],source_file=p.name,source_sheet=sh.title,source_row=j+1,total=val(r[1]),under25=val(r[6]),age25_54=val(r[7]),age55_64=val(r[8]),age65plus=val(r[9]),apprentices=val(r[11])))
a=pd.DataFrame(rows);assert not a.duplicated(['date','code']).any();a.to_csv(R/'derived/ALL_NATIVE_KLDB4_SNAPSHOTS.csv',index=False)
pd.DataFrame(totals).to_csv(R/'derived/SOURCE_TOTALS.csv',index=False)
a=a.merge(m,on='code',how='left',indicator=True);a['age25_64']=a.age25_54+a.age55_64;a['under65']=a.under25+a.age25_64
# Fixed cohort, any suppressed constituent excludes occupation at every date.
good=a[(a._merge=='both')&a[['under25','age25_54','age55_64']].notna().all(axis=1)].groupby('code').date.nunique();codes=good[good==a.date.nunique()].index
x=a[a.code.isin(codes)].copy();u=x[['isco3','THAIE']].drop_duplicates().sort_values(['THAIE','isco3']);u['quintile']=pd.qcut(u.THAIE.rank(method='first'),5,labels=range(1,6)).astype(int)
u['z']=(u.THAIE-u.THAIE.mean())/u.THAIE.std(ddof=0);x=x.merge(u[['isco3','quintile','z']],on='isco3')
x.to_csv(R/'derived/FIXED_ANALYSIS_COHORT.csv',index=False);u.to_csv(R/'derived/FIXED_THAIE_QUINTILES.csv',index=False)
coverage=[]
for dt,d in a.groupby('date'):
 selected=x[x.date==dt]
 coverage.append(dict(date=dt,all_native4=len(d),mapped4=(d._merge=='both').sum(),fixed4=len(selected),source_total=float(pd.DataFrame(totals).set_index('date').loc[dt,'total']),fixed_total=selected.total.sum(),coverage_total=selected.total.sum()/float(pd.DataFrame(totals).set_index('date').loc[dt,'total']),missing_under25=d.under25.isna().sum(),missing_25_54=d.age25_54.isna().sum(),missing_55_64=d.age55_64.isna().sum()))
pd.DataFrame(coverage).to_csv(R/'derived/COVERAGE_AND_MISSINGNESS.csv',index=False)
# Snapshot contrasts, never called a four-quarter moving average.
agg=x.groupby(['date','quintile'])[['under25','age25_54','age55_64','under65']].sum();res=[]
for age in ['under25','age25_54','age55_64','under65']:
 tab=agg[age].unstack('quintile');gap=100*np.log(tab[5]/tab[1]);gap-=gap.loc['202206']
 for dt,v in gap.items():res.append(dict(date=dt,age=age,logpoint_gap=v,relative_pct=100*np.expm1(v/100)))
gaps=pd.DataFrame(res);gaps.to_csv(R/'derived/PANEL_A_OBSERVED_GAPS.csv',index=False)
# Profile occupation-by-date Poisson FE out by conditioning on two age-group totals.
# The binomial log odds equals alpha_occ + gamma_date + beta_date*z.
def fit(old):
 d=x.sort_values(['code','date']).copy();oc=pd.Categorical(d.code);ts=sorted(d.date.unique());G=len(oc.categories);years=[t for t in ts if t!='202206'];n=len(d)
 mat=[sparse.csr_matrix((np.ones(n),(np.arange(n),oc.codes)),shape=(n,G))]
 for t in years:mat.append(sparse.csr_matrix((d.date==t).astype(float).to_numpy()[:,None]))
 for t in years:mat.append(sparse.csr_matrix(((d.date==t)*d.z).to_numpy()[:,None]))
 X=sparse.hstack(mat,format='csr');Y=d.under25.to_numpy();N=(d.under25+d[old]).to_numpy();theta=np.zeros(X.shape[1]);theta[:G]=np.log((Y.sum()+1)/(N.sum()-Y.sum()+1))
 def objective(b):
  eta=X@b;return float(np.sum(N*np.logaddexp(0,eta)-Y*eta))
 converged=False
 for it in range(80):
  prob=expit(X@theta);score=X.T@(Y-N*prob);H=(X.T@X.multiply((N*prob*(1-prob))[:,None])).toarray();step=linalg.solve(H,score,assume_a='pos');scale=1.;obj=objective(theta)
  while objective(theta+scale*step)>obj+1e-6 and scale>1e-7:scale*=.5
  theta+=scale*step
  if np.max(np.abs(scale*step))<1e-9:converged=True;break
 assert converged,(old,it)
 prob=expit(X@theta);H=(X.T@X.multiply((N*prob*(1-prob))[:,None])).toarray();bread=linalg.inv(H)
 sc=X.multiply((Y-N*prob)[:,None]).toarray();cluster=pd.Categorical(d.isco3);sg=np.zeros((len(cluster.categories),X.shape[1]));np.add.at(sg,cluster.codes,sc)
 K=len(cluster.categories);cov=bread@(sg.T@sg)@bread*K/(K-1);se=np.sqrt(np.diag(cov));crit=stats.t.ppf(.975,K-1);ans=[]
 for i,t in enumerate(years):
  j=G+len(years)+i;b=theta[j];zse=se[j];pv=2*stats.t.sf(abs(b/zse),K-1)
  ans.append(dict(comparator=old,date=t,beta=b,se=zse,logpoints=100*b,ci_low_logpoints=100*(b-crit*zse),ci_high_logpoints=100*(b+crit*zse),effect_pct=100*np.expm1(b),p=pv,isco_clusters=K,n_count_cells=2*n,conditional_cells=n,iterations=it+1))
 return ans
est=pd.DataFrame(fit('age25_64')+fit('age55_64'));est['holm4_p']=np.nan
order=est.p.sort_values().index;adj=np.maximum.accumulate(np.minimum(1,est.loc[order,'p'].to_numpy()*np.arange(len(est),0,-1)));est.loc[order,'holm4_p']=adj
est.to_csv(R/'derived/PANEL_B_CONDITIONAL_POISSON_DDD.csv',index=False)
# Publication figure uses disconnected observed points, with no fictional intervening quarters.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,axs=plt.subplots(1,2,figsize=(13,5.7));dates=['202006','202206','202603'];pos=[2020+5/12,2022+5/12,2026+2/12];labels=['Jun 2020','Jun 2022','Mar 2026'];colors=['#b4434c','#c18c91','#777f84','#b4b8bb'];names=['Under 25','25–54','55–64','Under 65']
for age,c,l in zip(['under25','age25_54','age55_64','under65'],colors,names):
 vals=gaps[gaps.age==age].set_index('date').loc[dates,'logpoint_gap'];axs[0].scatter(pos,vals,label=l,color=c,s=42)
axs[0].set(title='A  Observed Q5–Q1 employment gap',ylabel='Log points relative to June 2022')
for k,(comp,c,l,off) in enumerate([('age25_64','#b4434c','Under 25 versus 25–64',-.07),('age55_64','#577987','Under 25 versus 55–64',.07)]):
 e=est[est.comparator==comp].set_index('date')
 for dt,p0 in zip(dates,pos):
  if dt=='202206':axs[1].scatter([p0+off],[0],color=c,s=35);continue
  rr=e.loc[dt];axs[1].errorbar(p0+off,rr.logpoints,yerr=[[rr.logpoints-rr.ci_low_logpoints],[rr.ci_high_logpoints-rr.logpoints]],fmt='o',color=c,capsize=4,label=l if dt=='202006' else None)
axs[1].set(title='B  Snapshot age DDD, continuous THAIE',ylabel='Log points per SD of THAIE')
for ax in axs:
 ax.axhline(0,color='#999999',lw=.8);ax.set_xticks(pos,labels);ax.grid(axis='y',alpha=.18);ax.legend(frameon=False,fontsize=8);ax.set_xlim(2019.8,2026.7)
fig.suptitle('Germany | THAIE-linked BA employment snapshots',fontsize=15,fontweight='bold');fig.text(.04,.10,f'Fixed sample of {x.code.nunique()} KldB4 occupations ({x.isco3.nunique()} ISCO3 groups). Social-insurance employment, including part-time and apprentices.',fontsize=9)
fig.text(.04,.065,'Only three observed snapshots. No four-quarter moving average or long-pre-period event study is available. June 2022 = 0; not November 2022.',fontsize=9)
fig.text(.04,.03,'DDD intervals cluster by ISCO3. March-versus-June seasonality and crosswalk selection limit inference. No causal AI-displacement claim.',fontsize=9)
fig.subplots_adjust(bottom=.25,wspace=.26,top=.85)
for ext in ['png','svg','pdf']:fig.savefig(R/'figures'/f'GERMANY_OBSERVED_SNAPSHOT_ANALYSIS.{ext}',dpi=240,bbox_inches='tight')
plt.close(fig)
audit=dict(native_rows=len(a),fixed_occupation_count=x.code.nunique(),isco3_count=x.isco3.nunique(),dates=dates,source_rows=len(x),age_count_cells=len(x)*3,reference='2022-06',four_quarter_MA_available=False,exact_report_reproduction=False,continuous_DDD='conditional binomial profile likelihood of Poisson with occupation-date FE',suppression='missing, never zero-filled',quantiles='equal count of mapped ISCO3 occupations, fixed across snapshots',standardization='unweighted mean and SD across mapped ISCO3 occupations')
(R/'validation/ANALYSIS_AUDIT.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit));print(est.to_string(index=False));print(pd.DataFrame(coverage).to_string(index=False))
