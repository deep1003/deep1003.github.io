from pathlib import Path
import shutil,pandas as pd,json,zipfile,hashlib
from bs4 import BeautifulSoup
root=Path('/Users/deep1003/Library/Mobile Documents/com~apple~CloudDocs/data3');R=root/'Cambridge/06_execution/germany_econpol_style_20261126';W=Path('/tmp/germany-econpol-20261126');S=W/'assets/research/european-regions-ai-exposure'
# Preserve all numeric inputs and eliminate temporary-worktree dependencies.
for v in ['F1','F2020']:
 shutil.copy2(root/f'Cambridge/01_data/agent_search_20261119/E_crosswalks_geo/derived/pairs/PAIRS_DE_KLDB2010_{v}_4d.csv',R/'metadata'/f'PAIRS_DE_KLDB2010_{v}_4d.csv')
shutil.copy2(S/'downloads/THAIE_ISCO3_OUR_SCORES.csv',R/'metadata/THAIE_ISCO3_OUR_SCORES.csv')
f=R/'scripts/analyse.py';t=f.read_text().replace("P=C/'01_data/agent_search_20261119/E_crosswalks_geo/derived/pairs'","P=R/'metadata'").replace("pd.read_csv('/tmp/europe-literature-20261126/assets/research/european-regions-ai-exposure/downloads/THAIE_ISCO3_OUR_SCORES.csv'","pd.read_csv(R/'metadata/THAIE_ISCO3_OUR_SCORES.csv'");f.write_text(t)
e=pd.read_csv(R/'derived/PANEL_B_CONDITIONAL_POISSON_DDD.csv',dtype={'date':str});cov=pd.read_csv(R/'derived/COVERAGE_AND_MISSINGNESS.csv')
readme='''# 독일 보고서 방식 적용 및 재현 가능 범위

2026년 11월 26일. 원고는 수정하지 않았다.

## 수행한 분석

BA의 독일 전국 사회보험 취업자 공개 원표에서 2020년 6월, 2022년 6월, 2026년 3월의 직업×연령 주변표를 추출했다. 공식 KldB 2010 초판과 2020판 대응표에서 동일한 단일 ISCO3로 대응되는 KldB4만 남기고, 세 시점 모두 25세 미만·25~54세·55~64세 값이 공개된 262개 세부 직업을 고정했다. 85개 ISCO3 점수를 우리 THAIE와 연결했다. 2022년 전체 사회보험 취업자 대비 포함률은 19.22%이다. 이는 독일 전체를 대표하는 표본이 아니다. 분류 대응이 같아도 업무 내용의 완전한 시계열 불변성이 입증되는 것은 아니다.

분위는 포함된 ISCO3 직업 수 기준으로 동일 크기에 가깝게 나눠 세 시점에 고정했다. 동일 ISCO3에 속하는 KldB4에는 같은 점수·분위를 부여했다. 모호한 대응은 강제로 평균하거나 임의 배분하지 않았다. 원표의 비공개·비수치는 결측으로 유지하고, 분석 필수 연령의 결측 직업은 모든 시점에서 제외했다. 서로 포함되는 KldB3와 KldB4를 동시에 합산하지 않았다.

Panel A는 연령별 Q5/Q1 고용비의 로그 변화 ×100이며 2022년 6월을 0으로 했다. 2026년 3월 청년 격차는 양수일 수 있어도, 성인보다 상대적으로 약하면 DDD는 음수일 수 있다. 단순 Q5 고용의 절대 감소와 다르다.

Panel B는 연속 표준화 THAIE×청년×시점 DDD이다. 직업×시점 Poisson 고정효과를 프로파일링하면 청년·성인 두 집단의 조건부 이항 모형으로 계산할 수 있다. log(청년 기대 고용/성인 기대 고용) = 직업 효과 + 시점 효과 + THAIE 표준화점수×시점 효과. 따라서 직업×시점, 연령×시점, 직업×연령을 통제한 Poisson과 동일한 계수 구조이다. 주 비교는 25세 미만 대 25~64세, 보조 비교는 55~64세이다. 추가적인 2022년 WLS 가중치를 곱하지 않고 원래 고용량 우도를 사용한다. 표준화는 85개 ISCO3의 비가중 평균·표준편차 기준이다. 표준오차는 점수의 공통 단위인 ISCO3로 군집화하고 t(84) 신뢰구간을 표시한다. 네 비기준 계수의 Holm 보정도 제공한다.

## 결과

'''
for _,r in e[e.date=='202603'].iterrows():readme+=f"- 비교집단 {r.comparator}. 1 SD당 로그포인트 {r.logpoints:.3f}, 95% 구간 [{r.ci_low_logpoints:.3f}, {r.ci_high_logpoints:.3f}], 상대 변화율 {r.effect_pct:.3f}%, p={r.p:.4f}, Holm p={r.holm4_p:.4f}.\n"
readme+='''
두 비교 모두 통계적으로 유의하지 않다. 2020년 대비 계수가 유의하지 않다는 사실은 평행추세 검증 통과를 뜻하지 않는다. 사전 시점이 하나이고 COVID 시기이므로 장기 사전추세나 위약 검정은 불가능하다. 2026년 3월과 2022년 6월은 계절도 다르며 이를 식별해서 통제할 만큼 충분한 관측시점이 없다.

## 보고서와의 차이 및 미완료 범위

| 항목 | EconPol 61 | 이번 확보 자료 |
|---|---|---|
| 기간 | 2013Q1~2026Q1 연속 분기 | 2020-06, 2022-06, 2026-03 세 시점 |
| 청년 | 20~24세 | 25세 미만, 20세 미만 포함 |
| 고용 범위 | 전일제, 도제 제외 | 사회보험 취업자, 시간제와 도제 포함 |
| 점수 | Eloundou 기반 노출 | 우리 THAIE |
| 기준 | 기술통계 2022Q3, 회귀 2022년 | 2022년 6월 |
| 지역 | 독일 전국 행정자료 | 전국표의 엄격 대응·공개 셀 부분집합 |
| 이동평균 | 네 분기 | 구성 불가능, 적용하지 않음 |
| 사건연구 | 장기 사전 기간 | 세 시점 DDD, 장기 동적 사건연구 아님 |

2022년 11월 관측값이 없으므로 그 기준으로 표기하지 않았다. 누락된 분기를 보간하거나 연간·세 시점 자료를 이동평균으로 가장하지 않았다. 연령 주변합과 전일제 주변합을 곱해 공동표를 추정하지 않았고, 전체 도제 수를 전부 청년에게서 빼지도 않았다. 이 분석을 보고서의 정확한 재현이나 AI의 인과적 대체 효과로 인용해서는 안 된다.

추가 분기 원표 요청은 BA 서버가 HTTP 429로 제한했다. 일반 Chrome에서도 공식 사이트가 과도한 접근 안내를 표시했다. 접속 제한을 우회하지 않았다. 월별 데이터베이스의 공동교차 추출도 기존 시험에서 확보되지 않았다. 후속 수집기는 429 첫 응답에서 중지하도록 설정했다. 완전한 재현을 위해 직업×20~24/25~64세×전일제×도제 제외의 2013Q1~2026Q1 공동표가 필요하다.

## 검증과 재현

scripts/analyse.py와 scripts/validate.py를 실행한다. 필요 패키지는 pandas, numpy, scipy, openpyxl, matplotlib, statsmodels이다. metadata에 사용한 점수·공식 대응표를 보존했다. 독립적인 statsmodels 이항 GLM으로 회귀 계수를 대조한다. 연령 합계와 총계에는 2022·2026년 각각 한 셀의 1명 잔차가 발견돼 기록하며 임의로 배분하지 않았다. 65세 이상 결측은 이번 회귀에 사용하지 않는다. 출처 파일·시트·행 번호를 추출표에 남겼다.

공식 표 목록 https://statistik.arbeitsagentur.de/SiteGlobals/Forms/Suche/Einzelheftsuche/Einzelheftsuche_Formular.html?topic_f=beschaeftigung-sozbe-bo-heft
보고서 https://www.ifo.de/en/econpol/publications/2026/working-paper/ai-and-labor-market-productivity-driver-or-job-killer
'''
(R/'REPORT_KO.md').write_text(readme)
for f in ['GERMANY_OBSERVED_SNAPSHOT_ANALYSIS.png','GERMANY_OBSERVED_SNAPSHOT_ANALYSIS.svg','GERMANY_OBSERVED_SNAPSHOT_ANALYSIS.pdf']:shutil.copy2(R/'figures'/f,S/'figures'/f)
for f in ['PANEL_A_OBSERVED_GAPS.csv','PANEL_B_CONDITIONAL_POISSON_DDD.csv','COVERAGE_AND_MISSINGNESS.csv']:shutil.copy2(R/'derived'/f,S/'downloads'/('GERMANY_'+f))
shutil.copy2(R/'REPORT_KO.md',S/'downloads/GERMANY_REPORT_KO.md')
p=S/'index.html';s=BeautifulSoup(p.read_text(),'html.parser')
block='''<details id="germany-econpol-analysis"><summary>Germany · THAIE-linked employment gaps and age DDD · observed snapshots</summary><div class="prose"><p><strong>Partial implementation of the EconPol comparison structure, not a reproduction of its full-time 20–24-year-old sample.</strong> Three BA national snapshots are available: June 2020, June 2022 and March 2026. The fixed cohort contains 262 KldB4 occupations mapped unambiguously to 85 ISCO3 groups under both official crosswalk editions. It covers 19.22% of German social-insurance employment in June 2022. The exposure measure is our THAIE. This selected subset does not represent all German employment.</p><p>Panel A compares Q5 with Q1 by age, relative to June 2022. Panel B estimates continuous-exposure age DDD using the conditional profile likelihood of Poisson employment counts, with occupation-by-time, age-by-time and occupation-by-age effects. Uncertainty clusters by ISCO3. The main contrast is under 25 versus ages 25–64; ages 55–64 provide a supplementary comparison.</p><img style="width:100%;height:auto" loading="lazy" src="figures/GERMANY_OBSERVED_SNAPSHOT_ANALYSIS.png" alt="Germany three observed snapshots, Q5 versus Q1 log employment gaps and continuous THAIE age DDD with confidence intervals"/><table><thead><tr><th>March 2026 versus June 2022</th><th>Log points per SD</th><th>95% CI, log points</th><th>Relative change</th><th>p</th><th>Holm p, four tests</th></tr></thead><tbody><tr><td>Under 25 versus 25–64</td><td>−3.017</td><td>−9.461 to +3.427</td><td>−2.97%</td><td>.3545</td><td>1.000</td></tr><tr><td>Under 25 versus 55–64</td><td>−3.061</td><td>−9.276 to +3.155</td><td>−3.01%</td><td>.3303</td><td>1.000</td></tr></tbody></table><p><strong>Neither contrast is statistically significant.</strong> A positive Q5–Q1 youth gap in Panel A can coexist with a negative age DDD when the adult exposure gap rises more. These are different comparisons, not evidence that youth employment necessarily fell in absolute terms.</p><p>The public age bands include workers under 20, part-time employees and apprentices. Age-specific full-time employment excluding apprentices cannot be reconstructed from separate margins. The source has no November 2022 observation for this selection. Missing quarters are not interpolated, and no four-quarter moving average is calculated. One COVID-period pre-observation cannot establish parallel trends; March-versus-June seasonality is unresolved. Additional BA downloads currently return HTTP 429, including the ordinary browser. Full report-style quarterly analysis remains unavailable pending the required joint table.</p><p><a href="downloads/GERMANY_REPORT_KO.md">Methods, coverage and limitations (Korean)</a> · <a href="downloads/GERMANY_PANEL_B_CONDITIONAL_POISSON_DDD.csv">DDD estimates</a> · <a href="downloads/GERMANY_PANEL_A_OBSERVED_GAPS.csv">Observed gaps</a> · <a href="downloads/GERMANY_COVERAGE_AND_MISSINGNESS.csv">Coverage and missingness</a> · <a href="downloads/GERMANY_REPRODUCTION.zip">Data and analysis code</a> · <a href="figures/GERMANY_OBSERVED_SNAPSHOT_ANALYSIS.pdf">Figure PDF</a></p><p>Sources: <a href="https://statistik.arbeitsagentur.de/SiteGlobals/Forms/Suche/Einzelheftsuche/Einzelheftsuche_Formular.html?topic_f=beschaeftigung-sozbe-bo-heft">Bundesagentur für Arbeit, Beschäftigte nach Berufen</a>; <a href="https://www.ifo.de/en/econpol/publications/2026/working-paper/ai-and-labor-market-productivity-driver-or-job-killer">Falck, Fuest and Guo, EconPol 61 (2026)</a>.</p></div></details>'''
assert not s.find(id='germany-econpol-analysis');s.find(id='results').append(BeautifulSoup(block,'html.parser'));p.write_text(str(s))
print('Added collapsed German snapshot analysis with explicit full-replication limitations.')
