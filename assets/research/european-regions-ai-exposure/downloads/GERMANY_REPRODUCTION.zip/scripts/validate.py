from pathlib import Path
import pandas as pd,numpy as np,statsmodels.api as sm,json,openpyxl
R=Path(__file__).resolve().parents[1];x=pd.read_csv(R/'derived/FIXED_ANALYSIS_COHORT.csv',dtype={'date':str,'code':str,'isco3':str}).sort_values(['code','date']);e=pd.read_csv(R/'derived/PANEL_B_CONDITIONAL_POISSON_DDD.csv',dtype={'date':str})
assert len(x)==786 and x.groupby('date').code.nunique().nunique()==1
assert not x.duplicated(['date','code']).any()
assert (x[['under25','age25_54','age55_64']]>=0).all().all()
age_residual=x.total-x.under65-x.age65plus
assert (age_residual.dropna().between(0,1)).all()
# Verify all source headers before trusting column positions.
headers={}
for p in (R/'raw').glob('*.xlsx'):
 w=openpyxl.load_workbook(p,read_only=True,data_only=True);s=w['SVB - Tabelle I'];r=list(s.values);h=' '.join(str(v) for v in r[9][6:10]);assert '25' in h and '55' in h and '65' in h;headers[p.name]=h
X=pd.get_dummies(x.code,dtype=float);dates=['202006','202603']
for t in dates:X['time'+t]=(x.date==t).astype(float)
for t in dates:X['interaction'+t]=(x.date==t)*x.z
N=x.under25+x.age25_64
f=sm.GLM(x.under25/N,X,family=sm.families.Binomial(),var_weights=N).fit(maxiter=100,atol=1e-6,rtol=1e-10)
errors={t:float(abs(f.params['interaction'+t]-e[(e.comparator=='age25_64')&(e.date==t)].beta.iloc[0])) for t in dates};assert max(errors.values())<1e-7
assert f.converged
v=dict(rows=len(x),unique_keys=True,balanced_occupations=True,age_sum_residual_max=float(age_residual.max()),age_sum_residual_nonzero=int((age_residual.fillna(0)!=0).sum()),age65_missing=int(x.age65plus.isna().sum()),source_headers=headers,independent_statsmodels_conditional_fit_max_errors=errors,converged=bool(f.converged),moving_average_not_constructed=True)
(R/'validation/INDEPENDENT_VALIDATION.json').write_text(json.dumps(v,indent=2));print(json.dumps(v,indent=2))
