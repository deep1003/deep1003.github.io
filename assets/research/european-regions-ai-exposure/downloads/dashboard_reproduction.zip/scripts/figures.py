"""Publication-quality figures from our own official-source indices and THAIE."""

from pathlib import Path
import pandas as pd, numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.dates import YearLocator, DateFormatter

R = Path(__file__).resolve().parents[1]
D = R / "derived"
P = (
    R.parents[1].parent
    / "deep1003.github.io/assets/research/european-regions-ai-exposure"
)
(P / "figures").mkdir(exist_ok=True)
colors = ["#9e1b1b", "#587b99", "#ef5435", "#e7a000", "#431b1b"]
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "pdf.fonttype": 42,
        "svg.fonttype": "none",
    }
)
m = pd.read_csv(D / "se_monthly.csv")
m["date"] = pd.to_datetime(m.time)


def draw(ax, q, title):
    for j, (series, g) in enumerate(q.groupby("series", sort=True)):
        ax.plot(g.date, g["index"], label=series, color=colors[j % 5], lw=1.7)
    ax.axhline(100, color=".7", lw=0.7)
    ax.axvline(pd.Timestamp("2022-11-30"), color=".4", lw=0.8, ls=":")
    ax.set_title(title, loc="left", fontsize=11)
    ax.grid(axis="y", alpha=0.17)
    ax.xaxis.set_major_locator(YearLocator())
    ax.xaxis.set_major_formatter(DateFormatter("%Y"))
    ax.set_ylabel("Index (2022 mean = 100)")


def save(fig, name):
    for ext in ["png", "pdf", "svg"]:
        fig.savefig(R / "figures" / f"{name}.{ext}", dpi=260, bbox_inches="tight")
        fig.savefig(P / "figures" / f"{name}.{ext}", dpi=260, bbox_inches="tight")
    plt.close(fig)


fig, ax = plt.subplots(figsize=(9, 5))
draw(
    ax,
    m[(m.geo == "SE") & (m.age == "20–64") & (m.sex == "T")],
    "Monthly employment by regional THAIE quintile | Sweden, ages 20–64",
)
ax.legend(ncol=5, frameon=False, loc="upper left")
fig.subplots_adjust(bottom=0.23)
fig.text(
    0.03,
    0.04,
    "Source: Statistics Sweden ArbStatusM, 21 counties. Our THAIE 2025 uses fixed 2022 occupational weights.\nAll occupations within regions; not monthly software employment. Native monthly observations; no interpolation.\nEach series is rebased to its own 2022 annual mean. Dashed marker indicates 30 November 2022, not a causal design.",
    fontsize=8,
)
save(fig, "01_monthly_regional_exposure")
fig, axes = plt.subplots(2, 3, figsize=(13, 8), sharex=True)
ages = ["20–24", "25–29", "30–34", "35–44", "45–49", "50–64"]
for ax, age in zip(axes.flat, ages):
    draw(ax, m[(m.geo == "SE") & (m.age == age) & (m.sex == "T")], age)
handles, labels = axes.flat[0].get_legend_handles_labels()
fig.legend(
    handles,
    labels,
    ncol=5,
    loc="lower center",
    bbox_to_anchor=(0.5, 0.11),
    frameon=False,
)
fig.subplots_adjust(bottom=0.21, wspace=0.25, hspace=0.32)
fig.suptitle(
    "Monthly employment at fixed observed ages, by regional THAIE quintile", fontsize=14
)
fig.text(
    0.035,
    0.035,
    "Sweden, 21 counties, all occupations. The age bands are the actual official groups, not the requested 22–25, 26–30, 31–34, 35–40, 41–49, 50+.\nOnly regional exposure is observed monthly. All exposures and quintiles use our THAIE; no Stanford/ADP employment or exposure data.",
    fontsize=9,
)
save(fig, "02_monthly_fixed_observed_age_groups")
fig, axes = plt.subplots(1, 2, figsize=(12, 5), sharey=True)
for ax, sex, title in zip(axes, ["F", "M"], ["Women, ages 20–24", "Men, ages 20–24"]):
    draw(ax, m[(m.geo == "SE") & (m.age == "20–24") & (m.sex == sex)], title)
handles, labels = axes[0].get_legend_handles_labels()
fig.legend(
    handles,
    labels,
    ncol=5,
    loc="lower center",
    bbox_to_anchor=(0.5, 0.12),
    frameon=False,
)
fig.subplots_adjust(bottom=0.24, wspace=0.15)
fig.text(
    0.03,
    0.035,
    "Source sex categories; regional THAIE quintiles. Sweden only, all occupations; not individual occupation exposure.\nSource counts and the actual monthly 2022 baseline are retained. No monthly software or exact-age cells are fabricated.",
    fontsize=9,
)
save(fig, "03_monthly_age_fixed_sex_comparison")
s = pd.read_csv(D / "SOFTWARE_NATIVE_ALL_SERIES.csv", dtype={"geo": str})
fig, axes = plt.subplots(1, 2, figsize=(12, 5))
u = s[(s.geo == "UK") & s.kind.eq("UK_SOC_2134")]
axes[0].plot(u.time, u["index"], "o-", color="#431b1b")
axes[0].set_title("UK software development professionals | SOC2020 2134", fontsize=10)
w = s[s.geo.eq("00") & s.kind.eq("SE_broad_251") & s.sex.eq("T") & s.age.ne("16–64")]
for (age, g), color in zip(
    w.groupby("age", sort=False),
    ["#9e1b1b", "#587b99", "#ef5435", "#e7a000", "#431b1b", "#b4a494"],
):
    axes[1].plot(g.time, g["index"], "o-", label=age, color=color)
axes[1].set_title("Sweden broader software-related group | SSYK251", fontsize=10)
axes[1].legend(fontsize=8, frameon=False, ncol=2)
for ax in axes:
    ax.axhline(100, color=".7", lw=0.8)
    ax.set_ylabel("Annual employment index (2022 source baseline = 100)")
    ax.set_xlabel("Source reference year")
    ax.grid(axis="y", alpha=0.17)
fig.subplots_adjust(bottom=0.25, wspace=0.25)
fig.text(
    0.025,
    0.035,
    "UK: published national totals, annual windows ending June; no detailed age-by-sex split. SOC2010 pre-2022 values are not linked across the break.\nSweden: annual native SSYK251 is broader than exact software developers (SSYK2512). Actual ages are shown; 2023 provider-imputed occupations are flagged.\nThese are separate sources and populations, not estimates of a common AI effect.",
    fontsize=8.5,
)
save(fig, "04_native_software_occupation_paths")
print("Saved four fresh official-source figure sets")
