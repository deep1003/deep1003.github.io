from pathlib import Path
import requests, json, hashlib

R = Path(__file__).resolve().parents[1]
B = R.parents[1]
url = "https://api.scb.se/OV0104/v1/doris/en/ssd/AM/AM0208/AM0208M/YREG60BAS"
m = json.loads((B / "01_data/national_20261118/metadata/SE_YREG60BAS.json").read_text())
query = {
    "query": [
        {"code": v["code"], "selection": {"filter": "item", "values": v["values"]}}
        for v in m["variables"]
    ],
    "response": {"format": "json-stat2"},
}
(R / "metadata/SCB_EXACT_SOFTWARE.query.json").write_text(json.dumps(query, indent=2))
p = R / "raw/SCB_YREG60BAS_all.json"
if not p.exists():
    x = requests.post(url, json=query, timeout=(15, 90))
    x.raise_for_status()
    x.json()
    p.write_bytes(x.content)
(R / "metadata/SCB_EXACT_SOFTWARE_DOWNLOAD.json").write_text(
    json.dumps(
        {
            "url": url,
            "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        },
        indent=2,
    )
)
print("SCB exact software source", p.stat().st_size)
