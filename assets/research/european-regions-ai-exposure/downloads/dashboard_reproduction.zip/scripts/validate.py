"""Non-visual checks of our score lineage, official sources and index arithmetic."""

from pathlib import Path
import ast, hashlib, json, re, shutil, subprocess, zipfile
import numpy as np, pandas as pd, openpyxl
from bs4 import BeautifulSoup

R = Path(__file__).resolve().parents[1]
B = R.parents[1]
P = B.parent / "deep1003.github.io/assets/research/european-regions-ai-exposure"
checks = {}
for file in (R / "scripts").glob("*.py"):
    ast.parse(file.read_text())
subprocess.run(["node", "--check", str(P / "app.js")], check=True)
checks["python_and_javascript_syntax"] = True
assert not any(
    "stanford" in f.name.lower() or "adp" in f.name.lower()
    for f in (R / "raw").iterdir()
)
assert not any(
    "stanford" in f.name.lower() or "adp" in f.name.lower()
    for f in (R / "derived").iterdir()
)
# Freeze provenance of our own task-duration-adjusted score, never use a reference score.
score = (
    B
    / "06_execution/thaie_q5_did_20261124_v1/derived/THAIE2025_ISCO3_TRANSFERRED_SCORES.csv"
)
assert (
    hashlib.sha256(score.read_bytes()).hexdigest()
    == hashlib.sha256(
        (P / "downloads/THAIE_ISCO3_OUR_SCORES.csv").read_bytes()
    ).hexdigest()
)
checks["our_THAIE_score_sha256"] = hashlib.sha256(score.read_bytes()).hexdigest()
checks["stanford_data_used"] = False
checks["ADP_data_used"] = False
checks["all_indices_use_our_THAIE_rankings"] = True
for name in ["eu1", "eu2", "se_annual", "se_monthly", "software", "nuts2"]:
    d = json.loads((P / "data" / (name + ".json")).read_text())
    f = pd.DataFrame(d["rows"], columns=d["columns"])
    assert not f.duplicated(
        [x for x in ["geo", "age", "sex", "series", "kind", "time"] if x in f]
    ).any(), name
    vals = pd.to_numeric(f["index"], errors="coerce")
    assert vals.dropna().ge(0).all()
    if name not in ["software"]:
        if name == "se_monthly":
            base = (
                f[f.time.str.startswith("2022-")]
                .groupby(["geo", "age", "sex", "series"])["index"]
                .agg(["count", "mean"])
            )
            assert base["count"].eq(12).all()
            assert np.allclose(base["mean"], 100, atol=1e-6)
        else:
            assert np.allclose(f.loc[f.time.eq("2022"), "index"].dropna(), 100)
    checks[name] = {
        "plotted_rows": len(f),
        "geographies": f.geo.nunique(),
        "frequency": d["frequency"],
    }


# Independent raw JSON coordinate lookup.
def cell(j, **codes):
    shape = j["size"]
    idx = 0
    for key, n in zip(j["id"], shape):
        ix = j["dimension"][key]["category"]["index"]
        idx = idx * n + ix[codes[key]]
    return (
        j["value"].get(str(idx), np.nan)
        if isinstance(j["value"], dict)
        else j["value"][idx]
    )


month = json.loads((R / "raw/SCB_ArbStatusM_age_sex.json").read_text())
region = pd.read_csv(
    R / "derived/SWEDEN_FIXED_REGIONAL_THAIE_2022.csv", dtype={"geo": str}
)
m = pd.read_csv(R / "derived/se_monthly.csv", dtype={"time": str})
for quintile in [1, 5]:
    for date in ["2020M01", "2022M06", "2026M08"]:
        codes = region.loc[region.quintile.eq(quintile), "geo"]
        count = sum(
            cell(
                month,
                Region=g,
                Kon="1+2",
                Alder="20-64",
                Fodelseregion="tot",
                ContentsCode="000006HI",
                Tid=date,
            )
            for g in codes
        )
        actual = m[
            (m.geo == "SE")
            & m.age.eq("20–64")
            & m.sex.eq("T")
            & m.series.eq("Q" + str(quintile))
            & m.time.eq(date.replace("M", "-"))
        ]["count"].iloc[0]
        assert np.isclose(count, actual)
checks["monthly_quintile_counts_independently_reconciled_to_SCB"] = True
# Raw published UK total, not a sum across censored regional cells.
w = openpyxl.load_workbook(R / "raw/UK_ONS_3713.xlsx", read_only=True, data_only=True)
s = pd.read_csv(
    R / "derived/SOFTWARE_NATIVE_ALL_SERIES.csv", dtype={"geo": str, "time": str}
)
for name, year in [("J21J22", "2022"), ("J25J26", "2026")]:
    table = list(w[name].iter_rows(values_only=True))
    col = list(table[7]).index("Total")
    row = next(
        row
        for row in table
        if any(
            "Programmers and software development professionals" in str(v)
            for v in row[:2]
        )
    )
    actual = s[(s.geo == "UK") & s.time.eq(year) & s.sex.eq("T")]["count"].iloc[0]
    assert actual == row[col]
assert s.loc[s.kind.eq("UK_SOC_2136"), "index"].isna().all()
checks["UK_published_totals_and_classification_break_preserved"] = True
# No occupation monthly outcomes or false exact-age cells can appear.
assert all(len(str(x)) == 4 for x in s.time)
checks["software_outcomes_annual_only"] = True
ranks = pd.read_csv(R / "derived/FIXED_OCCUPATIONAL_RANKINGS.csv")
assert ranks.groupby(["dataset", "occupation"]).size().eq(1).all()
assert region.geo.nunique() == 21
checks["monthly_regional_exposure_is_21_counties_not_software_employment"] = True
# Links and assets in our new standalone page.
soup = BeautifulSoup((P / "index.html").read_text(), "html.parser")
links = []
for tag in soup.select("[href],[src]"):
    link = tag.get("href") or tag.get("src")
    if link.startswith(("http:", "https:", "mailto:", "#", "data:")):
        continue
    path = (P / link.split("#")[0]).resolve()
    if path.name == "AVAILABILITY_AND_VALIDATION.json":
        continue
    assert path.exists(), str(path)
    links.append(link)
assert all(not tag.has_attr("open") for tag in soup.select("#results > details"))
checks["local_links_and_initially_folded_results"] = len(links)
checks["no_new_employment_imputation_or_monthly_interpolation"] = True
checks["passed"] = True
(R / "metadata/VALIDATION.json").write_text(json.dumps(checks, indent=2))
(P / "downloads/AVAILABILITY_AND_VALIDATION.json").write_text(
    json.dumps(checks, indent=2)
)
print(json.dumps(checks, indent=2))
