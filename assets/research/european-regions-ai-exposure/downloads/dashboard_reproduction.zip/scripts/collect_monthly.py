from pathlib import Path
import requests, json, hashlib

R = Path(__file__).resolve().parents[1]
u = "https://api.scb.se/OV0104/v1/doris/en/ssd/AM/AM0210/AM0210A/ArbStatusM"
p = R / "raw/SCB_ArbStatusM_2020plus.json"
if not p.exists():
    m = requests.get(u, timeout=(15, 45)).json()
    (R / "raw/SCB_ArbStatusM_metadata.json").write_text(json.dumps(m))
    choices = {
        "Region": [v for v in m["variables"][0]["values"] if len(v) == 2],
        "Kon": ["1+2"],
        "Alder": ["15-74", "20-64"],
        "Fodelseregion": ["tot"],
        "ContentsCode": ["000006HI"],
    }
    q = {
        "query": [
            {
                "code": v["code"],
                "selection": {
                    "filter": "item",
                    "values": choices.get(v["code"], v["values"]),
                },
            }
            for v in m["variables"]
        ],
        "response": {"format": "json-stat2"},
    }
    (R / "metadata/SCB_MONTHLY.query.json").write_text(json.dumps(q, indent=2))
    x = requests.post(u, json=q, timeout=(15, 60))
    x.raise_for_status()
    x.json()
    p.write_bytes(x.content)
print("Monthly official table", p.stat().st_size)
