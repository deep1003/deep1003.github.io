from pathlib import Path
import json, requests

R = Path(__file__).resolve().parents[1]
u = "https://api.scb.se/OV0104/v1/doris/en/ssd/AM/AM0210/AM0210A/ArbStatusM"
m = json.loads((R / "raw/SCB_ArbStatusM_metadata.json").read_text())
choices = {
    "Region": [
        s
        for s in next(v for v in m["variables"] if v["code"] == "Region")["values"]
        if len(s) == 2
    ],
    "Kon": ["1", "2", "1+2"],
    "Alder": [
        "20-24",
        "25-29",
        "30-34",
        "35-39",
        "40-44",
        "45-49",
        "50-54",
        "55-59",
        "060-64",
        "20-64",
    ],
    "Fodelseregion": ["tot"],
    "ContentsCode": ["000006HI"],
}
q = {
    "query": [
        {
            "code": v["code"],
            "selection": {
                "filter": "item",
                "values": choices.get(v["code"], v["values"]),
            },
        }
        for v in m["variables"]
    ],
    "response": {"format": "json-stat2"},
}
(R / "metadata/SCB_MONTHLY_AGE_SEX.query.json").write_text(json.dumps(q, indent=2))
p = R / "raw/SCB_ArbStatusM_age_sex.json"
if not p.exists():
    x = requests.post(u, json=q, timeout=(15, 90))
    x.raise_for_status()
    x.json()
    p.write_bytes(x.content)
print("Monthly age-sex table", p.stat().st_size)
