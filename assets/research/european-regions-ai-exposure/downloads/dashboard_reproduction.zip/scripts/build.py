"""Build source-grain-aware employment indices; never fabricate monthly occupations."""

from pathlib import Path
import io, json, re, zipfile
import numpy as np, pandas as pd, openpyxl

R = Path(__file__).resolve().parents[1]
B = R.parents[1]
D = R / "derived"
D.mkdir(parents=True, exist_ok=True)
SITE = (
    (R / "site")
    if (R / "inputs").exists()
    else B.parent / "deep1003.github.io/assets/research/european-regions-ai-exposure"
)
(SITE / "data").mkdir(parents=True, exist_ok=True)


def jsonstat(path):
    j = json.loads(Path(path).read_text())
    axes = []
    for k in j["id"]:
        ix = j["dimension"][k]["category"]["index"]
        axes.append([x for x, n in sorted(ix.items(), key=lambda a: a[1])])
    frame = pd.MultiIndex.from_product(axes, names=j["id"]).to_frame(index=False)
    n = len(frame)
    values = np.full(n, np.nan)
    raw = j.get("value", {})
    if isinstance(raw, list):
        values = np.asarray([np.nan if x is None else x for x in raw], dtype=float)
    else:
        for k, v in raw.items():
            values[int(k)] = v
    flags = np.full(n, "", dtype=object)
    status = j.get("status", {})
    if isinstance(status, list):
        flags = np.asarray([x or "" for x in status], dtype=object)
    else:
        for k, v in status.items():
            flags[int(k)] = v
    frame["value"] = values
    frame["flag"] = flags
    frame.loc[frame.flag.str.contains("[cx]", regex=True, case=False), "value"] = np.nan
    return frame, j


scorefile = (
    (R / "inputs/THAIE_ISCO3_OUR_SCORES.csv")
    if (R / "inputs").exists()
    else B
    / "06_execution/thaie_q5_did_20261124_v1/derived/THAIE2025_ISCO3_TRANSFERRED_SCORES.csv"
)
score = pd.read_csv(scorefile, dtype={"isco3": str})
score["isco3"] = score.isco3.str.zfill(3)
rankings = []
datasets = {}
cohorts = []


def ranking(frame, key, value="THAIE"):
    a = frame[[key, value]].drop_duplicates(key).dropna().copy()
    a["quintile"] = pd.qcut(a[value], 5, labels=False, duplicates="drop") + 1
    assert a.quintile.nunique() == 5
    return a


def compact(rows):
    frame = pd.DataFrame(rows)
    if frame.empty:
        return {"columns": [], "rows": []}
    frame = frame.replace([np.inf, -np.inf], np.nan)
    return {
        "columns": list(frame.columns),
        "rows": json.loads(frame.to_json(orient="values", double_precision=7)),
    }


def publish(name, rows, extra):
    extra["count_unit"] = (
        "thousand persons"
        if name in ["eu1", "eu2", "nuts2"]
        else "persons" if name != "software" else "source-specific, see row count_unit"
    )
    for row in rows:
        row.setdefault("count_unit", extra["count_unit"])
    data = {**extra, **compact(rows)}
    datasets[name] = extra
    (SITE / "data" / (name + ".json")).write_text(
        json.dumps(data, separators=(",", ":"), allow_nan=False)
    )
    pd.DataFrame(rows).to_csv(D / (name + ".csv"), index=False)
    print(name, len(rows), flush=True)


def occupation_indices(frame, ranks, name, ages, years, extra):
    q = frame[
        frame.age.isin(ages) & frame.sex.isin(["T", "M", "F"]) & frame.year.isin(years)
    ].merge(ranks, on="occupation", how="inner", validate="many_to_one")
    rows = []
    for (geo, age), g in q.groupby(["geo", "age"]):
        complete = g.groupby("occupation").value.count()
        keep = set(complete[complete.eq(len(years) * 3)].index)
        g = g[g.occupation.isin(keep)]
        if g.empty:
            continue
        for (sex, quintile), h in g.groupby(["sex", "quintile"]):
            v = h.groupby("year").value.sum(min_count=h.occupation.nunique())
            base = v.get(2022, np.nan)
            if not np.isfinite(base) or base <= 0:
                continue
            for year, count in v.items():
                rows.append(
                    {
                        "geo": geo,
                        "age": ages[age],
                        "sex": sex,
                        "series": "Q" + str(int(quintile)),
                        "time": str(year),
                        "index": 100 * count / base,
                        "count": count,
                    }
                )
        cohorts.append(
            {
                "dataset": name,
                "geo": geo,
                "age": ages[age],
                "retained_occupations": len(keep),
                "years": len(years),
                "sex_cohort": "same occupations for M,F,T",
                "low_reliability_source_cells": int(
                    g.flag.fillna("").str.contains("u").sum()
                ),
            }
        )
        total = frame[
            (frame.geo == geo)
            & (frame.age == age)
            & (frame.year == 2022)
            & (frame.sex == "T")
            & frame.occupation.eq("TOTAL")
        ].value
        denom = total.iloc[0] if len(total) else np.nan
        mass = g[(g.year == 2022) & g.sex.eq("T")].value.sum()
        cohorts[-1].update(
            {
                "baseline_scored_mass": mass,
                "baseline_published_total": denom,
                "baseline_share": mass / denom if denom > 0 else np.nan,
            }
        )
    publish(name, rows, extra)


# Eurostat: one-digit occupations support broad ages; two-digit do not.
eu2, j = jsonstat(R / "raw/EUROSTAT_lfsa_egai2d_2020plus.json")
eu2 = eu2.rename(columns={"isco08": "occupation", "time": "year"})
eu2.year = eu2.year.astype(int)
sc2 = (
    score.assign(occupation="OC" + score.isco3.str[:2])
    .groupby("occupation", as_index=False)
    .THAIE.mean()
)
r2 = ranking(sc2, "occupation")
rankings.append(r2.assign(dataset="eu2"))
occupation_indices(
    eu2,
    r2,
    "eu2",
    {"Y15-64": "15–64"},
    list(range(2020, 2026)),
    {
        "title": "European countries, occupational exposure",
        "frequency": "annual",
        "exposure_kind": "ISCO2 occupational quintiles",
        "ages": ["15–64"],
        "default_age": "15–64",
        "source": "Eurostat lfsa_egai2d",
        "note": "National data, not NUTS regional software employment. Ages 15–64 only; subgroup quintiles use a fixed global occupation ranking and matched complete occupation support.",
    },
)
eu1, j = jsonstat(R / "raw/EUROSTAT_lfsa_egais_age_sex_2020plus.json")
eu1 = eu1.rename(columns={"isco08": "occupation", "time": "year"})
eu1.year = eu1.year.astype(int)
eu1 = eu1[eu1.unit.eq("THS_PER") & eu1.wstatus.eq("EMP")]
sc1 = (
    score.assign(occupation="OC" + score.isco3.str[:1])
    .groupby("occupation", as_index=False)
    .THAIE.mean()
)
r1 = ranking(sc1, "occupation")
rankings.append(r1.assign(dataset="eu1"))
occupation_indices(
    eu1,
    r1,
    "eu1",
    {"Y15-64": "15–64", "Y15-24": "15–24", "Y25-49": "25–49", "Y50-64": "50–64"},
    list(range(2020, 2026)),
    {
        "title": "European countries, broad age and sex groups",
        "frequency": "annual",
        "exposure_kind": "ISCO1 occupational quintiles (coarse)",
        "ages": ["15–64", "15–24", "25–49", "50–64"],
        "default_age": "15–24",
        "source": "Eurostat lfsa_egais",
        "note": "Only ten scored major occupation groups underlie these quintiles. They are not the same strata as the two-digit explorer, and do not identify software developers.",
    },
)

# Sweden annual native occupation x age x sex, workplace-based 21 counties.
z = zipfile.ZipFile(R / "raw/SCB_YREG57BAS_all.zip")
sw = pd.read_csv(io.BytesIO(z.read(z.namelist()[0])), dtype=str, encoding="cp1252")
sw.columns = [
    "region_label",
    "occupation_label",
    "age_native",
    "sex_native",
    "year",
    "raw_value",
]
sw["geo"] = sw.region_label.str.extract(r"^(\d+)")[0]
sw["occupation"] = sw.occupation_label.str.extract(r"^(\d+)")[0]
sw["value"] = pd.to_numeric(sw.raw_value, errors="coerce")
sw["year"] = sw.year.astype(int)
sw["sex"] = sw.sex_native.map({"men": "M", "women": "F"})
sw["flag"] = np.where(sw.value.isna(), "suppressed_or_missing", "")
regions = dict(sw[["geo", "region_label"]].drop_duplicates().values)
valid_geo = {x for x in regions if re.fullmatch(r"\d{2}", x) and int(x) <= 25}
sw = sw[sw.geo.isin(valid_geo)]
# Deterministic native SSYK3 -> ISCO3 only; ambiguous groups are not forcibly mapped.
mapfile = (
    (R / "inputs/SE_SSYK4_ISCO3_mapping.csv")
    if (R / "inputs").exists()
    else B / "01_data/national_20261118/derived/SE_SSYK4_ISCO3_mapping.csv"
)
xwalk = pd.read_csv(mapfile, dtype=str)
xwalk["occupation"] = xwalk.ssyk4.str[:3]
mp = (
    xwalk.groupby("occupation")
    .isco3_candidates.agg(
        lambda x: sorted(set(";".join(x.fillna("")).split(";")) - {""})
    )
    .reset_index(name="candidates")
)
mp["isco3"] = mp.candidates.map(lambda x: x[0] if len(x) == 1 else None)
mp["mapping_status"] = mp.candidates.map(
    lambda x: "unique" if len(x) == 1 else "ambiguous_unmapped"
)
mp.to_csv(D / "SWEDEN_SSYK3_MAPPING_AUDIT.csv", index=False)
ss = mp.merge(score, on="isco3", how="left")
rs = ranking(ss, "occupation")
rankings.append(rs.assign(dataset="se_annual"))
ageparts = {
    "16–24": ["16-24"],
    "25–29": ["25-29"],
    "30–34": ["30-34"],
    "35–44": ["35-39", "40-44"],
    "45–49": ["45-49"],
    "50–64": ["50-54", "55-59", "60-64"],
    "16–64": [
        "16-24",
        "25-29",
        "30-34",
        "35-39",
        "40-44",
        "45-49",
        "50-54",
        "55-59",
        "60-64",
    ],
}
sw["age_code"] = sw.age_native.str.extract(r"(\d+)[–-](\d+)").apply(
    lambda x: "-".join(x), axis=1
)
parts = []
for age, codes in ageparts.items():
    a = (
        sw[sw.age_code.isin(codes)]
        .groupby(["geo", "occupation", "sex", "year"], as_index=False)
        .value.agg(lambda x: x.sum(min_count=len(codes)))
    )
    a["age"] = age
    parts.append(a)
swa = pd.concat(parts, ignore_index=True)
total = swa.pivot(
    index=["geo", "occupation", "year", "age"], columns="sex", values="value"
)
total["value"] = total[["M", "F"]].sum(axis=1, min_count=2)
swa = pd.concat(
    [swa, total[["value"]].reset_index().assign(sex="T")], ignore_index=True
)
swa["flag"] = ""
occupation_indices(
    swa,
    rs,
    "se_annual",
    {a: a for a in ageparts},
    list(range(2020, 2025)),
    {
        "title": "Swedish counties, occupation × age × sex",
        "frequency": "annual",
        "exposure_kind": "deterministically mapped occupational quintiles",
        "ages": list(ageparts),
        "default_age": "16–24",
        "source": "SCB YREG57BAS, TAB4435",
        "note": "Mapped occupations only. Ambiguous SSYK3 groups, including the broad group 251, are excluded from quintile totals. 2023 includes model-imputed occupations; BAS comparison years are used for 2020–2022.",
    },
)
# Software-related age profile deliberately retains its native broader classification.
software = []
for _, a in swa[swa.occupation.eq("251")].iterrows():
    software.append(
        {
            "geo": a.geo,
            "age": a.age,
            "sex": a.sex,
            "time": str(a.year),
            "count": a.value,
            "kind": "SE_broad_251",
        }
    )
# Exact software developers, with sex but no age from the four-digit source.
se4, j = jsonstat(R / "raw/SCB_YREG60BAS_all.json")
se4 = se4.rename(
    columns={"Region": "geo", "Yrke2012": "occupation", "Tid": "year", "Kon": "sex"}
)
se4.sex = se4.sex.map({"1": "M", "2": "F"})
se4.year = se4.year.astype(int)
se4 = se4[se4.geo.isin(valid_geo)]
a = se4[se4.occupation.eq("2512")][["geo", "year", "sex", "value"]]
t = a.pivot(index=["geo", "year"], columns="sex", values="value")
t["value"] = t[["M", "F"]].sum(axis=1, min_count=2)
a = pd.concat([a, t[["value"]].reset_index().assign(sex="T")], ignore_index=True)
for _, v in a.iterrows():
    software.append(
        {
            "geo": v.geo,
            "age": "All source ages",
            "sex": v.sex,
            "time": str(v.year),
            "count": v.value,
            "kind": "SE_exact_2512",
        }
    )
# Regional fixed exposure uses uniquely mapped four-digit employment and native counts.
uni = (
    xwalk[xwalk.mapping_status.eq("unique_at_3_digit")]
    .drop(columns="occupation")
    .rename(columns={"ssyk4": "occupation", "deterministic_isco3": "isco3"})
)
base = (
    se4[se4.year.eq(2022)]
    .merge(uni[["occupation", "isco3"]], on="occupation", validate="many_to_one")
    .merge(score, on="isco3", validate="many_to_one")
)
exp = []
for geo, g in base.groupby("geo"):
    g = g.dropna(subset=["value", "THAIE"])
    mass = g.value.sum()
    denom = se4[(se4.year == 2022) & se4.geo.eq(geo)].value.sum(min_count=1)
    if mass > 0:
        exp.append(
            {
                "geo": geo,
                "THAIE2025": np.average(g.THAIE, weights=g.value),
                "scored_mass": mass,
                "published_mass": denom,
                "share_published_mass": mass / denom,
            }
        )
exp = pd.DataFrame(exp)
regional = exp[exp.geo.ne("00")].copy()
regional["quintile"] = pd.qcut(regional.THAIE2025, 5, labels=False) + 1
regional.to_csv(D / "SWEDEN_FIXED_REGIONAL_THAIE_2022.csv", index=False)
# Monthly series are actual BAS employment, not software employment.
month, j = jsonstat(R / "raw/SCB_ArbStatusM_age_sex.json")
month = month.rename(
    columns={"Region": "geo", "Kon": "sex", "Alder": "age_native", "Tid": "time"}
)
month.sex = month.sex.map({"1": "M", "2": "F", "1+2": "T"})
month["date"] = month.time.str.replace("M", "-", regex=False)
monthlyparts = []
monthages = {
    "20–24": ["20-24"],
    "25–29": ["25-29"],
    "30–34": ["30-34"],
    "35–44": ["35-39", "40-44"],
    "45–49": ["45-49"],
    "50–64": ["50-54", "55-59", "060-64"],
    "20–64": ["20-64"],
}
for age, codes in monthages.items():
    a = (
        month[month.age_native.isin(codes)]
        .groupby(["geo", "sex", "date"], as_index=False)
        .value.agg(lambda x: x.sum(min_count=len(codes)))
    )
    a["age"] = age
    monthlyparts.append(a)
monthly = pd.concat(monthlyparts, ignore_index=True)
monthly = monthly.merge(
    regional[["geo", "quintile"]], on="geo", how="left", validate="many_to_one"
)
monthly.to_csv(D / "SCB_MONTHLY_NATIVE_AGE_SEX_COUNTS.csv", index=False)
rows = []
for (age, sex), g in monthly[monthly.geo.ne("00")].groupby(["age", "sex"]):
    for quintile, h in g.groupby("quintile"):
        expected = h.geo.nunique()
        v = h.groupby("date").value.sum(min_count=expected)
        base = v[v.index.str.startswith("2022-")]
        if len(base) != 12 or base.isna().any() or base.mean() <= 0:
            continue
        for date, count in v.items():
            rows.append(
                {
                    "geo": "SE",
                    "age": age,
                    "sex": sex,
                    "series": "Q" + str(int(quintile)),
                    "time": date,
                    "count": count,
                    "index": 100 * count / base.mean(),
                }
            )
for (geo, age, sex), g in monthly[monthly.geo.ne("00")].groupby(["geo", "age", "sex"]):
    base = g[g.date.str.startswith("2022-")].value
    if len(base) != 12 or base.isna().any() or base.mean() <= 0:
        continue
    for _, a in g.iterrows():
        rows.append(
            {
                "geo": geo,
                "age": age,
                "sex": sex,
                "series": regions[geo].split(" ", 1)[1],
                "time": a.date,
                "count": a.value,
                "index": 100 * a.value / base.mean(),
            }
        )
publish(
    "se_monthly",
    rows,
    {
        "title": "Swedish regions, actual monthly employment",
        "frequency": "monthly",
        "exposure_kind": "regional THAIE quintiles, not occupational quintiles",
        "ages": list(monthages),
        "default_age": "20–24",
        "source": "SCB ArbStatusM; fixed 2022 YREG60BAS weights",
        "note": "All occupations within each county. This is not monthly software-developer employment. Exposure weights cover about 67–78% of published 2022 occupation mass, conditional on deterministic links and scored occupations. Unadjusted for seasonality; each series uses its own 2022 12-month mean = 100. Exact requested ages are unavailable.",
    },
)

# UK refreshed ONS source: published national totals are never a sum of suppressed areas.
w = openpyxl.load_workbook(R / "raw/UK_ONS_3713.xlsx", read_only=True, data_only=True)
uk = []
uknames = {}
for sh in w:
    year = 2000 + int(sh.title[-2:])
    if year < 2020:
        continue
    table = list(sh.iter_rows(values_only=True))
    header = table[7]
    for row in table:
        if not any(
            "Programmers and software development professionals" in str(v)
            for v in row[:2]
        ):
            continue
        native = str(row[1])
        soc = re.match(r"(\d+)", native).group(1)
        for col in range(2, len(header)):
            label = str(header[col] or "")
            raw = row[col] if col < len(row) else None
            if label == "Total":
                geo = "UK"
                name = "United Kingdom (published total)"
            elif re.match(r"(UK|TL)[A-Z0-9]{2}", label):
                geo = re.match(r"(UK|TL)[A-Z0-9]{2}", label).group(0)
                geo = "UK" + geo[2:]
                name = label.split(" ", 1)[1]
            else:
                continue
            uknames[geo] = name
            uk.append(
                {
                    "geo": geo,
                    "region_label": name,
                    "time": str(year),
                    "count": float(raw) if isinstance(raw, (int, float)) else np.nan,
                    "raw_cell": str(raw),
                    "soc_code": soc,
                    "period": str(table[2][0]),
                    "classification_break": year == 2022,
                    "boundary_regime": 2025 if year == 2026 else "source vintage",
                }
            )
uk = pd.DataFrame(uk)
uk.to_csv(D / "UK_SOFTWARE_NATIVE_ANNUAL_COUNTS.csv", index=False)
for (geo,), g in uk.groupby(["geo"]):
    base = g.loc[g.time.eq("2022"), "count"]
    for _, a in g.iterrows():
        software.append(
            {
                "geo": geo,
                "age": "All source ages",
                "sex": "T",
                "time": a.time,
                "count": a["count"],
                "kind": "UK_SOC_2134" if a.soc_code == "2134" else "UK_SOC_2136",
                "index": (
                    100 * a["count"] / base.iloc[0]
                    if len(base) and base.iloc[0] > 0
                    else np.nan
                ),
                "period": a.period,
            }
        )
# Finland, genuinely additional occupation/sex regional counts, annual only.
fi, j = jsonstat(R / "raw/FI_115s_2020plus.json")
fi = fi.rename(
    columns={
        "ammatti_104_20161021": "occupation",
        "alue_23_20260101": "geo",
        "timeperiod_y": "year",
        "sukupuoli_9_20180101": "sex",
    }
)
filabel = j["dimension"]["alue_23_20260101"]["category"]["label"]
fi.sex = fi.sex.map({"SSS": "T", "1": "M", "2": "F"})
for _, a in fi[fi.occupation.eq("251")].iterrows():
    software.append(
        {
            "geo": "FI" + a.geo,
            "age": "All source ages",
            "sex": a.sex,
            "time": str(a.year),
            "count": a.value,
            "kind": "FI_ISCO_251",
        }
    )
# Additional broad ICT-professional comparator, explicitly not exact software developers.
for _, a in eu2[eu2.occupation.eq("OC25")].iterrows():
    software.append(
        {
            "geo": "EU_" + a.geo,
            "age": "15–64",
            "sex": a.sex,
            "time": str(a.year),
            "count": a.value,
            "kind": "EU_ICT25_broad",
        }
    )
# Standardise software indices by each native series, never mixing countries/classifications.
soft = pd.DataFrame(software)
for (geo, age, sex), g in soft.groupby(["geo", "age", "sex"]):
    b = g.loc[g.time.eq("2022"), "count"]
    if len(b) == 1 and b.iloc[0] > 0:
        soft.loc[g.index, "index"] = 100 * g["count"] / b.iloc[0]
# A post-break SOC2020 baseline does not validate a SOC2010 pre-period index.
soft.loc[soft.kind.eq("UK_SOC_2136"), "index"] = np.nan
soft["count_unit"] = np.where(
    soft.kind.eq("EU_ICT25_broad"), "thousand persons", "persons"
)
soft.to_csv(D / "SOFTWARE_NATIVE_ALL_SERIES.csv", index=False)
publish(
    "software",
    soft.to_dict("records"),
    {
        "title": "Software occupations, separately sourced",
        "source": "ONS 3713; SCB YREG60BAS/YREG57BAS; StatFin115s",
        "frequency": "annual",
        "note": "UK SOC2010 2136 / SOC2020 2134 transition at 2022; UK years end in June. Sweden exact SSYK2512 has sex but no age; native 251 age series is broader. Finland ISCO251 is a broader software-and-applications group. No single-occupation exposure quintiles are manufactured.",
    },
)
# Existing European NUTS2 broad-age source, fixed regional quintiles.
nutsfile = (
    (R / "inputs/SOURCE_AGE_OUTCOME_PANEL.csv")
    if (R / "inputs").exists()
    else B
    / "06_execution/thaie_q5_did_20261124_v1/derived/SOURCE_AGE_OUTCOME_PANEL.csv"
)
nut = pd.read_csv(nutsfile)
nut = nut[nut.metric.eq("count") & nut.year.between(2020, 2025)]
good = nut.groupby("region").apply(
    lambda g: len(g) == 6 and g[["young", "older"]].notna().all().all(),
    include_groups=False,
)
nut = nut[nut.region.isin(good[good].index)]
nr = []
for age, col in [("15–24", "young"), ("55–64", "older")]:
    for quintile, g in nut.groupby("Q_THAIE2025"):
        v = g.groupby("year")[col].sum(min_count=g.region.nunique())
        base = v.loc[2022]
        for year, value in v.items():
            nr.append(
                {
                    "geo": "EU supported NUTS2",
                    "age": age,
                    "sex": "T",
                    "series": "Q" + str(int(quintile)),
                    "time": str(year),
                    "count": value,
                    "index": 100 * value / base,
                }
            )
publish(
    "nuts2",
    nr,
    {
        "title": "European NUTS2 regional exposure groups",
        "frequency": "annual",
        "exposure_kind": "fixed 2022 regional quintiles",
        "ages": ["15–24", "55–64"],
        "default_age": "15–24",
        "regions": nut.region.nunique(),
        "countries": nut.country.nunique(),
        "source": "Eurostat lfst_r_lfe2emp and prior fixed regional THAIE linkage",
        "note": "Balanced 2020–2025 regional cohort; native age bands are retained. Regional exposure is not individual occupational exposure; boundary and public-cell scope uncertainty remain. UK is not inserted with incompatible outcomes.",
    },
)
meta = {
    "updated": "2026-11-25",
    "datasets": datasets,
    "regions_sweden": regions,
    "regions_uk": uknames,
    "regions_finland": {"FI" + k: v for k, v in filabel.items()},
    "country_labels": json.loads(
        (R / "raw/EUROSTAT_lfsa_egai2d_2020plus.json").read_text()
    )["dimension"]["geo"]["category"].get("label", {}),
    "exact_requested_ages": ["22–25", "26–30", "31–34", "35–40", "41–49", "50+"],
    "monthly_software_age_sex_available": False,
    "new_country_sources": ["United Kingdom", "Finland", "Sweden"],
    "new_annual_country_coverage": int(
        eu2[eu2.value.notna() & eu2.geo.str.fullmatch("[A-Z]{2}")].geo.nunique()
    ),
    "monthly_counties": len(regional),
    "monthly_region_score_coverage_min": float(regional.share_published_mass.min()),
    "monthly_region_score_coverage_max": float(regional.share_published_mass.max()),
    "exposure_method": "our THAIE GPT5 2025, H50=203.012577 minutes; official occupation transfer",
    "annual_sweden_mapping_native_groups": len(mp),
    "annual_sweden_uniquely_mapped_groups": int(mp.mapping_status.eq("unique").sum()),
    "annual_sweden_scored_groups": len(rs),
    "regional_monthly_definition": "All-occupation employment grouped by fixed county exposure; not software jobs",
    "imputed_to_monthly": False,
    "single_occupation_quintiles_not_identified": True,
}
(SITE / "data/metadata.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False))
(R / "metadata/BUILD_SCOPE.json").write_text(
    json.dumps(meta, indent=2, ensure_ascii=False)
)
pd.concat(rankings, ignore_index=True).to_csv(
    D / "FIXED_OCCUPATIONAL_RANKINGS.csv", index=False
)
pd.DataFrame(cohorts).to_csv(D / "COHORT_AND_COVERAGE_AUDIT.csv", index=False)
print(
    json.dumps(
        {
            k: meta[k]
            for k in [
                "monthly_counties",
                "annual_sweden_scored_groups",
                "new_annual_country_coverage",
            ]
        },
        indent=2,
    )
)
