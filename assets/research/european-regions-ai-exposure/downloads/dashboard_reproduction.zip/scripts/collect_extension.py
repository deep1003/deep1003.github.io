"""Collect complementary age/sex and additional-country tables."""

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import json, requests, hashlib

R = Path(__file__).resolve().parents[1]
B = R.parents[1]
fi = json.loads((B / "01_data/national_20261118/metadata/FI_115s.json").read_text())
query = {
    "query": [
        {
            "code": v["code"],
            "selection": {
                "filter": "item",
                "values": (
                    [s for s in v["values"] if int(s) >= 2020]
                    if v["code"] == "timeperiod_y"
                    else v["values"]
                ),
            },
        }
        for v in fi["variables"]
    ],
    "response": {"format": "json-stat2"},
}
jobs = [
    (
        "FI_115s_2020plus.json",
        "https://pxdata.stat.fi/PxWeb/api/v1/en/StatFin/tyokay/115s.px",
        query,
    ),
    (
        "EUROSTAT_lfsa_egais_age_sex_2020plus.json",
        "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lfsa_egais?lang=EN&sinceTimePeriod=2020&wstatus=EMP",
        None,
    ),
    (
        "SCB_YREG55BAS_metadata.json",
        "https://api.scb.se/OV0104/v1/doris/en/ssd/AM/AM0208/AM0208C/YREG55BAS",
        None,
    ),
]


def go(item):
    name, url, payload = item
    dest = R / "raw" / name
    if dest.exists():
        return {
            "file": name,
            "url": url,
            "status": "cached",
            "sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
        }
    try:
        x = (
            requests.post(url, json=payload, timeout=(15, 60))
            if payload
            else requests.get(url, timeout=(15, 60))
        )
        x.raise_for_status()
        x.json()
        dest.write_bytes(x.content)
        if payload:
            (R / "metadata" / (name + ".query.json")).write_text(
                json.dumps(payload, indent=2)
            )
        return {
            "file": name,
            "url": url,
            "status": "downloaded",
            "bytes": len(x.content),
            "sha256": hashlib.sha256(x.content).hexdigest(),
        }
    except Exception as e:
        return {"file": name, "url": url, "status": "failed", "error": str(e)}


a = []
with ThreadPoolExecutor(max_workers=3) as pool:
    for f in as_completed([pool.submit(go, j) for j in jobs]):
        result = f.result()
        a.append(result)
        print(
            result["file"],
            result["status"],
            result.get("bytes", result.get("error")),
            flush=True,
        )
(R / "metadata/EXTENSION_DOWNLOADS.json").write_text(json.dumps(a, indent=2))
