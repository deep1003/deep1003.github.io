"""Download free official sources and preserve exact request provenance."""

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import json, hashlib, time
from datetime import datetime, timezone
import requests

R = Path(__file__).resolve().parents[1]
jobs = [
    (
        "SCB_YREG58BAS_all.zip",
        "https://www.statistikdatabasen.scb.se/Resources/PX/bulk/ssd/en/TAB4434_en.zip",
    ),
    (
        "SCB_YREG57BAS_all.zip",
        "https://www.statistikdatabasen.scb.se/Resources/PX/bulk/ssd/en/TAB4435_en.zip",
    ),
    (
        "UK_ONS_3713.xlsx",
        "https://www.ons.gov.uk/file?uri=%2Femploymentandlabourmarket%2Fpeopleinwork%2Femploymentandemployeetypes%2Fadhocs%2F3713employmentby4digitoccupationandnuts2itl2areajuly2017tojune2026%2Femploymentby4digitsocanditl2areaj17j18toj25j26.xlsx",
    ),
    (
        "EUROSTAT_lfsa_egai2d_2020plus.json",
        "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lfsa_egai2d?lang=EN&age=Y15-64&sinceTimePeriod=2020",
    ),
    (
        "EUROSTAT_lfsa_egais_sample.json",
        "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lfsa_egais?lang=EN&geo=EU27_2020&time=2022",
    ),
]


def job(item):
    name, url = item
    p = R / "raw" / name
    if p.exists():
        return {
            "file": name,
            "url": url,
            "status": "cached",
            "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        }
    for attempt in range(2):
        try:
            x = requests.get(url, timeout=(15, 45))
            x.raise_for_status()
            if name.endswith(".zip") and not x.content.startswith(b"PK"):
                raise ValueError("Not a ZIP")
            if name.endswith(".json"):
                x.json()
            p.write_bytes(x.content)
            return {
                "file": name,
                "url": url,
                "status": "downloaded",
                "bytes": len(x.content),
                "sha256": hashlib.sha256(x.content).hexdigest(),
                "retrieved_utc": datetime.now(timezone.utc).isoformat(),
            }
        except Exception as e:
            error = str(e)
    return {"file": name, "url": url, "status": "failed", "error": error}


results = []
with ThreadPoolExecutor(max_workers=6) as pool:
    for f in as_completed([pool.submit(job, x) for x in jobs]):
        a = f.result()
        results.append(a)
        print(a["file"], a["status"], a.get("bytes", a.get("error")), flush=True)
(R / "metadata/DOWNLOADS.json").write_text(json.dumps(results, indent=2))
