from pathlib import Path
import json
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];B=R.parents[1]
src=B/'01_data/eurostat_20261118/raw/lfst_r_lfe2emp.tsv.gz'
d=pd.read_csv(src,sep='\t',dtype=str);keys=d.iloc[:,0].str.split(',',expand=True);keys.columns=['freq','unit','sex','age','region'];d=pd.concat([keys,d.iloc[:,1:]],axis=1)
x=d[d.sex.eq('T')].melt(id_vars=keys.columns.tolist(),var_name='year',value_name='raw_cell');x.year=x.year.str.strip().astype(int);x=x[x.year.between(2020,2025)].copy();x['value']=pd.to_numeric(x.raw_cell.str.extract(r'^\s*([0-9]+(?:\.[0-9]+)?)')[0],errors='coerce');x['flag']=x.raw_cell.str.replace(r'^\s*[0-9]+(?:\.[0-9]+)?','',regex=True).str.strip()
q=pd.read_csv(B/'06_execution/thaie_q5_did_20261124_v1/derived/FIXED_2022_REGION_THAIE_QUINTILES.csv');x=x.merge(q[['region','country','Q_THAIE2025']],on='region',validate='many_to_one')
old=pd.read_csv(B/'06_execution/thaie_q5_did_20261124_v1/derived/SOURCE_AGE_OUTCOME_PANEL.csv');old=old[old.metric.eq('count')&old.year.between(2020,2025)];good=old.groupby('region').apply(lambda g:len(g)==6 and g[['young','older']].notna().all().all(),include_groups=False);regions=good[good].index;x=x[x.region.isin(regions)]
ages=['Y15-24','Y25-34','Y35-44','Y45-54','Y55-64','Y_GE65','Y15-64','Y15-74','Y20-64','Y25-64','Y_GE15','Y_GE25'];labels={a:a.removeprefix('Y').replace('_GE','') for a in ages};labels.update({'Y_GE65':'65+','Y_GE15':'15+','Y_GE25':'25+'})
valid=x.groupby(['region','age']).value.agg(['count']);common=valid.groupby('region').apply(lambda g:len(g)==12 and g['count'].eq(6).all(),include_groups=False);common=common[common].index
out=[];audit=[]
for age in ages:
 a=x[x.age.eq(age)];g=a.groupby('region').value.count();agegood=g[g.eq(6)].index
 audit.append(dict(age=age,label=labels[age],original_cohort_regions=len(regions),balanced_regions=len(agegood),missing_cells=int(a.value.isna().sum()),common_all_age_regions=len(common)))
 for scope,rs in [('age_balanced',agegood),('common_all_ages',common)]:
  z=a[a.region.isin(rs)]
  for quint,h in z.groupby('Q_THAIE2025'):
   sums=h.groupby('year').value.sum(min_count=h.region.nunique());base=sums.loc[2022]
   for year,v in sums.items():out.append(dict(scope=scope,age=age,label=labels[age],quintile=int(quint),year=year,employment_thousands=v,index=100*v/base,regions=h.region.nunique(),countries=h.country.nunique()))
o=pd.DataFrame(out);o.to_csv(R/'derived/ALL_AGE_QUINTILE_INDICES.csv',index=False);pd.DataFrame(audit).to_csv(R/'derived/AGE_COVERAGE.csv',index=False);x.to_csv(R/'derived/NATIVE_AGE_REGION_PANEL.csv.gz',index=False)
colors=['#ac171b','#587fa2','#ff5135','#e9a000','#481e20']
for scope in ['common_all_ages','age_balanced']:
 for name,subset in [('distinct_ages',ages[:6]),('overlapping_ages',ages[6:])]:
  fig,axs=plt.subplots(2,3,figsize=(16,9),sharex=True,sharey=True)
  for ax,age in zip(axs.flat,subset):
   a=o[o.scope.eq(scope)&o.age.eq(age)]
   for k,h in a.groupby('quintile'):ax.plot(h.year,h['index'],marker='o',ms=3,color=colors[k-1],label=f'Q{k}')
   ax.axhline(100,color='gray',lw=.6);ax.axvline(2022.91,color='gray',ls=':',lw=1);ax.grid(alpha=.15);ax.set_title(f"Age {labels[age]} | n = {a.groupby('quintile').regions.first().sum()} regions");ax.spines[['top','right']].set_visible(False);ax.set_xticks(range(2020,2026));ax.set_ylabel('Employment index (2022 = 100)')
  fig.suptitle('European NUTS-2 employment by fixed regional THAIE quintile',fontsize=17);handles,ls=axs.flat[0].get_legend_handles_labels();fig.legend(handles,ls,loc='lower center',ncol=5,bbox_to_anchor=(.5,.04));fig.text(.04,.015,'Source: collected Eurostat lfst_r_lfe2emp. Q1 lowest, Q5 highest own THAIE. Annual observed counts; overlapping ages are separate totals.',fontsize=9);fig.tight_layout(rect=(0,.09,1,.95));fig.savefig(R/f'figures/{name}_{scope}.png',dpi=180);fig.savefig(R/f'figures/{name}_{scope}.pdf');plt.close(fig)
assert not x.duplicated(['region','age','year']).any();assert np.allclose(o[o.year.eq(2022)]['index'],100)
(R/'metadata/VALIDATION.json').write_text(json.dumps({'original_regions':len(regions),'common_all_ages_regions':len(common),'common_countries':x[x.region.isin(common)].country.nunique(),'ages':12,'source':str(src),'imputed':False},indent=2))
print(pd.DataFrame(audit).to_string(index=False));print('common',len(common))
