# Audited current dashboard snapshot

Run `python validate_snapshot.py` to validate keys, finite counts and annual index arithmetic. Run `python -m http.server 8000 --directory site`, then open http://localhost:8000/assets/research/european-regions-ai-exposure/. A modern browser renders all current source frequencies separately. Monthly/quarterly baseline recalculation is in app.js.

This package reproduces current rendering and aggregate calculations. It is not a full upstream acquisition-to-result pipeline. Original source collection scripts remain archived locally. No interpolation creates monthly observations from annual data.
