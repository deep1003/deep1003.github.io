from pathlib import Path
import json,math,collections
root=Path(__file__).resolve().parent/'site/assets/research/european-regions-ai-exposure'
report={}
for p in sorted((root/'data').glob('*.json')):
 d=json.loads(p.read_text())
 if 'rows' not in d:continue
 rows=[dict(zip(d['columns'],r)) for r in d['rows']];seen=set();bases={};maxerr=0;tested=0
 key=lambda r:tuple(r.get(k) for k in ['kind','geo','age','sex','series'])
 for r in rows:
  uid=key(r)+(r['time'],);assert uid not in seen,(p.name,uid);seen.add(uid)
  for k in ['count','index']:
   v=r.get(k);assert v is None or (isinstance(v,(int,float)) and math.isfinite(v) and v>=0),(p.name,k,v)
  if str(r['time'])=='2022' and r.get('count',0) and r['count']>0:bases[key(r)]=r['count']
 if d.get('frequency')=='annual':
  for r in rows:
   if key(r) in bases and r.get('count') is not None and r.get('index') is not None:
    err=abs(r['index']-100*r['count']/bases[key(r)]);maxerr=max(maxerr,err);tested+=1
  assert maxerr<1e-5,(p.name,maxerr)
 report[p.name]={'rows':len(rows),'unique_keys':True,'finite_nonnegative':True,'annual_index_checks':tested,'max_error':maxerr}
print(json.dumps(report,indent=2))
