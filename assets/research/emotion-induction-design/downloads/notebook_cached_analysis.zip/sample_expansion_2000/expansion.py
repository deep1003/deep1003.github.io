"""Original UN × FA protocol, person/background variants, fixed maximum N."""
from pathlib import Path
import fcntl, hashlib, itertools, json, os, time
import numpy as np
import pandas as pd
import original_protocol as protocol
B=Path(__file__).resolve().parent
OUT=B/'results'
KEY=['item','condition','rotation']

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def atomic_json(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2));os.replace(temp,path)
def state(name,**kwargs):atomic_json(B/'status.json',dict(state=name,timestamp=time.time(),**kwargs))
def load():return pd.read_csv(B/'items_2000.csv')
def validate(d,items):
    assert not d.duplicated(KEY).any()
    assert set(d['item'])<=set(items.sample_id)
    assert set(d.condition)<=set(protocol.CONDITIONS) and set(d.rotation)<={0,1,2}
    p=d[['p_unknown','p_stereotype','p_anti']].to_numpy()
    assert np.isfinite(p).all() and (p>=0).all() and (p<=1).all()
    assert np.allclose(p.sum(1),1,atol=1e-5)
    assert np.isfinite(d.choice_mass).all() and d.choice_mass.between(0,1.00001).all()
def summarize(d,items):
    v=d.groupby(['item','condition']).p_unknown.mean().unstack().reindex(items.sample_id)
    assert v.notna().all().all()
    z=np.column_stack([((v.U1T0-v.U0T0)+(v.U1T1-v.U0T1))/2,((v.U0T1-v.U0T0)+(v.U1T1-v.U1T0))/2,v.U1T1-v.U1T0-v.U0T1+v.U0T0,v.U1T1-v.U0T0])
    g=items.cluster.astype('category').cat.codes.to_numpy();nc=g.max()+1
    sums=np.zeros((nc,4));np.add.at(sums,g,z);counts=np.bincount(g)
    w=np.random.default_rng(protocol.SEED).multinomial(nc,np.ones(nc)/nc,size=10000)
    draws=(w@sums)/(w@counts)[:,None]
    result=[]
    for k,term in enumerate(['UN','FA','interaction','combined']):
        lo,hi=np.quantile(draws[:,k],[.025,.975]);p=min(1,2*min((draws[:,k]<=0).mean(),(draws[:,k]>=0).mean())+.0001)
        result.append(dict(term=term,estimate=float(z[:,k].mean()),ci_low=float(lo),ci_high=float(hi),p_diagnostic=float(p)))
    adj=0.
    for i,r in enumerate(sorted(result[:3],key=lambda r:r['p_diagnostic'])):
        adj=max(adj,min(1.,r['p_diagnostic']*(3-i)));r['p_holm_diagnostic']=adj
    return dict(n=len(items),clusters=int(nc),conditions={k:float(v[k].mean()) for k in protocol.CONDITIONS},contrasts=result)
def checkpoint(d,items,n):
    subset=items.iloc[:n];chosen=d[d['item'].isin(subset.sample_id)]
    assert len(chosen)==n*12
    r=dict(pooled=summarize(chosen,subset))
    if n>139:
        extra=subset.iloc[139:];r['additional_only']=summarize(chosen[chosen['item'].isin(extra.sample_id)],extra)
    atomic_json(OUT/f'stage_{n}.json',r)
    rows=[]
    for p in sorted(OUT.glob('stage_*.json'),key=lambda p:int(p.stem.split('_')[1])):
        a=json.loads(p.read_text())
        for scope,s in a.items():
            for c in s['contrasts']:rows.append(dict(n=s['n'],stage=a['pooled']['n'],scope=scope,clusters=s['clusters'],**c))
    pd.DataFrame(rows).to_csv(OUT/'trajectories.csv',index=False)
    return r

def plot():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    d=pd.read_csv(OUT/'trajectories.csv');d=d[d.scope=='pooled']
    fig,axes=plt.subplots(1,3,figsize=(13,4),layout='constrained')
    for ax,term,color in zip(axes,['UN','FA','combined'],['#C34835','#2868A3','#8054A1']):
        s=d[d.term==term].sort_values('stage');x=s.stage.to_numpy()
        ax.plot(x,100*s.estimate.to_numpy(),'o-',color=color,ms=4)
        ax.fill_between(x,100*s.ci_low.to_numpy(),100*s.ci_high.to_numpy(),color=color,alpha=.15)
        ax.axhline(s.estimate.iloc[0]*100,color='#777777',ls=':',lw=1)
        ax.set(title=term+' effect',xlabel='Number of items',ylabel='Effect (percentage points)')
        ax.spines[['top','right']].set_visible(False)
    for extension in ['png','svg','pdf']:fig.savefig(OUT/f'effect_trajectories.{extension}',dpi=600)
    plt.close(fig)

def run():
    with open(B/'writer.lock','a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        items=load();plan=json.loads((B/'plan.json').read_text())
        original=B.parent/'uncertainty_self_threat_139/results/a8e92be4014f/trials.csv'
        manifest=dict(plan_sha256=sha(B/'plan.json'),items_sha256=sha(B/'items_2000.csv'),code_sha256=sha(__file__),protocol_sha256=sha(B/'original_protocol.py'),original_trials_sha256=sha(original))
        mp=OUT/'manifest.json'
        if mp.exists():assert json.loads(mp.read_text())==manifest
        else:atomic_json(mp,manifest)
        file=OUT/'trials.csv'
        if not file.exists():
            original_data=pd.read_csv(original);validate(original_data,items.iloc[:139]);assert len(original_data)==1668
            original_data.to_csv(file,index=False)
        d=pd.read_csv(file);validate(d,items);rows=d.to_dict('records');done=set(map(tuple,d[KEY].to_numpy()))
        checkpoint(d,items,139)
        state('loading',completed=len(rows),total=24000,complete_items=int((d.groupby('item').size()==12).sum()))
        import torch
        from transformers import AutoTokenizer,AutoModelForCausalLM
        torch.set_num_threads(4)
        tok=AutoTokenizer.from_pretrained(protocol.MODEL,local_files_only=True)
        model=AutoModelForCausalLM.from_pretrained(protocol.MODEL,dtype=torch.float32,attn_implementation='eager',local_files_only=True).to('mps').eval()
        revision=getattr(model.config,'_commit_hash',None)
        assert revision=='a09a35458c702b33eeacc393d103063234e8bc28'
        atomic_json(OUT/'runtime.json',dict(revision=revision,torch=torch.__version__,dtype='float32',device='mps',attention='eager',batch=1))
        ids=[tok.encode(str(i),add_special_tokens=False) for i in [1,2,3]];assert all(len(x)==1 for x in ids);ids=[x[0] for x in ids]
        rng=np.random.default_rng(protocol.SEED);order=list(itertools.product(protocol.CONDITIONS,range(3)))
        for ix,row in items.iloc[139:].iterrows():
            for j in rng.permutation(12):
                condition,rotation=order[j];key=(row.sample_id,condition,rotation)
                if key in done:continue
                msg,choices=protocol.messages(row,condition,rotation)
                text=tok.apply_chat_template(msg,tokenize=False,add_generation_prompt=True)
                enc=tok(text,return_tensors='pt').to('mps')
                with torch.inference_mode():logits=model(**enc,use_cache=False,logits_to_keep=1).logits[0,-1].float()
                assert torch.isfinite(logits).all()
                selected=logits[ids];probs=torch.softmax(selected,0).cpu().numpy();normalizer=float(torch.logsumexp(logits,0));mass=float(torch.exp(torch.logsumexp(selected,0)-normalizer))
                pm=dict(zip(choices,map(float,probs)));anti=next(c for c in choices if c not in ['알 수 없음',row['biased_answer']])
                record=dict(item=row.sample_id,condition=condition,rotation=int(rotation),p_unknown=pm['알 수 없음'],p_stereotype=pm[row['biased_answer']],p_anti=pm[anti],choice_mass=mass,prompt_sha256=hashlib.sha256(text.encode()).hexdigest(),logit_1=float(selected[0]),logit_2=float(selected[1]),logit_3=float(selected[2]),full_logsumexp=normalizer)
                validate(pd.DataFrame([record]),items)
                # Match the frozen CSV header before appending additional audit columns.
                if len(rows)==1668 and 'logit_1' not in pd.read_csv(file,nrows=0).columns:
                    first=pd.DataFrame(rows).reindex(columns=list(record));temp=file.with_suffix('.tmp');first.to_csv(temp,index=False);os.replace(temp,file)
                pd.DataFrame([record]).to_csv(file,mode='a',header=False,index=False)
                rows.append(record);done.add(key)
                n_complete=(len(rows)//12)
                state('running',completed=len(rows),total=24000,complete_items=n_complete,last_item=row.sample_id)
            n=int(ix)+1
            if n in plan['stages']:
                all_data=pd.DataFrame(rows);checkpoint(all_data,items,n);plot();print(f'Checkpoint {n}/2000',flush=True)
        d=pd.read_csv(file);validate(d,items);assert len(d)==24000
        assert sha(original)==manifest['original_trials_sha256']
        assert sha(B/'items_2000.csv')==manifest['items_sha256']
        checkpoint(d,items,2000);plot();state('complete',completed=len(d),total=24000,complete_items=2000)

if __name__=='__main__':
    try:run()
    except Exception as e:
        state('error',error=repr(e));raise
