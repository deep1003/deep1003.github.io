"""Sync cached publication artifacts to the existing GitHub Pages study."""
from pathlib import Path
import hashlib,json,shutil,zipfile
from bs4 import BeautifulSoup

BASE=Path(__file__).resolve().parent
SITE=Path('/Users/deep1003/data3/deep1003.github.io/assets/research/emotion-induction-design')
REP=BASE/'representation_analysis'

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def copy(source,relative):
    dest=SITE/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
    return {'source':str(source),'website':relative,'sha256':digest(source)}

def sync():
    records=[]
    for name in ['experiment_design_en','behavior_results_en','profile_pca_en','emotion_heatmap_en','embedding_pca_en','axis_similarity_L14_en']:
        for ext in ['png','svg','pdf']:records.append(copy(BASE/'figures'/f'{name}.{ext}',f'figures/{name}.{ext}'))
    records.append(copy(BASE/'figures/axis_similarity_L14_en_preview.png', 'figures/axis_similarity_L14_en_preview.png'))
    records.append(copy(BASE/'figures/axis_similarity_L14_validation.json', 'data/l14/validation.json'))
    for name in ['axis_cosines_qwen_L14.csv','heldout_checks.csv','manifest.json','qwen_runtime.json']:
        records.append(copy(REP/'results/d335ad178e3c'/name, 'data/l14/'+name))
    records.append(copy(REP/'anchors.json', 'data/l14/anchors.json'))
    records.append(copy(REP/'analysis.py', 'code/representation_analysis/analysis.py'))
    records.append(copy(BASE/'l14_methods.html', 'data/l14/methods.html'))
    records.append(copy(BASE/'axis_intervention.py', 'code/axis_intervention.py'))
    records.append(copy(BASE/'axis_intervention/protocol.json', 'data/l14/axis_intervention_protocol.json'))
    records.append(copy(BASE/'emotion_atlas.py', 'code/emotion_atlas.py'))
    atlas = REP/'emotion_atlas/output'
    for name in ['Emotion_atlas_absolute_en','Emotion_atlas_change_en']:
        for ext in ['png','svg','pdf']:
            records.append(copy(atlas/f'{name}.{ext}', f'figures/atlas/{name}.{ext}'))
        records.append(copy(atlas/f'{name}_preview.png', f'figures/atlas/{name}_preview.png'))
    for file in atlas.iterdir():
        if file.suffix in ['.csv','.json','.md']:
            records.append(copy(file, 'data/atlas/'+file.name))
    groups=[('publication_figures',['Figure_1_concept_alignment','Extended_Data_1_axis_specificity'],'concept'),('item_category_alignment',['Figure_2_KoBBQ_category_alignment','Extended_Data_2_four_conditions','KoBBQ_UN_FA_absolute_map','KoBBQ_UN_FA_change_map'],'category')]
    for module,names,dest in groups:
        out=REP/module/'output'
        for name in names:
            for ext in ['pdf','svg','png']:records.append(copy(out/f'{name}.{ext}',f'figures/{dest}/{name}.{ext}'))
            records.append(copy(out/f'{name}_preview.png',f'figures/{dest}/{name}_preview.png'))
        records.append(copy(out/'Captions_and_methods.md',f'data/{dest}/Captions_and_methods.md'))
        for file in out.glob('*.csv'):records.append(copy(file,f'data/{dest}/{file.name}'))
        for file in out.glob('source_data/*.csv'):records.append(copy(file,f'data/{dest}/source_data/{file.name}'))
        for name in ['validation.json','provenance.json','artwork_provenance.json','manifest.json','plot_summary.json']:
            if (out/name).exists():records.append(copy(out/name,f'data/{dest}/{name}'))
    token=REP/'token_highlights/output'
    for ext in ['png','svg','pdf']:records.append(copy(token/f'prompt_FA_trace_en.{ext}',f'figures/prompt_FA_trace_en.{ext}'))
    for source,dest in [('prompt_highlights.html','index.html'),('token_scores.csv','token_scores.csv'),('manifest.json','manifest.json')]:records.append(copy(token/source,f'prompt-activations/{dest}'))
    records.append(copy(BASE.parent/'uncertainty_self_threat_139.ipynb','downloads/uncertainty_self_threat_139.ipynb'))
    for source in [BASE/'english_figures.py',BASE/'notebook_views.py',BASE/'plot_style.py',REP/'publication_figures/build_figures.py',REP/'item_category_alignment/plot.py',REP/'item_category_alignment/measure.py',REP/'item_category_alignment/collection_source_v1.py',REP/'token_highlights/render.py',REP/'token_highlights/measure.py']:
        records.append(copy(source,'code/'+str(source.relative_to(BASE))))
    readme='''# Manual notebook workflow\n\nThe notebook and active figures are synchronized with the study page. All figure titles, axes, legends and annotations use American English. Korean explanations and the original Korean stimuli are preserved. The original text highlight viewer displays measured Korean input; token values are not reassigned to translated English words.\n\nUnzip next to the notebook so that uncertainty_self_threat_139/ and threat_139_pilot/ remain siblings. Cached analysis is the default and does not load a language model. Inference requires explicit manual opt-in through RUN_MISSING, MEASURE_REPRESENTATIONS, MEASURE_TOKEN_REPRESENTATIONS, MEASURE_ITEM_ALIGNMENT, or RUN_AXIS_INTERVENTIONS. The notebook does not start background controllers or scheduled jobs. Completed keys are retained.\n\nPlotting code is in english_figures.py, notebook_views.py, and the representation_analysis publication modules. Frozen collection code and manifests are preserved for source verification. Models and model weights are not included. Optional measurement uses the local model cache. Historical collector plotting functions are retained as provenance; the notebook uses the English presentation adapters.\n\nThe concept axes are exploratory and correlated. The item-level alignment changes show weak descriptive relationships with the change in information-insufficient response probability (UN rho = -0.009; FA rho = 0.085). These figures do not demonstrate functional emotion causing behavior.\n'''
    (BASE/'MANUAL_WORKFLOW.md').write_text(readme);(SITE/'downloads/MANUAL_WORKFLOW.md').write_text(readme)
    bundle=SITE/'downloads/notebook_cached_analysis.zip'
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(BASE.parent/'uncertainty_self_threat_139.ipynb','uncertainty_self_threat_139.ipynb')
        z.write(BASE.parent/'threat_139_pilot/items_139.csv','threat_139_pilot/items_139.csv')
        for f in BASE.glob('*.py'):
            if f.name!='run_notebook.py':z.write(f,Path(BASE.name)/f.relative_to(BASE))
        z.write(BASE/'axis_intervention/protocol.json', Path(BASE.name)/'axis_intervention/protocol.json')
        z.write(BASE/'MANUAL_WORKFLOW.md',Path(BASE.name)/'MANUAL_WORKFLOW.md')
        for f in (BASE/'results/a8e92be4014f').iterdir():
            if f.suffix in ['.csv','.json','.md']:z.write(f,Path(BASE.name)/f.relative_to(BASE))
        z.write(BASE/'figures/experiment_design_en.png',Path(BASE.name)/'figures/experiment_design_en.png')
        for f in REP.rglob('*'):
            if not f.is_file() or any(t in f.parts for t in ['references','hidden','chunks','__pycache__','loading_recovery']):continue
            if f.suffix not in ['.py','.csv','.json','.md','.npz']:continue
            if f.suffix=='.npz' and f.parent.name=='output':continue
            if f.parent.name in ['cb967efdc2e8','93cf36e80cd1']:continue
            z.write(f,Path(BASE.name)/f.relative_to(BASE))
    records.append({'source':str(bundle),'website':'downloads/notebook_cached_analysis.zip','sha256':digest(bundle)})
    page=SITE/'index.html';soup=BeautifulSoup(page.read_text(),'html.parser')
    for id in ['representations','category-map','behavior-figure']:
        old=soup.find(id=id)
        if old:old.decompose()
    for a in list(soup.find('nav').find_all('a')):
        if a.get('href') in ['#representations','#category-map']:a.decompose()
    for block,prefix in [('results-current','내부 정렬 분석에서는'),('limitations','내부 개념 축은')]:
        for paragraph in list(soup.find('section',id=block).find_all('p')):
            if paragraph.get_text().startswith(prefix):paragraph.decompose()
    for paragraph in list(soup.find('footer').find_all('p')):
        if paragraph.get_text().startswith('그래프·도식은 영문'):paragraph.decompose()
    source_section=soup.find('section',id='sources')
    for h in list(source_section.find_all('h3')):
        if h.get_text()=='직접 실행할 노트북과 논문용 산출물':
            for sibling in list(h.next_siblings):
                if hasattr(sibling,'decompose'):sibling.decompose()
            h.decompose()
    def fragment(value):return BeautifulSoup(value,'html.parser')
    def figure(path,caption,downloads=True):
        stem=path.removesuffix('_preview.png').removesuffix('.png')
        return f'<figure><a href="{stem}.svg"><img src="{path}" loading="lazy" alt="{caption}"/></a><figcaption>{caption}</figcaption></figure>'+ (f'<p class="links"><a href="{stem}.pdf">PDF</a><a href="{stem}.svg">SVG</a><a href="{stem}.png">600 dpi PNG</a></p>' if downloads else '')
    model=soup.find('section',id='model');model.clear();model.append(fragment('<h2>4. 연구모델</h2>'+figure('figures/experiment_design_en.png','대응 2×2 연구 설계. 동일한 139문항과 세 선택지 순서를 유지하며, 두 공지 요소의 효과를 분리한다. 영문 도식은 구조를 설명하며 실제 입력 원문은 프롬프트 항목에 제시한다.')))
    model.append(fragment('<p>Y<sub>un,fa</sub>를 각 조건의 평균 정보 부족 응답 확률로 두면 주요 대비는 다음과 같다.</p><div class="equation">Δ<sub>UN</sub> = ½[(Y<sub>10</sub> − Y<sub>00</sub>) + (Y<sub>11</sub> − Y<sub>01</sub>)]<br/>Δ<sub>FA</sub> = ½[(Y<sub>01</sub> − Y<sub>00</sub>) + (Y<sub>11</sub> − Y<sub>10</sub>)]<br/>Δ<sub>UN×FA</sub> = (Y<sub>11</sub> − Y<sub>01</sub>) − (Y<sub>10</sub> − Y<sub>00</sub>)</div><p class="formula-note">문항 내 대응을 유지한 추정량의 정의이며 별도의 회귀모형 적합 결과가 아니다.</p>'))
    results=soup.find('section',id='results')
    for old in list(results.find_all('figure')):old.decompose()
    for old in list(results.find_all('p',class_='links')):old.decompose()
    for detail in results.find_all('details'):detail.attrs.pop('open',None)
    details=fragment('<details id="behavior-figure"><summary>행동 결과 그래프 · 조건 평균과 주요 대비</summary><div class="detail-body">'+figure('figures/behavior_results_en.png','동일한 문항의 조건별 평균과 세 주요 대비. 95% 구간은 다중비교 보정 전이며, 세 주요 대비의 p값에 Holm 보정을 적용했다.')+'</div></details>')
    results.find('h2').insert_after(details)
    for summary in results.find_all('summary'):
        if '기존 결과' in summary.get_text():summary.string='조건별 평균 표'
    section=fragment('<section id="representations"><h2>7. 프롬프트 표현과 내부 개념 정렬</h2><p>네 시스템 공지 자체의 의미 표현과 7B 응답 시작 위치의 내부 표현을 구분한다. 개념 정렬 점수의 PCA는 전체 은닉 벡터의 PCA와 다르며, 네 고정 공지를 대상으로 한다. 높은 설명분산은 정서 측정의 타당성을 입증하지 않는다.</p><details id="concept-figure"><summary>개념 프로파일 PCA와 중립 대비 정렬 변화</summary><div class="detail-body">'+figure('figures/concept/Figure_1_concept_alignment_preview.png','일곱 개념 정렬 프로파일의 PCA와 UN0FA0 대비 변화. 두 공간은 각각 적합·보정했으므로 수치를 동일한 정서 강도로 비교하지 않는다.')+'<a href="data/concept/Captions_and_methods.md">영문 캡션과 방법</a></div></details><details id="axis-validity"><summary>축의 겹침과 개념 구분 점검</summary><div class="detail-body">'+figure('figures/concept/Extended_Data_1_axis_specificity_preview.png','축 간 코사인 유사도, 보류 문장쌍의 구분 개수와 내부 PC1 가중치. 의미 공간의 FA는 보류 4쌍 중 1쌍만 구분했다. 기능적 정서의 검증 결과로 해석하지 않는다.')+'</div></details><details id="token-figure"><summary>프롬프트를 읽는 위치별 내부 정렬</summary><div class="detail-body">'+figure('figures/prompt_FA_trace_en.png','14층의 입력 위치별 FA 정렬과 응답 시작 위치. 원문은 한국어이며, 그래프의 표기는 영어다. 글자별 색칠 보기는 원문 토큰과 연결한 탐색적 측정으로 단어의 인과 기여도가 아니다.')+'<p><a href="prompt-activations/index.html">원문 프롬프트의 토큰별 색칠 보기</a></p></div></details></section>')
    l14 = section.find('section')
    l14.append(fragment('<details id="l14-axis-heatmap"><summary>7×7 히트맵 · 개념 축 간 코사인 유사도</summary><div class="detail-body">' + figure('figures/axis_similarity_L14_en_preview.png', 'Qwen L14의 일곱 단위 방향 사이 코사인 유사도. 대각선은 1이며, 관측 활성값 사이의 상관계수나 정서 확률이 아니다.') + '</div></details>'))
    l14.append(fragment('<details id="l14-methods"><summary>Qwen L14 정서 개념 축 측정 방법 · 기술·수식·검증·참고문헌</summary><div class="detail-body">' + (BASE/'l14_methods.html').read_text() + '</div></details>'))
    atlas_html = (BASE/'emotion_atlas_section.html').read_text().replace('ATLAS_FIGURES', figure('figures/atlas/Emotion_atlas_change_en_preview.png', '동일 기준 대비 변화. 실제 139문항을 각 정서 구획에 배치하고, 네 조건에서 같은 색 범위를 유지했다.') + figure('figures/atlas/Emotion_atlas_absolute_en_preview.png', '현재 내부 개념 정렬값. 축별 기준 중심이 다르므로 정서의 절대 강도 순위로 해석하지 않는다.'))
    l14.append(fragment(atlas_html))
    l14.append(fragment((BASE/'axis_intervention_protocol.html').read_text()))
    results.insert_after(section)
    category=fragment('<section id="category-map"><h2>8. KoBBQ 카테고리와 UN·FA 정렬</h2><p>139문항의 전체 입력을 읽은 뒤 응답 시작 위치의 내부 상태를 측정했다. 선택지 순서 3개의 코사인을 평균해 문항당 하나의 점을 만들었다. 12개 카테고리를 색과 모양으로 구분하며 큰 외곽선 마커는 카테고리 평균이다.</p><p class="note">139문항 모두 결합 조건에서 중립 대비 UN·FA 정렬이 증가했다. 그러나 문항별 정렬 변화와 ‘알 수 없음’ 확률 변화의 상관은 UN −0.009, FA 0.085로 약했다. 카테고리별 정렬의 기술적 결과이며 정서가 판단 변화를 유발했다는 증거가 아니다.</p><details id="category-figure"><summary>139문항의 UN–FA 위치와 중립 대비 이동</summary><div class="detail-body">'+figure('figures/category/Figure_2_KoBBQ_category_alignment_preview.png','왼쪽은 UN+FA 조건의 절대 정렬, 오른쪽은 같은 문항의 중립 대비 변화다. 높은 절대 정렬과 높은 문맥 민감도를 구분한다. 상관계수는 UN·FA 두 좌표 사이의 기술적 관계다.')+'<p class="links"><a href="data/category/Figure_2a_source_data.csv">절대 좌표와 원문 CSV</a><a href="data/category/Figure_2b_source_data.csv">변화량과 원문 CSV</a><a href="data/category/Captions_and_methods.md">영문 캡션</a></p></div></details><details><summary>단일 UN–FA 지도와 네 조건 비교</summary><div class="detail-body">'+figure('figures/category/KoBBQ_UN_FA_absolute_map_preview.png','UN+FA 조건의 139문항 지도. 가로축은 UN 정렬, 세로축은 FA 정렬이다.')+figure('figures/category/Extended_Data_2_four_conditions_preview.png','같은 축 범위에서 비교한 네 조건. 같은 문항이 각 패널에 반복되므로 독립 표본으로 합치지 않는다.')+'</div></details><p>카테고리당 문항은 4~21개이며, 139문항은 91개 범주·문항 틀을 공유한다. 선별 표본의 평균 순위를 모집단의 민감도 순위로 일반화하지 않는다. 주 분석은 14층이며 21·28층의 자료도 보존했다.</p><p class="links"><a href="data/category/category_summary.csv">카테고리별 수치</a><a href="data/category/layer_category_sensitivity.csv">층별 점검</a><a href="data/category/representation_behavior_associations.csv">응답 변화와의 관계</a></p></section>')
    soup.find('section',id='representations').insert_after(category)
    for id,title in [('implications','9. 학술적 함의'),('limitations','10. 한계와 후속 검증'),('references','11. 참고문헌')]:soup.find('section',id=id).find('h2').string=title
    soup.find('section',id='limitations').append(fragment('<p>내부 개념 축은 서로 겹치며, 시스템 공지 기준에서 전체 KoBBQ 입력으로의 전이는 탐색적이다. 정렬 변화와 정보 부족 응답 확률 변화의 약한 관계를 고려하면, 정서 활성의 행동 기여를 주장하려면 별도의 활성 개입과 행동 검증이 필요하다.</p>'))
    soup.find('section',id='results-current').append(fragment('<p>내부 정렬 분석에서는 문항별 UN·FA 정렬 증가를 관측했으나, 그 증가와 정보 부족 응답 확률 변화의 관계는 약했다. 행동 효과와 내부 개념 정렬은 별도로 해석한다.</p>'))
    nav=soup.find('nav');nav.append(fragment('<a href="#representations">개념 정렬</a><a href="#category-map">카테고리 지도</a>'))
    artifacts=soup.find('section',id='sources');artifacts.append(fragment('<h3>직접 실행할 노트북과 논문용 산출물</h3><p>모든 활성 그래프는 미국식 영어로 출력한다. 노트북의 기본값은 저장 자료를 읽으며, 모델 추론은 사용자가 실행 설정을 바꿀 때만 시작한다.</p><p class="links"><a href="downloads/uncertainty_self_threat_139.ipynb">Jupyter Notebook</a><a href="downloads/notebook_cached_analysis.zip">코드·자료 포함 실행 묶음</a><a href="downloads/MANUAL_WORKFLOW.md">실행 안내</a><a href="sync-manifest.json">동기화 해시</a></p>'))
    for a in soup.find_all('a',href='result.png'):a['href']='figures/behavior_results_en.png'
    soup.find('footer').append(fragment('<p>그래프·도식은 영문 출판 형식으로 제공하며, 본문 설명과 실제 프롬프트 원문은 한글을 유지한다.</p>'))
    style=soup.find('style',id='publication-sync-layout')
    if style is None:
        style=soup.new_tag('style',id='publication-sync-layout');soup.head.append(style)
    style.string='.detail-body pre{overflow-x:auto;background:#f5f6f7;padding:16px;font-size:12px;line-height:1.6}.detail-body code{overflow-wrap:anywhere}.detail-body .equation{overflow-x:auto;padding:14px;line-height:2}.detail-body h3{margin-top:26px}section{scroll-margin-top:130px}@media(max-width:640px){section{scroll-margin-top:20px}}'
    # A changed figure gets a new URL so browsers do not show an older ordering.
    for tag, attribute in [(tag, 'src') for tag in soup.find_all('img')] + [(tag, 'href') for tag in soup.find_all('a')]:
        relative = tag.get(attribute, '').split('?')[0]
        if relative.startswith('figures/') and (SITE/relative).is_file():
            tag[attribute] = relative + '?v=' + digest(SITE/relative)[:10]
    page.write_text(str(soup))
    records.append({'source':str(page),'website':'index.html','sha256':digest(page)})
    (SITE/'sync-manifest.json').write_text(json.dumps({'manual_execution':True,'automatic_model_inference':False,'figure_language':'en-US','n_items':139,'records':records},indent=2,ensure_ascii=False))
    print('Synced',len(records),'files; bundle',round(bundle.stat().st_size/1e6,2),'MB')

if __name__=='__main__':sync()
