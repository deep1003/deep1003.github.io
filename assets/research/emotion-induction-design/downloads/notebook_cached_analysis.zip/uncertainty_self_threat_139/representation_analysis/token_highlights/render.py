"""Interactive text backgrounds from saved internal measurements, never inference."""
from pathlib import Path
import json
import numpy as np

BASE=Path(__file__).resolve().parent
LABELS=['불확실성 UN','공포·불안 FA','평온','슬픔','분노','절박함','기쁨']
import sys
PROJECT = Path(__file__).resolve().parents[2]
if str(PROJECT) not in sys.path:
    sys.path.insert(0, str(PROJECT))
from plot_style import PALETTE, CONCEPT_ORDER, CONDITION_COLORS, ACTIVATION_STOPS
COLORS=[PALETTE[k] for k in CONCEPT_ORDER]
HTML=r'''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>프롬프트를 읽는 동안의 감정 축 유사도</title>
<style>body{font:16px/1.7 -apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo",sans-serif;color:#222;background:#fafafa;max-width:1100px;margin:34px auto;padding:0 22px}h1{font-size:26px;line-height:1.4}h2{font-size:18px;margin:8px 0}p{margin:9px 0}small,.note{font-size:13px;color:#555}button,select{font:inherit;font-size:14px;border:1px solid #ccc;border-radius:5px;background:white;padding:7px 11px;cursor:pointer}button.active{border-color:#222;box-shadow:0 0 0 1px #222}nav,.controls{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}.card{border:1px solid #ddd;background:white;border-radius:8px;padding:22px;margin:15px 0}.prompt{font-size:20px;line-height:2.1;white-space:pre-wrap;overflow-wrap:anywhere}.prompt span{border-radius:2px;padding:3px 0;cursor:help}.legend{height:12px;width:240px;margin-top:10px}.scale{display:flex;justify-content:space-between;width:240px;font-size:12px}.summary{display:grid;grid-template-columns:repeat(7,1fr);gap:12px;margin-top:12px}.bar{height:7px;background:#eee}.bar i{display:block;height:7px}.score{font-size:13px}.axis{font-size:13px}.tooltip{font-size:14px;min-height:52px;background:#f5f5f5;padding:10px;margin-top:18px;border-radius:5px}.trace{width:100%;height:115px}.tip{border-left:3px solid #888;padding-left:12px}.divider{border-top:1px solid #eee;margin:22px 0}@media(max-width:640px){.prompt{font-size:17px}.summary{grid-template-columns:repeat(2,1fr)}body{padding:0 12px}.card{padding:15px}}</style>
<h1>프롬프트를 읽는 동안의 감정 축 유사도</h1><p>글자 배경은 해당 토큰까지 읽었을 때의 Qwen2.5-7B 내부 은닉 상태와 선택한 개념 방향의 유사도값입니다.</p><p class="note tip">이 색은 단어 자체의 감정 사전 점수나 원인 기여도가 아닙니다. 앞 문맥·토큰 정체성·위치의 영향을 포함합니다. 기능적 정서가 행동을 유발한다는 증거는 별도의 개입 검증이 필요합니다.</p>
<nav id="conditions"></nav><div class="controls"><label>층 <select id="layer"><option>14</option><option>21</option><option>28</option></select></label><label>값 <select id="metric"><option value="cosine">중심화 코사인 유사도</option><option value="z">기준 문장 표준화 투영</option></select></label><label>색 범위 ± <select id="limit"><option>0.10</option><option selected>0.25</option><option>0.50</option><option>1.00</option></select></label></div><nav id="concepts"></nav>
<div class="card"><h2 id="title"></h2><p class="note" id="detail"></p><div id="prompt" class="prompt"></div><div class="legend" id="legend"></div><div class="scale"><span id="left"></span><span>0</span><span id="right"></span></div><div class="tooltip" id="tooltip">글자에 마우스를 올리거나 누르면 실제 값과 토큰 위치를 볼 수 있습니다.</div><div class="divider"></div><h2>선택한 축의 읽기 위치별 변화</h2><svg class="trace" id="trace" viewBox="0 0 1000 110" preserveAspectRatio="none"></svg><p class="note">가로축은 원문 글자 위치입니다. 같은 토큰에 속한 글자는 같은 값을 공유할 수 있습니다. 문장 시작부터 읽은 누적 문맥을 반영하며, 서로 독립적인 단어 점수가 아닙니다.</p></div>
<div class="card"><h2>전체 공지 뒤, 응답 시작 위치의 유사도</h2><p class="note">아래 수치는 기존 문장 전체 측정과 같은 위치입니다. 입력을 읽는 도중의 글자 배경과 구분합니다.</p><div class="summary" id="summary"></div></div>
<details class="card"><summary>측정과 해석의 범위</summary><p>기존 고정 프롬프트 4개와 기준 문장으로 만든 7개 방향을 그대로 사용했습니다. KoBBQ 문항, 출력 생성, 정서 벡터 개입은 포함하지 않습니다.</p><p>토큰 위치 t의 값은 (h[t] − 기준 중심)과 개념 방향의 코사인입니다. 표준화 투영은 그 방향의 훈련 기준 문장 표준편차로 나눈 값입니다. 글자는 fast tokenizer의 offset으로 연결했고, 한국어 바이트 조각 토큰이 겹치면 평균합니다. 모델이 개별 한글 글자 단위로 작동한다는 뜻은 아닙니다.</p><p>기준 방향은 응답 시작 위치에서 학습·검증되었습니다. 입력 토큰에 적용하는 것은 위치 간 전이가 검증되지 않은 탐색적 측정입니다. 색 범위는 읽기 편의를 위한 표시 한계이며 실제 값은 툴팁에서 확인합니다. 글자 배경은 모든 개념에 공통인 짙은 적색–밝은 노란색 척도입니다. 선택 버튼과 개념 이름에는 고유 색을 사용합니다. 색 농도를 서로 같은 감정 강도로 비교하지 않습니다.</p><p>입력 토큰의 색은 그 단어를 지우면 마지막 응답 활성이나 KoBBQ 판단이 얼마나 바뀔지를 알려주지 않습니다. 이를 알아보려면 대조 문구 교체·활성 패칭·벡터 개입 및 행동 검증이 필요합니다.</p><a href="token_scores.csv">토큰별 원자료 CSV</a> · <a href="manifest.json">측정 설정과 해시</a></details>
<script>const DATA=__DATA__;const LABELS=__LABELS__;const COLORS=__COLORS__;const CONDITION_COLORS=__CONDITION_COLORS__;const VALUE_STOPS=__VALUE_STOPS__;const NAMES={UN0FA0:'00 중립',UN0FA1:'01 FA',UN1FA0:'10 UN',UN1FA1:'11 UN + FA'};let condition='UN1FA1',axis=1;
const el=x=>document.getElementById(x);const rgb=h=>h.match(/\w\w/g).map(x=>parseInt(x,16));function shade(v,limit){const t=Math.max(0,Math.min(1,(v/limit+1)/2));let k=1;while(k<VALUE_STOPS.length-1&&t>VALUE_STOPS[k][0])k++;const [a,ha]=VALUE_STOPS[k-1],[b,hb]=VALUE_STOPS[k],u=(t-a)/(b-a),ca=rgb(ha.slice(1)),cb=rgb(hb.slice(1));return `rgb(${ca.map((x,i)=>Math.round(x+(cb[i]-x)*u)).join(',')})`}
function ink(s){let c=s.match(/\d+/g).map(x=>+x/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4);return .2126*c[0]+.7152*c[1]+.0722*c[2]>.179?'#111111':'#FFFFFF'}

function draw(){let p=DATA.prompts.find(x=>x.condition===condition),layer=el('layer').value,metric=el('metric').value,limit=+el('limit').value,chars=p.layers[layer];el('title').textContent=NAMES[condition]+' · '+LABELS[axis];el('detail').textContent='7B '+layer+'층 · '+(metric==='cosine'?'중심화 코사인':'기준 문장 표준화 투영')+' · 입력 토큰 위치';el('prompt').replaceChildren();chars.forEach((r,i)=>{let s=document.createElement('span'),v=r[metric][axis];s.textContent=r.char;s.style.backgroundColor=shade(v,limit);s.style.color=ink(shade(v,limit));let msg=`글자 ${i+1} · 토큰 ${r.tokens.join(', ')} · ${LABELS[axis]} · 코사인 ${r.cosine[axis].toFixed(5)} · 표준화 투영 ${r.z[axis].toFixed(4)}`;s.title=msg;s.onmouseenter=()=>el('tooltip').textContent=msg;s.onclick=()=>el('tooltip').textContent=msg;el('prompt').appendChild(s)});el('legend').style.background=`linear-gradient(to right,${VALUE_STOPS.map(([p,c])=>c+' '+p*100+'%').join(',')})`;el('left').textContent=(-limit).toFixed(2);el('right').textContent='+'+limit.toFixed(2);
let values=chars.map(x=>x[metric][axis]),max=Math.max(.0001,...values.map(Math.abs)),points=values.map((v,i)=>`${10+i/(values.length-1)*980},${55-v/max*43}`).join(' ');el('trace').innerHTML=`<line x1="10" x2="990" y1="55" y2="55" stroke="#ddd"/><polyline points="${points}" fill="none" stroke="${COLORS[axis]}" stroke-width="1.4"/><text x="10" y="108" font-size="11">1</text><text x="965" y="108" font-size="11">${values.length}</text>`;
el('summary').replaceChildren();p.assistant_start[layer].cosine.forEach((v,i)=>{let box=document.createElement('div'),label=document.createElement('div'),bar=document.createElement('div'),fill=document.createElement('i'),score=document.createElement('div');label.className='axis';label.textContent=LABELS[i];label.style.color=COLORS[i];bar.className='bar';fill.style.width=Math.min(100,Math.abs(v)*100)+'%';fill.style.background=shade(v,limit);score.className='score';score.textContent=v.toFixed(4);bar.appendChild(fill);box.append(label,bar,score);box.title='응답 시작 코사인 '+v+'; 표준화 투영 '+p.assistant_start[layer].z[i];el('summary').appendChild(box)});
document.querySelectorAll('#conditions button').forEach(b=>b.classList.toggle('active',b.dataset.c===condition));document.querySelectorAll('#concepts button').forEach(b=>b.classList.toggle('active',+b.dataset.a===axis))}
Object.keys(NAMES).forEach(c=>{let b=document.createElement('button');b.textContent=NAMES[c];b.dataset.c=c;b.style.borderBottom='3px solid '+CONDITION_COLORS[c];b.onclick=()=>{condition=c;draw()};el('conditions').appendChild(b)});LABELS.forEach((l,i)=>{let b=document.createElement('button');b.textContent=l;b.dataset.a=i;b.style.borderBottom='3px solid '+COLORS[i];b.onclick=()=>{axis=i;draw()};el('concepts').appendChild(b)});['layer','metric','limit'].forEach(i=>el(i).onchange=draw);draw();</script></html>'''

def render(output=None):
    out=Path(output) if output else BASE/'output'
    payload=json.loads((out/'highlights.json').read_text())
    text=HTML.replace('__DATA__',json.dumps(payload,ensure_ascii=False).replace('</','<\\/')).replace('__LABELS__',json.dumps(LABELS,ensure_ascii=False)).replace('__COLORS__',json.dumps(COLORS)).replace('__NEGATIVE_COLOR__',PALETTE['neutral']).replace('__CONDITION_COLORS__',json.dumps(CONDITION_COLORS)).replace('__VALUE_STOPS__',json.dumps(ACTIVATION_STOPS))
    (out/'prompt_highlights.html').write_text(text)
    import sys
    project = BASE.parent.parent
    if str(project) not in sys.path:
        sys.path.insert(0, str(project))
    from english_figures import token_trace
    token_trace(out, show=False)
    return out/'prompt_highlights.html'

if __name__=='__main__':print(render())
