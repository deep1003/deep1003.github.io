"""저장된 표현 측정의 그림만 생성한다. 모델 추론을 호출하지 않는다."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from plot_style import PALETTE,condition_marker
from representation_analysis.analysis import LABELS,CONDITIONS

def render(out,show=False):
    import matplotlib
    if not show:matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import to_rgb
    from matplotlib.patches import Rectangle
    plt.rcParams.update({'font.family':'AppleGothic','axes.unicode_minus':False,'svg.fonttype':'path','pdf.fonttype':42})
    out=Path(out);scores=pd.read_csv(out/'scores.csv');checks=pd.read_csv(out/'heldout_checks.csv')
    names={'semantic':'프롬프트의 의미 표현','qwen_L14':'7B 응답 시작의 내부 표현 · 14층'}
    for kind,title in [('profile_pca','정서·불확실성 점수의 2차원 위치'),('embedding_pca','전체 표현 벡터의 2차원 위치')]:
        data=json.loads((out/f'{kind}.json').read_text());fig,axs=plt.subplots(1,2,figsize=(11,5.2),layout='constrained')
        for ax,space in zip(axs,names):
            result=data[space]
            if 'coordinates' not in result:
                ax.text(.5,.5,'보류 검증 통과 축이 2개 미만\n정서 점수 PCA 해석 보류',ha='center',va='center',transform=ax.transAxes);ax.axis('off');continue
            xy=pd.DataFrame(result['coordinates']).set_index('condition')
            for a,b in [('UN0FA0','UN1FA0'),('UN0FA1','UN1FA1')]:ax.plot(xy.loc[[a,b],'PC1'],xy.loc[[a,b],'PC2'],color='#cccccc',lw=1,zorder=1)
            for c,row in xy.iterrows():
                condition_marker(ax,row.PC1,row.PC2,c)
                ax.annotate(c,(row.PC1,row.PC2),xytext=(8,8),textcoords='offset points',fontsize=10)
            ratios=result['explained_variance_ratio'];ax.set(xlabel=f'PC1 ({ratios[0]:.1%})',ylabel=f'PC2 ({ratios[1]:.1%})',title=names[space]+f"\n보존 분산 {result['retained_variance']:.2%}")
            ax.margins(.38);ax.set_aspect('equal',adjustable='datalim');ax.axhline(0,color='#ddd',lw=.6);ax.axvline(0,color='#ddd',lw=.6);ax.spines[['top','right']].set_visible(False)
        fig.suptitle(title,fontsize=14)
        fig.supxlabel('회색 중립 · 빨강 UN · 파랑 FA · 반쪽 마커 UN+FA   |   두 패널은 별도 좌표계',fontsize=10)
        for ext in ['png','svg','pdf']:fig.savefig(out/f'{kind}.{ext}',dpi=200)
        if show:plt.show()
        plt.close(fig)
    # Colours identify concepts; numbers carry the quantitative magnitudes.
    fig,axs=plt.subplots(1,2,figsize=(12,5.3),layout='constrained');axes=list(LABELS)
    deltas=[]
    for space in names:
        base=scores[(scores.space==space)&(scores.condition=='UN0FA0')].set_index('axis').standardized
        part=scores[scores.space==space]
        deltas.extend([float(r.standardized-base[r.axis]) for r in part.itertuples()])
    vmax=max(.01,max(abs(v) for v in deltas))
    for ax,space in zip(axs,names):
        m=scores[scores.space==space].pivot(index='condition',columns='axis',values='standardized').reindex(index=CONDITIONS,columns=axes)
        m=m.subtract(m.loc['UN0FA0'])
        valid=checks[checks.space==space].set_index('axis').passed
        for i in range(4):
            for j,axis in enumerate(axes):
                value=float(m.iloc[i,j]);colour=PALETTE[axis];t=min(.75,abs(value)/vmax*.75)
                face=(1-t)*np.ones(3)+t*np.array(to_rgb(colour))
                if i==0:face=np.array(to_rgb('#eeeeee'))
                ax.add_patch(Rectangle((j-.5,i-.5),1,1,facecolor=face,edgecolor='white',hatch='//' if value < -1e-9 else None))
                ax.text(j,i,f'{value:+.2f}'+('' if valid[axis] else '*'),ha='center',va='center',fontsize=9)
        ax.set(xlim=(-.5,6.5),ylim=(3.5,-.5),xticks=range(7),xticklabels=[LABELS[x] for x in axes],yticks=range(4),yticklabels=CONDITIONS,title=names[space]);ax.tick_params(axis='x',rotation=45)
        for tick,axis in zip(ax.get_xticklabels(),axes):tick.set_color(PALETTE[axis])
        for spine in ax.spines.values():spine.set_visible(False)
    fig.suptitle('정서 개념의 동시 유사도 변화 · UN0FA0 대비',fontsize=14)
    fig.supxlabel('숫자는 표준화 투영 변화 · 빗금은 감소 · * 보류 검증 실패 · 정서 확률이 아님',fontsize=10)
    for ext in ['png','svg','pdf']:fig.savefig(out/f'emotion_heatmap.{ext}',dpi=200)
    if show:plt.show()
    plt.close(fig)
    # Directly interpretable axes complement PCA; these axes are not assumed orthogonal.
    fig,axs=plt.subplots(1,2,figsize=(11,4.8),layout='constrained')
    for ax,space in zip(axs,names):
        m=scores[scores.space==space].pivot(index='condition',columns='axis',values='cosine').reindex(CONDITIONS)
        for c,row in m.iterrows():
            condition_marker(ax,row.UN,row.FA,c);ax.annotate(c,(row.UN,row.FA),xytext=(7,7),textcoords='offset points',fontsize=10)
        ax.set(xlabel='UN 축의 코사인 유사도',ylabel='FA 축의 코사인 유사도',title=names[space]);ax.margins(.4);ax.axhline(0,color='#ddd',lw=.7);ax.axvline(0,color='#ddd',lw=.7);ax.spines[['top','right']].set_visible(False)
    fig.suptitle('UN·FA 축의 직접 유사도 · PCA와 구분',fontsize=14)
    for ext in ['png','svg','pdf']:fig.savefig(out/f'un_fa_alignment.{ext}',dpi=200)
    if show:plt.show()
    plt.close(fig)
    return out
