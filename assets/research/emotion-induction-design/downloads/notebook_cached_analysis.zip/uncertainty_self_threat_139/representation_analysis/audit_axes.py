"""저장된 값만 사용하는 축 구분·공유 성분의 탐색적 진단. 원 측정/축을 수정하지 않는다."""
from pathlib import Path
import hashlib,json,re
import numpy as np
import pandas as pd
BASE=Path(__file__).resolve().parent
OUT=Path(json.loads((BASE/'status.json').read_text())['out'])
DEST=OUT/'axis_audit';DEST.mkdir(exist_ok=True)
AXES=['UN','FA','calm','sadness','anger','desperation','joy']
CONDITIONS=['UN0FA0','UN0FA1','UN1FA0','UN1FA1']
a=json.loads((BASE/'anchors.json').read_text());q=np.load(OUT/'qwen.npz');semantic=np.load(OUT/'semantic.npz')
spaces={'semantic':(semantic['anchors'],semantic['targets'])}
for j,layer in enumerate([14,21,28]):spaces[f'qwen_L{layer}']=(q['anchors'][:,:,j,:],q['targets'][:,j,:])
results=[];all_records=[]
for space,(v,targets) in spaces.items():
    saved=np.load(OUT/f'axes_{space}.npz');d=saved['directions'];matrix=[]
    for k,axis in enumerate(AXES):
        held=[i for i,r in enumerate(a) if r['axis']==axis and r['split']=='heldout']
        diff=v[held,0]-v[held,1];diff/=np.linalg.norm(diff,axis=1,keepdims=True)
        similarities=diff@d.T;matrix.append(similarities.mean(0))
        for i,index in enumerate(held):
            all_records.append({'space':space,'true_axis':axis,'pair':a[index]['pair'],
                                'predicted_axis':AXES[int(similarities[i].argmax())],
                                'correct':bool(similarities[i].argmax()==k)})
        results.append({'space':space,'axis':axis,'correct_of_4':int((similarities.argmax(1)==k).sum()),
                        'own_direction_cosine_mean':float(similarities[:,k].mean()),
                        'largest_other_direction_cosine_mean':float(np.delete(similarities,k,axis=1).max(1).mean())})
    pd.DataFrame(matrix,index=AXES,columns=AXES).to_csv(DEST/f'heldout_cross_loadings_{space}.csv')
    if space=='qwen_L14':
        common=d.mean(0);common/=np.linalg.norm(common)
        delta=targets-targets[0];residual=delta-(delta@common)[:,None]*common
        pd.DataFrame(delta@d.T/saved['scales'],index=CONDITIONS,columns=AXES).to_csv(DEST/'original_delta_L14.csv')
        pd.DataFrame(residual@d.T/saved['scales'],index=CONDITIONS,columns=AXES).to_csv(DEST/'shared_direction_removed_delta_L14.csv')
        np.savez_compressed(DEST/'shared_direction_L14.npz',direction=common)
pd.DataFrame(results).to_csv(DEST/'heldout_axis_identification.csv',index=False)
pd.DataFrame(all_records).to_csv(DEST/'heldout_predictions.csv',index=False)
counts=[]
for axis in AXES:
    rows=[r for r in a if r['axis']==axis]
    counts.append({'axis':axis,'n_pairs':len(rows),
                   'positive_procedural_words':sum(bool(re.search('확인|정리|기록',r['positive'])) for r in rows),
                   'negative_procedural_words':sum(bool(re.search('확인|정리|기록',r['negative'])) for r in rows)})
pd.DataFrame(counts).to_csv(DEST/'anchor_wording_audit.csv',index=False)
record={'method':'Exploratory heldout paired-direction top-1 cosine; seven candidate directions. Each pair difference is normalized. Not a calibrated classifier of unpaired texts.',
        'shared_component':'Unit mean of seven unit directions. Residualization is a sensitivity diagnostic and mathematically constrains shared positive projections; not a corrected emotion estimate.',
        'original_measurements_and_axis_parameters_changed':False,
        'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'sources':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [BASE/'anchors.json',OUT/'qwen.npz',OUT/'semantic.npz',OUT/'scores.csv']}}
(DEST/'audit_manifest.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print('Audit saved:',DEST)
