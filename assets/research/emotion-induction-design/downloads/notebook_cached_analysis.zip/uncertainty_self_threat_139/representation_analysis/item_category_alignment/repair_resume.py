"""Preserve collection source; normalize checkpoint rotation keys for safe replay."""
from pathlib import Path
import hashlib,json

BASE=Path(__file__).resolve().parent
OUT=BASE/'output'

def repair():
    assert json.loads((OUT/'status.json').read_text())['state']=='complete'
    manifest=json.loads((OUT/'manifest.json').read_text())
    p=BASE/'measure.py';frozen=BASE/'collection_source_v1.py'
    if not frozen.exists():
        assert hashlib.sha256(p.read_bytes()).hexdigest()==manifest['code_sha256']
        frozen.write_bytes(p.read_bytes())
    assert hashlib.sha256(frozen.read_bytes()).hexdigest()==manifest['code_sha256']
    text=p.read_text()
    text=text.replace("saved.extend(map(tuple,a['keys'].tolist()))", "saved.extend((str(k[0]),str(k[1]),int(k[2])) for k in a['keys'].tolist())")
    text=text.replace("glob('batch_*.npz')", "glob('batch_[0-9][0-9][0-9][0-9][0-9].npz')")
    text=text.replace("'code_sha256':sha(__file__)", "'code_sha256':sha(BASE/'collection_source_v1.py')")
    p.write_text(text)
    revision={'collection_source_sha256':manifest['code_sha256'],'current_runner_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'change':'Checkpoint key handling only: restore rotation as integer; ignore incomplete .tmp.npz files. Preserve the source used for the completed collection. Model inputs, axis values, analysis and saved observations are unchanged.'}
    (OUT/'runner_revision.json').write_text(json.dumps(revision,indent=2))
    return revision

if __name__=='__main__':print(repair())
