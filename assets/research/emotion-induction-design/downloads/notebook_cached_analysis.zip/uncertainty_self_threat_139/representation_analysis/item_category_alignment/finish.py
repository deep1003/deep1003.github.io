"""Build figures, source tables, and cached-data notebook cells after collection."""
from pathlib import Path
import datetime,hashlib,html,itertools,json,shutil,sys,zipfile
import numpy as np
import pandas as pd
import nbformat
from nbclient import NotebookClient
import fitz

BASE=Path(__file__).resolve().parent
OUT=BASE/'output'


def finish():
    status=json.loads((OUT/'status.json').read_text());assert status['state']=='complete'
    import plot
    plot.build(OUT)
    shutil.copy2(BASE/'Captions_and_methods.md',OUT/'Captions_and_methods.md')
    means=pd.read_csv(OUT/'item_alignment.csv');changes=pd.read_csv(OUT/'item_changes.csv');summary=json.loads((OUT/'plot_summary.json').read_text())
    trials=pd.read_csv(OUT/'trial_alignment.csv')
    item_source=pd.read_csv(BASE.parents[2]/'threat_139_pilot/items_139.csv')
    expected=set(itertools.product(item_source.sample_id,['UN0FA0','UN1FA0','UN0FA1','UN1FA1'],range(3),[14,21,28]))
    assert set(map(tuple,trials[['item','condition','rotation','layer']].to_numpy()))==expected
    assert (trials.filter(regex='^cos_').abs()<=1.000001).all().all()
    manifest=json.loads((OUT/'manifest.json').read_text())
    assert hashlib.sha256((BASE.parents[1]/'results/a8e92be4014f/trials.csv').read_bytes()).hexdigest()==manifest['original_trials_sha256']
    for l in [14,21,28]:
        assert hashlib.sha256((BASE.parent/f'results/d335ad178e3c/axes_qwen_L{l}.npz').read_bytes()).hexdigest()==manifest['axes_sha256'][str(l)]
    primary=changes[(changes.layer==14)&(changes.condition=='UN1FA1')]
    cluster=primary.groupby(['category','cluster'],as_index=False)[['delta_cos_UN','delta_cos_FA']].mean().groupby('category',as_index=False).agg(n_templates=('cluster','size'),template_balanced_UN_shift=('delta_cos_UN','mean'),template_balanced_FA_shift=('delta_cos_FA','mean'))
    cats=pd.read_csv(OUT/'category_summary.csv')
    # Matched three-dimensional layer sensitivity, without choosing a favourable layer.
    sens=[]
    for layer in [14,21,28]:
        sub=changes[(changes.layer==layer)&(changes.condition=='UN1FA1')]
        for c,part in sub.groupby('category'):
            sens.append({'layer':layer,'category':c,'n_items':len(part),'UN_shift':part.delta_cos_UN.mean(),'FA_shift':part.delta_cos_FA.mean()})
    pd.DataFrame(sens).to_csv(OUT/'layer_category_sensitivity.csv',index=False)
    order_variation=trials.groupby(['item','condition','layer'],as_index=False).agg(UN_order_sd=('cos_UN','std'),FA_order_sd=('cos_FA','std'))
    order_variation.to_csv(OUT/'choice_order_sensitivity.csv',index=False)
    validation=json.loads((OUT/'validation.json').read_text());figure_checks={}
    for name in ['Figure_2_KoBBQ_category_alignment','Extended_Data_2_four_conditions','KoBBQ_UN_FA_change_map','KoBBQ_UN_FA_absolute_map']:
        pdf=fitz.open(OUT/f'{name}.pdf');page=pdf[0]
        spans=[s for b in page.get_text('dict')['blocks'] if 'lines' in b for line in b['lines'] for s in line['spans']]
        clipped=[s['text'] for s in spans if s['bbox'][0]<0 or s['bbox'][1]<0 or s['bbox'][2]>page.rect.width+.5 or s['bbox'][3]>page.rect.height+.5]
        fonts=page.get_fonts(full=True)
        check={'pdf_width_mm':page.rect.width/72*25.4,'minimum_font_pt':min(s['size'] for s in spans),'maximum_font_pt':max(s['size'] for s in spans),'out_of_page_text':clipped,'fonts':[[f[2],f[3]] for f in fonts],'svg_text_nodes':(OUT/f'{name}.svg').read_text().count('<text')}
        figure_checks[name]=check
        page.get_pixmap(matrix=fitz.Matrix(1.8,1.8)).save(OUT/f'{name}_pdf_check.png')
        assert not clipped, (name,clipped)
        assert all(f[2]!='Type3' for f in fonts)
    validation['artwork']=figure_checks
    (OUT/'validation.json').write_text(json.dumps(validation,indent=2))
    top=cats.iloc[0];bottom=cats.iloc[-1]
    report='''# KoBBQ 문항별 UN·FA 내부 정렬과 카테고리 분포

기존 선별 139문항, 4개 고정 공지, 3개 선택지 순서를 그대로 사용했다. 추가로 7B의 응답 시작 은닉 상태를 측정했으며 답변 생성과 원래 행동 결과 파일의 변경은 하지 않았다. 주 분석은 14층, 21·28층은 민감도 점검용이다.

본문 그림 a는 UN+FA 공지 아래의 절대 정렬, b는 같은 문항의 중립 대비 변화다. 각 패널에 139문항을 모두 표시하고, 12개 카테고리를 색과 모양으로 구분했다. 큰 외곽선 마커는 선택된 문항들의 카테고리 평균이며 별도의 독립 관측값이 아니다.

'''
    report+=f"이 선별 표본에서 FA 코사인 변화의 카테고리 평균은 {top.category}가 가장 높고 {bottom.category}가 가장 낮았다. UN 변화의 최대·최소는 별도 열에서 읽는다. 두 값을 하나의 감정 강도로 합산하지 않는다. 이는 사후 기술 순위이며 카테고리 모집단의 순위가 아니다.\n\n"
    report+=cats.to_string(index=False)+'\n\n'
    report+='UN과 FA 축 자체의 코사인 유사도는 '+str(summary['UN_FA_axis_cosine'])+'이다. 따라서 좌표 간 양의 상관 일부는 축의 겹침을 반영할 수 있다. 카테고리는 명목형 변수이므로 숫자 코드를 부여해 Pearson 상관을 계산하지 않았다. 그림의 Spearman 계수는 두 연속 정렬 좌표 사이의 기술적 관계다.\n\n'
    report+='개념 정렬 변화와 기존 정보 부족 응답 확률 변화의 관계도 별도 CSV에 기술했다. 91개 공유 문항 틀을 무시한 독립 문항 유의성 검정은 하지 않았다.\n\n'
    report+=pd.DataFrame(summary['representation_behavior_associations']).to_string(index=False)+'\n\n'
    report+='선택된 모호 문항의 재사용, 카테고리별 불균형 표본, 한 개 고정 문구 조합, 축의 겹침, 시스템 공지 기준에서 KoBBQ 입력으로의 검증되지 않은 전이 때문에 일반화와 정서적 해석에 제한이 있다. 특히 높은 정렬은 기능적 정서가 편향을 유발했다는 인과 증거가 아니다. 모든 측정과 그림은 탐색적이다.\n'
    (OUT/'report_ko.md').write_text(report)
    root=BASE.parents[2]
    notebook=root/'uncertainty_self_threat_139.ipynb'
    assert notebook.exists(),notebook
    n=nbformat.read(notebook,as_version=4)
    heading='## 26. KoBBQ 문항별 UN·FA 공간과 카테고리'
    if not any(c.cell_type=='markdown' and heading in c.source for c in n.cells):
        backup=BASE.parent.parent/'recovery_backups'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S_category_map');backup.mkdir(parents=True);shutil.copy2(notebook,backup/notebook.name)
        cells=[nbformat.v4.new_markdown_cell('''## 26. KoBBQ 문항별 UN·FA 공간과 카테고리

기존 선별 139문항을 네 고정 공지와 결합한 입력의 응답 시작 위치에서 내부 상태를 측정했다. 문항 수와 프롬프트는 유지했으며 선택지 순서 3개를 평균하여 문항마다 점 하나를 만든다. 주 분석은 14층, 21·28층은 민감도 점검이다. 그림은 영문 논문용이다.

본문 a는 UN+FA 조건의 절대 코사인 정렬, b는 같은 문항의 중립 대비 코사인 변화다. **높은 절대 정렬과 높은 문맥 민감도는 다르다.** 139개 점을 모두 표시하며 12개 카테고리를 색과 모양으로 구분한다. 큰 외곽선 마커는 카테고리 평균이다. 차원 축소나 좌표 흔들기는 사용하지 않는다.

다음 코드는 저장된 문항별 측정만 읽어 PDF·SVG·PNG를 생성한다. 모델을 불러오거나 행동 실험을 실행하지 않는다.'''),
        nbformat.v4.new_code_cell('''from pathlib import Path
import importlib.util
from IPython.display import Image, Markdown, display

category_module = Path("uncertainty_self_threat_139/representation_analysis/item_category_alignment").resolve()
if not category_module.exists():
    category_module = Path("/Users/deep1003/data3/fear_axis_pilot/output/jupyter-notebook/uncertainty_self_threat_139/representation_analysis/item_category_alignment")
spec = importlib.util.spec_from_file_location("category_alignment_plot", category_module / "plot.py")
category_plotter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(category_plotter)
category_output = category_plotter.build()
display(Image(filename=str(category_output / "Figure_2_KoBBQ_category_alignment_preview.png")))
'''),nbformat.v4.new_markdown_cell('''## 27. 네 실험 조건과 단일 문항 변화 지도

네 조건은 같은 문항들을 반복 측정한 것이므로 독립 표본으로 합치지 않는다. 네 패널의 범위는 동일하다. 별도의 단일 지도는 중립 대비 문항별 이동만 보여준다.

UN과 FA 방향은 서로 직교하지 않는다. 두 연속 좌표의 Spearman 상관은 축의 겹침과 문맥의 공통 영향을 포함한다. 카테고리는 명목형 변수이므로 카테고리 번호와 활성값의 숫자 상관을 계산하지 않는다. 다음 셀은 저장된 조건 비교와 변화 지도를 표시한다.'''),
        nbformat.v4.new_code_cell('''display(Image(filename=str(category_output / "Extended_Data_2_four_conditions_preview.png")))
display(Image(filename=str(category_output / "KoBBQ_UN_FA_change_map_preview.png")))
'''),nbformat.v4.new_markdown_cell('''## 28. 카테고리별 수치와 해석 범위

카테고리 표는 선택된 문항의 평균과 문항 틀별 동일 가중 평균을 함께 제공한다. 카테고리당 표본이 4~21개로 다르므로 평균의 순위를 모집단의 감정 민감도 순위로 일반화하지 않는다. 139문항은 91개 카테고리·문항 틀을 공유한다. 독립 문항 유의성 검정이나 인과적 정서 해석은 하지 않는다.

개념 축은 기존 시스템 공지만 있는 문맥에서 만든 것이므로 KoBBQ가 추가된 입력으로의 전이는 탐색적이다. 기존 행동 결과와의 관계, 원자료 해시, 배치·단일 입력 비교와 모든 문항의 보존 검증을 별도 파일에 기록했다. 다음 셀은 완성된 수치와 영문 캡션을 읽는다.'''),
        nbformat.v4.new_code_cell('''import pandas as pd
import json
display(pd.read_csv(category_output / "category_summary.csv"))
display(pd.read_csv(category_output / "representation_behavior_associations.csv"))
display(Markdown((category_output / "Captions_and_methods.md").read_text()))
''')]
        sub=nbformat.v4.new_notebook(cells=cells);sub.metadata.kernelspec={'display_name':'Python 3 (ipykernel)','language':'python','name':'python3'}
        NotebookClient(sub,timeout=120,kernel_name='python3',resources={'metadata':{'path':str(root)}}).execute()
        last=max(c.execution_count or 0 for c in n.cells if c.cell_type=='code')
        for c in sub.cells:
            if c.cell_type=='code':last+=1;c.execution_count=last;c.metadata.trusted=True
        n.cells.extend(sub.cells);n.metadata.kernelspec=sub.metadata.kernelspec;nbformat.validate(n);nbformat.write(n,notebook)
        from nbformat.sign import NotebookNotary
        NotebookNotary().sign(n)
    files=[BASE/'measure.py',BASE/'collection_source_v1.py',BASE/'plot.py',BASE/'Captions_and_methods.md']
    provenance={'code_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files},'outputs_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in OUT.glob('*.csv')},'figure_width_mm':180,'point_unit':'unique selected KoBBQ item; three choice rotations averaged','primary_layer':14,'axes_refit':False}
    (OUT/'artwork_provenance.json').write_text(json.dumps(provenance,indent=2))
    with zipfile.ZipFile(BASE/'publication_figures.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in OUT.iterdir():
            if f.is_file() and f.suffix in ['.pdf','.svg','.png','.csv','.md','.json'] and not f.name.endswith('_pdf_check.png'):z.write(f,Path('figures')/f.name)
        for f in files:z.write(f,Path('code')/f.name)
    print('Finished figures and notebook',notebook,flush=True)
    print(cats[['category','n_items','UN_shift','FA_shift']].to_string(index=False),flush=True)
    return OUT

if __name__=='__main__':print(finish())
