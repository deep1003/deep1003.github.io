"""Frozen measurement primitives copied without edits from the completed pilot."""
from pathlib import Path
import hashlib,json,os,ast
import numpy as np
import pandas as pd
MODEL="Qwen/Qwen2.5-7B-Instruct"
REVISION="a09a35458c702b33eeacc393d103063234e8bc28"
SEED=20261018
LAYER=14
DIM=3584
CONDITIONS=["U0T0","U0T1","U1T0","U1T1","C1T0","C1T1","C1T0P1","C1T1P1"]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def text_sha(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()

def json_read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def write_json(path: Path, value) -> None:
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(temp, path)

def write_csv(path: Path, frame: pd.DataFrame) -> None:
    temp = path.with_name(path.name + ".tmp")
    frame.to_csv(temp, index=False)
    os.replace(temp, path)

def save_npy(path: Path, array: np.ndarray) -> None:
    temp = path.with_name(path.name + ".tmp")
    with temp.open("wb") as stream:
        np.save(stream, array, allow_pickle=False)
    os.replace(temp, path)

class Engine:
    """One lazily loaded model, batch one, no generated responses or warmup runs."""
    def __init__(self, out: Path):
        self.out = out
        self.model = None

    def load(self):
        if self.model is not None:
            return
        import torch
        import transformers
        from transformers import AutoModelForCausalLM, AutoTokenizer
        import transformers.modeling_utils as modeling_utils
        assert torch.backends.mps.is_available(), "MPS required for the frozen runtime"
        torch.manual_seed(SEED)
        self.torch = torch
        self.tok = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, local_files_only=True, use_fast=True)
        warmup = modeling_utils.caching_allocator_warmup
        modeling_utils.caching_allocator_warmup = lambda *args, **kwargs: None
        try:
            self.model = AutoModelForCausalLM.from_pretrained(
                MODEL, revision=REVISION, dtype=torch.float32, attn_implementation="eager",
                local_files_only=True, device_map={"": "mps"}, low_cpu_mem_usage=True).eval()
        finally:
            modeling_utils.caching_allocator_warmup = warmup
        assert self.model.config.hidden_size == DIM
        assert getattr(self.model.config, "_commit_hash", None) == REVISION
        assert next(self.model.parameters()).dtype == torch.float32
        choice_ids = [self.tok.encode(str(i), add_special_tokens=False) for i in [1, 2, 3]]
        assert all(len(v) == 1 for v in choice_ids)
        self.choice_ids = [v[0] for v in choice_ids]
        runtime = {"model": MODEL, "revision": REVISION, "device": "mps", "dtype": "float32",
                   "attention": "eager", "batch": 1, "torch": torch.__version__,
                   "transformers": transformers.__version__, "choice_token_ids": self.choice_ids,
                   "allocator_warmup_skipped": True, "model_generation": False}
        path = self.out / "runtime.json"
        if path.exists():
            assert json_read(path) == runtime
        else:
            write_json(path, runtime)

    def forward(self, messages: list[dict], all_positions=False):
        self.load()
        torch = self.torch
        rendered = self.tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        encoded = self.tok(rendered, return_tensors="pt", return_offsets_mapping=all_positions)
        offsets = encoded.pop("offset_mapping")[0].tolist() if all_positions else None
        token_ids = encoded["input_ids"][0].tolist()
        encoded = encoded.to("mps")
        with torch.inference_mode():
            result = self.model(**encoded, output_hidden_states=True, use_cache=False, logits_to_keep=1)
            h = result.hidden_states[LAYER][0]
            hidden = h.float().cpu().numpy().copy() if all_positions else h[-1].float().cpu().numpy().copy()
            logits = result.logits[0, -1].float()
            assert torch.isfinite(logits).all()
            selected = logits[self.choice_ids]
            probabilities = torch.softmax(selected, 0).cpu().numpy().astype(float)
            raw = selected.cpu().numpy().astype(float)
            lse = float(torch.logsumexp(logits, 0).cpu())
            mass = float(torch.exp(torch.logsumexp(selected, 0) - torch.logsumexp(logits, 0)).cpu())
        del result, logits, selected, encoded, h
        assert np.isfinite(hidden).all()
        return {"hidden": hidden, "probabilities": probabilities, "logits": raw,
                "full_logsumexp": lse, "choice_mass": mass, "rendered_sha256": text_sha(rendered),
                "rendered": rendered, "token_ids": token_ids, "offsets": offsets}

    def close(self):
        if self.model is not None:
            del self.model
            self.model = None
            self.torch.mps.empty_cache()

def messages(row, system: str, notice: str, rotation: int):
    choices = ast.literal_eval(row["choices"])
    choices = choices[rotation:] + choices[:rotation]
    body = "\n".join(["다음 질문에 답하세요. 반드시 선택지 번호 하나만 숫자로 답하세요.", "",
                      row["context"], row["question"]] + [f"{i + 1}: {choice}" for i, choice in enumerate(choices)])
    return [{"role": "system", "content": system + "\n\n" + notice}, {"role": "user", "content": body}], choices

def align(hidden, directions, centers):
    delta = np.asarray(hidden, dtype=np.float64)[None, :] - centers
    denominator = np.linalg.norm(delta, axis=1)
    assert (denominator > 0).all()
    return np.einsum("ij,ij->i", delta, directions) / denominator

def measure_system_tokens(out: Path, stimuli: dict, engine: Engine, names, directions, centers):
    directory = out / "system_tokens_L14"
    directory.mkdir(exist_ok=True)
    notices = {**stimuli["original_four"], **stimuli["new_Certainty_two"]}
    metadata = []
    scores, assistant_scores = [], []
    for condition in CONDITIONS:
        hpath = directory / f"{condition}.npy"
        mpath = directory / f"{condition}.json"
        if not (hpath.exists() and mpath.exists()):
            content = stimuli["system"] + "\n\n" + notices[condition]
            result = engine.forward([{"role": "system", "content": content}], all_positions=True)
            save_npy(hpath, result["hidden"])
            start = result["rendered"].index(content)
            notice_start = start + len(stimuli["system"]) + 2
            spans = []
            cursor = 0
            for sentence in notices[condition].split(". "):
                if not sentence:
                    continue
                segment = sentence if sentence.endswith(".") else sentence + "."
                begin = notices[condition].find(segment, cursor)
                if begin >= 0:
                    spans.append({"start": notice_start + begin, "end": notice_start + begin + len(segment), "text": segment})
                    cursor = begin + len(segment)
            record = {"condition": condition, "rendered": result["rendered"],
                      "rendered_sha256": result["rendered_sha256"], "token_ids": result["token_ids"],
                      "offsets": result["offsets"], "system_content_span": [start, start + len(content)],
                      "notice_span": [notice_start, notice_start + len(notices[condition])],
                      "notice_sentence_spans": spans, "hidden_file": str(hpath.relative_to(out)), "hidden_sha256": sha(hpath)}
            write_json(mpath, record)
            del result
        record = json_read(mpath)
        assert sha(hpath) == record["hidden_sha256"]
        hidden = np.load(hpath, allow_pickle=False)
        assert hidden.shape == (len(record["token_ids"]), DIM)
        metadata.append(record)
        for axis, value in zip(names, align(hidden[-1], directions, centers)):
            assistant_scores.append({"condition": condition, "axis": axis, "cosine": float(value),
                                     "position": "assistant_start_after_system_only"})
        for i, vector in enumerate(hidden):
            begin, end = record["offsets"][i]
            values = align(vector, directions, centers)
            for axis, value in zip(names, values):
                scores.append({"condition": condition, "token_index": i, "token_id": record["token_ids"][i],
                               "char_start": begin, "char_end": end,
                               "token_text": record["rendered"][begin:end], "axis": axis, "cosine": float(value)})
    write_json(out / "system_token_metadata.json", metadata)
    write_csv(out / "system_token_alignment.csv", pd.DataFrame(scores))
    assistant_scores = pd.DataFrame(assistant_scores)
    reference = assistant_scores[assistant_scores.condition == "U0T0"][["axis", "cosine"]].rename(columns={"cosine": "baseline_cosine"})
    assistant_scores = assistant_scores.merge(reference, on="axis", validate="many_to_one")
    assistant_scores["delta_vs_U0T0"] = assistant_scores.cosine - assistant_scores.baseline_cosine
    write_csv(out / "system_only_assistant_alignment.csv", assistant_scores)
