"""Portable handover driver. Default: validate saved inputs, no model inference.

Only --execute can load model weights. No downloads, quantization or automatic
larger sample. All results go into this copy's new results/ directory.
"""
from pathlib import Path
import argparse
import ast
import fcntl
import importlib.metadata
import itertools
import json
import os
import platform
import subprocess
import time

import numpy as np
import pandas as pd
import measurement as m

BASE=Path(__file__).resolve().parent
OUT=BASE/'results'
KEYS=['item','condition','rotation']
PROBS=['p_unknown','p_stereotype','p_anti']


def read(name):return m.json_read(BASE/name)


def verify():
    checks=read('CHECKSUMS.json')
    for name,digest in checks.items():assert m.sha(BASE/name)==digest,f'Changed handover input: {name}'
    config=read('inputs/protocol.json');items=pd.read_csv(BASE/'inputs/items_139.csv')
    prompts=read('inputs/prompts_8.json')
    assert len(items)==items.sample_id.nunique()==139 and items.cluster.nunique()==91
    assert [p['condition'] for p in prompts['conditions']]==m.CONDITIONS
    for p in prompts['conditions']:
        assert p['system_content']==prompts['common_system']+'\n\n'+p['notice']
        assert m.text_sha(p['system_content'])==p['system_sha256']
    with np.load(BASE/'inputs/axes_L14.npz',allow_pickle=False) as a:
        assert a['directions'].shape==a['centers'].shape==(11,3584)
        assert np.allclose(np.linalg.norm(a['directions'],axis=1),1)
    original=pd.read_csv(BASE/'cache/original/trials.csv')
    cn=pd.read_csv(BASE/'cache/cn12/trials.csv')
    assert len(original)==1668 and len(cn)==72
    for frame in [original,cn]:
        assert not frame.duplicated(KEYS).any() and set(frame.item)<=set(items.sample_id)
        assert np.isfinite(frame[PROBS]).all().all() and np.allclose(frame[PROBS].sum(axis=1),1,atol=1e-6)
    assert set(map(tuple,original[KEYS].to_numpy()))==set(itertools.product(items.sample_id,m.CONDITIONS[:4],range(3)))
    with np.load(BASE/'cache/original/hidden_L14.npz',allow_pickle=False) as a:
        assert a['hidden'].shape==(1668,3584) and np.isfinite(a['hidden']).all()
        assert {(str(k[0]),str(k[1]),int(k[2])) for k in a['keys']}==keyset(original)
    validate_new(cn,items)
    assert len(set(map(tuple,cn[KEYS].to_numpy())))==72
    for r in cn.itertuples():assert m.sha(BASE/'cache/cn12'/r.hidden_file)==r.hidden_sha256
    # Machine-independent input checks also run without torch installed.
    return config,items,prompts,original,cn


def runtime_gate(config):
    assert platform.system()=='Darwin' and platform.machine()=='arm64','Reference profile requires Apple Silicon macOS'
    ram=int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True))
    assert ram>=31_000_000_000,'Reference FP32 Qwen7B needs a larger unified-memory budget; no automatic lower precision/model fallback'
    assert importlib.metadata.version('torch')==config['torch_version']
    assert importlib.metadata.version('transformers')==config['transformers_version']
    metadata=importlib.metadata.distribution('transformers').read_text('direct_url.json')
    assert metadata and json.loads(metadata)['vcs_info']['commit_id']==config['transformers_commit'],'Pin the recorded transformers git commit'
    import torch
    assert torch.backends.mps.is_available()
    return dict(system=platform.system(),machine=platform.machine(),memory_bytes=ram,
                torch=torch.__version__,transformers=importlib.metadata.version('transformers'),
                reference_precision_unchanged=True,weights_downloaded_automatically=False)


def validate_new(frame,items):
    assert not frame.duplicated(KEYS).any()
    lookup=items.set_index('sample_id')
    for r in frame.itertuples():
        assert r.condition in m.CONDITIONS[4:]
        item=lookup.loc[r.item];choices=ast.literal_eval(item.choices)
        choices=choices[int(r.rotation):]+choices[:int(r.rotation)]
        anti=next(c for c in choices if c not in ['알 수 없음',item.biased_answer])
        assert json.loads(r.choices)==choices
        assert int(r.unknown_position)==choices.index('알 수 없음')+1
        assert int(r.stereotype_position)==choices.index(item.biased_answer)+1
        assert int(r.anti_position)==choices.index(anti)+1
    raw=frame[['logit_1','logit_2','logit_3']].to_numpy(float)
    assert np.isfinite(raw).all()
    maxima=raw.max(axis=1);denom=maxima+np.log(np.exp(raw-maxima[:,None]).sum(axis=1))
    p=np.exp(raw-denom[:,None])
    rebuilt=np.array([[p[i,int(r.unknown_position)-1],p[i,int(r.stereotype_position)-1],p[i,int(r.anti_position)-1]] for i,r in enumerate(frame.itertuples())])
    assert np.allclose(rebuilt,frame[PROBS],atol=3e-7)
    assert np.isfinite(frame.full_logsumexp).all() and frame.choice_mass.between(0,1.00001).all()
    assert np.allclose(np.exp(denom-frame.full_logsumexp.to_numpy()),frame.choice_mass,atol=2e-5)


def status(state,**values):
    record=dict(state=state,pid=os.getpid(),timestamp=time.time(),**values)
    m.write_json(OUT/'status.json',record);print(json.dumps(record,ensure_ascii=False),flush=True)


def keyset(frame):return {(r.item,r.condition,int(r.rotation)) for r in frame.itertuples()}


def execute():
    config,items,prompts,original,cn=verify();hardware=runtime_gate(config)
    OUT.mkdir(exist_ok=True)
    with (OUT/'writer.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        engine=m.Engine(OUT)
        try:
            m.write_json(OUT/'hardware.json',hardware)
            notices={p['condition']:p['notice'] for p in prompts['conditions']}
            engine.load()
            assert engine.choice_ids==[16,17,18]
            lookup=items.set_index('sample_id')
            for r in cn.itertuples():
                msg,_=m.messages(lookup.loc[r.item],prompts['common_system'],notices[r.condition],int(r.rotation))
                rendered=engine.tok.apply_chat_template(msg,tokenize=False,add_generation_prompt=True)
                assert m.text_sha(rendered)==r.prompt_sha256,'Cached CN prompt/tokenizer rendering changed'
            rows=pd.read_csv(OUT/'new_trials.csv').to_dict('records') if (OUT/'new_trials.csv').exists() else []
            if rows:validate_new(pd.DataFrame(rows),items)
            cached=keyset(original)|keyset(cn)
            expected=set(itertools.product(items.sample_id,m.CONDITIONS,range(3)))
            missing=expected-cached
            assert len(missing)==1596
            done={(r['item'],r['condition'],int(r['rotation'])) for r in rows}
            assert done<=missing
            for r in rows:assert m.sha(OUT/r['hidden_file'])==r['hidden_sha256']
            rng=np.random.default_rng(config['seed']);lookup=items.set_index('sample_id')
            plan=[]
            for item in np.array(items.sample_id)[rng.permutation(len(items))]:
                candidates=sorted(k for k in missing if k[0]==item)
                plan.extend(candidates[i] for i in rng.permutation(len(candidates)))
            plan_record={'keys':[list(k) for k in plan],'seed':config['seed'],'outcome_independent':True}
            if (OUT/'plan.json').exists():assert m.json_read(OUT/'plan.json')==plan_record
            else:m.write_json(OUT/'plan.json',plan_record)
            states=OUT/'hidden_L14';states.mkdir(exist_ok=True)
            for key in plan:
                if key in done:continue
                item,condition,rotation=key;row=lookup.loc[item]
                msg,choices=m.messages(row,prompts['common_system'],notices[condition],rotation)
                status('measuring',completed_new=len(rows),total_new=1596,item=item,condition=condition,rotation=rotation)
                result=engine.forward(msg)
                hpath=states/(m.text_sha('|'.join(map(str,key)))[:24]+'.npy');m.save_npy(hpath,result['hidden'])
                anti=next(c for c in choices if c not in ['알 수 없음',row.biased_answer])
                p=dict(zip(choices,map(float,result['probabilities'])))
                record=dict(item=item,condition=condition,rotation=rotation,p_unknown=p['알 수 없음'],p_stereotype=p[row.biased_answer],
                    p_anti=p[anti],choice_mass=result['choice_mass'],full_logsumexp=result['full_logsumexp'],
                    logit_1=float(result['logits'][0]),logit_2=float(result['logits'][1]),logit_3=float(result['logits'][2]),
                    unknown_position=choices.index('알 수 없음')+1,stereotype_position=choices.index(row.biased_answer)+1,
                    anti_position=choices.index(anti)+1,choices=json.dumps(choices,ensure_ascii=False),
                    prompt_sha256=result['rendered_sha256'],hidden_file=str(hpath.relative_to(OUT)),hidden_sha256=m.sha(hpath),n_tokens=len(result['token_ids']))
                validate_new(pd.DataFrame([record]),items);rows.append(record);done.add(key)
                m.write_csv(OUT/'new_trials.csv',pd.DataFrame(rows));del result
            assert done==missing
            # Reuse six recorded system-only traces; infer only the two appraisal traces.
            import shutil
            token_dir=OUT/'system_tokens_L14';token_dir.mkdir(exist_ok=True)
            for p in (BASE/'cache/system_tokens_L14').iterdir():
                target=token_dir/p.name
                if not target.exists():shutil.copy2(p,target)
            with np.load(BASE/'inputs/axes_L14.npz',allow_pickle=False) as a:
                directions=a['directions'];centers=a['centers'];names=a['names']
            extended={'system':prompts['common_system'],'original_four':{k:notices[k] for k in m.CONDITIONS[:4]},
                      'new_Certainty_two':{k:notices[k] for k in m.CONDITIONS[4:]}}
            m.measure_system_tokens(OUT,extended,engine,names,directions,centers)
            engine.close();status('analyzing_saved_data',completed_new=1596,total_behavior_keys=3336)
            analyze(config,items,original,cn,pd.DataFrame(rows))
            verify()
            status('complete',items=139,clusters=91,conditions=8,total_behavior_keys=3336,
                   reused_behavior_keys=1740,new_behavior_keys=1596,new_system_only_inputs=2)
        except BaseException as exc:
            status('error',exception=type(exc).__name__,message=str(exc));raise
        finally:engine.close()


def contrasts(t):
    return {
      'CN_vs_Reference_preserved':t.C1T0-t.U0T0,
      'CN_Appraisal_vs_Reference_preserved':t.C1T0P1-t.U0T0,
      'Appraisal_increment_preserved':t.C1T0P1-t.C1T0,
      'CN_vs_Reference_deleted':t.C1T1-t.U0T1,
      'Appraisal_increment_deleted':t.C1T1P1-t.C1T1,
      'CN_vs_UN_average':((t.C1T0-t.U1T0)+(t.C1T1-t.U1T1))/2,
      'UN_vs_Reference_average':((t.U1T0-t.U0T0)+(t.U1T1-t.U0T1))/2,
      'Threat_Reference':t.U0T1-t.U0T0,'Threat_Uncertainty':t.U1T1-t.U1T0,
      'Threat_Certainty':t.C1T1-t.C1T0,'Threat_Certainty_Appraisal':t.C1T1P1-t.C1T0P1,
      'UN_Threat_interaction':(t.U1T1-t.U1T0)-(t.U0T1-t.U0T0),
      'CN_vs_UN_Threat_interaction':(t.C1T1-t.C1T0)-(t.U1T1-t.U1T0),
      'CN_Threat_combined':t.C1T1-t.U0T0,
    }


def summarize(table,items):
    groups=pd.Categorical(items.cluster).codes;n=int(groups.max())+1
    weights=np.random.default_rng(20261018).multinomial(n,np.ones(n)/n,size=10000)[:,groups].astype(float)
    weights/=weights.sum(axis=1,keepdims=True)
    def interval(values):
        values=np.asarray(values,float);point=float(values.mean());draws=weights@values
        lo,hi=np.quantile(draws,[.025,.975])
        return dict(estimate=point,ci_low=float(lo),ci_high=float(hi))
    means=[dict(condition=c,**interval(table[c])) for c in m.CONDITIONS]
    differences=[dict(term=term,**interval(values)) for term,values in contrasts(table).items()]
    return means,differences


def analyze(config,items,original,cn,new):
    validate_new(new,items);assert len(new)==1596
    behavior=pd.concat([original,cn[original.columns],new[original.columns]],ignore_index=True)
    assert len(behavior)==3336 and not behavior.duplicated(KEYS).any()
    assert behavior.groupby(['item','condition']).size().eq(3).all()
    m.write_csv(OUT/'behavior_8_conditions.csv',behavior)
    splits=pd.read_csv(BASE/'inputs/analysis_splits.csv').set_index('item')
    summaries=[]
    for population,subset in [('all139',items),('new_items127',items[~items.sample_id.isin(cn.item)]),
                               ('nonoverlap119',items[items.sample_id.map(splits.validation_nonoverlap_cluster)])]:
        subset=subset.reset_index(drop=True)
        for metric in PROBS:
            table=behavior.groupby(['item','condition'])[metric].mean().unstack().reindex(subset.sample_id)
            means,differences=summarize(table,subset)
            summaries.append(dict(population=population,items=len(subset),clusters=int(subset.cluster.nunique()),metric=metric,
                                  condition_means=means,contrasts=differences))
    with np.load(BASE/'cache/original/hidden_L14.npz',allow_pickle=False) as a:
        hidden={(str(k[0]),str(k[1]),int(k[2])):h.copy() for k,h in zip(a['keys'],a['hidden'])}
    for folder,frame in [(BASE/'cache/cn12',cn),(OUT,new)]:
        for r in frame.itertuples():
            assert m.sha(folder/r.hidden_file)==r.hidden_sha256
            hidden[(r.item,r.condition,int(r.rotation))]=np.load(folder/r.hidden_file,allow_pickle=False)
    assert len(hidden)==3336
    with np.load(BASE/'inputs/axes_L14.npz',allow_pickle=False) as a:
        names=a['names'];directions=a['directions'];centers=a['centers']
    rows=[]
    for key,h in hidden.items():
        for axis,value in zip(names,m.align(h,directions,centers)):
            rows.append(dict(item=key[0],condition=key[1],rotation=key[2],axis=str(axis),cosine=float(value)))
    alignment=pd.DataFrame(rows);assert len(alignment)==36696
    m.write_csv(OUT/'alignment_8_conditions.csv',alignment)
    axis_summaries=[]
    for axis in names:
        table=alignment[alignment.axis==axis].groupby(['item','condition']).cosine.mean().unstack().reindex(items.sample_id)
        means,differences=summarize(table,items)
        axis_summaries.append(dict(axis=str(axis),condition_means=means,contrasts=differences))
    # p values are deliberately not produced automatically: the handover calls
    # for freezing the new three-test family before inferential testing.
    m.write_json(OUT/'summary.json',dict(state='complete',behavior=summaries,alignment=axis_summaries,
        method='10000 paired template-cluster percentile intervals; rotations averaged per item first',
        pointwise_95_percent=True,p_values_automatically_computed=False,
        old_behavior_rerun=False,old_results_overwritten=False,actual_emotion_or_mediation_claim=False))
    m.write_json(OUT/'validation.json',dict(total_keys=3336,duplicates=0,items=139,clusters=91,
        new_keys=1596,cached_keys=1740,alignment_rows=36696,protected_inputs_verified=True,
        new_raw_logits_probability_and_mass_reconstructed=True,NPY_hashes_verified=True,
        old_hidden_batch=4,new_hidden_batch=1,documented_probability_parity_max=0.0001723766326904297))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--analyze-only',action='store_true')
    args=parser.parse_args()
    if args.execute:
        assert not args.analyze_only;execute()
    elif args.analyze_only:
        c,i,_,o,p=verify();analyze(c,i,o,p,pd.read_csv(OUT/'new_trials.csv'))
    else:
        config,items,*_=verify()
        print(json.dumps(dict(state='verified_no_model_inference',items=len(items),clusters=int(items.cluster.nunique()),
             conditions=8,target=3336,cached=1740,new_required=1596,new_system_only=2),ensure_ascii=False,indent=2))


if __name__=='__main__':main()
